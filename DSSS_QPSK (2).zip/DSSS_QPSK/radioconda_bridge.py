#!/usr/bin/env python3
r"""
radioconda_bridge.py -- let Claude run commands inside YOUR radioconda
environment, with your USRP attached.

WHY THIS EXISTS
    Claude runs in a cloud sandbox.  It can read and write files in this folder,
    but it has no shell on your Windows machine and no access to your USB.  So
    it cannot run uhd_find_devices, it cannot touch the B206mini-i, and it
    cannot see what UHD actually prints when things go wrong.

    This script closes that gap.  You start it ONCE, inside the radioconda
    prompt, and leave it running.  It watches the `bridge\` subfolder for
    command files, runs them in this environment (so UHD, GNU Radio and the
    radio are all right there), and writes the full stdout/stderr back to a file
    Claude can read.  Claude gets a real, text-complete shell into radioconda.

HOW TO START IT
    1. Open the "GNU Radio Command Prompt" / "radioconda prompt" from the Start
       menu  (or open any terminal and run:  conda activate radioconda).
    2. cd to this folder:
           cd C:\Users\garre\OneDrive\Desktop\DSSS_QPSK
    3. python radioconda_bridge.py

    Leave that window open.  Everything it runs is echoed there, so you can see
    exactly what is happening.  Ctrl-C stops it, and so does creating a file
    called  bridge\STOP.

WHAT IT RUNS
    Only what appears in bridge\cmd_*.txt -- which only you and Claude can write.
    Every command is printed to your console before it runs.  If you ever want
    it to stop, Ctrl-C the window; nothing survives it.

SAFETY VALVES
    --dry-run        print commands but do not execute them
    --confirm        ask you [y/N] before each command
    --timeout N      default per-command timeout in seconds (default 180)

FILE PROTOCOL  (all inside bridge\)
    cmd_<id>.txt     a command to run.  Optional header lines first:
                         # timeout: 300
                         # cwd: subdir
                     everything after the header is the command body, run as a
                     batch file, so multiple lines work.
    out_<id>.txt     stdout+stderr, written LIVE as the command runs
    done_<id>.json   {"id","exit_code","seconds","timed_out"} -- written last,
                     so its existence means "finished"
    status.json      heartbeat + environment report, refreshed every few seconds
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
BRIDGE = HERE / "bridge"
POLL_S = 0.4
HEARTBEAT_S = 3.0


# ----------------------------------------------------------------- environment
def probe_environment() -> dict:
    """One-shot report of everything Claude needs to know about this machine."""
    info = {
        "python": sys.version.split()[0],
        "python_exe": sys.executable,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cwd": str(HERE),
        "conda_env": os.environ.get("CONDA_DEFAULT_ENV", "(none)"),
        "conda_prefix": os.environ.get("CONDA_PREFIX", "(none)"),
    }

    def grab(cmd, timeout=25):
        try:
            r = subprocess.run(cmd, shell=True, capture_output=True, text=True,
                               encoding="utf-8", errors="replace", timeout=timeout)
            return ((r.stdout or "") + (r.stderr or "")).strip()[:4000]
        except Exception as e:
            return f"<<failed: {e!r}>>"

    for key, exe in (("uhd_find_devices", "uhd_find_devices"),
                     ("uhd_config_info", "uhd_config_info --version --images-dir")):
        info[key] = grab(exe) if shutil.which(exe.split()[0]) else "<<not on PATH>>"

    try:
        import numpy
        info["numpy"] = numpy.__version__
    except Exception as e:
        info["numpy"] = f"<<{e!r}>>"
    try:
        import scipy
        info["scipy"] = scipy.__version__
    except Exception as e:
        info["scipy"] = f"<<{e!r}>>"
    try:
        from gnuradio import gr
        info["gnuradio"] = gr.version()
    except Exception as e:
        info["gnuradio"] = f"<<{e!r}>>"
    try:
        from gnuradio import uhd  # noqa: F401
        info["gr_uhd"] = "importable"
    except Exception as e:
        info["gr_uhd"] = f"<<{e!r}>>"
    try:
        import uhd as pyuhd
        info["pyuhd"] = getattr(pyuhd, "__version__", "importable")
    except Exception as e:
        info["pyuhd"] = f"<<{e!r}>>"
    return info


def write_status(state: str, last_id=None, extra=None):
    payload = {
        "state": state,
        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
        "epoch": time.time(),
        "last_command": last_id,
        "pid": os.getpid(),
    }
    if extra:
        payload.update(extra)
    tmp = BRIDGE / "status.json.tmp"
    tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    tmp.replace(BRIDGE / "status.json")


# --------------------------------------------------------------- command files
def parse_command(text: str):
    """Split optional '# key: value' header lines from the command body."""
    opts, body = {}, []
    in_header = True
    for line in text.splitlines():
        if in_header and line.strip().startswith("#") and ":" in line:
            k, _, v = line.lstrip("# ").partition(":")
            opts[k.strip().lower()] = v.strip()
            continue
        in_header = False
        body.append(line)
    return opts, "\n".join(body).strip()


def run_command(cmd_id: str, body: str, opts: dict, default_timeout: float,
                dry_run: bool):
    out_path = BRIDGE / f"out_{cmd_id}.txt"
    done_path = BRIDGE / f"done_{cmd_id}.json"
    timeout = float(opts.get("timeout", default_timeout))
    cwd = HERE / opts.get("cwd", ".")

    if dry_run:
        out_path.write_text(f"<<dry run -- not executed>>\n{body}\n", encoding="utf-8")
        done_path.write_text(json.dumps({"id": cmd_id, "exit_code": None,
                                         "seconds": 0.0, "timed_out": False,
                                         "dry_run": True}), encoding="utf-8")
        return

    # Windows: run the body as a batch file so multi-line commands work and the
    # already-activated conda environment is inherited by the child.
    if os.name == "nt":
        script = BRIDGE / f"_run_{cmd_id}.bat"
        script.write_text("@echo off\r\n" + body.replace("\n", "\r\n") + "\r\n",
                          encoding="utf-8")
        argv = ["cmd", "/c", str(script)]
    else:
        script = BRIDGE / f"_run_{cmd_id}.sh"
        script.write_text("#!/bin/sh\n" + body + "\n", encoding="utf-8")
        script.chmod(0o755)
        argv = ["/bin/sh", str(script)]

    t0 = time.time()
    timed_out = False
    rc = None
    with open(out_path, "w", encoding="utf-8", errors="replace", buffering=1) as fh:
        fh.write(f"$ {body}\n{'-' * 70}\n")
        try:
            proc = subprocess.Popen(
                argv, cwd=str(cwd), stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT, text=True, encoding="utf-8",
                errors="replace", bufsize=1)
        except Exception as e:
            fh.write(f"<<failed to launch: {e!r}>>\n")
            done_path.write_text(json.dumps({"id": cmd_id, "exit_code": -1,
                                             "seconds": 0.0, "timed_out": False,
                                             "error": repr(e)}), encoding="utf-8")
            return

        try:
            for line in proc.stdout:            # live: Claude can poll out_*.txt
                fh.write(line)
                sys.stdout.write(line)
                sys.stdout.flush()
                if time.time() - t0 > timeout:
                    timed_out = True
                    break
        except Exception as e:
            fh.write(f"<<read error: {e!r}>>\n")

        if timed_out or proc.poll() is None:
            try:
                if time.time() - t0 > timeout:
                    timed_out = True
                    fh.write(f"\n<<TIMEOUT after {timeout:.0f} s -- killing>>\n")
                    if os.name == "nt":
                        subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                                       capture_output=True)
                    else:
                        proc.kill()
                else:
                    proc.wait(timeout=5)
            except Exception:
                pass
        rc = proc.poll()
        dt = time.time() - t0
        fh.write(f"{'-' * 70}\n<<exit {rc} after {dt:.1f} s>>\n")

    done_path.write_text(json.dumps({"id": cmd_id, "exit_code": rc,
                                     "seconds": round(time.time() - t0, 2),
                                     "timed_out": timed_out}), encoding="utf-8")
    try:
        script.unlink()
    except OSError:
        pass


# ------------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    # 180 s was the old default and it silently capped every long job: a
    # sensitivity sweep, a file transfer and anything in hw_campaign.py all run
    # past it, and a killed command looks identical to a failed one in the
    # output.  An hour is long enough for any single campaign phase; a soak run
    # sets its own with a "# timeout: 14400" header line.
    ap.add_argument("--timeout", type=float, default=3600.0,
                    help="default per-command timeout in seconds "
                         "(a command can override with '# timeout: N')")
    ap.add_argument("--forever", action="store_true",
                    help="keep running even if a poll cycle raises.  Use this "
                         "for unattended campaigns: without it, one transient "
                         "filesystem or USB error ends the worker and every "
                         "queued command silently stops being picked up.")
    ap.add_argument("--dry-run", action="store_true",
                    help="show commands but do not run them")
    ap.add_argument("--confirm", action="store_true",
                    help="ask before running each command")
    a = ap.parse_args()

    BRIDGE.mkdir(exist_ok=True)
    for stale in BRIDGE.glob("STOP"):
        stale.unlink()

    print("=" * 72)
    print("  radioconda bridge")
    print("=" * 72)
    print(f"  watching : {BRIDGE}")
    print(f"  python   : {sys.executable}")
    print(f"  conda env: {os.environ.get('CONDA_DEFAULT_ENV', '(none)')}")
    if a.dry_run:
        print("  MODE     : DRY RUN -- nothing will actually execute")
    if a.confirm:
        print("  MODE     : CONFIRM -- you approve each command")
    print("  stop with Ctrl-C, or by creating a file called  bridge\\STOP")
    print("=" * 72)
    print("  probing the environment...")

    env = probe_environment()
    # Persist the environment report separately -- status.json gets rewritten on
    # every heartbeat, and this is the part Claude needs to keep.
    (BRIDGE / "environment.json").write_text(json.dumps(env, indent=2),
                                             encoding="utf-8")
    write_status("ready", extra={"environment": env})
    for k in ("python", "conda_env", "gnuradio", "gr_uhd", "pyuhd", "numpy",
              "uhd_config_info"):
        v = str(env.get(k, "")).splitlines()
        print(f"    {k:18s}: {v[0] if v else ''}")
    print(f"    uhd_find_devices  : "
          f"{str(env.get('uhd_find_devices','')).splitlines()[:1]}")
    print("=" * 72)
    print("  ready -- leave this window open.\n")

    seen: set[str] = set()
    last_beat = 0.0
    consecutive_errors = 0
    try:
        while True:
            # --forever wraps ONE poll cycle, not the whole loop, so a transient
            # error costs a single cycle instead of the worker.  Without this,
            # any exception here -- a locked file while OneDrive syncs, a USB
            # hiccup, a disk blip -- ends the process, status.json goes to
            # "stopped", and every queued command sits unread with no sign that
            # anything is wrong.  That is exactly how an unattended campaign
            # silently stalls overnight.
            try:
                if (BRIDGE / "STOP").exists():
                    print("\n  STOP file found -- exiting.")
                    break
                _poll_once(a, seen)
                consecutive_errors = 0
            except KeyboardInterrupt:
                raise
            except Exception as e:
                consecutive_errors += 1
                print(f"  !! poll cycle failed ({consecutive_errors}): {e!r}")
                if not a.forever:
                    raise
                if consecutive_errors >= 20:
                    print("  !! 20 consecutive failures -- giving up.")
                    raise
                time.sleep(min(2.0 * consecutive_errors, 30.0))

            if time.time() - last_beat > HEARTBEAT_S:
                write_status("ready")
                last_beat = time.time()
            time.sleep(POLL_S)
    except KeyboardInterrupt:
        print("\n  stopped by Ctrl-C.")
    finally:
        write_status("stopped")


def _poll_once(a, seen: set):
    """One scan of the bridge directory: run whatever is pending, once each."""
    pending = sorted(p for p in BRIDGE.glob("cmd_*.txt")
                     if p.stem[4:] not in seen)
    for path in pending:
        cmd_id = path.stem[4:]
        if (BRIDGE / f"done_{cmd_id}.json").exists():
            seen.add(cmd_id)
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue                            # still being written
        opts, body = parse_command(text)
        if not body:
            continue

        print(f"\n>>> [{cmd_id}] {body.splitlines()[0][:100]}")
        if len(body.splitlines()) > 1:
            print(f"    (+{len(body.splitlines())-1} more lines)")
        if a.confirm:
            try:
                if input("    run this? [y/N] ").strip().lower() != "y":
                    (BRIDGE / f"out_{cmd_id}.txt").write_text(
                        "<<declined by operator>>\n", encoding="utf-8")
                    (BRIDGE / f"done_{cmd_id}.json").write_text(
                        json.dumps({"id": cmd_id, "exit_code": None,
                                    "declined": True}), encoding="utf-8")
                    seen.add(cmd_id)
                    continue
            except EOFError:
                pass

        write_status("running", cmd_id)
        # A crash inside ONE command must not take the worker down with it, or
        # every later command in the queue is lost too.  Record it as a failure
        # and move on -- that is what the done_*.json is for.
        try:
            run_command(cmd_id, body, opts, a.timeout, a.dry_run)
        except Exception as e:
            import traceback
            tb = traceback.format_exc()
            print(f"  !! command {cmd_id} raised: {e!r}")
            try:
                (BRIDGE / f"out_{cmd_id}.txt").write_text(
                    f"<<worker exception>>\n{tb}\n", encoding="utf-8")
                (BRIDGE / f"done_{cmd_id}.json").write_text(
                    json.dumps({"id": cmd_id, "exit_code": None,
                                "worker_exception": repr(e)}), encoding="utf-8")
            except OSError:
                pass
        seen.add(cmd_id)
        write_status("ready", cmd_id)
        print(f"<<< [{cmd_id}] done\n")


if __name__ == "__main__":
    main()
