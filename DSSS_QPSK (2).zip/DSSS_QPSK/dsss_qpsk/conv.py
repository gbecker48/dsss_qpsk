"""
conv.py -- convolutional encoder and SOFT-DECISION Viterbi decoder.

Soft decisions are the whole point.  Feeding the decoder hard 0/1 bits throws
away about 2 dB; feeding it log-likelihood ratios recovers that.  At the SNRs
this link runs at, 2 dB is the difference between working and not.

Conventions
-----------
* LLR sign convention:  L > 0  means the bit is more likely to be 0.
  (L = log P(b=0) / P(b=1).)
* The encoder appends K-1 zero tail bits so the trellis terminates in state 0,
  which lets the decoder start traceback from a known state.  Costs
  (K-1)*n_polys coded bits per frame -- negligible here, and worth it.
* State  s  holds the previous K-1 input bits (most recent in the MSB of s).
  Register for the current step is  r = (b << (K-1)) | s .
"""

from __future__ import annotations

import numpy as np


def _parity(x: int) -> int:
    x ^= x >> 16
    x ^= x >> 8
    x ^= x >> 4
    x ^= x >> 2
    x ^= x >> 1
    return x & 1


class ConvCode:
    def __init__(self, K: int, polys: list[int], puncture=None):
        self.K = int(K)
        self.polys = [int(p) for p in polys]
        self.n = len(self.polys)
        self.n_states = 1 << (self.K - 1)
        self.puncture = None
        if puncture is not None:
            p = np.asarray(puncture, dtype=np.int8)
            if p.shape[0] != self.n:
                raise ValueError("puncture matrix must have one row per polynomial")
            self.puncture = p
            self.punc_period = p.shape[1]
            self.punc_kept = int(p.sum())
        self._build_tables()

    # ---------------------------------------------------------------- tables
    def _build_tables(self):
        S, K, n = self.n_states, self.K, self.n
        self.next_state = np.zeros((S, 2), dtype=np.int32)
        self.out_bits = np.zeros((S, 2, n), dtype=np.int8)
        for s in range(S):
            for b in (0, 1):
                r = (b << (K - 1)) | s
                self.next_state[s, b] = r >> 1
                for j, poly in enumerate(self.polys):
                    self.out_bits[s, b, j] = _parity(r & poly)

        # Inverse trellis: every state has exactly two predecessors.
        prev_state = np.full((S, 2), -1, dtype=np.int32)
        prev_input = np.zeros((S, 2), dtype=np.int8)
        prev_out = np.zeros((S, 2, n), dtype=np.int8)
        fill = np.zeros(S, dtype=np.int8)
        for s in range(S):
            for b in (0, 1):
                ns = self.next_state[s, b]
                k = fill[ns]
                prev_state[ns, k] = s
                prev_input[ns, k] = b
                prev_out[ns, k] = self.out_bits[s, b]
                fill[ns] += 1
        assert np.all(fill == 2), "trellis is not regular -- bad generator polys"
        self.prev_state = prev_state
        self.prev_input = prev_input
        # +/-1 signs used to turn LLRs into branch metrics (sum L_j * (1-2c_j)).
        self.prev_sign = (1 - 2 * prev_out.astype(np.float32)).reshape(S * 2, n)
        self.prev_state_flat = prev_state.reshape(S * 2)
        self.prev_input_flat = prev_input.reshape(S * 2)

    # ---------------------------------------------------------------- encode
    def encode(self, bits: np.ndarray) -> np.ndarray:
        """bits (uint8 0/1) -> coded bits (uint8 0/1), tail-terminated."""
        bits = np.asarray(bits, dtype=np.uint8).ravel()
        padded = np.concatenate([bits, np.zeros(self.K - 1, dtype=np.uint8)])
        s = 0
        out = np.empty((len(padded), self.n), dtype=np.uint8)
        nxt = self.next_state
        ob = self.out_bits
        for i, b in enumerate(padded):
            out[i] = ob[s, b]
            s = nxt[s, b]
        coded = out.reshape(-1)
        if self.puncture is not None:
            coded = self._apply_puncture(coded)
        return coded

    def _apply_puncture(self, coded: np.ndarray) -> np.ndarray:
        n, P = self.n, self.punc_period
        m = coded.reshape(-1, n).T                     # (n, nsteps)
        nsteps = m.shape[1]
        mask = np.tile(self.puncture, (1, int(np.ceil(nsteps / P))))[:, :nsteps]
        return m.T.reshape(-1)[mask.T.reshape(-1).astype(bool)]

    def _undo_puncture(self, llrs: np.ndarray, nsteps: int) -> np.ndarray:
        """Insert zero (= no information) LLRs where bits were punctured."""
        n, P = self.n, self.punc_period
        mask = np.tile(self.puncture, (1, int(np.ceil(nsteps / P))))[:, :nsteps]
        flat_mask = mask.T.reshape(-1).astype(bool)
        full = np.zeros(flat_mask.size, dtype=np.float32)
        full[flat_mask] = llrs[:int(flat_mask.sum())]
        return full

    def coded_len(self, n_info_bits: int) -> int:
        steps = n_info_bits + self.K - 1
        if self.puncture is None:
            return steps * self.n
        full = steps * self.n
        return int(np.ceil(full * self.punc_kept / (self.n * self.punc_period)))

    # ---------------------------------------------------------------- decode
    def decode(self, llrs: np.ndarray, n_info_bits: int | None = None):
        """Soft Viterbi.

        llrs : float array of channel LLRs for the coded bits, in transmit order
               (positive = bit 0 more likely).
        returns (info_bits uint8, metric_margin) where metric_margin is the
        difference between the best and second-best final path metric -- a
        useful confidence indicator that gets reported in the UI.
        """
        llrs = np.asarray(llrs, dtype=np.float32).ravel()
        if self.puncture is not None:
            steps_guess = int(np.ceil(len(llrs) * self.n * self.punc_period
                                      / (self.punc_kept * self.n)))
            if n_info_bits is not None:
                steps_guess = n_info_bits + self.K - 1
            llrs = self._undo_puncture(llrs, steps_guess)
        T = len(llrs) // self.n
        L = llrs[:T * self.n].reshape(T, self.n)

        S = self.n_states
        # All branch metrics in one matmul:  (T, n) x (n, 2S) -> (T, 2S)
        bm = L @ self.prev_sign.T                       # (T, 2S)

        NEG = np.float32(-1e18)
        pm = np.full(S, NEG, dtype=np.float32)
        pm[0] = 0.0
        dec = np.empty((T, S), dtype=np.uint8)
        ps = self.prev_state_flat

        # The inner loop runs once per coded bit -- ~9800 times for a 512-byte
        # frame -- so what matters is the NUMBER of numpy calls per step, not
        # the size of the arrays (they are 128 floats).  argmax(axis=1) plus a
        # fancy-indexed gather is four calls and two temporaries; comparing the
        # two columns directly is two.  Measured: 31% off the Viterbi, which is
        # the single most expensive thing in the receiver.
        for t in range(T):
            cand = (pm[ps] + bm[t]).reshape(S, 2)       # (S, 2)
            c0 = cand[:, 0]
            c1 = cand[:, 1]
            k = c1 > c0
            pm = np.where(k, c1, c0)
            dec[t] = k
            # renormalise to avoid float drift on long frames
            if (t & 255) == 255:
                pm -= pm.max()

        # Traceback from the terminating state 0 (tail bits force it there).
        order = np.argsort(pm)
        margin = float(pm[order[-1]] - pm[order[-2]]) if S > 1 else 0.0
        s = 0
        bits = np.empty(T, dtype=np.uint8)
        prev_state = self.prev_state
        prev_input = self.prev_input
        for t in range(T - 1, -1, -1):
            k = dec[t, s]
            bits[t] = prev_input[s, k]
            s = prev_state[s, k]
        info = bits[:T - (self.K - 1)]
        if n_info_bits is not None:
            info = info[:n_info_bits]
        return info, margin
