"""
transports.py -- what the link layer plugs into.

Three of them:

  SimTransport    pure numpy, no GNU Radio, no radio.  Generates a continuous
                  noisy stream and injects your own bursts into it through the
                  channel model.  This is what `run_link.py --sim` uses, and it
                  is the fastest way to try a config change.

  GrLoopbackTransport   GNU Radio flowgraph with no hardware:
                  burst source -> channel model -> receiver sink.
                  Use it to confirm the GNU Radio blocks themselves are wired
                  correctly before you plug a radio in.

  UsrpTransport   GNU Radio flowgraph driving a real B206mini-i:
                  burst source -> usrp_sink      (tagged bursts, tx_sob/tx_eob)
                  usrp_source  -> receiver sink

All three expose the same tiny interface:
    t.rx_callback = fn      # called with numpy complex64 blocks
    t.transmit(samples)     # queue one burst
    t.start() / t.stop()
"""

from __future__ import annotations

import queue
import threading
import time

import numpy as np

from . import channel


class SimTransport:
    """Simulated radio: continuous noise with your own bursts folded back in."""

    def __init__(self, cfg, snr_db=None, cfo_hz=None, sfo_ppm=None,
                 delay=None, loop_latency_s=0.02, chunk=1 << 15, seed=0,
                 realtime=True):
        self.cfg = cfg
        self.rx_callback = None
        self.snr_db = cfg.SIM_SNR_DB if snr_db is None else snr_db
        self.cfo_hz = cfg.SIM_CFO_HZ if cfo_hz is None else cfo_hz
        self.sfo_ppm = cfg.SIM_SFO_PPM if sfo_ppm is None else sfo_ppm
        self.delay = cfg.SIM_DELAY_CHIPS if delay is None else delay
        self.chunk = int(chunk)
        self.realtime = realtime
        self.rng = np.random.default_rng(seed)
        self._lock = threading.Lock()
        self._future = np.zeros(0, dtype=np.complex128)   # samples still to come
        self._latency = int(loop_latency_s * cfg.SAMP_RATE_HZ)
        self._running = False
        self._thread = None
        # The receiver runs on its own thread, exactly like the GNU Radio sink
        # does, so a slow decode never stalls the sample stream and stretch the
        # wall clock the ARQ timers run on.
        self._rxq: "queue.Queue" = queue.Queue(maxsize=256)
        self._rxthread = None
        self.dropped = 0

        # Reference burst power, so SNR means what it says.
        from .framing import Header
        from .modulator import Modulator
        ref = Modulator(cfg).modulate(Header(payload_len=0), b"")
        self._p_sig = float(np.mean(np.abs(ref) ** 2))
        self._sigma2 = self._p_sig * cfg.SPS_CHIP / (10 ** (self.snr_db / 10.0))

    def set_snr(self, snr_db: float):
        self.snr_db = float(snr_db)
        self._sigma2 = self._p_sig * self.cfg.SPS_CHIP / (10 ** (self.snr_db / 10.0))

    # ---- the same controls the radio exposes, so one UI drives both ----------
    # In simulation there IS a noise generator, so the SNR slider can move the
    # noise directly instead of attenuating the signal.  The mapping is chosen so
    # the slider's useful region lines up with the hardware one: the link dies
    # around -14 dB chip SNR either way, so both ends of the control mean the
    # same thing to the person turning it.
    SIM_SNR_AT_ZERO_DB = -20.0
    SIM_SNR_AT_ONE_DB = +20.0

    def set_signal_level(self, level: float) -> dict:
        level = float(min(max(level, 0.0), 1.0))
        snr = (self.SIM_SNR_AT_ZERO_DB
               + (self.SIM_SNR_AT_ONE_DB - self.SIM_SNR_AT_ZERO_DB) * level)
        self.set_snr(snr)
        self.cfg.SIGNAL_LEVEL = level
        return {"level": level, "sim_snr_db": snr, "atten_db": None,
                "tx_gain_db": None, "digital_db": None}

    # No radio here, so there is nothing to turn.  They exist so the dashboard
    # does not need to know which transport it is talking to.
    def set_tx_gain_norm(self, norm: float):
        return None

    def set_rx_gain_norm(self, norm: float):
        return None

    def transmit(self, samples: np.ndarray):
        x = np.asarray(samples, dtype=np.complex128)
        # Channel: fractional delay + clock offset, then carrier offset/phase.
        y = channel.fractional_resample(
            np.concatenate([np.zeros(32), x, np.zeros(64)]),
            self.delay, self.sfo_ppm)
        n = np.arange(len(y))
        ph = self.rng.uniform(-np.pi, np.pi)
        y = y * np.exp(1j * (2 * np.pi * self.cfo_hz * n / self.cfg.SAMP_RATE_HZ + ph))
        with self._lock:
            need = self._latency + len(y)
            if len(self._future) < need:
                self._future = np.concatenate(
                    [self._future, np.zeros(need - len(self._future), dtype=np.complex128)])
            self._future[self._latency:self._latency + len(y)] += y

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._pump, daemon=True)
        self._rxthread = threading.Thread(target=self._rx_worker, daemon=True)
        self._thread.start()
        self._rxthread.start()

    def stop(self):
        self._running = False
        for t in (self._thread, self._rxthread):
            if t:
                t.join(timeout=1.0)

    def _rx_worker(self):
        while self._running:
            try:
                x = self._rxq.get(timeout=0.1)
            except queue.Empty:
                continue
            if self.rx_callback:
                self.rx_callback(x)

    def _pump(self):
        period = self.chunk / self.cfg.SAMP_RATE_HZ
        next_t = time.time()
        while self._running:
            n = self.chunk
            noise = np.sqrt(self._sigma2 / 2) * (
                self.rng.standard_normal(n) + 1j * self.rng.standard_normal(n))
            with self._lock:
                if len(self._future):
                    take = min(n, len(self._future))
                    noise[:take] += self._future[:take]
                    self._future = self._future[take:]
            try:
                self._rxq.put_nowait(noise.astype(np.complex64))
            except queue.Full:
                self.dropped += n
            if self.realtime:
                next_t += period
                dt = next_t - time.time()
                if dt > 0:
                    time.sleep(dt)
                else:
                    next_t = time.time()


# ============================================================ GNU Radio based
def _require_gr():
    try:
        from gnuradio import blocks, gr  # noqa: F401
    except ImportError as e:
        raise SystemExit(
            "GNU Radio could not be imported.\n"
            "  Windows/radioconda : open the 'GNU Radio Command Prompt', or run\n"
            "                       `conda activate radioconda` first.\n"
            "  Linux              : sudo apt install gnuradio\n"
            "You can still run everything in simulation:  python run_link.py --sim"
        ) from e


class GrLoopbackTransport:
    """GNU Radio flowgraph, no hardware: source -> channel model -> sink."""

    def __init__(self, cfg, snr_db=None, cfo_hz=None, seed=0):
        _require_gr()
        from gnuradio import analog, blocks, channels, gr

        from .blocks.gr_blocks import DsssBurstSource, DsssReceiverSink
        from .framing import Header
        from .modulator import Modulator

        self.cfg = cfg
        self.rx_callback = None
        snr_db = cfg.SIM_SNR_DB if snr_db is None else snr_db
        cfo_hz = cfg.SIM_CFO_HZ if cfo_hz is None else cfo_hz

        ref = Modulator(cfg).modulate(Header(payload_len=0), b"")
        p_sig = float(np.mean(np.abs(ref) ** 2))
        sigma = np.sqrt(p_sig * cfg.SPS_CHIP / (10 ** (snr_db / 10.0)))

        self.tb = gr.top_block("dsss_loopback")
        # idle_fill so samples flow (and therefore noise exists) between bursts,
        # and a throttle so the flowgraph runs at the real sample rate instead of
        # as fast as the CPU allows -- otherwise the ARQ timers are meaningless.
        self.src = DsssBurstSource(idle_fill=True)
        self.throttle = blocks.throttle(gr.sizeof_gr_complex, cfg.SAMP_RATE_HZ, True)
        self.chan = channels.channel_model(
            noise_voltage=float(sigma),
            frequency_offset=float(cfo_hz / cfg.SAMP_RATE_HZ),
            epsilon=1.0 + cfg.SIM_SFO_PPM * 1e-6,
            taps=[1.0 + 0.0j],
            noise_seed=seed,
            block_tags=False)
        self.sink = DsssReceiverSink(None, on_samples=self._on_samples)
        self.tb.connect(self.src, self.throttle, self.chan, self.sink)

    def _on_samples(self, x):
        if self.rx_callback:
            self.rx_callback(x)

    def transmit(self, samples):
        self.src.transmit(samples)

    def start(self):
        self.tb.start()

    def stop(self):
        self.tb.stop()
        self.tb.wait()


class UsrpTransport:
    """GNU Radio flowgraph driving a real USRP (B206mini-i and friends)."""

    def __init__(self, cfg):
        _require_gr()
        from gnuradio import gr, uhd

        from .blocks.gr_blocks import PACKET_LEN_TAG, DsssBurstSource, DsssReceiverSink

        self.cfg = cfg
        self.rx_callback = None
        self.tb = gr.top_block("dsss_qpsk_link")

        stream_args = uhd.stream_args(cpu_format="fc32", args="", channels=[0])

        # ---------------------------------------------------------- receive
        self.usrp_src = uhd.usrp_source(cfg.DEVICE_ARGS, stream_args)
        self.usrp_src.set_clock_source(cfg.CLOCK_SOURCE, 0)
        self.usrp_src.set_time_source(cfg.TIME_SOURCE, 0)
        self.usrp_src.set_samp_rate(cfg.SAMP_RATE_HZ)
        # RX_FREQ_OFFSET_HZ tunes the RECEIVE synthesizer away from the transmit
        # synthesizer.  On a B2xx these are two independent PLLs, so this is a
        # genuine carrier frequency offset generated by the hardware -- the only
        # way to exercise acquisition's Doppler search and the fine CFO
        # estimator without a second radio.  Defaults to 0 (see config.py).
        self.rx_freq = cfg.CENTER_FREQ_HZ + getattr(cfg, "RX_FREQ_OFFSET_HZ", 0.0)
        self.usrp_src.set_center_freq(uhd.tune_request(self.rx_freq), 0)
        self.usrp_src.set_gain(cfg.RX_GAIN_DB, 0)
        self.usrp_src.set_antenna(cfg.RX_ANTENNA, 0)
        if cfg.RX_BANDWIDTH_HZ:
            self.usrp_src.set_bandwidth(cfg.RX_BANDWIDTH_HZ, 0)

        # --------------------------------------------------------- transmit
        # The third argument is the length tag: uhd.usrp_sink turns each tagged
        # packet into one burst with tx_sob on the first sample and tx_eob on
        # the last, and transmits nothing in between.  That is exactly the
        # half-duplex burst behaviour we want, and it is why the transmitter
        # does not spew underrun 'U' characters between messages.
        self.usrp_sink = uhd.usrp_sink(cfg.DEVICE_ARGS, stream_args, PACKET_LEN_TAG)
        self.usrp_sink.set_samp_rate(cfg.SAMP_RATE_HZ)
        self.usrp_sink.set_center_freq(uhd.tune_request(cfg.CENTER_FREQ_HZ), 0)
        self.usrp_sink.set_gain(cfg.TX_GAIN_DB, 0)
        self.usrp_sink.set_antenna(cfg.TX_ANTENNA, 0)
        if cfg.TX_BANDWIDTH_HZ:
            self.usrp_sink.set_bandwidth(cfg.TX_BANDWIDTH_HZ, 0)

        self.src = DsssBurstSource()
        self.sink = DsssReceiverSink(None, on_samples=self._on_samples)
        self.tb.connect(self.src, self.usrp_sink)
        self.tb.connect(self.usrp_src, self.sink)

        # "Full power" for the SNR slider is whatever TX gain was configured at
        # start-up -- NOT the device maximum.  On a bare cable the device maximum
        # would drive the receiver straight into clipping, and the operating
        # point found by `hw_diag.py --autolevel` is the honest top of the range.
        self._tx_gain_ceiling = float(cfg.TX_GAIN_DB)
        self._read_gain_ranges()
        if not hasattr(cfg, "TX_AMPLITUDE_BASE"):
            cfg.TX_AMPLITUDE_BASE = cfg.TX_AMPLITUDE
        cfg.SIGNAL_LEVEL = 1.0

    def _on_samples(self, x):
        if self.rx_callback:
            self.rx_callback(x)

    def transmit(self, samples):
        # TX_SFO_PPM fractionally resamples the burst before it reaches the DAC.
        # The radio still clocks it out at the nominal rate, so what comes back
        # over the cable is a waveform whose chip rate differs from the
        # receiver's by exactly this many ppm.  That is precisely what a sample
        # clock offset is, and the DLL cannot distinguish it from a second radio
        # running off a different crystal.  Defaults to 0 (see config.py).
        #
        # Stay in complex64.  This runs inline on the transmit path, so its cost
        # is stolen directly from the receiver: at complex128 it took 204 ms to
        # resample a 131 ms burst (1.56x real time) and dropped 17.6 M samples
        # during a live 50 ppm test -- a harness artifact that looked exactly
        # like a receiver failure.  In complex64 it is 26 ms, 0.20x real time.
        ppm = getattr(self.cfg, "TX_SFO_PPM", 0.0)
        if ppm:
            from . import channel
            samples = channel.fractional_resample(
                np.asarray(samples, dtype=np.complex64), 0.0, ppm)
        self.src.transmit(samples)

    def start(self):
        self.tb.start()

    def stop(self):
        self.tb.stop()
        self.tb.wait()
        # Let UHD actually release the USB device before this process exits.
        #
        # OBSERVED, WINDOWS / UHD 4.10: running three hardware scripts back to
        # back in one batch file, the third crashed at device-open time with
        # 0xC0000005 (access violation) -- inside the driver, before any of our
        # code ran.  The same command passed on its own, and on other runs three
        # in a row were fine, so it is a race between one process releasing the
        # B200 and the next one claiming it, not a limit.
        #
        # There is no way to catch an access violation from Python, so the only
        # defence is not to provoke it.  Half a second costs nothing at the end
        # of a test and makes the race much harder to hit.  If you still see it,
        # put a `timeout /t 3` between radio invocations in your batch file.
        time.sleep(0.5)

    def describe(self) -> str:
        try:
            info = self.usrp_src.get_usrp_info()
            mb = info.get("mboard_id", "?")
            serial = info.get("mboard_serial", "?")
            return f"{mb} serial {serial}"
        except Exception:
            return "USRP"

    # ------------------------------------------------- live gain / level control
    # Gains used to be set once, in __init__.  That meant a UI slider could only
    # change cfg.TX_GAIN_DB -- a number nothing read again until the flowgraph was
    # rebuilt -- so the slider moved and the radio did not.  These apply on the
    # spot, to the running flowgraph.
    def _read_gain_ranges(self):
        """Ask the radio what its gain range actually is, and tell config.

        The B206mini is 0..89.75 TX and 0..76 RX, which is what config.py
        defaults to, but a different board has different ends and the 0-to-1
        slider has to map onto the real ones or the numbers lie.
        """
        for obj, key in ((self.usrp_sink, "TX_GAIN_RANGE_DB"),
                         (self.usrp_src, "RX_GAIN_RANGE_DB")):
            try:
                r = obj.get_gain_range()
                lo, hi = float(r.start()), float(r.stop())
                if hi > lo:
                    setattr(self.cfg, key, (lo, hi))
            except Exception:
                pass                      # keep the config defaults
        return {"tx": self.cfg.TX_GAIN_RANGE_DB, "rx": self.cfg.RX_GAIN_RANGE_DB}

    def set_tx_gain_db(self, db: float) -> float:
        lo, hi = self.cfg.TX_GAIN_RANGE_DB
        db = float(min(max(db, lo), hi))
        self.usrp_sink.set_gain(db, 0)
        self.cfg.TX_GAIN_DB = db
        return db

    def set_rx_gain_db(self, db: float) -> float:
        lo, hi = self.cfg.RX_GAIN_RANGE_DB
        db = float(min(max(db, lo), hi))
        self.usrp_src.set_gain(db, 0)
        self.cfg.RX_GAIN_DB = db
        return db

    def set_tx_gain_norm(self, norm: float) -> float:
        return self.set_tx_gain_db(
            self.cfg.norm_to_gain_db(norm, self.cfg.TX_GAIN_RANGE_DB))

    def set_rx_gain_norm(self, norm: float) -> float:
        return self.set_rx_gain_db(
            self.cfg.norm_to_gain_db(norm, self.cfg.RX_GAIN_RANGE_DB))

    def set_signal_level(self, level: float) -> dict:
        """The SNR slider.  0..1 -> real attenuation against a fixed noise floor.

        Analogue TX gain is spent first, then digital backoff of TX_AMPLITUDE.
        TX_AMPLITUDE is read by the modulator on every burst, so the digital half
        takes effect on the very next frame with no rebuild; the analogue half is
        applied to the running flowgraph here.  Both are absolute, computed from
        TX_AMPLITUDE_BASE and the slider's own maximum, so dragging the slider
        back and forth lands on the same place every time instead of ratcheting.
        """
        tx_max = float(getattr(self.cfg, "TX_GAIN_MAX_DB", None)
                       or self._tx_gain_ceiling)
        tx_db, dig_db, atten = self.cfg.level_to_setting(level, tx_max)
        self.set_tx_gain_db(tx_db)
        base = float(getattr(self.cfg, "TX_AMPLITUDE_BASE", self.cfg.TX_AMPLITUDE))
        self.cfg.TX_AMPLITUDE = base * (10.0 ** (dig_db / 20.0))
        self.cfg.SIGNAL_LEVEL = float(min(max(level, 0.0), 1.0))
        return {"level": self.cfg.SIGNAL_LEVEL, "tx_gain_db": tx_db,
                "digital_db": dig_db, "atten_db": atten,
                "tx_amplitude": self.cfg.TX_AMPLITUDE}
