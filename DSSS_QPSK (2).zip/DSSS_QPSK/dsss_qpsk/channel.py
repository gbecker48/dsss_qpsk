"""
channel.py -- a realistic simulation channel, so the whole link can be tested
and tuned without touching hardware.

Models, in the order a real link suffers them:
  * fractional propagation delay      (the receiver never samples on chip centres)
  * sample clock offset (SFO, ppm)    (two radios never share a clock)
  * carrier frequency offset (CFO)    (two LOs never agree either)
  * carrier phase                     (arbitrary)
  * complex AWGN at a specified CHIP-BAND SNR
  * optional receiver DC offset and IQ imbalance, which is what a
    direct-conversion front end like the B2xx actually adds

SNR CONVENTION
    SNR_chip = Es_chip / N0, i.e. the SNR measured in the chip bandwidth.
    NEGATIVE MEANS BELOW THE NOISE FLOOR -- at -10 dB the noise in the occupied
    bandwidth is ten times the signal power.  After despreading, the symbol SNR
    is SNR_chip + 10*log10(SPREADING_FACTOR).
"""

from __future__ import annotations

import numpy as np

# Polyphase windowed-sinc resampler: 128 sub-sample phases, 24 taps.
# Accurate to about -60 dB, so the channel model itself does not limit EVM.
_NPHASE = 128
_NTAPS = 24


def _build_resampler():
    t = np.arange(_NTAPS) - (_NTAPS // 2 - 1)
    table = np.empty((_NPHASE, _NTAPS))
    for p in range(_NPHASE):
        mu = p / _NPHASE
        x = t - mu
        h = np.sinc(x)
        w = 0.42 - 0.5 * np.cos(2 * np.pi * (np.arange(_NTAPS) + 0.5) / _NTAPS) \
            + 0.08 * np.cos(4 * np.pi * (np.arange(_NTAPS) + 0.5) / _NTAPS)
        h = h * w
        table[p] = h / h.sum()
    return table


_RESAMP = _build_resampler()


_RESAMP32 = _RESAMP.astype(np.float32)
# Transposed, tap-major copies.  The inner loop below wants "all phases for tap
# k" as a contiguous run; holding the table phase-major makes every one of those
# 24 gathers stride across the array instead, which measured 33.7 ms against
# 25.6 ms on a 262k-sample burst.  Two small tables, 25% off the hot loop.
_RESAMP_T = np.ascontiguousarray(_RESAMP.T)
_RESAMP32_T = np.ascontiguousarray(_RESAMP32.T)


def fractional_resample(x: np.ndarray, delay: float, sfo_ppm: float = 0.0,
                        n_out: int | None = None) -> np.ndarray:
    """Resample x on the grid  t_k = (1 + sfo) * k + delay  (in input samples).

    Precision follows the input: a complex64 input resamples in complex64 and a
    complex128 input in complex128.  That matters because this runs on the
    TRANSMIT path when TX_SFO_PPM is set, where it is the only thing standing
    between the modulator and the radio.  Measured on a 400-byte burst
    (262k samples, 131 ms of air time):

        original, complex128 accumulate        204 ms   1.56x real time
        this version, complex128                75 ms   0.57x
        this version, complex64                 26 ms   0.20x

    The 1.56x version starved the receiver badly enough to drop 17.6 M samples
    during a live 50 ppm link test -- an artifact of the test harness that
    looked exactly like a receiver bug.  Three things bought the 8x: single
    precision taps and accumulator, padding the input once so the inner loop
    indexes instead of clipping 262k int64 values per tap, and the tap-major
    coefficient table above.
    """
    scale = 1.0 + sfo_ppm * 1e-6
    if n_out is None:
        n_out = int((len(x) - _NTAPS - 2 - delay) / scale)
        n_out = max(0, n_out)
    if n_out <= 0:
        return np.zeros(0, dtype=x.dtype if np.iscomplexobj(x) else np.complex128)

    single = (np.asarray(x).dtype == np.complex64)
    cdtype = np.complex64 if single else np.complex128
    taps_t = _RESAMP32_T if single else _RESAMP_T

    t = scale * np.arange(n_out) + delay
    base = np.floor(t).astype(np.int64)
    mu = t - base
    ph = np.minimum((mu * _NPHASE).astype(np.int64), _NPHASE - 1)

    # Pad once, by the most any tap can reach past either end, then index into
    # the padded array with a simple offset.  This replaces one np.clip over
    # n_out int64 values PER TAP (24 of them) with a single add.
    c = _NTAPS // 2 - 1
    lo_pad = c
    hi_pad = _NTAPS - c + 1
    xp = np.concatenate([np.zeros(lo_pad, dtype=cdtype),
                         np.asarray(x, dtype=cdtype),
                         np.zeros(hi_pad + int(base[-1] + _NTAPS - len(x)) + 1
                                  if base[-1] + _NTAPS >= len(x) else hi_pad,
                                  dtype=cdtype)])
    idx0 = base + lo_pad - c

    # Accumulate tap by tap rather than materialising an (n_out, NTAPS) matrix.
    # For a 78k-sample burst that matrix is 15 MB and the gather dominates.
    y = np.zeros(n_out, dtype=cdtype)
    for k in range(_NTAPS):
        y += taps_t[k][ph] * xp[idx0 + k]
    return y


def apply_channel(x: np.ndarray, cfg, snr_db: float, cfo_hz: float = 0.0,
                  phase: float = 0.0, delay: float = 0.0, sfo_ppm: float = 0.0,
                  seed: int = 0, pad_before: int | None = None,
                  pad_after: int | None = None,
                  dc_offset: complex = 0.0, iq_gain_db: float = 0.0,
                  iq_phase_deg: float = 0.0) -> np.ndarray:
    """Pass one burst through the channel and return a longer noise-only-padded
    stream, exactly like what the radio hands the receiver."""
    rng = np.random.default_rng(seed)
    x = np.asarray(x, dtype=np.complex128)

    # Signal power of the burst itself (used to set the noise level).
    p_sig = float(np.mean(np.abs(x) ** 2))

    if pad_before is None:
        pad_before = int(0.3 * cfg.ACQ_WINDOW_SAMPLES)
    if pad_after is None:
        pad_after = int(0.3 * cfg.ACQ_WINDOW_SAMPLES)
    stream = np.concatenate([
        np.zeros(pad_before, dtype=np.complex128),
        x,
        np.zeros(pad_after, dtype=np.complex128),
    ])

    # Delay + sample clock offset.
    if delay != 0.0 or sfo_ppm != 0.0:
        stream = fractional_resample(stream, delay, sfo_ppm)

    # Carrier frequency offset and phase.
    if cfo_hz != 0.0 or phase != 0.0:
        n = np.arange(len(stream))
        stream = stream * np.exp(1j * (2 * np.pi * cfo_hz * n / cfg.SAMP_RATE_HZ + phase))

    # IQ imbalance (direct-conversion front-end impairment).
    if iq_gain_db != 0.0 or iq_phase_deg != 0.0:
        g = 10 ** (iq_gain_db / 20.0)
        ph = np.radians(iq_phase_deg)
        i = np.real(stream)
        q = np.imag(stream) * g
        stream = (i + q * np.sin(ph)) + 1j * (q * np.cos(ph))

    # AWGN at the requested chip-band SNR.
    #   SNR_chip = Es_chip/N0 = P * sps / sigma^2   ->   sigma^2 = P*sps/SNR
    snr = 10 ** (snr_db / 10.0)
    sigma2 = p_sig * cfg.SPS_CHIP / snr
    noise = np.sqrt(sigma2 / 2) * (rng.standard_normal(len(stream))
                                   + 1j * rng.standard_normal(len(stream)))
    stream = stream + noise + dc_offset

    return stream.astype(np.complex64)


def measure_snr_chip_db(burst_power: float, sigma2: float, sps: int) -> float:
    return 10 * np.log10(burst_power * sps / max(sigma2, 1e-30))
