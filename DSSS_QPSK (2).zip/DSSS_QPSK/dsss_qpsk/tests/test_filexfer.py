"""test_filexfer.py -- the file-transfer application layer, on its own.

These tests drive FileTransfer directly, with a loopback that hands one end's
payloads straight to the other.  No modem, no radio, no FEC: the point is to
test the segmentation, the manifest, the repair logic and above all the WIRE
FORMAT, without a 20-minute transfer in the way.

The format is the reason this file exists.  The first version used a u16
segment index, which silently capped a transfer at 65534 segments -- about
33 MB at the default segment size.  Past that the indices wrapped and the
receiver reassembled garbage that passed every per-segment check and only
failed at the final CRC-32, by which point hours of air time were gone.  So
the tests that matter here are the ones that push the index past 65535.
"""

from __future__ import annotations

import hashlib
import time
from pathlib import Path

import numpy as np

from .. import config as cfg
from .. import filexfer as fx


# --------------------------------------------------------------------------
def test_wire_format_round_trip():
    """Every message type survives encode -> decode at extreme values."""
    m = fx.encode_manifest(200, "a" * 255, 4_000_000_000, 1 << 40, 0xDEADBEEF)
    tag, f = fx.decode(m)
    assert tag == fx.APP_MANIFEST
    assert f["nseg"] == 4_000_000_000, "u32 segment count"
    assert f["size"] == 1 << 40, "u64 size (1 TB)"
    assert f["crc"] == 0xDEADBEEF
    assert f["name"] == "a" * 255

    s = fx.encode_segment(7, 4_294_967_294, b"payload")
    tag, f = fx.decode(s)
    assert tag == fx.APP_SEGMENT and f["index"] == 4_294_967_294
    assert f["data"] == b"payload"

    idx = [0, 1, 65535, 65536, 1_000_000, fx.MANIFEST_INDEX]
    tag, f = fx.decode(fx.encode_repair(3, idx))
    assert tag == fx.APP_REPAIR and f["indices"] == idx

    tag, f = fx.decode(fx.encode_done(9, 1))
    assert tag == fx.APP_DONE and f["status"] == 1
    tag, f = fx.decode(fx.encode_end(9))
    assert tag == fx.APP_END and f["xid"] == 9


def test_repair_request_fits_one_frame():
    """A repair request must fit in a single link message.

    Indices are u32 now, so the old cap of 200 per request would produce an
    806-byte payload that MAX_PAYLOAD_BYTES cannot carry -- the receiver would
    ask for repairs that could never be sent, and the transfer would stall at
    99% forever.
    """
    biggest = fx.encode_repair(0, range(10_000))
    assert len(biggest) <= cfg.MAX_PAYLOAD_BYTES, (
        f"repair request is {len(biggest)} B, over MAX_PAYLOAD_BYTES "
        f"({cfg.MAX_PAYLOAD_BYTES})")


def test_manifest_index_is_not_a_valid_segment():
    """The 'I am missing the manifest' sentinel must sit outside the index space
    that a real transfer can reach, or a big file's last segment collides with
    it."""
    assert fx.MANIFEST_INDEX == 0xFFFFFFFF
    # A transfer that could actually reach the sentinel would need 4 G segments;
    # at the smallest legal segment that is still ~64 GB, well past FILE_MAX_BYTES.
    smallest_seg = 16
    assert fx.MANIFEST_INDEX * smallest_seg > cfg.FILE_MAX_BYTES


# --------------------------------------------------------------------------
class _Loop:
    """Two FileTransfer instances wired to each other, in memory.

    `drop` makes every Nth payload vanish, so the repair path is exercised
    exactly the way a bad link exercises it.
    """

    def __init__(self, conf, drop_every: int = 0):
        self.conf = conf
        self.drop_every = drop_every
        self.n = 0
        self.dropped = 0
        # Payloads are QUEUED, never delivered inside the send call.  Delivering
        # synchronously recurses -- on_delivered() calls tick(), which queues the
        # next segment, which sends, which delivers -- and blows the stack at a
        # few thousand segments.  A real transport is asynchronous, so the
        # harness has to be too, or it tests something the link never does.
        self.q: list[tuple] = []
        self.a = fx.FileTransfer(conf, self._send_a, lambda k, t: None)
        self.b = fx.FileTransfer(conf, self._send_b, lambda k, t: None)

    def _send_a(self, payload, reliable=True):
        self.q.append((self.a, self.b, payload, reliable))

    def _send_b(self, payload, reliable=True):
        self.q.append((self.b, self.a, payload, reliable))

    def _pump(self):
        batch, self.q = self.q, []
        for src, dst, payload, reliable in batch:
            self.n += 1
            if self.drop_every and self.n % self.drop_every == 0:
                self.dropped += 1
                if reliable:
                    src.on_lost(payload)          # the link gave up on it
                continue
            dst.on_payload(payload)
            if reliable:
                src.on_delivered(payload)

    def run(self, seconds=60.0):
        t0 = time.time()
        while time.time() - t0 < seconds:
            self.a.tick()
            self.b.tick()
            if self.q:
                self._pump()
            snap = self.b.snapshot()
            rx = [t for t in snap["active"] + snap["history"] if t["dir"] == "rx"]
            if rx and rx[0]["state"] in ("complete", "failed"):
                return rx[0]
        return None


def _conf(seg_bytes, inbox):
    """A throwaway config object that shadows only what this layer reads."""
    class C:
        pass
    c = C()
    for k in dir(cfg):
        if k.isupper():
            setattr(c, k, getattr(cfg, k))
    c.FILE_SEGMENT_BYTES = seg_bytes
    c.FILE_INBOX = str(inbox)
    c.FILE_STREAM_MODE = False        # deterministic, no pacing needed
    return c


def test_transfer_past_the_old_u16_ceiling(tmp_path):
    """The case the old format got silently wrong.

    A tiny segment size gets the index past 65535 without needing a 33 MB file.
    With u16 indices this reassembles into garbage and fails its CRC; with u32
    it is byte-exact.
    """
    conf = _conf(16, tmp_path)                  # smallest the layer allows
    loop = _Loop(conf)
    # Ask the layer what a segment actually holds rather than assuming:
    # seg_bytes() has a floor of its own, so computing it here got the size
    # wrong and produced a test that quietly stayed under the old ceiling.
    per = loop.a.seg_bytes()
    data_len = 70_000 * per                     # ~70k segments
    blob = bytes(np.random.default_rng(5).integers(0, 256, data_len,
                                                   dtype=np.uint8))
    loop.a.send_blob(blob, "past_u16.bin")
    got = loop.run(120.0)

    assert got is not None, "transfer never finished"
    assert got["nseg"] > 65535, f"only {got['nseg']} segments -- test is too small"
    assert got["state"] == "complete", got["state"]
    out = open(got["path"], "rb").read()
    assert hashlib.sha256(out).hexdigest() == hashlib.sha256(blob).hexdigest(), (
        f"{len(out)} B out vs {len(blob)} B in -- indices wrapped")


def test_transfer_with_losses_repairs(tmp_path):
    """Selective repair still converges when the link drops segments."""
    conf = _conf(128, tmp_path)
    blob = bytes(np.random.default_rng(9).integers(0, 256, 60_000, dtype=np.uint8))
    loop = _Loop(conf, drop_every=7)            # ~14% loss
    loop.a.send_blob(blob, "lossy.bin")
    got = loop.run(120.0)
    assert got is not None and got["state"] == "complete", got
    assert loop.dropped > 50, f"only {loop.dropped} drops -- not a real test"
    out = open(got["path"], "rb").read()
    assert out == blob, "repair did not converge to the original bytes"


def test_rejects_beyond_file_max_bytes(tmp_path):
    conf = _conf(512, tmp_path)
    conf.FILE_MAX_BYTES = 1024
    ft = fx.FileTransfer(conf, lambda p, reliable=True: None, lambda k, t: None)
    try:
        ft.send_blob(b"x" * 4096, "too_big.bin")
    except ValueError as e:
        assert "FILE_MAX_BYTES" in str(e)
    else:
        raise AssertionError("oversized blob was accepted")


# --------------------------------------------------------------------------
# Standalone runner, so this file works the same way the other test modules do
# (`python -m dsss_qpsk.tests.test_filexfer`) as well as under pytest.  The rest
# of the suite has no pytest dependency and this one should not introduce it.
def main() -> int:
    import inspect
    import shutil
    import sys
    import tempfile

    tests = [(n, f) for n, f in sorted(globals().items())
             if n.startswith("test_") and callable(f)]
    fails = []
    for name, fn in tests:
        tmp = Path(tempfile.mkdtemp(prefix="fx_"))
        t0 = time.time()
        try:
            if "tmp_path" in inspect.signature(fn).parameters:
                fn(tmp)
            else:
                fn()
            print(f"  PASS  {name}   [{time.time()-t0:.1f} s]")
        except Exception as e:
            fails.append(name)
            print(f"  FAIL  {name}: {e}")
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
    print()
    print("ALL PASS" if not fails else "FAILED: " + ", ".join(fails))
    return 1 if fails else 0


if __name__ == "__main__":
    import sys
    sys.exit(main())
