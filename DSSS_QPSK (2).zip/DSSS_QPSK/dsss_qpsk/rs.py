"""
rs.py -- Reed-Solomon over GF(256), systematic, with shortened-codeword support.

This is the OUTER code.  The inner soft Viterbi decoder is very good at random
bit errors but, when it does fail, it fails in short bursts of 10-40 bits.  A
byte-oriented RS code is exactly the right tool for that: RS(255,223) repairs
any 16 wrong bytes in a codeword no matter how the bit errors inside them fall.

Field : GF(2^8), primitive polynomial 0x11D, generator element alpha = 2.
Code  : roots of the generator are alpha^0 .. alpha^(nsym-1)  (first consecutive
        root = 0).  Conventional basis, NOT the CCSDS dual basis.

Polynomial conventions inside this file
---------------------------------------
* A *codeword byte array* cw[0..m-1] has cw[0] as the HIGHEST degree term, i.e.
  the coefficient of x^(m-1).  That is the natural "bytes on the wire" order.
* The decoder's internal polynomials (syndromes, error locator, error
  evaluator) are kept in ASCENDING order, p[0] = constant term.  Mixing the two
  is the classic way to get an RS implementation subtly wrong, so they are kept
  strictly separate and every helper says which one it wants.
"""

from __future__ import annotations

import numpy as np

_PRIM = 0x11D

# ------------------------------------------------------------------ GF tables
_EXP = np.zeros(512, dtype=np.uint8)
_LOG = np.zeros(256, dtype=np.uint8)
_x = 1
for _i in range(255):
    _EXP[_i] = _x
    _LOG[_x] = _i
    _x <<= 1
    if _x & 0x100:
        _x ^= _PRIM
_EXP[255:510] = _EXP[0:255]
_EXP[510] = _EXP[0]
_EXP[511] = _EXP[1]

EXP = _EXP
LOG = _LOG


def gf_mul(a: int, b: int) -> int:
    if a == 0 or b == 0:
        return 0
    return int(_EXP[int(_LOG[a]) + int(_LOG[b])])


def gf_div(a: int, b: int) -> int:
    if b == 0:
        raise ZeroDivisionError("GF division by zero")
    if a == 0:
        return 0
    return int(_EXP[(int(_LOG[a]) - int(_LOG[b])) % 255])


def gf_pow(a: int, n: int) -> int:
    if a == 0:
        return 0
    return int(_EXP[(int(_LOG[a]) * n) % 255])


def gf_inv(a: int) -> int:
    if a == 0:
        raise ZeroDivisionError("GF inverse of zero")
    return int(_EXP[(255 - int(_LOG[a])) % 255])


# ----------------------------------------------------- ascending-order helpers
def _asc_mul(p, q):
    r = [0] * (len(p) + len(q) - 1)
    for i, pi in enumerate(p):
        if pi:
            lp = int(_LOG[pi])
            for j, qj in enumerate(q):
                if qj:
                    r[i + j] ^= int(_EXP[lp + int(_LOG[qj])])
    return r


def _asc_add(p, q):
    n = max(len(p), len(q))
    r = [0] * n
    for i, v in enumerate(p):
        r[i] ^= v
    for i, v in enumerate(q):
        r[i] ^= v
    return r


def _asc_eval(p, x):
    """Evaluate an ascending-order polynomial at x (Horner from the top)."""
    y = 0
    for c in reversed(p):
        y = gf_mul(y, x) ^ c
    return y


def _desc_eval(p, x):
    """Evaluate a descending-order polynomial (p[0] = highest degree) at x."""
    y = 0
    for c in p:
        y = gf_mul(y, x) ^ int(c)
    return y


class ReedSolomon:
    """RS(n, k).  nsym = n-k parity bytes per codeword, corrects nsym//2 bytes."""

    def __init__(self, n: int = 255, k: int = 223):
        if not (0 < k < n <= 255):
            raise ValueError("need 0 < k < n <= 255 for GF(256)")
        self.n = int(n)
        self.k = int(k)
        self.nsym = self.n - self.k
        self.t = self.nsym // 2
        self._powmat_cache: dict[int, np.ndarray] = {}

        # Generator polynomial, DESCENDING order, monic: prod (x - alpha^i)
        g = [1]
        for i in range(self.nsym):
            g = self._desc_mul(g, [1, gf_pow(2, i)])
        self.gen = g                                     # length nsym+1
        # Fast encode table: gen[1:] scaled by every possible feedback value.
        self._gmul = np.zeros((256, self.nsym), dtype=np.uint8)
        for c in range(256):
            for j in range(1, len(g)):
                self._gmul[c, j - 1] = gf_mul(g[j], c)

    @staticmethod
    def _desc_mul(p, q):
        r = [0] * (len(p) + len(q) - 1)
        for i, pi in enumerate(p):
            if pi:
                lp = int(_LOG[pi])
                for j, qj in enumerate(q):
                    if qj:
                        r[i + j] ^= int(_EXP[lp + int(_LOG[qj])])
        return r

    # ------------------------------------------------------------------ split
    def block_sizes(self, nbytes: int) -> list[int]:
        """Deterministic, balanced split of nbytes into <= k-byte blocks.

        Both ends compute this from the payload length in the header, so the
        receiver always reproduces the transmitter's blocking exactly.
        """
        nblocks = max(1, int(np.ceil(nbytes / self.k)))
        base = nbytes // nblocks
        rem = nbytes % nblocks
        return [base + (1 if i < rem else 0) for i in range(nblocks)]

    def encoded_len(self, nbytes: int) -> int:
        return nbytes + len(self.block_sizes(nbytes)) * self.nsym

    # ----------------------------------------------------------------- encode
    def encode_block(self, data: bytes) -> bytes:
        """Systematic encode of up to k bytes (shortened codeword if fewer)."""
        if len(data) > self.k:
            raise ValueError("RS block too long")
        par = np.zeros(self.nsym, dtype=np.uint8)
        gm = self._gmul
        for c in data:
            coef = int(c) ^ int(par[0])
            par[:-1] = par[1:]
            par[-1] = 0
            if coef:
                par ^= gm[coef]
        return bytes(data) + par.tobytes()

    def encode(self, data: bytes) -> bytes:
        out = bytearray()
        pos = 0
        for sz in self.block_sizes(len(data)):
            out += self.encode_block(data[pos:pos + sz])
            pos += sz
        return bytes(out)

    # ----------------------------------------------------------------- decode
    def _syndromes(self, cw) -> list[int]:
        """S_j = c(alpha^j), j = 0..nsym-1  (cw is descending order)."""
        # Horner in Python costs len(cw) * nsym GF multiplies -- 8160 calls for
        # one 255-byte codeword, and it showed up as 7% of the whole receiver.
        # Written as a table lookup it is one vectorised pass: build alpha^(j*k)
        # once per codeword length, multiply in the log domain, XOR-reduce.
        arr = np.asarray(cw, dtype=np.uint8)
        m = len(arr)
        mat = self._powmat_cache.get(m)
        if mat is None:
            k = np.arange(m - 1, -1, -1, dtype=np.int64)
            mat = _EXP[(np.outer(np.arange(self.nsym, dtype=np.int64), k) % 255)]
            self._powmat_cache[m] = mat
        la = _LOG[arr].astype(np.int64)[None, :]
        lm = _LOG[mat].astype(np.int64)
        prod = np.where((arr[None, :] == 0) | (mat == 0), 0,
                        _EXP[(la + lm) % 255])
        return [int(v) for v in np.bitwise_xor.reduce(prod.astype(np.uint8), axis=1)]

    def _berlekamp_massey(self, S) -> list[int]:
        """Massey's algorithm.  Returns Lambda in ASCENDING order, Lambda_0 = 1.

        Lambda(x) = prod_p (1 - X_p x)  with  X_p = alpha^(error degree p).
        """
        lam = [1]
        B = [1]
        L = 0
        b = 1
        m = 1
        for n in range(self.nsym):
            d = S[n]
            for i in range(1, L + 1):
                if i < len(lam):
                    d ^= gf_mul(lam[i], S[n - i])
            if d == 0:
                m += 1
            else:
                coef = gf_div(d, b)
                shifted = [0] * m + [gf_mul(coef, c) for c in B]
                if 2 * L <= n:
                    T = lam[:]
                    lam = _asc_add(lam, shifted)
                    L = n + 1 - L
                    B = T
                    b = d
                    m = 1
                else:
                    lam = _asc_add(lam, shifted)
                    m += 1
        while len(lam) > 1 and lam[-1] == 0:
            lam.pop()
        return lam

    def _roots(self, lam, m_len: int):
        """Chien search.

        Lambda has roots at x = X_p^-1 = alpha^(-p), so if Lambda(alpha^k) == 0
        the error is at DEGREE p = (-k) mod 255, i.e. array index m_len-1-p.
        """
        degs = []
        for kk in range(255):
            if _asc_eval(lam, gf_pow(2, kk)) == 0:
                p = (255 - kk) % 255
                idx = m_len - 1 - p
                if 0 <= idx < m_len:
                    degs.append(p)
        return degs

    def _forney(self, S, lam, degs):
        """Error magnitudes.

        Omega(x) = [S(x) Lambda(x)] mod x^nsym   (both ascending)
        e_q = Omega(X_q^-1) / prod_{p != q} (1 + X_p X_q^-1)       [char 2]
        (the usual X^(1-fcr) factor cancels because fcr = 0 here)
        """
        omega = _asc_mul(list(S), lam)[:self.nsym]
        X = [gf_pow(2, p) for p in degs]
        mags = []
        for q, Xq in enumerate(X):
            Xq_inv = gf_inv(Xq)
            num = _asc_eval(omega, Xq_inv)
            den = 1
            for p, Xp in enumerate(X):
                if p != q:
                    den = gf_mul(den, 1 ^ gf_mul(Xp, Xq_inv))
            if den == 0:
                return None
            mags.append(gf_div(num, den))
        return mags

    def decode_block(self, block: bytes):
        """Correct one (possibly shortened) codeword.

        Returns (data_bytes, n_bytes_corrected) or (None, -1) if uncorrectable.
        """
        cw = list(np.frombuffer(block, dtype=np.uint8))
        m_len = len(cw)
        S = self._syndromes(cw)
        if max(S) == 0:
            return bytes(cw[:m_len - self.nsym]), 0

        lam = self._berlekamp_massey(S)
        nerr = len(lam) - 1
        if nerr == 0 or nerr > self.t:
            return None, -1

        degs = self._roots(lam, m_len)
        if len(degs) != nerr:
            return None, -1

        mags = self._forney(S, lam, degs)
        if mags is None:
            return None, -1

        for p, e in zip(degs, mags):
            cw[m_len - 1 - p] ^= e

        if max(self._syndromes(cw)) != 0:
            return None, -1
        return bytes(cw[:m_len - self.nsym]), len(degs)

    def decode(self, encoded: bytes, nbytes: int):
        """Decode the concatenation produced by encode().

        nbytes : original (pre-RS) byte count, taken from the frame header.
        Returns (data, total_byte_corrections) or (None, -1).
        """
        out = bytearray()
        pos = 0
        total = 0
        for sz in self.block_sizes(nbytes):
            need = sz + self.nsym
            blk = encoded[pos:pos + need]
            pos += need
            if len(blk) < need:
                return None, -1
            data, ncorr = self.decode_block(blk)
            if data is None:
                return None, -1
            out += data
            total += ncorr
        return bytes(out), total
