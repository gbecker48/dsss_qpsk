#!/usr/bin/env python3
"""
hw_file_test.py -- send a real file over the REAL radio and check every byte.

    python hw_file_test.py                       32 kB of random data
    python hw_file_test.py -b 131072             128 kB
    python hw_file_test.py -f report.pdf         a file you actually care about
    python hw_file_test.py --nostream            per-segment ARQ instead
    python hw_file_test.py --web                 also serve the dashboard

WHAT IT PROVES
    Messages are one burst each with a round trip between them, so they never
    exercise the receiver back to back.  A file does: hundreds of bursts, one
    after another, with nothing but the pacing gap in between.  That is a
    different and much harder test of the receiver, and it is the one that found
    the strong-signal sync bug.

    It checks the SHA-256 of what came out of the inbox against what went in, so
    "it worked" means every byte, not "the progress bar filled up".
"""

import argparse
import hashlib
import shutil
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from dsss_qpsk import config as cfg              # noqa: E402
from dsss_qpsk.filexfer import human             # noqa: E402
from dsss_qpsk.link import LinkManager           # noqa: E402


def main():
    p = argparse.ArgumentParser()
    p.add_argument("-b", "--bytes", type=int, default=32768)
    p.add_argument("-f", "--file", default=None)
    p.add_argument("--timeout", type=float, default=900.0)
    p.add_argument("--txgain", type=float, default=None)
    p.add_argument("--rxgain", type=float, default=None)
    p.add_argument("--nostream", action="store_true")
    p.add_argument("--pace", type=float, default=None,
                   help="FILE_STREAM_PACE: burst air time multiplier. 1.06 packs "
                        "the air tight; higher leaves idle time for the receiver "
                        "to catch up on a slower machine (see run_sim.py bench)")
    p.add_argument("--web", action="store_true")
    p.add_argument("--cfo", type=float, default=None,
                   help="RX_FREQ_OFFSET_HZ: retune the RECEIVE synthesizer this "
                        "far from the transmit one.  A real hardware carrier "
                        "offset from a real independent PLL -- the only way to "
                        "exercise acquisition's Doppler search and the fine CFO "
                        "estimator on a single radio.  Search covers +/-16.1 kHz.")
    p.add_argument("--ppm", type=float, default=None,
                   help="TX_SFO_PPM: resample the burst before the DAC so the "
                        "chip rate that comes back differs from the receiver's "
                        "by this many ppm.  This is what a sample clock offset "
                        "IS; the DLL cannot tell it from a second crystal.")
    a = p.parse_args()

    if a.cfo is not None:
        cfg.RX_FREQ_OFFSET_HZ = float(a.cfo)
    if a.ppm is not None:
        cfg.TX_SFO_PPM = float(a.ppm)
    if a.txgain is not None:
        cfg.TX_GAIN_DB = a.txgain
    if a.rxgain is not None:
        cfg.RX_GAIN_DB = a.rxgain
    if a.nostream:
        cfg.FILE_STREAM_MODE = False
    if a.pace is not None:
        cfg.FILE_STREAM_PACE = float(a.pace)
    inbox = HERE / "inbox_hw"
    shutil.rmtree(inbox, ignore_errors=True)
    cfg.FILE_INBOX = str(inbox)
    cfg.recompute()

    if a.file:
        src = Path(a.file)
        payload = src.read_bytes()
    else:
        payload = bytes(np.random.default_rng(11).integers(
            0, 256, a.bytes, dtype=np.uint8))
        src = HERE / "hw_testfile.bin"
        src.write_bytes(payload)
    want = hashlib.sha256(payload).hexdigest()

    print("=" * 74)
    print("  FILE TRANSFER OVER THE RADIO")
    print("=" * 74)
    print(f"  file      : {src.name}  {human(len(payload))}")
    print(f"  segments  : {cfg.FILE_SEGMENT_BYTES} B payload each")
    print(f"  mode      : {'STREAM (unacknowledged + repair)' if cfg.FILE_STREAM_MODE else 'per-segment ARQ'}")
    print(f"  gains     : TX {cfg.TX_GAIN_DB}  RX {cfg.RX_GAIN_DB}")
    print(f"  pace      : {cfg.FILE_STREAM_PACE:.2f}x burst air time  "
          f"(~{100/cfg.FILE_STREAM_PACE:.0f} % duty cycle)")
    print(f"  sha256    : {want[:32]}...")
    print()

    from dsss_qpsk import transports
    tr = transports.UsrpTransport(cfg)
    print(f"  radio     : {tr.describe()}")
    link = LinkManager(cfg, tr)
    dash = None
    if a.web:
        from dsss_qpsk.webui import Dashboard
        dash = Dashboard(cfg, link, port=cfg.WEB_PORT, host=cfg.WEB_HOST)
        print(f"  dashboard : {dash.start()}")
    print()

    tr.start()
    link.start()
    time.sleep(1.0)                      # let the receiver see some noise first

    t0 = time.time()
    link.send_file(src)
    got, last = None, ""
    try:
        while time.time() - t0 < a.timeout:
            time.sleep(1.0)
            snap = link.files.snapshot()
            rxs = [t for t in snap["active"] + snap["history"] if t["dir"] == "rx"]
            txs = [t for t in snap["active"] + snap["history"] if t["dir"] == "tx"]
            if rxs or txs:
                t = (rxs or txs)[0]
                line = (f"  {t['seg_done']:5d}/{t['nseg']:<5d} segments  "
                        f"{t['pct']:5.1f}%  {human(t['rate'])}/s  "
                        f"eta {t['eta']:5.0f} s  {t['state']}")
                if line != last:
                    print(line, flush=True)
                    last = line
            done = [r for r in rxs if r["state"] in ("complete", "failed")]
            if done:
                got = done[0]
                break
    except KeyboardInterrupt:
        pass
    finally:
        if dash is not None:
            dash.stop()
        link.stop()
        tr.stop()

    el = time.time() - t0
    m = link.metrics()
    print()
    print("=" * 74)
    if got is None:
        print(f"  FAIL: the transfer never finished ({el:.0f} s)")
        print(f"  rx stats: {link.rx.stats}")
        return 1
    blob = Path(got["path"]).read_bytes() if got.get("path") else b""
    same = hashlib.sha256(blob).hexdigest() == want
    print(f"  bytes            : {len(blob)} / {len(payload)}")
    print(f"  sha256 match     : {same}")
    print(f"  wall time        : {el:.1f} s   ({human(len(payload)/max(el,1e-6))}/s"
          f"  = {8*len(payload)/max(el,1e-6)/1000:.1f} kbit/s)")
    print(f"  segments         : {got['nseg']}   repair rounds: {got['repairs']}")
    print(f"  link retries     : {m['retries']}   lost messages: {m['lost']}")
    print(f"  STREAM frames    : tx {m['stream_tx']}  rx {m['stream_rx']}")
    if m['stream_tx']:
        print(f"  efficiency       : {100.0*got['nseg']/m['stream_tx']:.0f} % "
              f"(segments delivered per STREAM burst transmitted)")
    print(f"  last frame       : EVM {m.get('evm_pct', float('nan')):.2f} %   "
          f"chip SNR {m.get('snr_chip_db', float('nan')):.1f} dB   "
          f"sym SNR {m.get('snr_sym_db', float('nan')):.1f} dB")
    print(f"  rx stats         : {link.rx.stats}")
    s = link.rx.stats
    if s.payload_fail or s.false_acquisitions:
        print(f"  NOTE: {s.payload_fail} payload failures and "
              f"{s.false_acquisitions} rejected acquisitions.  If you also saw "
              f"'U' underruns, the machine is over its sustainable duty cycle "
              f"-- run `python run_sim.py bench` and raise --pace accordingly.")
    print(f"  saved to         : {got.get('path')}")
    print()
    print(f"  VERDICT: {'PASS' if same else 'FAIL - contents differ'}")
    print("=" * 74)
    return 0 if same else 1


if __name__ == "__main__":
    sys.exit(main())
