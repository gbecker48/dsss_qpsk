#!/usr/bin/env python3
r"""
verify_grc.py -- compile the .grc files and prove the flowgraph really decodes.

    python grc/verify_grc.py                 compile + run the sim at 4 SNRs
    python grc/verify_grc.py --seconds 20    run each point longer
    python grc/verify_grc.py --compile-only  just check both files compile

A flowgraph that opens without an error is not the same as a flowgraph that
works.  This compiles the .grc with grcc exactly as GRC would, imports the
generated top block, runs it headless at several settings of the SNR slider,
and checks that frames actually decode -- including well below the noise floor,
which is the whole point of the thing.

On Windows in radioconda this runs as-is.  On a headless box, wrap it:
    xvfb-run -a python grc/verify_grc.py
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
sys.path.insert(0, str(PROJECT))
sys.path.insert(0, str(HERE))

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

# GRC's Function Probe runs in a daemon thread that keeps touching the top
# block after stop().  Holding a reference stops Python freeing the C++ object
# underneath it, which is otherwise a segfault on the way out.
_KEEP = []


def compile_grc(name: str) -> Path:
    src = HERE / name
    print(f"  compiling {src.name} ...", flush=True)
    r = subprocess.run([sys.executable, "-c",
                        "from gnuradio.grc.compiler import main; main()",
                        "-o", str(HERE), str(src)],
                       capture_output=True, text=True)
    out = (r.stdout or "") + (r.stderr or "")
    bad = [ln for ln in out.splitlines()
           if "Error" in ln or "Traceback" in ln or "error:" in ln.lower()]
    if bad or r.returncode != 0:
        print("    FAILED")
        print("   ", "\n    ".join(out.strip().splitlines()[-12:]))
        raise SystemExit(1)
    gen = HERE / (src.stem + ".py")
    print(f"    ok -> {gen.name}")
    return gen


def sweep(tb, app, points, seconds, interval=0.4, payload=64, cfo=800.0):
    """Drag the slider on a RUNNING flowgraph, exactly as you would by hand."""
    tb.set_cfo_hz(cfo)
    tb.set_interval(interval)
    tb.set_payload_bytes(payload)
    rows = []
    for snr in points:
        tb.set_snr_db(snr)
        # Let the level settle and the current burst finish before counting.
        t0 = time.time()
        while time.time() - t0 < 1.0:
            app.processEvents()
            time.sleep(0.05)
        tb.dsss_rx.reset_counters()
        tb.dsss_tx.reset_counters()
        t0 = time.time()
        while time.time() - t0 < seconds:
            app.processEvents()
            time.sleep(0.05)
        rx, tx, corr = tb.dsss_rx, tb.dsss_tx, tb.dsss_corr
        sent = max(int(tx.bursts_sent) - 1, 1)     # one may still be on the air
        rows.append({
            "snr": snr, "sent": sent,
            "ok": int(rx.frames_ok), "bad": int(rx.frames_bad),
            "pct": 100.0 * min(int(rx.frames_ok), sent) / sent,
            "meas": rx.mean_snr_chip_db(), "evm": rx.mean_evm_pct(),
            "corr": float(corr.peak()), "text": rx.last_message(),
        })
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seconds", type=float, default=12.0)
    ap.add_argument("--compile-only", action="store_true")
    a = ap.parse_args()

    print("=" * 76)
    print("  GNU RADIO COMPANION FLOWGRAPH VERIFICATION")
    print("=" * 76)
    compile_grc("dsss_qpsk_sim.grc")
    compile_grc("dsss_qpsk_radio.grc")
    print("    (the radio flowgraph compiles; running it needs the USRP)")
    if a.compile_only:
        return 0

    print()
    print("  Starting the flowgraph ONCE and dragging the SNR slider, which is")
    print("  what you will actually do.  'corr peak' is the despread")
    print("  correlation pulse height the Despread Correlation plot shows.")
    print()
    import dsss_qpsk_sim                                    # noqa: E402
    from PyQt5 import Qt                                    # noqa: E402
    app = Qt.QApplication.instance() or Qt.QApplication(sys.argv)
    tb = dsss_qpsk_sim.dsss_qpsk_sim()
    _KEEP.append(tb)
    tb.start()

    points = [10.0, 0.0, -6.0, -10.0, -13.0]
    rows = sweep(tb, app, points, a.seconds)
    tb.stop()
    tb.wait()

    hdr = (f"  {'slider dB':>9s} {'bursts':>7s} {'decoded':>8s} {'failed':>7s} "
           f"{'ok %':>6s} {'measured dB':>12s} {'error':>7s} {'EVM %':>7s} "
           f"{'corr pk':>8s}  verdict")
    print(hdr)
    print("  " + "-" * (len(hdr) - 2))
    fails = []
    for r in rows:
        # -13 dB is the rated sensitivity limit (95% in the validation suite);
        # everything above it should be essentially perfect.
        want = 85.0 if r["snr"] <= -13.0 else 95.0
        good = r["pct"] >= want
        if not good:
            fails.append(r["snr"])
        err = r["meas"] - r["snr"]
        print(f"  {r['snr']:9.1f} {r['sent']:7d} {r['ok']:8d} {r['bad']:7d} "
              f"{r['pct']:6.0f} {r['meas']:12.2f} {err:+7.2f} {r['evm']:7.2f} "
              f"{r['corr']:8.1f}  {'PASS' if good else 'FAIL'}")
    errs = [r["meas"] - r["snr"] for r in rows if r["ok"]]
    print()
    print(f"  slider calibration: mean error {sum(errs)/len(errs):+.2f} dB, "
          f"worst {max(errs, key=abs):+.2f} dB")
    print(f"  last message decoded: {rows[-1]['text'][:58]!r}")
    print("=" * 76)
    if fails:
        print(f"  FAILED at slider settings: {fails}")
        return 1
    print("  ALL FLOWGRAPH CHECKS PASSED")
    print("=" * 76)
    return 0


if __name__ == "__main__":
    code = main()
    sys.stdout.flush()
    os._exit(code)       # do not run interpreter teardown under live Qt threads
