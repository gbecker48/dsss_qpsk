"""DSSS PN matched filter

Samples in, despread correlation in dB above the noise out.
A burst that is invisible in the spectrum makes an obvious
pulse here.  Two outputs on one 0-to-1 scale: output 0 knows
the spreading code, output 1 is the identical measurement with
a flat template instead.  The second one never moves, because
without the code a DSSS burst and noise are the same thing.
"""
import os
import sys

_HINTS = ["C:/Users/garre/OneDrive/Desktop/DSSS_QPSK"]
try:
    _HINTS.append(os.path.dirname(os.path.abspath(__file__)))
except NameError:
    pass
_HINTS.append(os.getcwd())
for _h in list(_HINTS):
    _p = _h
    for _ in range(3):
        _p = os.path.dirname(_p) if _p else ""
        _HINTS.append(_p)
for _h in _HINTS:
    if _h and os.path.isdir(os.path.join(_h, "dsss_qpsk")) and _h not in sys.path:
        sys.path.insert(0, _h)
        break

# Bound under BOTH names on purpose: GRC's block loader looks for any class in
# this file, and the code it generates calls it by its real name.
from dsss_qpsk.blocks.grc_blocks import DsssPnMatchedFilter          # noqa: E402

blk = DsssPnMatchedFilter
