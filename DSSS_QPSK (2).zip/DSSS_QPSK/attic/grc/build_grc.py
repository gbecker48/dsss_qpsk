#!/usr/bin/env python3
r"""
build_grc.py -- generate the GNU Radio Companion flowgraphs.

    python grc/build_grc.py

Writes:
    grc/dsss_qpsk_sim.grc       simulation, with an SNR slider
    grc/dsss_qpsk_radio.grc     the real B206mini, same plots

WHY GENERATED AND NOT HAND-DRAWN
    A .grc file is YAML with a hundred parameters per QT GUI sink, and the
    interesting part -- which blocks connect to what, and how the panels are
    laid out -- is about twenty lines.  Generating it keeps those twenty lines
    readable, keeps the two flowgraphs in step with each other, and means a
    change to the layout is a one-line edit here rather than a hunt through
    3000 lines of YAML.

    You can still open the result in GRC and edit it normally.  Nothing about it
    is unusual -- it is an ordinary flowgraph.
"""

from __future__ import annotations

import sys
from pathlib import Path

import yaml

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
# Where the project lives on the machine that will RUN the flowgraph.  It is
# also a parameter on every block, so you can change it in GRC without coming
# back here.
DEFAULT_PROJECT_PATH = r"C:\Users\garre\OneDrive\Desktop\DSSS_QPSK"

GRC_VERSION = "3.10.9.2"


# ---------------------------------------------------------------- epy sources
# Each embedded block is a ten-line shim: put the project on sys.path, then
# import the real class.  GRC's block loader execs this snippet and takes the
# first gr block class it finds, so importing the class under the name `blk` is
# all it takes -- no duplicated DSP, and editing grc_blocks.py updates both
# flowgraphs and the command-line tools at once.
BOOT = '''"""{title}

{doc}
"""
import os
import sys

_HINTS = ["{project}"]
try:
    _HINTS.append(os.path.dirname(os.path.abspath(__file__)))
except NameError:
    pass
_HINTS.append(os.getcwd())
for _h in list(_HINTS):
    _p = _h
    for _ in range(3):
        _p = os.path.dirname(_p) if _p else ""
        _HINTS.append(_p)
for _h in _HINTS:
    if _h and os.path.isdir(os.path.join(_h, "dsss_qpsk")) and _h not in sys.path:
        sys.path.insert(0, _h)
        break

# Bound under BOTH names on purpose: GRC's block loader looks for any class in
# this file, and the code it generates calls it by its real name.
from dsss_qpsk.blocks.grc_blocks import {cls}          # noqa: E402

blk = {cls}
'''


def _posix(path: str) -> str:
    r"""Windows paths go into Python source, so they must not carry backslashes.

    r"C:\Users\garre\..." looks safe until the path ends in a separator, and
    plain "C:\Users\..." is an outright syntax error -- \U starts a unicode
    escape, which is exactly how the first build failed on the real machine.
    Windows accepts forward slashes everywhere Python is concerned, so use them.
    """
    return str(path).replace("\\", "/")


def epy(cls, title, doc, project):
    return BOOT.format(cls=cls, title=title, doc=doc, project=_posix(project))


# ------------------------------------------------------------------ helpers
_Y = 0


def blk(bid, name, params, x, y, **states):
    st = {"bus_sink": False, "bus_source": False, "bus_structure": None,
          "coordinate": [int(x), int(y)], "rotation": 0, "state": "enabled"}
    st.update(states)
    p = {"comment": ""}
    p.update({k: str(v) for k, v in params.items()})
    return {"name": name, "id": bid, "parameters": p, "states": st}


def var(name, value, x, y):
    return blk("variable", name, {"value": value}, x, y)


def rng(name, label, value, start, stop, step, x, y, hint, widget="counter_slider"):
    return blk("variable_qtgui_range", name, {
        "label": label, "rangeType": "float", "value": value,
        "start": start, "stop": stop, "step": step,
        "widget": widget, "orient": "Qt.Horizontal", "min_len": "200",
        "gui_hint": hint}, x, y)


def label(name, lab, value, x, y, hint):
    # The block's GRC id is variable_qtgui_label, not qtgui_label.  Get it wrong
    # and the block is dropped from the generated flowgraph without a word.
    return blk("variable_qtgui_label", name, {
        "label": lab, "type": "string", "value": value,
        "formatter": "None", "gui_hint": hint}, x, y)


def probe(name, block_id, fn, poll, x, y, value="0"):
    return blk("variable_function_probe", name, {
        "block_id": block_id, "function_name": fn, "function_args": "",
        "poll_rate": poll, "value": value}, x, y)


# =========================================================================== #
def constellation_sink(name, hint, x, y, title="Constellation",
                       xmax="1.6", ymax="1.6"):
    return blk("qtgui_const_sink_x", name, {
        "type": "complex", "name": f'"{title}"', "size": "2048",
        "grid": "True", "autoscale": "False",
        "xmin": f"-{xmax}", "xmax": xmax, "ymin": f"-{ymax}", "ymax": ymax,
        "nconnections": "1", "update_time": "0.10",
        "tr_mode": "qtgui.TRIG_MODE_FREE", "tr_slope": "qtgui.TRIG_SLOPE_POS",
        "tr_level": "0.0", "tr_chan": "0", "tr_tag": '""',
        "legend": "False", "axislabels": "True",
        "label1": '"payload symbols"', "width1": "1", "color1": '"cyan"',
        "style1": "0", "marker1": "0", "alpha1": "0.55",
        "gui_hint": hint}, x, y)


def freq_sink(name, hint, x, y, title, srate="samp_rate", ymin="-85", ymax="-5"):
    return blk("qtgui_freq_sink_x", name, {
        "type": "complex", "name": f'"{title}"', "fftsize": "2048",
        "freqhalf": "True", "wintype": "window.WIN_BLACKMAN_hARRIS",
        "norm_window": "False", "fc": "0", "bw": srate,
        "grid": "True", "autoscale": "False", "average": "0.15",
        "ymin": ymin, "ymax": ymax, "label": '"Relative Gain"', "units": '"dB"',
        "nconnections": "1", "update_time": "0.10", "showports": "False",
        "tr_mode": "qtgui.TRIG_MODE_FREE", "tr_level": "0.0", "tr_chan": "0",
        "tr_tag": '""', "ctrlpanel": "False",
        "legend": "True", "axislabels": "True",
        "label1": '"channel output"', "width1": "2", "color1": '"blue"',
        "alpha1": "1.0", "gui_hint": hint}, x, y)


def waterfall_sink(name, hint, x, y, title, srate="samp_rate"):
    return blk("qtgui_waterfall_sink_x", name, {
        "type": "complex", "name": f'"{title}"', "fftsize": "1024",
        "freqhalf": "True", "wintype": "window.WIN_BLACKMAN_hARRIS",
        "fc": "0", "bw": srate, "int_min": "-50", "int_max": "-5",
        "grid": "True", "nconnections": "1", "update_time": "0.10",
        "showports": "False", "legend": "False", "axislabels": "True",
        "label1": '""', "color1": "0", "alpha1": "1.0",
        "gui_hint": hint}, x, y)


def time_sink(name, hint, x, y, title, dtype="float", size="1024",
              srate="samp_rate", ymin="-5", ymax="30", ylabel='"dB"',
              tr_mode="qtgui.TRIG_MODE_FREE", tr_level="0.0", tr_delay="0",
              label1='"trace"', color1='"blue"', autoscale="False",
              nconn="1", label2='"trace 2"', color2='"red"'):
    return blk("qtgui_time_sink_x", name, {
        "type": dtype, "name": f'"{title}"', "ylabel": ylabel, "yunit": '""',
        "size": size, "srate": srate, "grid": "True", "autoscale": autoscale,
        "ymin": ymin, "ymax": ymax, "nconnections": nconn,
        "update_time": "0.10", "entags": "True",
        "tr_mode": tr_mode, "tr_slope": "qtgui.TRIG_SLOPE_POS",
        "tr_level": tr_level, "tr_delay": tr_delay, "tr_chan": "0", "tr_tag": '""',
        "ctrlpanel": "False", "legend": "True", "axislabels": "True",
        "stemplot": "False",
        # color1/color2 on the time sink are ENUMs whose options are bare
        # words, so a quoted value silently falls back to the default.
        "label1": label1, "width1": "2", "color1": color1.strip('"'),
        "style1": "1",
        "marker1": "-1", "alpha1": "1.0",
        "label2": label2, "width2": "2", "color2": color2.strip('"'),
        "style2": "1",
        "marker2": "-1", "alpha2": "1.0",
        "gui_hint": hint}, x, y)


# =========================================================================== #
def common_blocks(project_path, hardware=False):
    """Everything both flowgraphs share: the modem blocks and all the plots."""
    project_path = _posix(project_path)
    b = []
    c = []

    tx_doc = ("Transmits one DSSS/QPSK burst every `interval` seconds and is\n"
              "silent in between.  The burst is scaled to unit mean power over\n"
              "its own duration, which is what makes the SNR slider mean\n"
              "exactly what it says.")
    rx_doc = ("Samples in, decoded PAYLOAD symbols out.  Wire the output to a\n"
              "Constellation Sink: you get only real, phase-corrected payload\n"
              "symbols, with no preamble and nothing from the gaps between\n"
              "bursts.  Every measurement is a method, for the Function Probe.")
    demo_doc = ("Three views of the same data, side by side: the QPSK symbols\n"
                "before spreading (narrow, 32 kHz), the same symbols after\n"
                "spreading (wide, 1 MHz, 15 dB lower for the same power), and\n"
                "the symbols themselves for a constellation.  Continuous, not\n"
                "bursty, because it is a display -- it carries no frames.")

    mf_doc = ("Samples in, despread correlation in dB above the noise out.\n"
              "A burst that is invisible in the spectrum makes an obvious\n"
              "pulse here.  Two outputs on one 0-to-1 scale: output 0 knows\n"
              "the spreading code, output 1 is the identical measurement with\n"
              "a flat template instead.  The second one never moves, because\n"
              "without the code a DSSS burst and noise are the same thing.")

    b.append(blk("epy_block", "dsss_tx", {
        "_source_code": epy("DsssTxSource", "DSSS/QPSK burst transmitter",
                            tx_doc, project_path),
        "project_path": f'"{project_path}"',
        "payload_bytes": "payload_bytes", "interval": "interval",
        "amplitude": "1.0", "text": '""', "spreading_factor": "0",
        "affinity": "", "alias": "", "maxoutbuf": "0", "minoutbuf": "0",
    }, 350, 160))

    b.append(blk("epy_block", "dsss_rx", {
        "_source_code": epy("DsssRxSymbols", "DSSS/QPSK receiver",
                            rx_doc, project_path),
        "project_path": f'"{project_path}"',
        "spreading_factor": "0", "max_symbols": "4096",
        "window_width": "1900", "window_height": "1300",
        "affinity": "", "alias": "", "maxoutbuf": "0", "minoutbuf": "0",
    }, 900, 300))

    b.append(blk("epy_block", "dsss_corr", {
        "_source_code": epy("DsssPnMatchedFilter", "DSSS PN matched filter",
                            mf_doc, project_path),
        "project_path": f'"{project_path}"',
        "spreading_factor": "0", "periods": "32", "coherent": "16",
        "average": "0.02",
        "affinity": "", "alias": "", "maxoutbuf": "0", "minoutbuf": "0",
    }, 900, 430))

    # ---- the plots ------------------------------------------------------
    b.append(constellation_sink(
        "const", "tabs@0: 0,0,5,6", 1250, 280,
        "AFTER despreading - the decoded payload symbols"))
    b.append(constellation_sink(
        "rawconst", "tabs@0: 0,6,5,6", 1250, 180,
        "BEFORE despreading - the samples as they arrive",
        xmax="4", ymax="4"))
    b.append(freq_sink("spectrum", "tabs@1: 0,0,6,12", 900, 90,
                       "Spectrum at the receiver input - look for the signal"))
    b.append(waterfall_sink("waterfall", "tabs@1: 6,0,6,12", 900, 190,
                            "Waterfall"))

    # One output value per `periods` symbols, so the sink's time axis has to be
    # samp_rate / (sps * sf * periods) or the trigger delay lands off-screen.
    b.append(time_sink("corr", "tabs@0: 5,0,5,12", 1250, 430,
                       "Match to the spreading code, 0 to 1 - green knows the "
                       "code, red does not",
                       dtype="float", size="512",
                       srate="samp_rate/(sps*sf*32)", ymin="0", ymax="0.75",
                       ylabel='"normalised correlation"',
                       tr_mode="qtgui.TRIG_MODE_AUTO", tr_level="0.12",
                       tr_delay="0.05", nconn="2",
                       label1='"with the code"', color1='"dark green"',
                       label2='"without the code"', color2='"red"'))

    # ---- what spreading actually does, on its own tab -------------------
    b.append(blk("epy_block", "spread_demo", {
        "_source_code": epy("DsssSpreadingDemo", "DSSS spreading demo",
                            demo_doc, project_path),
        "project_path": f'"{_posix(project_path)}"',
        "spreading_factor": "0", "amplitude": "1.0",
        "affinity": "", "alias": "", "maxoutbuf": "0", "minoutbuf": "0",
    }, 350, 820))
    b.append(constellation_sink(
        "demo_const", "tabs@2: 0,0,5,6", 900, 820,
        "BEFORE spreading - the QPSK symbols themselves"))
    b.append(freq_sink("demo_narrow", "tabs@2: 0,6,5,6", 900, 900,
                       "BEFORE spreading - one QPSK symbol per 31 us, "
                       "about 32 kHz wide", ymin="-90", ymax="0"))
    b.append(freq_sink("demo_wide", "tabs@2: 5,6,5,6", 900, 980,
                       "AFTER spreading - the same data and the same power, "
                       "31x the bandwidth and 15 dB lower", ymin="-90",
                       ymax="0"))
    b.append(constellation_sink(
        "demo_chips", "tabs@2: 5,0,5,6", 900, 1060,
        "AFTER spreading - the chips", xmax="2.5", ymax="2.5"))
    c.append(["spread_demo", "0", "demo_narrow", "0"])
    c.append(["spread_demo", "1", "demo_wide", "0"])
    c.append(["spread_demo", "1", "demo_chips", "0"])
    c.append(["spread_demo", "2", "demo_const", "0"])
    c.append(["dsss_corr", "1", "corr", "1"])

    # ---- readouts -------------------------------------------------------
    b.append(probe("rx_status", "dsss_rx", "status_text", "5", 350, 560,
                   value='"waiting"'))
    b.append(probe("rx_message", "dsss_rx", "last_message", "5", 350, 640,
                   value='"-"'))
    b.append(label("lbl_status", '"link"', "rx_status", 600, 560, "2,0,1,12"))
    b.append(label("lbl_message", '"last message"', "rx_message", 600, 640,
                   "3,0,1,12"))

    # ---- send box -------------------------------------------------------
    # Two tabs, so every plot gets half a screen instead of a twelfth.
    b.append(blk("qtgui_tab_widget", "tabs", {
        "num_tabs": "3", "label0": "Receiving", "label1": "Spectrum",
        "label2": "What spreading does",
        "gui_hint": "4,0,12,12"}, 350, 740))

    b.append(blk("qtgui_edit_box_msg", "sendbox", {
        "type": "string", "value": '"hello over the air"',
        "label": '"type a message, press enter to send it"',
        "is_pair": "False", "is_static": "False", "key": '""',
        "gui_hint": "1,0,1,12"}, 350, 300))

    c.append(["sendbox", "msg", "dsss_tx", "send"])
    c.append(["dsss_rx", "0", "const", "0"])
    c.append(["dsss_corr", "0", "corr", "0"])
    return b, c


# =========================================================================== #
def simulation(project_path):
    b, c = [], []
    b.append(blk("import", "imports", {"imports": "import math"}, 10, 160))
    b.append(var("samp_rate", "2000000", 190, 12))
    b.append(var("sps", "2", 190, 76))
    b.append(var("sf", "31", 260, 76))
    # The constant is measured, not derived.  GNU Radio's Gaussian source
    # delivers 0.991 x noise_voltage^2 of complex noise power, and the burst
    # loses a little mean power to its own amplitude ramp; rather than model
    # either, the whole chain was run and the residual folded in here.  With
    # 0.988 the slider and the receiver's own measurement agree to within
    # 0.05 dB from +10 dB down to -13 dB -- see grc/verify_grc.py.
    b.append(var("noise_voltage",
                 "math.sqrt(sps / 10**(snr_db/10.0)) * 0.988", 330, 12))

    b.append(rng("snr_db", '"chip-band SNR (dB)   negative = BELOW the noise floor"',
                 "-10", "-25", "20", "0.5", 10, 12, "0,0,1,4"))
    b.append(rng("cfo_hz", '"carrier offset (Hz)"', "800", "-6000", "6000",
                 "50", 10, 76, "0,4,1,3"))
    b.append(rng("interval", '"seconds between bursts"', "0.5", "0.2", "3.0",
                 "0.1", 10, 236, "0,7,1,3"))
    b.append(rng("payload_bytes", '"payload bytes"', "64", "0", "512", "16",
                 10, 300, "0,10,1,2"))

    # Without a throttle a no-hardware flowgraph runs as fast as the CPU can
    # go: the "seconds between bursts" slider would mean nothing, the plots
    # would be an unreadable blur, and one core would sit at 100%.  The
    # throttle is what makes the simulation run in real time, like the radio.
    b.append(blk("blocks_throttle2", "throttle", {
        "type": "complex", "samples_per_second": "samp_rate", "vlen": "1",
        "ignoretag": "True", "limit": "auto", "maximum": "0.1",
        "affinity": "", "alias": "", "maxoutbuf": "0", "minoutbuf": "0"},
        480, 160))

    b.append(blk("channels_channel_model", "channel", {
        "noise_voltage": "noise_voltage",
        "freq_offset": "cfo_hz/samp_rate",
        "epsilon": "1.0000005", "taps": "[1.0]", "seed": "0",
        "block_tags": "False",
        "affinity": "", "alias": "", "maxoutbuf": "0", "minoutbuf": "0"},
        620, 160))

    bb, cc = common_blocks(project_path)
    b += bb
    c += cc
    c.append(["dsss_tx", "0", "throttle", "0"])
    c.append(["throttle", "0", "channel", "0"])
    for dst in ("dsss_rx", "dsss_corr", "spectrum", "waterfall", "rawconst"):
        c.append(["channel", "0", dst, "0"])
    return b, c


def radio(project_path):
    b, c = [], []
    b.append(blk("import", "imports", {"imports": "import math"}, 10, 160))
    b.append(var("samp_rate", "2000000", 190, 12))
    b.append(var("sps", "2", 190, 76))
    b.append(var("sf", "31", 260, 76))
    b.append(var("center_freq", "915e6", 330, 12))
    b.append(var("device_args", '""', 330, 76))

    b.append(rng("tx_gain", '"TX gain (dB)"', "40", "0", "89", "1", 10, 12,
                 "0,0,1,4"))
    b.append(rng("rx_gain", '"RX gain (dB)"', "20", "0", "76", "1", 10, 76,
                 "0,4,1,3"))
    b.append(rng("interval", '"seconds between bursts"', "0.5", "0.2", "3.0",
                 "0.1", 10, 236, "0,7,1,3"))
    b.append(rng("payload_bytes", '"payload bytes"', "64", "0", "512", "16",
                 10, 300, "0,10,1,2"))

    b.append(blk("uhd_usrp_sink", "usrp_sink", {
        "type": "fc32", "otw": "", "stream_args": "", "stream_chans": "[]",
        "dev_addr": "device_args", "dev_args": '""', "sync": "none",
        "clock_rate": "0e0", "num_mboards": "1", "nchan": "1",
        "clock_source0": "", "time_source0": "", "sd_spec0": "",
        "samp_rate": "samp_rate",
        "center_freq0": "center_freq", "gain0": "tx_gain", "ant0": '"TX/RX"',
        "bw0": "0", "lo_export0": "False", "lo_source0": "internal",
        "dc_offset0": "0", "iq_balance0": "0",
        "len_tag_name": '""',
        "affinity": "", "alias": "", "comment": ""}, 620, 100))

    b.append(blk("uhd_usrp_source", "usrp_source", {
        "type": "fc32", "otw": "", "stream_args": "", "stream_chans": "[]",
        "dev_addr": "device_args", "dev_args": '""', "sync": "none",
        "clock_rate": "0e0", "num_mboards": "1", "nchan": "1",
        "clock_source0": "", "time_source0": "", "sd_spec0": "",
        "samp_rate": "samp_rate",
        "center_freq0": "center_freq", "gain0": "rx_gain", "ant0": '"RX2"',
        "bw0": "0", "lo_export0": "False", "lo_source0": "internal",
        "dc_offset0": "0", "iq_balance0": "0",
        "affinity": "", "alias": "", "comment": "",
        "maxoutbuf": "0", "minoutbuf": "0"}, 620, 260))

    bb, cc = common_blocks(project_path, hardware=True)
    b += bb
    c += cc
    c.append(["dsss_tx", "0", "usrp_sink", "0"])
    for dst in ("dsss_rx", "dsss_corr", "spectrum", "waterfall", "rawconst"):
        c.append(["usrp_source", "0", dst, "0"])
    return b, c


# =========================================================================== #
def options(fid, title, desc, window="(1900, 1150)"):
    # No "name" key here: GRC calls options_block.import_data(name='', **options),
    # so a name in the dict is a duplicate keyword argument and the file fails
    # to load with a message that does not mention the options block at all.
    return {
        "id": "options",
        "parameters": {
            "author": "Garrett", "catch_exceptions": "True",
            "category": "[GRC Hier Blocks]", "cmake_opt": "", "comment": "",
            "copyright": "", "description": desc, "gen_cmake": "On",
            "gen_linking": "dynamic", "generate_options": "qt_gui",
            "hier_block_src_path": ".:", "id": fid, "max_nouts": "0",
            "output_language": "python", "placement": "(0,0)",
            "qt_qss_theme": "", "realtime_scheduling": "", "run": "True",
            "run_command": "{python} -u {filename}", "run_options": "prompt",
            "sizing_mode": "fixed", "thread_safe_setters": "",
            "title": title, "window_size": window,
        },
        "states": {"bus_sink": False, "bus_source": False,
                   "bus_structure": None, "coordinate": [8, 8],
                   "rotation": 0, "state": "enabled"},
    }


def write(path, fid, title, desc, blocks, connections):
    doc = {
        "options": options(fid, title, desc),
        "blocks": blocks,
        "connections": [[a, b, c, d] for a, b, c, d in connections],
        "metadata": {"file_format": 1, "grc_version": GRC_VERSION},
    }
    path.write_text(
        yaml.dump(doc, default_flow_style=False, sort_keys=False, width=100000),
        encoding="utf-8")
    print(f"  wrote {path}  ({len(blocks)} blocks, {len(connections)} connections)")


def main():
    project_path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_PROJECT_PATH
    print(f"  project path baked into the blocks: {project_path}")
    b, c = simulation(project_path)
    write(HERE / "dsss_qpsk_sim.grc", "dsss_qpsk_sim",
          "DSSS / QPSK link -- simulation with a noise slider",
          "Drag the SNR slider below zero and watch the signal disappear from "
          "the spectrum while the constellation keeps decoding.",
          b, c)
    b, c = radio(project_path)
    write(HERE / "dsss_qpsk_radio.grc", "dsss_qpsk_radio",
          "DSSS / QPSK link -- USRP B206mini",
          "The same plots, driven by the real radio. TX/RX to RX2 through a "
          "cable, or two antennas.",
          b, c)
    return 0


if __name__ == "__main__":
    sys.exit(main())
