"""DSSS/QPSK receiver

Samples in, decoded PAYLOAD symbols out.  Wire the output to a
Constellation Sink: you get only real, phase-corrected payload
symbols, with no preamble and nothing from the gaps between
bursts.  Every measurement is a method, for the Function Probe.
"""
import os
import sys

_HINTS = ["C:/Users/garre/OneDrive/Desktop/DSSS_QPSK"]
try:
    _HINTS.append(os.path.dirname(os.path.abspath(__file__)))
except NameError:
    pass
_HINTS.append(os.getcwd())
for _h in list(_HINTS):
    _p = _h
    for _ in range(3):
        _p = os.path.dirname(_p) if _p else ""
        _HINTS.append(_p)
for _h in _HINTS:
    if _h and os.path.isdir(os.path.join(_h, "dsss_qpsk")) and _h not in sys.path:
        sys.path.insert(0, _h)
        break

# Bound under BOTH names on purpose: GRC's block loader looks for any class in
# this file, and the code it generates calls it by its real name.
from dsss_qpsk.blocks.grc_blocks import DsssRxSymbols          # noqa: E402

blk = DsssRxSymbols
