#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: DSSS / QPSK link -- simulation with a noise slider
# Author: Garrett
# Description: Drag the SNR slider below zero and watch the signal disappear from the spectrum while the constellation keeps decoding.
# GNU Radio version: 3.10.12.0

from PyQt5 import Qt
from gnuradio import qtgui
from PyQt5 import QtCore
from gnuradio import blocks
from gnuradio import channels
from gnuradio.filter import firdes
from gnuradio import eng_notation
from gnuradio import gr
from gnuradio.fft import window
import sys
import signal
from PyQt5 import Qt
from argparse import ArgumentParser
from gnuradio.eng_arg import eng_float, intx
import dsss_qpsk_sim_dsss_corr as dsss_corr  # embedded python block
import dsss_qpsk_sim_dsss_rx as dsss_rx  # embedded python block
import dsss_qpsk_sim_dsss_tx as dsss_tx  # embedded python block
import dsss_qpsk_sim_spread_demo as spread_demo  # embedded python block
import math
import sip
import threading
import time



class dsss_qpsk_sim(gr.top_block, Qt.QWidget):

    def __init__(self):
        gr.top_block.__init__(self, "DSSS / QPSK link -- simulation with a noise slider", catch_exceptions=True)
        Qt.QWidget.__init__(self)
        self.setWindowTitle("DSSS / QPSK link -- simulation with a noise slider")
        qtgui.util.check_set_qss()
        try:
            self.setWindowIcon(Qt.QIcon.fromTheme('gnuradio-grc'))
        except BaseException as exc:
            print(f"Qt GUI: Could not set Icon: {str(exc)}", file=sys.stderr)
        self.top_scroll_layout = Qt.QVBoxLayout()
        self.setLayout(self.top_scroll_layout)
        self.top_scroll = Qt.QScrollArea()
        self.top_scroll.setFrameStyle(Qt.QFrame.NoFrame)
        self.top_scroll_layout.addWidget(self.top_scroll)
        self.top_scroll.setWidgetResizable(True)
        self.top_widget = Qt.QWidget()
        self.top_scroll.setWidget(self.top_widget)
        self.top_layout = Qt.QVBoxLayout(self.top_widget)
        self.top_grid_layout = Qt.QGridLayout()
        self.top_layout.addLayout(self.top_grid_layout)

        self.settings = Qt.QSettings("gnuradio/flowgraphs", "dsss_qpsk_sim")

        try:
            geometry = self.settings.value("geometry")
            if geometry:
                self.restoreGeometry(geometry)
        except BaseException as exc:
            print(f"Qt GUI: Could not restore geometry: {str(exc)}", file=sys.stderr)
        self.flowgraph_started = threading.Event()

        ##################################################
        # Variables
        ##################################################
        self.sps = sps = 2
        self.snr_db = snr_db = -10
        self.rx_status = rx_status = "waiting"
        self.rx_message = rx_message = "-"
        self.sf = sf = 31
        self.samp_rate = samp_rate = 2000000
        self.payload_bytes = payload_bytes = 64
        self.noise_voltage = noise_voltage = math.sqrt(sps / 10**(snr_db/10.0)) * 0.988
        self.lbl_status = lbl_status = rx_status
        self.lbl_message = lbl_message = rx_message
        self.interval = interval = 0.5
        self.cfo_hz = cfo_hz = 800

        ##################################################
        # Blocks
        ##################################################

        self.tabs = Qt.QTabWidget()
        self.tabs_widget_0 = Qt.QWidget()
        self.tabs_layout_0 = Qt.QBoxLayout(Qt.QBoxLayout.TopToBottom, self.tabs_widget_0)
        self.tabs_grid_layout_0 = Qt.QGridLayout()
        self.tabs_layout_0.addLayout(self.tabs_grid_layout_0)
        self.tabs.addTab(self.tabs_widget_0, 'Receiving')
        self.tabs_widget_1 = Qt.QWidget()
        self.tabs_layout_1 = Qt.QBoxLayout(Qt.QBoxLayout.TopToBottom, self.tabs_widget_1)
        self.tabs_grid_layout_1 = Qt.QGridLayout()
        self.tabs_layout_1.addLayout(self.tabs_grid_layout_1)
        self.tabs.addTab(self.tabs_widget_1, 'Spectrum')
        self.tabs_widget_2 = Qt.QWidget()
        self.tabs_layout_2 = Qt.QBoxLayout(Qt.QBoxLayout.TopToBottom, self.tabs_widget_2)
        self.tabs_grid_layout_2 = Qt.QGridLayout()
        self.tabs_layout_2.addLayout(self.tabs_grid_layout_2)
        self.tabs.addTab(self.tabs_widget_2, 'What spreading does')
        self.top_grid_layout.addWidget(self.tabs, 4, 0, 12, 12)
        for r in range(4, 16):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(0, 12):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._payload_bytes_range = qtgui.Range(0, 512, 16, 64, 200)
        self._payload_bytes_win = qtgui.RangeWidget(self._payload_bytes_range, self.set_payload_bytes, "payload bytes", "counter_slider", float, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._payload_bytes_win, 0, 10, 1, 2)
        for r in range(0, 1):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(10, 12):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._interval_range = qtgui.Range(0.2, 3.0, 0.1, 0.5, 200)
        self._interval_win = qtgui.RangeWidget(self._interval_range, self.set_interval, "seconds between bursts", "counter_slider", float, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._interval_win, 0, 7, 1, 3)
        for r in range(0, 1):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(7, 10):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.dsss_rx = dsss_rx.DsssRxSymbols(project_path="C:/Users/garre/OneDrive/Desktop/DSSS_QPSK", spreading_factor=0, max_symbols=4096, window_width=1900, window_height=1300)
        self._cfo_hz_range = qtgui.Range(-6000, 6000, 50, 800, 200)
        self._cfo_hz_win = qtgui.RangeWidget(self._cfo_hz_range, self.set_cfo_hz, "carrier offset (Hz)", "counter_slider", float, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._cfo_hz_win, 0, 4, 1, 3)
        for r in range(0, 1):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(4, 7):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.waterfall = qtgui.waterfall_sink_c(
            1024, #size
            window.WIN_BLACKMAN_hARRIS, #wintype
            0, #fc
            samp_rate, #bw
            "Waterfall", #name
            1, #number of inputs
            None # parent
        )
        self.waterfall.set_update_time(0.10)
        self.waterfall.enable_grid(True)
        self.waterfall.enable_axis_labels(True)

        self.waterfall.disable_legend()


        labels = ["", '', '', '', '',
                  '', '', '', '', '']
        colors = [0, 0, 0, 0, 0,
                  0, 0, 0, 0, 0]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
                  1.0, 1.0, 1.0, 1.0, 1.0]

        for i in range(1):
            if len(labels[i]) == 0:
                self.waterfall.set_line_label(i, "Data {0}".format(i))
            else:
                self.waterfall.set_line_label(i, labels[i])
            self.waterfall.set_color_map(i, colors[i])
            self.waterfall.set_line_alpha(i, alphas[i])

        self.waterfall.set_intensity_range(-50, -5)

        self._waterfall_win = sip.wrapinstance(self.waterfall.qwidget(), Qt.QWidget)

        self.tabs_grid_layout_1.addWidget(self._waterfall_win, 6, 0, 6, 12)
        for r in range(6, 12):
            self.tabs_grid_layout_1.setRowStretch(r, 1)
        for c in range(0, 12):
            self.tabs_grid_layout_1.setColumnStretch(c, 1)
        self.throttle = blocks.throttle( gr.sizeof_gr_complex*1, samp_rate, True, 0 if "auto" == "auto" else max( int(float(0.1) * samp_rate) if "auto" == "time" else int(0.1), 1) )
        self.spread_demo = spread_demo.DsssSpreadingDemo(project_path="C:/Users/garre/OneDrive/Desktop/DSSS_QPSK", spreading_factor=0, amplitude=1.0)
        self.spectrum = qtgui.freq_sink_c(
            2048, #size
            window.WIN_BLACKMAN_hARRIS, #wintype
            0, #fc
            samp_rate, #bw
            "Spectrum at the receiver input - look for the signal", #name
            1,
            None # parent
        )
        self.spectrum.set_update_time(0.10)
        self.spectrum.set_y_axis((-85), (-5))
        self.spectrum.set_y_label("Relative Gain", "dB")
        self.spectrum.set_trigger_mode(qtgui.TRIG_MODE_FREE, 0.0, 0, "")
        self.spectrum.enable_autoscale(False)
        self.spectrum.enable_grid(True)
        self.spectrum.set_fft_average(1.0)
        self.spectrum.enable_axis_labels(True)
        self.spectrum.enable_control_panel(False)
        self.spectrum.set_fft_window_normalized(False)



        labels = ["channel output", '', '', '', '',
            '', '', '', '', '']
        widths = [2, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        colors = ["blue", "red", "green", "black", "cyan",
            "magenta", "yellow", "dark red", "dark green", "dark blue"]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]

        for i in range(1):
            if len(labels[i]) == 0:
                self.spectrum.set_line_label(i, "Data {0}".format(i))
            else:
                self.spectrum.set_line_label(i, labels[i])
            self.spectrum.set_line_width(i, widths[i])
            self.spectrum.set_line_color(i, colors[i])
            self.spectrum.set_line_alpha(i, alphas[i])

        self._spectrum_win = sip.wrapinstance(self.spectrum.qwidget(), Qt.QWidget)
        self.tabs_grid_layout_1.addWidget(self._spectrum_win, 0, 0, 6, 12)
        for r in range(0, 6):
            self.tabs_grid_layout_1.setRowStretch(r, 1)
        for c in range(0, 12):
            self.tabs_grid_layout_1.setColumnStretch(c, 1)
        self._snr_db_range = qtgui.Range(-25, 20, 0.5, -10, 200)
        self._snr_db_win = qtgui.RangeWidget(self._snr_db_range, self.set_snr_db, "chip-band SNR (dB)   negative = BELOW the noise floor", "counter_slider", float, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._snr_db_win, 0, 0, 1, 4)
        for r in range(0, 1):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(0, 4):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.sendbox = qtgui.edit_box_msg(qtgui.STRING, "hello over the air", "type a message, press enter to send it", False, False, "", None)
        self._sendbox_win = sip.wrapinstance(self.sendbox.qwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._sendbox_win, 1, 0, 1, 12)
        for r in range(1, 2):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(0, 12):
            self.top_grid_layout.setColumnStretch(c, 1)
        def _rx_status_probe():
          self.flowgraph_started.wait()
          while True:

            val = self.dsss_rx.status_text()
            try:
              try:
                self.doc.add_next_tick_callback(functools.partial(self.set_rx_status,val))
              except AttributeError:
                self.set_rx_status(val)
            except AttributeError:
              pass
            time.sleep(1.0 / (5))
        _rx_status_thread = threading.Thread(target=_rx_status_probe)
        _rx_status_thread.daemon = True
        _rx_status_thread.start()
        def _rx_message_probe():
          self.flowgraph_started.wait()
          while True:

            val = self.dsss_rx.last_message()
            try:
              try:
                self.doc.add_next_tick_callback(functools.partial(self.set_rx_message,val))
              except AttributeError:
                self.set_rx_message(val)
            except AttributeError:
              pass
            time.sleep(1.0 / (5))
        _rx_message_thread = threading.Thread(target=_rx_message_probe)
        _rx_message_thread.daemon = True
        _rx_message_thread.start()
        self.rawconst = qtgui.const_sink_c(
            2048, #size
            "BEFORE despreading - the samples as they arrive", #name
            1, #number of inputs
            None # parent
        )
        self.rawconst.set_update_time(0.10)
        self.rawconst.set_y_axis((-4), 4)
        self.rawconst.set_x_axis((-4), 4)
        self.rawconst.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, "")
        self.rawconst.enable_autoscale(False)
        self.rawconst.enable_grid(True)
        self.rawconst.enable_axis_labels(True)

        self.rawconst.disable_legend()

        labels = ["payload symbols", '', '', '', '',
            '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        colors = ["cyan", "red", "green", "black", "cyan",
            "magenta", "yellow", "dark red", "dark green", "dark blue"]
        styles = [0, 0, 0, 0, 0,
            0, 0, 0, 0, 0]
        markers = [0, 0, 0, 0, 0,
            0, 0, 0, 0, 0]
        alphas = [0.55, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]

        for i in range(1):
            if len(labels[i]) == 0:
                self.rawconst.set_line_label(i, "Data {0}".format(i))
            else:
                self.rawconst.set_line_label(i, labels[i])
            self.rawconst.set_line_width(i, widths[i])
            self.rawconst.set_line_color(i, colors[i])
            self.rawconst.set_line_style(i, styles[i])
            self.rawconst.set_line_marker(i, markers[i])
            self.rawconst.set_line_alpha(i, alphas[i])

        self._rawconst_win = sip.wrapinstance(self.rawconst.qwidget(), Qt.QWidget)
        self.tabs_grid_layout_0.addWidget(self._rawconst_win, 0, 6, 5, 6)
        for r in range(0, 5):
            self.tabs_grid_layout_0.setRowStretch(r, 1)
        for c in range(6, 12):
            self.tabs_grid_layout_0.setColumnStretch(c, 1)
        self._lbl_status_tool_bar = Qt.QToolBar(self)

        if None:
            self._lbl_status_formatter = None
        else:
            self._lbl_status_formatter = lambda x: str(x)

        self._lbl_status_tool_bar.addWidget(Qt.QLabel("link"))
        self._lbl_status_label = Qt.QLabel(str(self._lbl_status_formatter(self.lbl_status)))
        self._lbl_status_tool_bar.addWidget(self._lbl_status_label)
        self.top_grid_layout.addWidget(self._lbl_status_tool_bar, 2, 0, 1, 12)
        for r in range(2, 3):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(0, 12):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._lbl_message_tool_bar = Qt.QToolBar(self)

        if None:
            self._lbl_message_formatter = None
        else:
            self._lbl_message_formatter = lambda x: str(x)

        self._lbl_message_tool_bar.addWidget(Qt.QLabel("last message"))
        self._lbl_message_label = Qt.QLabel(str(self._lbl_message_formatter(self.lbl_message)))
        self._lbl_message_tool_bar.addWidget(self._lbl_message_label)
        self.top_grid_layout.addWidget(self._lbl_message_tool_bar, 3, 0, 1, 12)
        for r in range(3, 4):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(0, 12):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.dsss_tx = dsss_tx.DsssTxSource(project_path="C:/Users/garre/OneDrive/Desktop/DSSS_QPSK", payload_bytes=payload_bytes, interval=interval, amplitude=1.0, text="", spreading_factor=0)
        self.dsss_corr = dsss_corr.DsssPnMatchedFilter(project_path="C:/Users/garre/OneDrive/Desktop/DSSS_QPSK", spreading_factor=0, periods=32, coherent=16, average=0.02)
        self.demo_wide = qtgui.freq_sink_c(
            2048, #size
            window.WIN_BLACKMAN_hARRIS, #wintype
            0, #fc
            samp_rate, #bw
            "AFTER spreading - the same data and the same power, 31x the bandwidth and 15 dB lower", #name
            1,
            None # parent
        )
        self.demo_wide.set_update_time(0.10)
        self.demo_wide.set_y_axis((-90), 0)
        self.demo_wide.set_y_label("Relative Gain", "dB")
        self.demo_wide.set_trigger_mode(qtgui.TRIG_MODE_FREE, 0.0, 0, "")
        self.demo_wide.enable_autoscale(False)
        self.demo_wide.enable_grid(True)
        self.demo_wide.set_fft_average(1.0)
        self.demo_wide.enable_axis_labels(True)
        self.demo_wide.enable_control_panel(False)
        self.demo_wide.set_fft_window_normalized(False)



        labels = ["channel output", '', '', '', '',
            '', '', '', '', '']
        widths = [2, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        colors = ["blue", "red", "green", "black", "cyan",
            "magenta", "yellow", "dark red", "dark green", "dark blue"]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]

        for i in range(1):
            if len(labels[i]) == 0:
                self.demo_wide.set_line_label(i, "Data {0}".format(i))
            else:
                self.demo_wide.set_line_label(i, labels[i])
            self.demo_wide.set_line_width(i, widths[i])
            self.demo_wide.set_line_color(i, colors[i])
            self.demo_wide.set_line_alpha(i, alphas[i])

        self._demo_wide_win = sip.wrapinstance(self.demo_wide.qwidget(), Qt.QWidget)
        self.tabs_grid_layout_2.addWidget(self._demo_wide_win, 5, 6, 5, 6)
        for r in range(5, 10):
            self.tabs_grid_layout_2.setRowStretch(r, 1)
        for c in range(6, 12):
            self.tabs_grid_layout_2.setColumnStretch(c, 1)
        self.demo_narrow = qtgui.freq_sink_c(
            2048, #size
            window.WIN_BLACKMAN_hARRIS, #wintype
            0, #fc
            samp_rate, #bw
            "BEFORE spreading - one QPSK symbol per 31 us, about 32 kHz wide", #name
            1,
            None # parent
        )
        self.demo_narrow.set_update_time(0.10)
        self.demo_narrow.set_y_axis((-90), 0)
        self.demo_narrow.set_y_label("Relative Gain", "dB")
        self.demo_narrow.set_trigger_mode(qtgui.TRIG_MODE_FREE, 0.0, 0, "")
        self.demo_narrow.enable_autoscale(False)
        self.demo_narrow.enable_grid(True)
        self.demo_narrow.set_fft_average(1.0)
        self.demo_narrow.enable_axis_labels(True)
        self.demo_narrow.enable_control_panel(False)
        self.demo_narrow.set_fft_window_normalized(False)



        labels = ["channel output", '', '', '', '',
            '', '', '', '', '']
        widths = [2, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        colors = ["blue", "red", "green", "black", "cyan",
            "magenta", "yellow", "dark red", "dark green", "dark blue"]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]

        for i in range(1):
            if len(labels[i]) == 0:
                self.demo_narrow.set_line_label(i, "Data {0}".format(i))
            else:
                self.demo_narrow.set_line_label(i, labels[i])
            self.demo_narrow.set_line_width(i, widths[i])
            self.demo_narrow.set_line_color(i, colors[i])
            self.demo_narrow.set_line_alpha(i, alphas[i])

        self._demo_narrow_win = sip.wrapinstance(self.demo_narrow.qwidget(), Qt.QWidget)
        self.tabs_grid_layout_2.addWidget(self._demo_narrow_win, 0, 6, 5, 6)
        for r in range(0, 5):
            self.tabs_grid_layout_2.setRowStretch(r, 1)
        for c in range(6, 12):
            self.tabs_grid_layout_2.setColumnStretch(c, 1)
        self.demo_const = qtgui.const_sink_c(
            2048, #size
            "BEFORE spreading - the QPSK symbols themselves", #name
            1, #number of inputs
            None # parent
        )
        self.demo_const.set_update_time(0.10)
        self.demo_const.set_y_axis((-1.6), 1.6)
        self.demo_const.set_x_axis((-1.6), 1.6)
        self.demo_const.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, "")
        self.demo_const.enable_autoscale(False)
        self.demo_const.enable_grid(True)
        self.demo_const.enable_axis_labels(True)

        self.demo_const.disable_legend()

        labels = ["payload symbols", '', '', '', '',
            '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        colors = ["cyan", "red", "green", "black", "cyan",
            "magenta", "yellow", "dark red", "dark green", "dark blue"]
        styles = [0, 0, 0, 0, 0,
            0, 0, 0, 0, 0]
        markers = [0, 0, 0, 0, 0,
            0, 0, 0, 0, 0]
        alphas = [0.55, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]

        for i in range(1):
            if len(labels[i]) == 0:
                self.demo_const.set_line_label(i, "Data {0}".format(i))
            else:
                self.demo_const.set_line_label(i, labels[i])
            self.demo_const.set_line_width(i, widths[i])
            self.demo_const.set_line_color(i, colors[i])
            self.demo_const.set_line_style(i, styles[i])
            self.demo_const.set_line_marker(i, markers[i])
            self.demo_const.set_line_alpha(i, alphas[i])

        self._demo_const_win = sip.wrapinstance(self.demo_const.qwidget(), Qt.QWidget)
        self.tabs_grid_layout_2.addWidget(self._demo_const_win, 0, 0, 5, 6)
        for r in range(0, 5):
            self.tabs_grid_layout_2.setRowStretch(r, 1)
        for c in range(0, 6):
            self.tabs_grid_layout_2.setColumnStretch(c, 1)
        self.demo_chips = qtgui.const_sink_c(
            2048, #size
            "AFTER spreading - the chips", #name
            1, #number of inputs
            None # parent
        )
        self.demo_chips.set_update_time(0.10)
        self.demo_chips.set_y_axis((-2.5), 2.5)
        self.demo_chips.set_x_axis((-2.5), 2.5)
        self.demo_chips.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, "")
        self.demo_chips.enable_autoscale(False)
        self.demo_chips.enable_grid(True)
        self.demo_chips.enable_axis_labels(True)

        self.demo_chips.disable_legend()

        labels = ["payload symbols", '', '', '', '',
            '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        colors = ["cyan", "red", "green", "black", "cyan",
            "magenta", "yellow", "dark red", "dark green", "dark blue"]
        styles = [0, 0, 0, 0, 0,
            0, 0, 0, 0, 0]
        markers = [0, 0, 0, 0, 0,
            0, 0, 0, 0, 0]
        alphas = [0.55, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]

        for i in range(1):
            if len(labels[i]) == 0:
                self.demo_chips.set_line_label(i, "Data {0}".format(i))
            else:
                self.demo_chips.set_line_label(i, labels[i])
            self.demo_chips.set_line_width(i, widths[i])
            self.demo_chips.set_line_color(i, colors[i])
            self.demo_chips.set_line_style(i, styles[i])
            self.demo_chips.set_line_marker(i, markers[i])
            self.demo_chips.set_line_alpha(i, alphas[i])

        self._demo_chips_win = sip.wrapinstance(self.demo_chips.qwidget(), Qt.QWidget)
        self.tabs_grid_layout_2.addWidget(self._demo_chips_win, 5, 0, 5, 6)
        for r in range(5, 10):
            self.tabs_grid_layout_2.setRowStretch(r, 1)
        for c in range(0, 6):
            self.tabs_grid_layout_2.setColumnStretch(c, 1)
        self.corr = qtgui.time_sink_f(
            512, #size
            samp_rate/(sps*sf*32), #samp_rate
            "Match to the spreading code, 0 to 1 - green knows the code, red does not", #name
            2, #number of inputs
            None # parent
        )
        self.corr.set_update_time(0.10)
        self.corr.set_y_axis(0, 0.75)

        self.corr.set_y_label("normalised correlation", "")

        self.corr.enable_tags(True)
        self.corr.set_trigger_mode(qtgui.TRIG_MODE_AUTO, qtgui.TRIG_SLOPE_POS, 0.12, 0.05, 0, "")
        self.corr.enable_autoscale(False)
        self.corr.enable_grid(True)
        self.corr.enable_axis_labels(True)
        self.corr.enable_control_panel(False)
        self.corr.enable_stem_plot(False)


        labels = ["with the code", "without the code", 'Signal 3', 'Signal 4', 'Signal 5',
            'Signal 6', 'Signal 7', 'Signal 8', 'Signal 9', 'Signal 10']
        widths = [2, 2, 1, 1, 1,
            1, 1, 1, 1, 1]
        colors = ['dark green', 'red', 'green', 'black', 'cyan',
            'magenta', 'yellow', 'dark red', 'dark green', 'dark blue']
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]
        styles = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        markers = [-1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1]


        for i in range(2):
            if len(labels[i]) == 0:
                self.corr.set_line_label(i, "Data {0}".format(i))
            else:
                self.corr.set_line_label(i, labels[i])
            self.corr.set_line_width(i, widths[i])
            self.corr.set_line_color(i, colors[i])
            self.corr.set_line_style(i, styles[i])
            self.corr.set_line_marker(i, markers[i])
            self.corr.set_line_alpha(i, alphas[i])

        self._corr_win = sip.wrapinstance(self.corr.qwidget(), Qt.QWidget)
        self.tabs_grid_layout_0.addWidget(self._corr_win, 5, 0, 5, 12)
        for r in range(5, 10):
            self.tabs_grid_layout_0.setRowStretch(r, 1)
        for c in range(0, 12):
            self.tabs_grid_layout_0.setColumnStretch(c, 1)
        self.const = qtgui.const_sink_c(
            2048, #size
            "AFTER despreading - the decoded payload symbols", #name
            1, #number of inputs
            None # parent
        )
        self.const.set_update_time(0.10)
        self.const.set_y_axis((-1.6), 1.6)
        self.const.set_x_axis((-1.6), 1.6)
        self.const.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, "")
        self.const.enable_autoscale(False)
        self.const.enable_grid(True)
        self.const.enable_axis_labels(True)

        self.const.disable_legend()

        labels = ["payload symbols", '', '', '', '',
            '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        colors = ["cyan", "red", "green", "black", "cyan",
            "magenta", "yellow", "dark red", "dark green", "dark blue"]
        styles = [0, 0, 0, 0, 0,
            0, 0, 0, 0, 0]
        markers = [0, 0, 0, 0, 0,
            0, 0, 0, 0, 0]
        alphas = [0.55, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]

        for i in range(1):
            if len(labels[i]) == 0:
                self.const.set_line_label(i, "Data {0}".format(i))
            else:
                self.const.set_line_label(i, labels[i])
            self.const.set_line_width(i, widths[i])
            self.const.set_line_color(i, colors[i])
            self.const.set_line_style(i, styles[i])
            self.const.set_line_marker(i, markers[i])
            self.const.set_line_alpha(i, alphas[i])

        self._const_win = sip.wrapinstance(self.const.qwidget(), Qt.QWidget)
        self.tabs_grid_layout_0.addWidget(self._const_win, 0, 0, 5, 6)
        for r in range(0, 5):
            self.tabs_grid_layout_0.setRowStretch(r, 1)
        for c in range(0, 6):
            self.tabs_grid_layout_0.setColumnStretch(c, 1)
        self.channel = channels.channel_model(
            noise_voltage=noise_voltage,
            frequency_offset=(cfo_hz/samp_rate),
            epsilon=1.0000005,
            taps=[1.0],
            noise_seed=0,
            block_tags=False)


        ##################################################
        # Connections
        ##################################################
        self.msg_connect((self.sendbox, 'msg'), (self.dsss_tx, 'send'))
        self.connect((self.channel, 0), (self.dsss_corr, 0))
        self.connect((self.channel, 0), (self.dsss_rx, 0))
        self.connect((self.channel, 0), (self.rawconst, 0))
        self.connect((self.channel, 0), (self.spectrum, 0))
        self.connect((self.channel, 0), (self.waterfall, 0))
        self.connect((self.dsss_corr, 1), (self.corr, 1))
        self.connect((self.dsss_corr, 0), (self.corr, 0))
        self.connect((self.dsss_rx, 0), (self.const, 0))
        self.connect((self.dsss_tx, 0), (self.throttle, 0))
        self.connect((self.spread_demo, 1), (self.demo_chips, 0))
        self.connect((self.spread_demo, 2), (self.demo_const, 0))
        self.connect((self.spread_demo, 0), (self.demo_narrow, 0))
        self.connect((self.spread_demo, 1), (self.demo_wide, 0))
        self.connect((self.throttle, 0), (self.channel, 0))


    def closeEvent(self, event):
        self.settings = Qt.QSettings("gnuradio/flowgraphs", "dsss_qpsk_sim")
        self.settings.setValue("geometry", self.saveGeometry())
        self.stop()
        self.wait()

        event.accept()

    def get_sps(self):
        return self.sps

    def set_sps(self, sps):
        self.sps = sps
        self.set_noise_voltage(math.sqrt(self.sps / 10**(self.snr_db/10.0)) * 0.988)
        self.corr.set_samp_rate(self.samp_rate/(self.sps*self.sf*32))

    def get_snr_db(self):
        return self.snr_db

    def set_snr_db(self, snr_db):
        self.snr_db = snr_db
        self.set_noise_voltage(math.sqrt(self.sps / 10**(self.snr_db/10.0)) * 0.988)

    def get_rx_status(self):
        return self.rx_status

    def set_rx_status(self, rx_status):
        self.rx_status = rx_status
        self.set_lbl_status(self.rx_status)

    def get_rx_message(self):
        return self.rx_message

    def set_rx_message(self, rx_message):
        self.rx_message = rx_message
        self.set_lbl_message(self.rx_message)

    def get_sf(self):
        return self.sf

    def set_sf(self, sf):
        self.sf = sf
        self.corr.set_samp_rate(self.samp_rate/(self.sps*self.sf*32))

    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.throttle.set_sample_rate(self.samp_rate)
        self.channel.set_frequency_offset((self.cfo_hz/self.samp_rate))
        self.spectrum.set_frequency_range(0, self.samp_rate)
        self.waterfall.set_frequency_range(0, self.samp_rate)
        self.corr.set_samp_rate(self.samp_rate/(self.sps*self.sf*32))
        self.demo_narrow.set_frequency_range(0, self.samp_rate)
        self.demo_wide.set_frequency_range(0, self.samp_rate)

    def get_payload_bytes(self):
        return self.payload_bytes

    def set_payload_bytes(self, payload_bytes):
        self.payload_bytes = payload_bytes
        self.dsss_tx.payload_bytes = self.payload_bytes

    def get_noise_voltage(self):
        return self.noise_voltage

    def set_noise_voltage(self, noise_voltage):
        self.noise_voltage = noise_voltage
        self.channel.set_noise_voltage(self.noise_voltage)

    def get_lbl_status(self):
        return self.lbl_status

    def set_lbl_status(self, lbl_status):
        self.lbl_status = lbl_status
        Qt.QMetaObject.invokeMethod(self._lbl_status_label, "setText", Qt.Q_ARG("QString", str(self._lbl_status_formatter(self.lbl_status))))

    def get_lbl_message(self):
        return self.lbl_message

    def set_lbl_message(self, lbl_message):
        self.lbl_message = lbl_message
        Qt.QMetaObject.invokeMethod(self._lbl_message_label, "setText", Qt.Q_ARG("QString", str(self._lbl_message_formatter(self.lbl_message))))

    def get_interval(self):
        return self.interval

    def set_interval(self, interval):
        self.interval = interval
        self.dsss_tx.interval = self.interval

    def get_cfo_hz(self):
        return self.cfo_hz

    def set_cfo_hz(self, cfo_hz):
        self.cfo_hz = cfo_hz
        self.channel.set_frequency_offset((self.cfo_hz/self.samp_rate))




def main(top_block_cls=dsss_qpsk_sim, options=None):

    qapp = Qt.QApplication(sys.argv)

    tb = top_block_cls()

    tb.start()
    tb.flowgraph_started.set()

    tb.show()

    def sig_handler(sig=None, frame=None):
        tb.stop()
        tb.wait()

        Qt.QApplication.quit()

    signal.signal(signal.SIGINT, sig_handler)
    signal.signal(signal.SIGTERM, sig_handler)

    timer = Qt.QTimer()
    timer.start(500)
    timer.timeout.connect(lambda: None)

    qapp.exec_()

if __name__ == '__main__':
    main()
