#!/usr/bin/env python3
"""Screenshot the running flowgraph, so the layout can be checked without eyes on it.

    xvfb-run -a python grc/shot_grc.py out.png -10
"""
import os
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))
os.environ.setdefault("QT_QPA_PLATFORM", "xcb")

OUT = sys.argv[1] if len(sys.argv) > 1 else "grc_dashboard.png"
SNR = float(sys.argv[2]) if len(sys.argv) > 2 else -10.0
WAIT = float(sys.argv[3]) if len(sys.argv) > 3 else 25.0
TAB = int(sys.argv[4]) if len(sys.argv) > 4 else 0

# Always compile first: importing a stale generated .py is a great way to
# screenshot a flowgraph you are no longer building.
import subprocess                                           # noqa: E402
subprocess.run([sys.executable, "-c",
                "from gnuradio.grc.compiler import main; main()",
                "-o", str(HERE), str(HERE / "dsss_qpsk_sim.grc")],
               check=True, capture_output=True)

import dsss_qpsk_sim                                        # noqa: E402
from PyQt5 import Qt                                        # noqa: E402

app = Qt.QApplication.instance() or Qt.QApplication(sys.argv)
tb = dsss_qpsk_sim.dsss_qpsk_sim()
tb.set_snr_db(SNR)
tb.set_interval(0.35)
tb.show()
try:
    tb.tabs.setCurrentIndex(TAB)
except Exception:
    pass
tb.start()
t0 = time.time()
while time.time() - t0 < WAIT:
    app.processEvents()
    time.sleep(0.03)
tb.grab().save(OUT)
print("wrote", OUT, "  frames decoded:", tb.dsss_rx.frames_ok,
      " mean chip SNR", round(tb.dsss_rx.mean_snr_chip_db(), 2))
tb.stop()
sys.stdout.flush()
os._exit(0)
