"""DSSS spreading demo

Three views of the same data, side by side: the QPSK symbols
before spreading (narrow, 32 kHz), the same symbols after
spreading (wide, 1 MHz, 15 dB lower for the same power), and
the symbols themselves for a constellation.  Continuous, not
bursty, because it is a display -- it carries no frames.
"""
import os
import sys

_HINTS = ["C:/Users/garre/OneDrive/Desktop/DSSS_QPSK"]
try:
    _HINTS.append(os.path.dirname(os.path.abspath(__file__)))
except NameError:
    pass
_HINTS.append(os.getcwd())
for _h in list(_HINTS):
    _p = _h
    for _ in range(3):
        _p = os.path.dirname(_p) if _p else ""
        _HINTS.append(_p)
for _h in _HINTS:
    if _h and os.path.isdir(os.path.join(_h, "dsss_qpsk")) and _h not in sys.path:
        sys.path.insert(0, _h)
        break

# Bound under BOTH names on purpose: GRC's block loader looks for any class in
# this file, and the code it generates calls it by its real name.
from dsss_qpsk.blocks.grc_blocks import DsssSpreadingDemo          # noqa: E402

blk = DsssSpreadingDemo
