#!/usr/bin/env python3
"""Work out what noise_voltage the GRC Channel Model needs for a given SNR.

The flowgraph's SNR slider has to mean the same thing the receiver reports, or
it is worse than useless.  Rather than reasoning about how GNU Radio scales its
Gaussian source, measure it: transmit a unit-mean-power burst, add noise at a
known noise_voltage, and see what the receiver says the chip SNR is.
"""
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from gnuradio import blocks, channels, gr                  # noqa: E402

from dsss_qpsk import config as cfg                        # noqa: E402
from dsss_qpsk.blocks.grc_blocks import DsssRxSymbols, DsssTxSource  # noqa: E402


def measure_noise_power(noise_voltage, n=200000):
    """What is the actual complex noise power for a given noise_voltage?"""
    tb = gr.top_block()
    src = blocks.null_source(gr.sizeof_gr_complex)
    head = blocks.head(gr.sizeof_gr_complex, n)
    ch = channels.channel_model(noise_voltage=noise_voltage, frequency_offset=0.0,
                                epsilon=1.0, taps=[1.0], noise_seed=7)
    snk = blocks.vector_sink_c()
    tb.connect(src, head, ch, snk)
    tb.run()
    d = np.array(snk.data())
    return float(np.mean(np.abs(d) ** 2))


def main():
    print("  noise_voltage -> measured complex noise power")
    for nv in (0.1, 0.5, 1.0, 2.0):
        p = measure_noise_power(nv)
        print(f"    {nv:6.3f}  ->  {p:10.6f}   (power/nv^2 = {p/nv**2:.4f})")
    k = measure_noise_power(1.0)
    print(f"\n  So noise power = {k:.4f} * noise_voltage^2")
    print(f"  and noise_voltage = sqrt(noise_power / {k:.4f})")

    print("\n  Now check the whole chain: does the receiver agree with the slider?")
    print(f"  {'slider SNR':>11s} {'noise_voltage':>14s} {'frames':>7s} "
          f"{'measured chip SNR':>18s} {'error':>7s}")
    for snr_db in (10.0, 0.0, -6.0, -10.0, -13.0):
        # Burst has unit mean power in-band; chip-band SNR convention is
        # Es_chip/N0 = P * sps / sigma^2  (see channel.py), so:
        noise_power = cfg.SPS_CHIP / (10 ** (snr_db / 10.0))
        nv = float(np.sqrt(noise_power / k))
        tb = gr.top_block()
        tx = DsssTxSource(project_path=str(HERE.parent), payload_bytes=64,
                          interval=0.25)
        ch = channels.channel_model(noise_voltage=nv, frequency_offset=0.0005,
                                    epsilon=1.0000005, taps=[1.0], noise_seed=11)
        rx = DsssRxSymbols(project_path=str(HERE.parent))
        head = blocks.head(gr.sizeof_gr_complex, int(1.6 * cfg.SAMP_RATE_HZ))
        snk = blocks.null_sink(gr.sizeof_gr_complex)
        tb.connect(tx, head, ch, rx, snk)
        tb.run()
        got = rx.snr_chip_db()
        err = got - snr_db if np.isfinite(got) else float("nan")
        print(f"  {snr_db:11.1f} {nv:14.5f} {rx.frames_ok:7d} "
              f"{got:18.2f} {err:+7.2f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
