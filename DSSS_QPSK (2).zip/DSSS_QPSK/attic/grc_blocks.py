"""
blocks/grc_blocks.py -- blocks built for GNU Radio Companion.

The blocks in gr_blocks.py exist to drive a USRP from the link layer.  These
exist so you can SEE the link in GRC: drop them on a canvas, wire the standard
QT GUI sinks to them, and watch a signal that is under the noise floor come out
the other side.

  DsssTxSource      a source that transmits a burst every so often and is quiet
                    in between.  Unit mean power inside the burst, so the
                    flowgraph can compute a noise voltage for a requested SNR
                    without having to know anything about the waveform.

  DsssRxSymbols     samples in, decoded PAYLOAD SYMBOLS out.  Wire it to a QT
                    GUI Constellation Sink and you get the real constellation,
                    with nothing else in it -- no preamble, no noise between
                    bursts, no zeros dragging a blob into the middle.  It also
                    publishes decoded messages on a message port and exposes
                    every per-frame measurement as a plain method, so GRC's
                    Function Probe can put them in a label.

  DsssPnMatchedFilter
                    samples in, despread correlation in dB out.  Wire it to a
                    Time Sink and you watch a burst that is invisible in the
                    spectrum produce a clear pulse.  Read the note on its class
                    about WHICH gain it shows -- one PN period's worth, not the
                    receiver's full acquisition gain.

WHY THESE ARE SEPARATE FROM gr_blocks.py
    gr_blocks.py is about hardware framing (packet_len tags, burst keying).
    These are about visibility.  Keeping them apart means the hardware path has
    no GUI dependencies and the GUI path has no USRP dependencies.
"""

from __future__ import annotations

import threading
import time

import numpy as np

try:
    import pmt
    from gnuradio import gr
except ImportError as e:                                    # pragma: no cover
    raise ImportError(
        "GNU Radio is not importable in this Python.  On Windows/radioconda, "
        "open GNU Radio Companion (or the GNU Radio Command Prompt) and run "
        "from there."
    ) from e


def _load(project_path: str = ""):
    """Make `dsss_qpsk` importable, then return its config module.

    GRC generates a script that runs from wherever you launched it, which is
    usually not the project folder, so every block takes the project path as a
    parameter and puts it on sys.path itself.  Leave it blank if the package is
    already installed or already importable.
    """
    import os
    import sys
    if project_path:
        p = os.path.abspath(os.path.expanduser(project_path))
        if p not in sys.path:
            sys.path.insert(0, p)
    from dsss_qpsk import config as cfg
    return cfg


def _open_window_big(width: int, height: int):
    """Open the flowgraph's window at a usable size.

    GRC's "Window Size" option only does anything for the bokeh output; the Qt
    template ignores it, so a flowgraph with six plots opens at whatever Qt
    thinks the layout needs, which is far too small to read any of them.  This
    schedules one resize on the Qt event loop after the window exists.  Set
    either dimension to 0 to leave the window alone.
    """
    if not width or not height:
        return
    try:
        from PyQt5 import Qt
    except Exception:
        return

    def _do():
        try:
            for w in Qt.QApplication.topLevelWidgets():
                if w.isWindow() and w.isVisible():
                    w.resize(int(width), int(height))
        except Exception:
            pass
    try:
        Qt.QTimer.singleShot(400, _do)
    except Exception:
        pass


# ===========================================================================
class DsssTxSource(gr.sync_block):
    """Transmit one DSSS/QPSK burst every `interval` seconds, silence between.

    The burst is scaled to unit MEAN power over its own duration.  That is what
    lets the flowgraph set a noise level for a requested chip-band SNR with one
    formula and no knowledge of the waveform:

        noise_voltage = sqrt(samples_per_chip / 10**(snr_db/10))

    Payload is either the text you typed or `payload_bytes` of random data, so
    you can leave it running as a soak test or send something readable.
    """

    def __init__(self, project_path="", payload_bytes=64, interval=0.6,
                 amplitude=1.0, text="", spreading_factor=0):
        gr.sync_block.__init__(self, name="DSSS/QPSK TX burst source",
                               in_sig=None, out_sig=[np.complex64])
        cfg = _load(project_path)
        if spreading_factor:
            cfg.SPREADING_FACTOR = int(spreading_factor)
            cfg.recompute()
        self.cfg = cfg

        from dsss_qpsk.framing import FT_DATA, Header
        from dsss_qpsk.modulator import Modulator
        self._Header, self._FT_DATA = Header, FT_DATA
        self.mod = Modulator(cfg)

        self.payload_bytes = int(payload_bytes)
        self.interval = float(interval)
        self.amplitude = float(amplitude)
        self.text = str(text or "")
        self._rng = np.random.default_rng()

        self._cur = np.zeros(0, dtype=np.complex64)
        self._pos = 0
        self._gap = 0                      # samples of silence still to emit
        self._seq = 0
        self.bursts_sent = 0
        self._lock = threading.Lock()
        self.message_port_register_in(pmt.intern("send"))
        self.set_msg_handler(pmt.intern("send"), self._on_send)
        self._queued: list[bytes] = []

    # --- GRC callbacks (these are what a slider or an entry box calls) -----
    def set_interval(self, v):
        self.interval = max(0.05, float(v))

    def set_payload_bytes(self, v):
        self.payload_bytes = max(0, min(int(v), self.cfg.MAX_PAYLOAD_BYTES))

    def set_amplitude(self, v):
        self.amplitude = float(v)

    def set_text(self, v):
        self.text = str(v or "")

    def reset_counters(self):
        self.bursts_sent = 0

    def _on_send(self, msg):
        try:
            s = pmt.symbol_to_string(msg) if pmt.is_symbol(msg) else str(msg)
        except Exception:
            return
        with self._lock:
            self._queued.append(s.encode("utf-8", errors="replace")
                                [:self.cfg.MAX_PAYLOAD_BYTES])

    # ----------------------------------------------------------------------
    def _next_payload(self) -> bytes:
        with self._lock:
            if self._queued:
                return self._queued.pop(0)
        if self.text:
            return self.text.encode("utf-8", errors="replace")[
                :self.cfg.MAX_PAYLOAD_BYTES]
        # int(), because GRC wires a float slider straight onto this attribute.
        n = max(0, min(int(self.payload_bytes), self.cfg.MAX_PAYLOAD_BYTES))
        return bytes(self._rng.integers(32, 127, n, dtype=np.uint8)) if n else b""

    def _make_burst(self) -> np.ndarray:
        payload = self._next_payload()
        h = self._Header(ftype=self._FT_DATA, src=1, dst=255,
                         seq=self._seq & 0x0F, payload_len=len(payload))
        self._seq += 1
        b = self.mod.modulate(h, payload).astype(np.complex64)
        # Unit mean power inside the burst.  Done here, once per burst, so the
        # flowgraph's SNR arithmetic does not depend on TX_AMPLITUDE, the ramp
        # length, the payload size or anything else about the waveform.
        p = float(np.mean(np.abs(b) ** 2))
        if p > 0:
            b = b * np.float32(self.amplitude / np.sqrt(p))
        self.bursts_sent += 1
        return b.astype(np.complex64)

    def work(self, input_items, output_items):
        out = output_items[0]
        n = len(out)
        produced = 0
        while produced < n:
            if self._gap > 0:
                k = min(self._gap, n - produced)
                out[produced:produced + k] = 0
                self._gap -= k
                produced += k
                continue
            if self._pos >= len(self._cur):
                self._cur = self._make_burst()
                self._pos = 0
                gap = int(float(self.interval) * self.cfg.SAMP_RATE_HZ) - len(self._cur)
                self._gap_next = max(gap, int(0.02 * self.cfg.SAMP_RATE_HZ))
            k = min(len(self._cur) - self._pos, n - produced)
            out[produced:produced + k] = self._cur[self._pos:self._pos + k]
            self._pos += k
            produced += k
            if self._pos >= len(self._cur):
                self._gap = getattr(self, "_gap_next", 0)
        return n


# ===========================================================================
class DsssRxSymbols(gr.basic_block):
    """Samples in -> decoded payload symbols out, plus every measurement.

    A general block rather than a sync block on purpose: symbols do not come out
    at a fixed rate relative to samples.  Most of the time this consumes input
    and produces nothing (there is no burst on the air); when a frame decodes it
    produces that frame's payload symbols in one go.  A Constellation Sink then
    shows only real, phase-corrected, payload symbols.
    """

    def __init__(self, project_path="", spreading_factor=0, max_symbols=4096,
                 window_width=1900, window_height=1300):
        gr.basic_block.__init__(self, name="DSSS/QPSK receiver",
                                in_sig=[np.complex64], out_sig=[np.complex64])
        cfg = _load(project_path)
        if spreading_factor:
            cfg.SPREADING_FACTOR = int(spreading_factor)
            cfg.recompute()
        self.cfg = cfg
        from dsss_qpsk.receiver import Receiver
        self.rx = Receiver(cfg)
        self.max_symbols = int(max_symbols)

        self._pending = np.zeros(0, dtype=np.complex64)
        self._lock = threading.Lock()
        self.frames_ok = 0
        self.frames_bad = 0
        self._snr_sum = 0.0
        self._evm_sum = 0.0
        self.last = None
        self.last_text = ""
        self.t0 = time.time()
        self.message_port_register_out(pmt.intern("msg"))
        _open_window_big(window_width, window_height)

    # --- measurements, for GRC's Function Probe ---------------------------
    def snr_chip_db(self):
        return float(self.last.snr_chip_db) if self.last else float("nan")

    def snr_sym_db(self):
        return float(self.last.snr_sym_db) if self.last else float("nan")

    def evm_pct(self):
        return float(self.last.evm_pct) if self.last else float("nan")

    def mer_db(self):
        return float(self.last.mer_db) if self.last else float("nan")

    def acq_psr(self):
        return float(self.last.acq_psr) if self.last else 0.0

    def cfo_hz(self):
        return float(self.last.fine_cfo_hz) if self.last else 0.0

    def frame_count(self):
        return int(self.frames_ok)

    def mean_snr_chip_db(self):
        """Averaged over every frame so far.  A single frame's estimate moves
        around by a few tenths of a dB, which is enough to make you chase a
        calibration error that is not there."""
        return self._snr_sum / self.frames_ok if self.frames_ok else float("nan")

    def mean_evm_pct(self):
        return self._evm_sum / self.frames_ok if self.frames_ok else float("nan")

    def status_text(self):
        """One line for a QT GUI Label.  Everything you want at a glance."""
        s = self.rx.stats
        f = self.last
        tot = self.frames_ok + self.frames_bad
        head = (f"frames {self.frames_ok}/{tot} ok   "
                f"acq {s.acquisitions}   rejected {s.false_acquisitions}   ")
        if f is None:
            return head + "waiting for the first frame"
        return (head +
                f"chip SNR {f.snr_chip_db:+.1f} dB   "
                f"sym SNR {f.snr_sym_db:+.1f} dB   "
                f"EVM {f.evm_pct:.2f} %   MER {f.mer_db:.1f} dB   "
                f"CFO {f.fine_cfo_hz:+.1f} Hz   RS {max(f.rs_corrections,0)}   "
                f"acq peak/median {f.acq_psr:,.0f}")

    def last_message(self):
        return self.last_text or "(nothing decoded yet)"

    def reset_counters(self):
        """Zero the running totals.  Used when sweeping a setting so each point
        reports its own numbers instead of everything since the graph started."""
        self.frames_ok = 0
        self.frames_bad = 0
        self._snr_sum = 0.0
        self._evm_sum = 0.0
        self.rx.stats.__init__()

    # ----------------------------------------------------------------------
    def forecast(self, noutput_items, ninputs):
        # We cannot predict the ratio, and it does not matter: the scheduler
        # only uses this as a hint for how much input to make available.
        return [noutput_items] * ninputs

    def general_work(self, input_items, output_items):
        x = input_items[0]
        out = output_items[0]
        n_in = len(x)
        if n_in:
            try:
                frames = self.rx.process(np.asarray(x, dtype=np.complex64))
            except Exception:
                frames = []
            self.consume(0, n_in)
            for f in frames:
                self.last = f
                if f.ok:
                    self.frames_ok += 1
                    self._snr_sum += float(f.snr_chip_db)
                    self._evm_sum += float(f.evm_pct)
                    try:
                        self.last_text = f.payload.decode("utf-8")
                    except UnicodeDecodeError:
                        self.last_text = repr(f.payload[:48])
                    self.message_port_pub(
                        pmt.intern("msg"), pmt.intern(self.last_text))
                    if f.constellation is not None and len(f.constellation):
                        c = np.asarray(f.constellation, dtype=np.complex64)
                        with self._lock:
                            self._pending = np.concatenate(
                                [self._pending, c])[-self.max_symbols * 4:]
                else:
                    self.frames_bad += 1

        with self._lock:
            k = min(len(self._pending), len(out))
            if k:
                out[:k] = self._pending[:k]
                self._pending = self._pending[k:]
        return k


# ===========================================================================
class DsssPnMatchedFilter(gr.decim_block):
    """Samples in -> how well they match the spreading code, on a 0 to 1 scale.

    TWO OUTPUTS, BOTH 0 TO 1, BOTH THE SAME MEASUREMENT:

        0  "with the code"     correlate against `coherent` periods of the PN
                               waveform the transmitter actually uses
        1  "without the code"  correlate against a flat template of exactly the
                               same length -- the same maths, the same scale,
                               the only difference being that this one does not
                               know the code

    The number is the normalised correlation coefficient

        rho = |<x, template>| / (||x|| * ||template||)

    which Cauchy-Schwarz pins to [0, 1]: 1 means the samples in that window ARE
    the template up to a scale factor, and pure noise gives about
    1/sqrt(coherent * samples_per_symbol) -- 0.03 at the defaults.  No dB, no
    reference level to calibrate, no floor that drifts with the gain.

    WHY THE SECOND TRACE IS THE INTERESTING ONE.  Put them on the same plot and
    drag the SNR slider down.  The green trace keeps pulsing.  The red trace
    never moves off its noise value -- because without the code, a DSSS burst
    and thermal noise are the same thing.  That is the entire idea of the
    waveform, on one axis, in one picture.

    MEASURED peak of the coded trace (the uncoded one stays at ~0.03 throughout):

        chip SNR   +10     0    -6   -10   -13   -17
        rho       0.79  0.47  0.28  0.18  0.13  0.08

    HOW MUCH GAIN THIS IS.  `coherent` PN periods of despreading: 14.9 dB for
    one period plus 10*log10(coherent) for adding them, and only at the one chip
    phase where the code lines up.  The phase is unknown, so it takes the
    largest of all 62 of them and the noise gets 62 chances to be large too.
    The receiver's acquisition engine integrates 256 periods WITH a Doppler
    search and gets 36 dB, which is why it decodes where this plot merely
    twitches -- the acq peak/median in the status line is that real number.

    The coherent part is the only piece that cares about carrier offset, since
    it assumes consecutive periods share a carrier phase.  16 is the default: a
    clearly visible pulse at the sensitivity limit and still fine at the offsets
    you see on a cable.  Past a couple of kHz of offset, drop it to 4.  None of
    this affects decoding -- the receiver has its own, much better, acquisition.
    """

    def __init__(self, project_path="", spreading_factor=0, periods=32,
                 coherent=16, average=0.02):
        cfg = _load(project_path)
        if spreading_factor:
            cfg.SPREADING_FACTOR = int(spreading_factor)
            cfg.recompute()
        spsym = int(cfg.SAMPLES_PER_SYMBOL)
        self.periods = max(1, int(periods))
        self.coherent = max(1, int(coherent))
        while self.periods % self.coherent:          # must divide evenly
            self.coherent -= 1
        gr.decim_block.__init__(self, name="DSSS PN matched filter",
                                in_sig=[np.complex64],
                                out_sig=[np.float32, np.float32],
                                decim=spsym * self.periods)
        self.cfg = cfg
        self.spsym = spsym

        from dsss_qpsk import filters, pn
        code = pn.spreading_code(cfg.PN_KIND, cfg.SPREADING_FACTOR, cfg.PN_INDEX)
        # One PN period as a sampled waveform: the chips at SPS_CHIP samples per
        # chip, shaped by the same root-raised-cosine the transmitter uses, so
        # this really is the matched filter for one period of the preamble.
        up = np.zeros(len(code) * cfg.SPS_CHIP, dtype=np.float64)
        up[::cfg.SPS_CHIP] = code
        rrc = filters.rrc_taps(cfg.SPS_CHIP, cfg.RRC_SPAN_CHIPS, cfg.RRC_ROLLOFF)
        h = np.convolve(up, rrc)[:len(up)]
        self.h = np.conj((h / np.sqrt(np.sum(h ** 2) + 1e-30))[::-1]
                         ).astype(np.complex64)             # unit energy
        # The control: same length, same unit energy, no code in it at all.
        flat = np.ones(len(h), dtype=np.float64)
        self.h0 = np.conj((flat / np.sqrt(np.sum(flat ** 2)))[::-1]
                          ).astype(np.complex64)
        self._tail = np.zeros(len(self.h) - 1, dtype=np.complex64)

        # The transmitter puts the signal on a digital IF, so the matched filter
        # has to take it off again first.  Skipping this is not subtle: at a
        # 250 kHz IF and a 1 Mchip/s chip rate the carrier turns 90 degrees per
        # chip and 7.75 whole turns across one PN period, which shreds the
        # correlation the block exists to compute.
        self.if_hz = float(cfg.IF_OFFSET_HZ)
        self._if_n = 0
        self.peak_val = 0.0
        self._peak_t = time.time()

    def _rho(self, buf, template, n_out, power):
        """Normalised correlation, coherently combined over `coherent` periods."""
        y = np.convolve(buf, template, mode="valid")[:n_out * self.spsym * self.periods]
        grid = y.reshape(-1, self.spsym)
        if self.coherent > 1:
            grid = grid.reshape(-1, self.coherent, self.spsym).sum(axis=1)
        # Cauchy-Schwarz denominator: ||x|| over the template's own support,
        # times ||template||.  Stacking `coherent` unit-energy copies gives a
        # template of energy `coherent`, hence the C on the bottom.
        C = float(self.coherent)
        denom = C * np.sqrt(self.spsym * np.maximum(power, 1e-30))
        rho = np.abs(grid).max(axis=1) / denom
        return np.clip(rho.reshape(n_out, -1).max(axis=1), 0.0, 1.0)

    def work(self, input_items, output_items):
        x = np.asarray(input_items[0], dtype=np.complex64)
        out, out0 = output_items[0], output_items[1]
        n_out = len(out)
        need = n_out * self.spsym * self.periods
        x = x[:need]
        if len(x) < need:
            return 0
        if self.if_hz:
            n = np.arange(self._if_n, self._if_n + len(x), dtype=np.float64)
            x = (x * np.exp(-2j * np.pi * self.if_hz * n / self.cfg.SAMP_RATE_HZ)
                 ).astype(np.complex64)
            self._if_n += len(x)
            period = int(round(self.cfg.SAMP_RATE_HZ / max(self.if_hz, 1e-9)))
            if period > 0:
                self._if_n %= period * 1024

        buf = np.concatenate([self._tail, x])
        if len(self.h) > 1:
            self._tail = buf[-(len(self.h) - 1):]
        if len(buf) < need + len(self.h) - 1:
            return 0
        # Mean sample power per output block: the ||x|| of the normalisation.
        power = (np.abs(x) ** 2).reshape(n_out, -1).mean(axis=1)
        power = np.repeat(power, self.periods // self.coherent)

        out[:n_out] = self._rho(buf, self.h, n_out, power).astype(np.float32)
        out0[:n_out] = self._rho(buf, self.h0, n_out, power).astype(np.float32)

        # Peak hold with a decay, so peak() reports the height of the last pulse
        # rather than whatever noise happened to be in this buffer.
        now = time.time()
        self.peak_val = max(float(out[:n_out].max()),
                            self.peak_val - 0.3 * (now - self._peak_t))
        self._peak_t = now
        return n_out

    def peak(self):
        """Height of the most recent correlation pulse, 0 to 1."""
        return self.peak_val


# ===========================================================================
class DsssSpreadingDemo(gr.sync_block):
    """No input; three views of the SAME data, so you can see what spreading does.

        0  before spreading   the QPSK symbols, pulse shaped at the SYMBOL rate.
                              Put a Frequency Sink on it: about 32 kHz wide.
        1  after spreading    the same symbols multiplied by the PN code and
                              pulse shaped at the CHIP rate.  Same Frequency
                              Sink settings: about 1 MHz wide and 15 dB lower,
                              because the same power is spread over 31 times the
                              bandwidth.  That trade is the whole waveform.
        2  the symbols        one QPSK symbol held for a whole symbol period,
                              for a Constellation Sink: four exact points, which
                              is what the constellation looks like BEFORE any of
                              this happens.

    This runs continuously rather than in bursts, because it is a display: a
    spectrum that is only present 8% of the time is unreadable.  It carries no
    frames and is not part of the link -- the real transmitter is DsssTxSource.
    """

    def __init__(self, project_path="", spreading_factor=0, amplitude=1.0):
        gr.sync_block.__init__(
            self, name="DSSS spreading demo", in_sig=None,
            out_sig=[np.complex64, np.complex64, np.complex64])
        cfg = _load(project_path)
        if spreading_factor:
            cfg.SPREADING_FACTOR = int(spreading_factor)
            cfg.recompute()
        self.cfg = cfg
        self.amplitude = float(amplitude)

        from dsss_qpsk import filters, pn
        self.code = pn.spreading_code(cfg.PN_KIND, cfg.SPREADING_FACTOR,
                                      cfg.PN_INDEX).astype(np.float32)
        self.spsym = int(cfg.SAMPLES_PER_SYMBOL)
        # Two pulse shapers, identical except for what they call a symbol: one
        # at the chip rate (what the real transmitter uses) and one at the
        # symbol rate (what the same data would look like unspread).
        self.rrc_chip = filters.rrc_taps(cfg.SPS_CHIP, cfg.RRC_SPAN_CHIPS,
                                         cfg.RRC_ROLLOFF).astype(np.float64)
        self.rrc_sym = filters.rrc_taps(self.spsym, 6,
                                        cfg.RRC_ROLLOFF).astype(np.float64)
        self._rng = np.random.default_rng()
        self._buf = [np.zeros(0, dtype=np.complex64) for _ in range(3)]
        self._tail = [np.zeros(len(self.rrc_sym) - 1, dtype=np.complex64),
                      np.zeros(len(self.rrc_chip) - 1, dtype=np.complex64)]

    def _generate(self, nsym: int):
        from dsss_qpsk.modulator import bits_to_qpsk
        bits = self._rng.integers(0, 2, 2 * nsym, dtype=np.uint8)
        sym = bits_to_qpsk(bits).astype(np.complex64)

        # --- unspread: one symbol every spsym samples, shaped at symbol rate --
        up = np.zeros(nsym * self.spsym, dtype=np.complex64)
        up[::self.spsym] = sym
        a = np.convolve(np.concatenate([self._tail[0], up]), self.rrc_sym,
                        mode="valid")
        self._tail[0] = up[-(len(self.rrc_sym) - 1):]

        # --- spread: one chip every SPS_CHIP samples, shaped at chip rate -----
        chips = np.repeat(sym, self.cfg.SPREADING_FACTOR) * np.tile(self.code, nsym)
        upc = np.zeros(len(chips) * self.cfg.SPS_CHIP, dtype=np.complex64)
        upc[::self.cfg.SPS_CHIP] = chips
        b = np.convolve(np.concatenate([self._tail[1], upc]), self.rrc_chip,
                        mode="valid")
        self._tail[1] = upc[-(len(self.rrc_chip) - 1):]

        n = min(len(a), len(b), nsym * self.spsym)
        # Equal MEAN POWER on both, so the Frequency Sinks show the real trade:
        # the same energy, spread 31x wider and therefore 15 dB lower.
        def norm(v):
            p = float(np.mean(np.abs(v) ** 2))
            return (v * (self.amplitude / np.sqrt(p))).astype(np.complex64)                 if p > 0 else v.astype(np.complex64)
        return norm(a[:n]), norm(b[:n]), np.repeat(sym, self.spsym)[:n]

    def work(self, input_items, output_items):
        n = len(output_items[0])
        while len(self._buf[0]) < n:
            nsym = max(8, int(np.ceil((n - len(self._buf[0])) / self.spsym)) + 4)
            parts = self._generate(nsym)
            for i in range(3):
                self._buf[i] = np.concatenate([self._buf[i], parts[i]])
        for i in range(3):
            output_items[i][:n] = self._buf[i][:n]
            self._buf[i] = self._buf[i][n:]
        return n
