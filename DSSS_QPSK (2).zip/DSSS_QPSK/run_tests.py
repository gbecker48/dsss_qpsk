#!/usr/bin/env python3
"""
run_tests.py -- run every self-test, in order of increasing scope.

    python run_tests.py            # quick: primitives + one frame + link
    python run_tests.py --full     # adds the sensitivity sweep and false-alarm run
    python run_tests.py --gr       # also exercise the real GNU Radio flowgraph

Run this after ANY change to config.py or the DSP.  The sweep in particular is
what tells you whether a change helped or hurt: it prints the lowest chip SNR
at which frames still get through.
"""

import argparse
import subprocess
import sys
import time

PY = sys.executable


def run(label, args, python=None):
    print("\n" + "=" * 78)
    print(f"  {label}")
    print("=" * 78)
    t0 = time.time()
    r = subprocess.run([python or PY] + args)
    dt = time.time() - t0
    status = "PASS" if r.returncode == 0 else f"FAIL (exit {r.returncode})"
    print(f"  -> {status}   [{dt:.1f} s]")
    return r.returncode == 0


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--full", action="store_true")
    p.add_argument("--gr", action="store_true")
    p.add_argument("--gr-python", default=None,
                   help="interpreter that has GNU Radio (e.g. /usr/bin/python3.12)")
    a = p.parse_args()

    ok = []
    ok.append(run("UNIT TESTS -- PN codes, RRC, CRC, Reed-Solomon, Viterbi, interleaver",
                  ["-m", "dsss_qpsk.tests.test_primitives"]))
    ok.append(run("END TO END -- one frame at +10 dB chip SNR",
                  ["-m", "dsss_qpsk.tests.test_link", "10"]))
    ok.append(run("END TO END -- one frame BELOW the noise floor (-10 dB chip SNR)",
                  ["run_sim.py", "one", "-s", "-10", "-b", "128"]))
    ok.append(run("FILE TRANSFER -- wire format, big indices, selective repair",
                  ["-m", "dsss_qpsk.tests.test_filexfer"]))
    ok.append(run("LINK LAYER -- messages + ARQ over the simulated channel",
                  ["-m", "dsss_qpsk.tests.test_integration", "--snr", "-10",
                   "--messages", "3"]))

    if a.gr:
        ok.append(run("GNU RADIO -- the real flowgraph, no hardware",
                      ["-m", "dsss_qpsk.tests.test_integration", "--gr",
                       "--snr", "-10", "--messages", "3"],
                      python=a.gr_python))

    if a.full:
        ok.append(run("SENSITIVITY SWEEP",
                      ["run_sim.py", "sweep", "--start", "-16", "--stop", "-6",
                       "--step", "1", "-n", "16"]))
        ok.append(run("FALSE ALARM -- 20 s of pure noise must produce no frames",
                      ["run_sim.py", "falsealarm", "--seconds", "20"]))

    print("\n" + "=" * 78)
    print(f"  {sum(ok)}/{len(ok)} test groups passed")
    print("=" * 78)
    return 0 if all(ok) else 1


if __name__ == "__main__":
    sys.exit(main())
