#!/usr/bin/env python3
"""
run_sim.py -- exercise the complete link over a simulated channel.

This is how you check a change before you touch the radio.  Nothing here needs
UHD or GNU Radio; it runs the exact same modulator and receiver objects the
hardware flowgraph uses.

    python run_sim.py sweep            # sensitivity curve (the important one)
    python run_sim.py one -s -10       # one frame at chip SNR -10 dB, verbose
    python run_sim.py falsealarm       # how often does noise alone fake a frame
    python run_sim.py constellation -s -8 -o const.npy
    python run_sim.py bench            # can this machine keep up with the radio?
    python run_sim.py profile          # where the CPU time goes

The SNR on the x axis is the CHIP-BAND SNR.  Negative means the signal is below
the noise floor in its own occupied bandwidth.
"""

from __future__ import annotations

import argparse
import sys
import time

import numpy as np

from dsss_qpsk import channel
from dsss_qpsk import config as cfg
from dsss_qpsk.framing import FT_DATA, Header
from dsss_qpsk.modulator import Modulator
from dsss_qpsk.receiver import Receiver


def one_frame(snr_db, payload, seed=0, cfo=None, delay=None, sfo=None, phase=None,
              chunk=1 << 16):
    """Modulate one burst, push it through the channel, receive it."""
    rng = np.random.default_rng(seed)
    cfo = rng.uniform(-3000, 3000) if cfo is None else cfo
    delay = rng.uniform(0, 20) if delay is None else delay
    sfo = rng.uniform(-3, 3) if sfo is None else sfo
    phase = rng.uniform(-np.pi, np.pi) if phase is None else phase

    mod = Modulator(cfg)
    hdr = Header(ftype=FT_DATA, src=1, dst=2, seq=seed & 0x0F,
                 payload_len=len(payload))
    burst = mod.modulate(hdr, payload)
    stream = channel.apply_channel(burst, cfg, snr_db, cfo_hz=cfo, phase=phase,
                                   delay=delay, sfo_ppm=sfo, seed=seed + 7919)

    rx = Receiver(cfg)
    frames = []
    for i in range(0, len(stream), chunk):
        frames += rx.process(stream[i:i + chunk])
    frames += rx.flush()   # the stream has ended; finish anything still waiting
    truth = dict(cfo=cfo, delay=delay, sfo=sfo, phase=phase)
    return frames, rx, truth


# ------------------------------------------------------------------- commands
def cmd_one(a):
    payload = (a.text.encode() if a.text else
               bytes(np.random.default_rng(a.seed).integers(0, 256, a.bytes, dtype=np.uint8)))
    frames, rx, truth = one_frame(a.snr, payload, seed=a.seed)
    print(cfg.summary())
    print(f"\ntruth: CFO={truth['cfo']:.1f} Hz  delay={truth['delay']:.3f} samp  "
          f"SFO={truth['sfo']:.2f} ppm  phase={np.degrees(truth['phase']):.1f} deg")
    print(f"rx stats: {rx.stats}\n")
    for f in frames:
        print(f"  stage            : {f.stage}   ok={f.ok}")
        print(f"  acq peak/median  : {f.acq_psr:.1f}      sync peak/bg : {f.sync_psr:.2f}")
        print(f"  CFO coarse/fine  : {f.coarse_cfo_hz:.1f} / {f.fine_cfo_hz:.1f} Hz"
              f"   (error {f.fine_cfo_hz - truth['cfo']:+.2f} Hz)")
        print(f"  residual CFO     : {f.residual_cfo_hz:+.2f} Hz   final timing err {f.timing_err:+.4f}")
        print(f"  SNR chip / sym   : {f.snr_chip_db:.2f} / {f.snr_sym_db:.2f} dB"
              f"   (true chip {a.snr:.2f})")
        print(f"  EVM / MER        : {f.evm_pct:.2f} % / {f.mer_db:.2f} dB")
        print(f"  header           : {f.header.describe() if f.header else '--'}")
        print(f"  RS corrections   : {f.rs_corrections}   CRC32 ok: {f.crc_ok}")
        print(f"  payload          : {len(f.payload)} bytes, match={f.payload == payload}")
    return 0 if any(f.ok and f.payload == payload for f in frames) else 1


def cmd_sweep(a):
    snrs = np.arange(a.start, a.stop + 1e-9, a.step)
    payload = bytes(np.random.default_rng(0).integers(0, 256, a.bytes, dtype=np.uint8))
    print(cfg.summary())
    print(f"\n{a.trials} frames per point, {a.bytes}-byte payload, "
          f"random CFO +/-3 kHz, random SFO +/-3 ppm, random delay/phase\n")
    hdr = (f"{'chipSNR':>8s} {'symSNR':>7s} {'acq%':>6s} {'sync%':>6s} {'hdr%':>6s} "
           f"{'FRAME%':>7s} {'EVM%':>7s} {'CFOerr':>8s} {'RScorr':>7s}")
    print(hdr)
    print("-" * len(hdr))
    rows = []
    for snr in snrs:
        nacq = nsync = nhdr = nok = 0
        evms, snrs_sym, cfoerr, rscorr = [], [], [], []
        for t in range(a.trials):
            frames, rx, truth = one_frame(snr, payload, seed=1000 * (t + 1) + int(snr * 10))
            nacq += 1 if rx.stats.acquisitions else 0
            nsync += 1 if rx.stats.sync_found else 0
            nhdr += 1 if rx.stats.header_ok else 0
            good = [f for f in frames if f.ok and f.payload == payload]
            if good:
                nok += 1
                f = good[0]
                evms.append(f.evm_pct)
                snrs_sym.append(f.snr_sym_db)
                cfoerr.append(f.fine_cfo_hz - truth["cfo"])
                if f.rs_corrections >= 0:
                    rscorr.append(f.rs_corrections)
        n = a.trials
        row = (snr, np.mean(snrs_sym) if snrs_sym else np.nan,
               100 * nacq / n, 100 * nsync / n, 100 * nhdr / n, 100 * nok / n,
               np.mean(evms) if evms else np.nan,
               np.mean(np.abs(cfoerr)) if cfoerr else np.nan,
               np.mean(rscorr) if rscorr else np.nan)
        rows.append(row)
        print(f"{row[0]:8.1f} {row[1]:7.2f} {row[2]:6.0f} {row[3]:6.0f} {row[4]:6.0f} "
              f"{row[5]:7.0f} {row[6]:7.2f} {row[7]:8.2f} {row[8]:7.1f}")
    # Sensitivity = lowest SNR with >= 90% frame success.
    good = [r for r in rows if r[5] >= 90.0]
    if good:
        print(f"\nSENSITIVITY: {min(r[0] for r in good):.1f} dB chip SNR at >=90% frame success")
        print(f"             ({min(r[0] for r in good) + cfg.PROCESSING_GAIN_DB:.1f} dB "
              f"symbol SNR after {cfg.PROCESSING_GAIN_DB:.1f} dB of processing gain)")
    if a.csv:
        np.savetxt(a.csv, np.array(rows), delimiter=",",
                   header="chip_snr_db,sym_snr_db,acq_pct,sync_pct,hdr_pct,frame_pct,"
                          "evm_pct,cfo_err_hz,rs_corrections", comments="")
        print(f"wrote {a.csv}")
    return 0


def cmd_falsealarm(a):
    """Feed pure noise and count anything the receiver thinks it saw."""
    rx = Receiver(cfg)
    rng = np.random.default_rng(a.seed)
    total = int(a.seconds * cfg.SAMP_RATE_HZ)
    chunk = 1 << 17
    frames = []
    done = 0
    t0 = time.time()
    while done < total:
        n = min(chunk, total - done)
        x = (rng.standard_normal(n) + 1j * rng.standard_normal(n)) * 0.1
        frames += rx.process(x.astype(np.complex64))
        done += n
    frames += rx.flush()
    dt = time.time() - t0
    print(f"{a.seconds:.1f} s of pure noise ({total} samples) in {dt:.1f} s")
    print(f"  acquisitions       : {rx.stats.acquisitions}  "
          f"({rx.stats.acquisitions/a.seconds:.2f} /s)")
    print(f"  rejected at sync   : {rx.stats.false_acquisitions}")
    print(f"  got past sync      : {rx.stats.sync_found}")
    print(f"  header CRC passed  : {rx.stats.header_ok}   (these are the costly ones)")
    print(f"  full frames faked  : {rx.stats.payload_ok}")
    print(f"\n  ACQ_THRESHOLD_PSR = {cfg.ACQ_THRESHOLD_PSR}, "
          f"SYNC_THRESHOLD_RATIO = {cfg.SYNC_THRESHOLD_RATIO}")
    return 0


def cmd_constellation(a):
    payload = bytes(np.random.default_rng(0).integers(0, 256, a.bytes, dtype=np.uint8))
    frames, rx, truth = one_frame(a.snr, payload, seed=a.seed)
    good = [f for f in frames if f.constellation is not None]
    if not good:
        print("no frame decoded")
        return 1
    f = good[0]
    np.save(a.out, f.constellation)
    print(f"saved {len(f.constellation)} symbols to {a.out}")
    print(f"EVM {f.evm_pct:.2f}%  MER {f.mer_db:.2f} dB  symbol SNR {f.snr_sym_db:.2f} dB")
    from dsss_qpsk.ui import ascii_constellation
    print(ascii_constellation(f.constellation, cfg.CONSTELLATION_SIZE))
    return 0


def cmd_bench(a):
    """Measure whether THIS machine can keep up with the radio.

    Two numbers matter.  IDLE is the sustained rate the receiver can search for
    preambles at; it must exceed the sample rate or the receiver falls behind
    for ever and starts dropping samples -- which looks exactly like a broken
    radio, because holes in the stream destroy the coherent integration that
    acquisition depends on.  DECODE is the rate while demodulating a burst; it
    can be below 1x because bursts are intermittent and the queue absorbs them,
    but the idle margin has to be able to drain that backlog.
    """
    import time as _t
    rng = np.random.default_rng(0)
    n = 1 << 15
    noise = (rng.standard_normal(n) + 1j * rng.standard_normal(n)).astype(np.complex64) * 0.05

    rx = Receiver(cfg)
    rx.process(noise)                                   # warm up
    t0 = _t.time()
    total = 0
    while _t.time() - t0 < a.seconds:
        rx.process(noise)
        total += n
    idle = total / (_t.time() - t0)

    payload = bytes(rng.integers(0, 256, a.bytes, dtype=np.uint8))
    mod = Modulator(cfg)
    hdr = Header(ftype=FT_DATA, src=1, dst=2, payload_len=len(payload))
    stream = channel.apply_channel(mod.modulate(hdr, payload), cfg, -8,
                                   cfo_hz=1200, phase=1.1, delay=3.37,
                                   sfo_ppm=2.0, seed=5)
    rx = Receiver(cfg)
    t0 = _t.time()
    frames = []
    for i in range(0, len(stream), n):
        frames += rx.process(stream[i:i + n])
    frames += rx.flush()
    dt = _t.time() - t0
    dec = len(stream) / dt

    print(cfg.summary())
    print()
    print("=" * 74)
    print("  RECEIVER THROUGHPUT ON THIS MACHINE")
    print("=" * 74)
    print(f"  radio sample rate   : {cfg.SAMP_RATE_HZ/1e6:7.3f} Msps")
    print(f"  IDLE   (searching)  : {idle/1e6:7.3f} Msps  = {idle/cfg.SAMP_RATE_HZ:5.2f}x real time")
    print(f"  DECODE (a burst)    : {dec/1e6:7.3f} Msps  = {dec/cfg.SAMP_RATE_HZ:5.2f}x real time")
    print(f"  frames decoded ok   : {sum(1 for f in frames if f.ok)}")
    print("-" * 74)
    fs = cfg.SAMP_RATE_HZ
    margin = idle / fs
    # The number that actually predicts failure is not either rate on its own:
    # it is the fraction of the time the radio may be carrying a burst.  Running
    # a duty cycle d costs d/dec + (1-d)/idle seconds of CPU per second of air,
    # and that has to stay under 1.
    if dec > 0 and idle > fs and dec < idle:
        duty = (1.0 - fs / idle) / (fs / dec - fs / idle)
        duty = max(0.0, min(1.0, duty))
    else:
        duty = 1.0 if dec >= fs else 0.0
    print(f"  sustainable duty cycle: {duty*100:5.1f} %  "
          f"(how much of the air time may be burst)")
    print(f"    a typed message     :  ~10 %   -> "
          f"{'fine' if duty > 0.15 else 'MARGINAL'}")
    print(f"    a file transfer     :  ~90 %   -> "
          f"{'fine' if duty > 0.90 else 'will drop samples on long files'}")
    print("-" * 74)
    if margin < 1.0:
        print("  VERDICT: TOO SLOW.  The receiver cannot keep up even when idle, so it")
        print("           WILL drop samples and the link will look broken.")
        print(f"           Drop SAMP_RATE_HZ to about {idle/2/1e6:.1f}e6 or lower.")
    elif duty < 0.15:
        print("  VERDICT: MARGINAL.  It keeps up while idle but cannot absorb even")
        print("           occasional bursts.  Lower SAMP_RATE_HZ, or shorten")
        print("           MAX_PAYLOAD_BYTES so each burst costs less.")
    elif duty < 0.90:
        print("  VERDICT: OK for messages.  Long file transfers keep the air busy")
        print("           most of the time and may outrun it -- raise")
        print("           FILE_STREAM_PACE above 1.2 to leave more idle air, or")
        print("           lower SAMP_RATE_HZ.")
    else:
        print("  VERDICT: OK.  Comfortable margin for continuous operation.")
    print(f"  Max sample rate this machine should be asked to run: "
          f"~{idle/1.8/1e6:.2f} Msps")
    print("=" * 74)
    return 0


def cmd_profile(a):
    import cProfile
    import pstats
    payload = bytes(np.random.default_rng(0).integers(0, 256, a.bytes, dtype=np.uint8))
    pr = cProfile.Profile()
    pr.enable()
    one_frame(a.snr, payload, seed=1)
    pr.disable()
    pstats.Stats(pr).sort_stats("cumulative").print_stats(18)
    return 0


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    q = sub.add_parser("one", help="one frame, verbose")
    q.add_argument("-s", "--snr", type=float, default=-8.0)
    q.add_argument("-b", "--bytes", type=int, default=64)
    q.add_argument("-t", "--text", type=str, default=None)
    q.add_argument("--seed", type=int, default=1)
    q.set_defaults(func=cmd_one)

    q = sub.add_parser("sweep", help="sensitivity curve")
    q.add_argument("--start", type=float, default=-18.0)
    q.add_argument("--stop", type=float, default=0.0)
    q.add_argument("--step", type=float, default=2.0)
    q.add_argument("-n", "--trials", type=int, default=20)
    q.add_argument("-b", "--bytes", type=int, default=64)
    q.add_argument("--csv", type=str, default=None)
    q.set_defaults(func=cmd_sweep)

    q = sub.add_parser("falsealarm", help="noise-only false alarm rate")
    q.add_argument("--seconds", type=float, default=5.0)
    q.add_argument("--seed", type=int, default=3)
    q.set_defaults(func=cmd_falsealarm)

    q = sub.add_parser("constellation", help="dump + draw the constellation")
    q.add_argument("-s", "--snr", type=float, default=-8.0)
    q.add_argument("-b", "--bytes", type=int, default=256)
    q.add_argument("-o", "--out", type=str, default="constellation.npy")
    q.add_argument("--seed", type=int, default=1)
    q.set_defaults(func=cmd_constellation)

    q = sub.add_parser("bench", help="can this machine keep up with the radio?")
    q.add_argument("--seconds", type=float, default=4.0)
    q.add_argument("-b", "--bytes", type=int, default=200)
    q.set_defaults(func=cmd_bench)

    q = sub.add_parser("profile", help="CPU profile of one frame")
    q.add_argument("-s", "--snr", type=float, default=-8.0)
    q.add_argument("-b", "--bytes", type=int, default=256)
    q.set_defaults(func=cmd_profile)

    a = p.parse_args()
    sys.exit(a.func(a))


if __name__ == "__main__":
    main()
