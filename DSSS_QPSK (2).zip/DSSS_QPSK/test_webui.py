#!/usr/bin/env python3
"""Exercise every dashboard endpoint against a live simulated link."""
import json
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from dsss_qpsk import config as cfg, transports          # noqa: E402
from dsss_qpsk.link import LinkManager                    # noqa: E402
from dsss_qpsk.webui import Dashboard                     # noqa: E402

PORT = 8799
BASE = f"http://127.0.0.1:{PORT}"


def get(p):
    try:
        with urllib.request.urlopen(BASE + p, timeout=10) as r:
            return r.status, r.read(), r.headers.get("Content-Type", "")
    except urllib.error.HTTPError as e:
        return e.code, e.read(), e.headers.get("Content-Type", "")


def post(p, obj=None, raw=None, headers=None):
    data = raw if raw is not None else json.dumps(obj or {}).encode()
    req = urllib.request.Request(BASE + p, data=data, method="POST",
                                 headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())


def main():
    cfg.FILE_INBOX = str(HERE / "inbox_web")
    import shutil
    shutil.rmtree(HERE / "inbox_web", ignore_errors=True)
    cfg.recompute()

    transport = transports.SimTransport(cfg, snr_db=-12.0)
    link = LinkManager(cfg, transport)
    dash = Dashboard(cfg, link, port=PORT)
    transport.start(); link.start(); dash.start()
    time.sleep(0.4)

    fails = []

    def check(name, cond, extra=""):
        print(("  PASS  " if cond else "  FAIL  ") + name + ("  " + str(extra) if extra else ""))
        if not cond:
            fails.append(name)

    code, body, ctype = get("/")
    check("page loads", code == 200 and b"DSSS / QPSK LINK" in body, f"{len(body)} B")
    check("page is html", "text/html" in ctype)

    code, body, _ = get("/data?since=0")
    d = json.loads(body)
    check("data endpoint", code == 200 and "spectrum" in d and "cfg" in d)
    check("config exposed", len(d["cfg"]) >= 15, f"{len(d['cfg'])} keys")

    code, r = post("/send", {"text": "hello over the air"})
    check("send text", code == 200 and r.get("ok"))

    code, r = post("/ping", {})
    check("ping", code == 200)

    code, r = post("/set", {"key": "ARQ_MAX_RETRIES", "value": "5"})
    check("set a knob", code == 200 and cfg.ARQ_MAX_RETRIES == 5, r.get("message"))
    code, r = post("/set", {"key": "NOPE_NOT_REAL", "value": "1"})
    check("set rejects unknown", code == 400 and "error" in r)

    code, body, _ = get("/browse?path=" + str(HERE))
    b = json.loads(body)
    check("browse", code == 200 and any(e["name"] == "run_link.py" for e in b["entries"]),
          f"{len(b.get('entries', []))} entries")

    # ---- the real one: upload a file and wait for it to come back ----------
    blob = bytes(range(256)) * 12          # 3072 B, 7 segments
    code, r = post("/upload", raw=blob,
                   headers={"X-Filename": "endpoint_test.bin"})
    check("upload accepted", code == 200 and r.get("bytes") == len(blob))

    got = None
    t0 = time.time()
    while time.time() - t0 < 120:
        time.sleep(0.5)
        _, body, _ = get("/data?since=0")
        d = json.loads(body)
        for f in d.get("inbox", []):
            if f["name"] == "endpoint_test.bin":
                got = f
                break
        if got:
            break
    check("file arrived in inbox", got is not None and got["size"] == len(blob),
          f"{time.time()-t0:.1f} s")

    if got:
        code, body, ctype = get("/file?name=endpoint_test.bin")
        check("download matches byte for byte", code == 200 and body == blob)
    code, body, _ = get("/file?name=../config.py")
    check("download refuses a path escape", code == 404)

    # ---- levels: the 0..1 sliders ---------------------------------------
    _, body, _ = get("/data?since=0")
    d = json.loads(body)
    L = d.get("levels") or {}
    check("levels block present", bool(L), ", ".join(sorted(L)[:4]))
    check("gain ranges exposed",
          len(L.get("tx_range", [])) == 2 and len(L.get("rx_range", [])) == 2,
          f"tx {L.get('tx_range')} rx {L.get('rx_range')}")
    check("gains normalized 0..1",
          0.0 <= L.get("tx_norm", -1) <= 1.0 and 0.0 <= L.get("rx_norm", -1) <= 1.0,
          f"tx {L.get('tx_norm'):.3f} rx {L.get('rx_norm'):.3f}")

    code, r = post("/level", {"level": 0.25})
    check("level endpoint accepts 0..1", code == 200 and "level" in r,
          json.dumps({k: v for k, v in r.items() if k != "ok"})[:70])
    _, body, _ = get("/data?since=0")
    check("level round-trips through the snapshot",
          abs(json.loads(body)["levels"]["level"] - 0.25) < 1e-6)
    # Simulated transport: the slider moves the NOISE, so a lower level must
    # mean a lower simulated SNR.  That is the whole point of the control.
    lo = json.loads(body)["levels"].get("sim_snr_db")
    post("/level", {"level": 0.9})
    _, body, _ = get("/data?since=0")
    hi = json.loads(body)["levels"].get("sim_snr_db")
    check("level actually moves SNR", lo is not None and hi is not None and hi > lo,
          f"{lo:.1f} dB at 0.25 -> {hi:.1f} dB at 0.90")
    post("/level", {"level": 1.0})

    code, r = post("/level", {"level": 5.0})
    _, body, _ = get("/data?since=0")
    check("level clamps out-of-range input",
          json.loads(body)["levels"]["level"] <= 1.0)
    post("/level", {"level": 1.0})

    code, r = post("/gain", {"which": "tx", "norm": 0.5})
    check("gain endpoint reachable", code == 200, str(r)[:50])
    code, r = post("/gain", {"which": "nonsense", "norm": 0.5})
    check("gain rejects an unknown side", code == 400)

    _, body, _ = get("/data?since=0")
    d = json.loads(body)
    check("transfer history recorded",
          bool(d.get("transfers") or d.get("transfer_history")))
    check("stream frames counted", d["stream_tx"] > 0, f"{d['stream_tx']} sent")
    check("constellation present", len(d["constellation"]) > 100,
          f"{len(d['constellation'])//2} symbols")
    check("spectrum present", len(d["spectrum"]["db"]) > 100)
    check("log has entries", len(d["log"]) > 3, f"{len(d['log'])} events")

    dash.stop(); link.stop(); transport.stop()
    print()
    print("ALL PASS" if not fails else "FAILED: " + ", ".join(fails))
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
