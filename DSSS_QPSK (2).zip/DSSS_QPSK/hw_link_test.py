#!/usr/bin/env python3
"""
hw_link_test.py -- end to end link test on the REAL radio, non-interactive.

    python hw_link_test.py                      4 messages of 64 bytes
    python hw_link_test.py -n 6 -b 256
    python hw_link_test.py --web                also serve the dashboard

This is the proof that the whole stack works on hardware: modulator -> USRP ->
cable -> USRP -> receiver -> FEC -> ARQ.  It runs headless and prints a verdict,
so it can be driven from the bridge.
"""

import argparse
import os
import sys
import time

import numpy as np

from dsss_qpsk import config as cfg
from dsss_qpsk.link import LinkManager


def main():
    p = argparse.ArgumentParser()
    p.add_argument("-n", "--messages", type=int, default=4)
    p.add_argument("-b", "--bytes", type=int, default=64)
    p.add_argument("--timeout", type=float, default=120.0)
    p.add_argument("--txgain", type=float, default=None)
    p.add_argument("--rxgain", type=float, default=None)
    p.add_argument("--web", action="store_true")
    p.add_argument("--cfo", type=float, default=None,
                   help="RX_FREQ_OFFSET_HZ: retune the RECEIVE synthesizer this "
                        "far from the transmit one.  A real hardware carrier "
                        "offset from a real independent PLL.  Search covers "
                        "+/-16.1 kHz.")
    p.add_argument("--ppm", type=float, default=None,
                   help="TX_SFO_PPM: resample the burst before the DAC so the "
                        "chip rate that comes back differs from the receiver's "
                        "by this many ppm -- a real sample clock offset.")
    a = p.parse_args()

    if a.cfo is not None:
        cfg.RX_FREQ_OFFSET_HZ = float(a.cfo)
    if a.ppm is not None:
        cfg.TX_SFO_PPM = float(a.ppm)
    if a.txgain is not None:
        cfg.TX_GAIN_DB = a.txgain
    if a.rxgain is not None:
        cfg.RX_GAIN_DB = a.rxgain
    cfg.recompute()
    print(cfg.summary())
    print(f"\n  TX gain {cfg.TX_GAIN_DB}  RX gain {cfg.RX_GAIN_DB}  "
          f"{cfg.TX_ANTENNA} -> {cfg.RX_ANTENNA}")
    print(f"  impairments: RX LO offset {cfg.RX_FREQ_OFFSET_HZ:+.0f} Hz, "
          f"clock offset {cfg.TX_SFO_PPM:+.1f} ppm\n")

    from dsss_qpsk import transports
    tr = transports.UsrpTransport(cfg)
    print(f"  radio: {tr.describe()}\n")
    link = LinkManager(cfg, tr)

    dash = None
    if a.web:
        from dsss_qpsk.webui import Dashboard
        dash = Dashboard(cfg, link, port=cfg.WEB_PORT, host=cfg.WEB_HOST)
        print(f"  dashboard: {dash.start()}\n")

    tr.start()
    link.start()
    time.sleep(1.0)                      # let the receiver see some noise first

    rng = np.random.default_rng(7)
    sent = []
    for i in range(a.messages):
        msg = (f"HW TEST {i:03d} " + "".join(
            chr(int(c)) for c in rng.integers(33, 126, max(0, a.bytes - 12))))
        sent.append(msg.encode())
        link.send_text(msg)

    got, seen = [], 0
    t0 = time.time()
    while time.time() - t0 < a.timeout:
        ev = list(link.events)
        for e in ev[seen:]:
            tag = {"rx": "<<", "tx": ">>", "ack": "ok", "timeout": "!!",
                   "error": "XX"}.get(e.kind, "..")
            extra = ""
            if e.kind == "rx" and e.frame is not None:
                f = e.frame
                extra = (f"  [chipSNR {f.snr_chip_db:+6.1f} symSNR {f.snr_sym_db:6.1f} "
                         f"EVM {f.evm_pct:5.2f}%  RS {max(f.rs_corrections,0):2d}  "
                         f"CFO {f.fine_cfo_hz:+7.1f} Hz  acqPSR {f.acq_psr:.0f}]")
                got.append(e.text.encode())
            print(f"  {tag} {e.text[:46]:46s}{extra}", flush=True)
        seen = len(ev)
        if len(got) >= a.messages and link.queue_depth() == 0:
            break
        time.sleep(0.1)

    time.sleep(0.6)
    ok = all(s in got for s in sent)
    s = link.rx.stats
    print("\n" + "=" * 74)
    print(f"  sent {len(sent)}   received {len(got)}   all matched: {ok}")
    print(f"  retries {link.total_retries}  deferred {link.deferred_retries}  "
          f"late ACKs {link.late_acks}  lost {link.lost_messages}")
    print(f"  mean RTT {link.rtt_avg*1e3:.0f} ms")
    print(f"  {s}")
    print(f"  deaf {100*s.deaf_samples/max(s.samples_processed,1):.1f}%   "
          f"buffer_aborts {s.buffer_aborts}   stalls {s.stalls}")
    print(f"  gr sink dropped {tr.sink.dropped} samples, "
          f"max backlog {tr.sink.max_backlog}, errors {tr.sink.errors}")
    if link.last_frame is not None and link.last_frame.constellation is not None:
        os.makedirs("hwdata", exist_ok=True)
        np.save("hwdata/last_constellation.npy", link.last_frame.constellation)
        print("  saved hwdata/last_constellation.npy")
    print(f"  VERDICT: {'PASS' if ok else 'FAIL'}")
    print("=" * 74)

    if dash:
        dash.stop()
    link.stop()
    tr.stop()
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
