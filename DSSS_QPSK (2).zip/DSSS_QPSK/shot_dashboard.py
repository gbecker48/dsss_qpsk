#!/usr/bin/env python3
"""Run the link in simulation, drive some traffic, and screenshot the dashboard.

This is how the UI gets looked at without a radio: it is the real page, served
by the real Dashboard, reading a real (simulated) link.
"""
import shutil
import sys
import threading
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from dsss_qpsk import config as cfg, transports      # noqa: E402
from dsss_qpsk.link import LinkManager                # noqa: E402
from dsss_qpsk.webui import Dashboard                 # noqa: E402

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8797
WIDTH = int(sys.argv[2]) if len(sys.argv) > 2 else 1600
OUT = sys.argv[3] if len(sys.argv) > 3 else "dashboard.png"
SNR = float(sys.argv[4]) if len(sys.argv) > 4 else -12.0


def main():
    shutil.rmtree(HERE / "inbox_shot", ignore_errors=True)
    cfg.FILE_INBOX = str(HERE / "inbox_shot")
    cfg.recompute()
    transport = transports.SimTransport(cfg, snr_db=SNR)
    link = LinkManager(cfg, transport)
    dash = Dashboard(cfg, link, port=PORT)
    transport.start(); link.start(); dash.start()

    def traffic():
        time.sleep(1.0)
        for i in range(4):
            link.send_text(f"message {i}: the quick brown fox jumps over the lazy dog")
            time.sleep(1.2)
        blob = bytes(range(256)) * 40         # 10 kB, 20 segments
        (HERE / "shotfile.bin").write_bytes(blob)
        link.send_file(HERE / "shotfile.bin")
    threading.Thread(target=traffic, daemon=True).start()

    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        b = p.chromium.launch(args=["--no-sandbox"])
        pg = b.new_page(viewport={"width": WIDTH, "height": 1200},
                        device_scale_factor=1)
        pg.goto(f"http://127.0.0.1:{PORT}/", wait_until="load")
        time.sleep(14)                        # let traffic and a transfer run
        pg.screenshot(path=OUT, full_page=True)
        errs = []
        pg.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
        time.sleep(1.5)
        b.close()
    dash.stop(); link.stop(); transport.stop()
    print("wrote", OUT)
    if errs:
        print("CONSOLE ERRORS:", *errs, sep="\n  ")


if __name__ == "__main__":
    main()
