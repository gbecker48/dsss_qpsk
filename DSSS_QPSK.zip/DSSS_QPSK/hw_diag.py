#!/usr/bin/env python3
r"""
hw_diag.py -- find out what the radio is ACTUALLY doing.

Run this on the machine with the USRP attached, from the radioconda prompt:

    python hw_diag.py                    full sweep, writes hwdata\
    python hw_diag.py --quick            probe + CW tone only (about 20 s)
    python hw_diag.py --rx-only          no transmit at all (noise floor only)
    python hw_diag.py --freq 915e6 --rate 2e6 --txgain 60 --rxgain 30

WHY: the link reports chip SNR of -20 to -36 dB, and no amount of processing
gain fixes it.  That number comes from the receiver's own estimate, and if the
receiver is triggering on noise and never actually seeing the burst, that is
EXACTLY the number it prints.  So the first job is not more DSP -- it is to find
out whether the signal is physically getting from TX to RX at all, and at what
level.  This script answers that with measurements that do not depend on the
modem working.

WHAT IT MEASURES
  1. Device identity, firmware/FPGA, USB link speed.
  2. Requested vs ACTUAL sample rate and master clock rate.  A silent rate
     substitution makes the whole waveform wrong and is a prime suspect.
  3. LO lock sensors on TX and RX after tuning.
  4. Noise floor vs RX gain, with TX idle.  Tells you whether the front end is
     behaving and where it starts compressing.
  5. CW TONE LOOPBACK -- the important one.  Transmits a single tone through
     your cable/attenuator and measures, at the receiver:
        * tone power vs noise floor in the chip bandwidth  <- the real link SNR
        * DC offset and LO leakage
        * image rejection (IQ imbalance)
        * whether the level moves the way TX/RX gain says it should
     If the tone SNR is high but the modem reports -20 dB, the problem is in the
     waveform or the DSP.  If the tone SNR is also low, it is RF: cabling,
     antenna port, gain, or attenuation.
  6. TX/RX gain sweep, to find the operating point and detect compression.
  7. A real DSSS burst transmitted and captured, saved as raw IQ so it can be
     analysed offline in full.

EVERYTHING is written to hwdata\ :
     report.json     every number, machine readable
     report.txt      the same thing, readable
     cap_*.npy       raw complex64 IQ captures
Nothing here depends on the link working, so it still produces a diagnosis when
the link is completely broken.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import threading
import time
import traceback
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
REPORT: dict = {"stages": {}, "errors": []}


def log(msg=""):
    print(msg, flush=True)


def stage(name):
    """Decorator-ish helper: record a stage result, never let it kill the run."""
    def wrap(fn):
        log("\n" + "=" * 72)
        log(f"  {name}")
        log("=" * 72)
        try:
            out = fn()
            REPORT["stages"][name] = out if out is not None else {"ok": True}
            return out
        except Exception as e:
            tb = traceback.format_exc()
            log(f"  !! FAILED: {e!r}")
            log(tb.splitlines()[-1])
            REPORT["stages"][name] = {"ok": False, "error": repr(e)}
            REPORT["errors"].append({"stage": name, "error": repr(e), "traceback": tb})
            return None
    return wrap


# ============================================================ signal analysis
def analyse(x: np.ndarray, samp_rate: float, tone_hz: float | None = None) -> dict:
    """Everything worth knowing about a block of IQ, without assuming a modem."""
    x = np.asarray(x, dtype=np.complex64)
    n = len(x)
    out = {"n_samples": n, "seconds": n / samp_rate}
    if n == 0:
        return out

    dc = complex(np.mean(x))
    out["dc_offset"] = [float(dc.real), float(dc.imag)]
    out["dc_mag"] = float(abs(dc))
    out["rms"] = float(np.sqrt(np.mean(np.abs(x) ** 2)))
    out["peak"] = float(np.max(np.abs(x)))
    out["papr_db"] = float(20 * np.log10(out["peak"] / max(out["rms"], 1e-12)))
    # ADC clipping shows up as a hard ceiling near full scale.
    out["frac_above_0p9"] = float(np.mean(np.abs(x) > 0.9))
    out["frac_above_0p99"] = float(np.mean(np.abs(x) > 0.99))

    # Welch-ish spectrum
    nfft = 4096
    nseg = max(1, min(64, n // nfft))
    win = np.hanning(nfft).astype(np.float32)
    acc = np.zeros(nfft)
    for i in range(nseg):
        seg = x[i * nfft:(i + 1) * nfft]
        if len(seg) < nfft:
            break
        acc += np.abs(np.fft.fftshift(np.fft.fft(seg * win))) ** 2
    psd = acc / max(nseg, 1) / (nfft * float(np.sum(win ** 2)))
    freqs = np.fft.fftshift(np.fft.fftfreq(nfft, 1.0 / samp_rate))
    psd_db = 10 * np.log10(psd + 1e-30)
    out["psd_freqs_hz"] = freqs[::16].tolist()
    out["psd_db"] = psd_db[::16].tolist()

    pk = int(np.argmax(psd))
    out["spectral_peak_hz"] = float(freqs[pk])
    out["spectral_peak_db"] = float(psd_db[pk])
    # median = noise floor, immune to the tone itself
    out["noise_floor_db"] = float(np.median(psd_db))
    out["peak_over_floor_db"] = out["spectral_peak_db"] - out["noise_floor_db"]

    # DC bin level relative to the floor -> LO leakage
    dcbin = nfft // 2
    out["dc_bin_db"] = float(psd_db[dcbin])
    out["dc_over_floor_db"] = out["dc_bin_db"] - out["noise_floor_db"]

    if tone_hz is not None:
        def band_power(centre, half_bw=6000.0):
            m = np.abs(freqs - centre) <= half_bw
            return float(psd[m].sum()) if m.any() else 0.0

        p_tone = band_power(tone_hz)
        p_image = band_power(-tone_hz)
        # noise density * chip bandwidth, from a band with no tone in it
        clear = np.abs(np.abs(freqs) - abs(tone_hz)) > 60000.0
        clear &= np.abs(freqs) > 20000.0
        n_density = float(np.median(psd[clear])) if clear.any() else 1e-30
        chip_bw = samp_rate / 2.0            # SPS_CHIP = 2
        bins_in_chip_bw = chip_bw / (samp_rate / nfft)
        p_noise_chipbw = n_density * bins_in_chip_bw

        out["tone_hz"] = tone_hz
        out["tone_power"] = p_tone
        out["image_power"] = p_image
        out["image_rejection_db"] = float(
            10 * np.log10(max(p_tone, 1e-30) / max(p_image, 1e-30)))
        out["tone_snr_chipbw_db"] = float(
            10 * np.log10(max(p_tone, 1e-30) / max(p_noise_chipbw, 1e-30)))
        out["noise_density_db"] = float(10 * np.log10(max(n_density, 1e-30)))
    return out


def save_capture(x: np.ndarray, name: str, outdir: Path, decimate: int = 1):
    p = outdir / f"cap_{name}.npy"
    np.save(p, np.asarray(x, dtype=np.complex64)[::decimate])
    log(f"    saved {p.name}  ({p.stat().st_size/1e6:.1f} MB)")
    return str(p.name)


def _sensor_str(sv) -> str:
    """Render a UHD sensor_value across binding versions.

    UHD 4.10's Python bindings dropped to_pp_string(), so the older call throws
    AttributeError and you lose exactly the readings you want most (lo_locked,
    rssi, temp).  Try everything.
    """
    for attr in ("to_pp_string", "value", "to_bool"):
        try:
            v = getattr(sv, attr)
            return str(v() if callable(v) else v)
        except Exception:
            continue
    try:
        return str(sv)
    except Exception:
        return "<unreadable>"


# ============================================================== UHD plumbing
class Radio:
    """Thin wrapper over the UHD Python API with everything read BACK."""

    def __init__(self, args, freq, rate, txgain, rxgain, tx_ant, rx_ant, bw=None):
        import uhd
        self.uhd = uhd
        self.usrp = uhd.usrp.MultiUSRP(args)
        self.freq = float(freq)
        self.req_rate = float(rate)

        self.info = {}
        try:
            d = self.usrp.get_usrp_rx_info(0)
            self.info = {k: d[k] for k in d.keys()}
        except Exception as e:
            self.info = {"error": repr(e)}

        self.usrp.set_rx_rate(self.req_rate, 0)
        self.usrp.set_tx_rate(self.req_rate, 0)
        self.rate = float(self.usrp.get_rx_rate(0))
        self.tx_rate = float(self.usrp.get_tx_rate(0))
        self.mcr = float(self.usrp.get_master_clock_rate())

        self.usrp.set_rx_freq(uhd.types.TuneRequest(self.freq), 0)
        self.usrp.set_tx_freq(uhd.types.TuneRequest(self.freq), 0)
        self.usrp.set_rx_gain(float(rxgain), 0)
        self.usrp.set_tx_gain(float(txgain), 0)
        try:
            self.usrp.set_rx_antenna(tx_ant if False else rx_ant, 0)
            self.usrp.set_tx_antenna(tx_ant, 0)
        except Exception as e:
            REPORT["errors"].append({"stage": "antenna", "error": repr(e)})
        if bw:
            try:
                self.usrp.set_rx_bandwidth(float(bw), 0)
                self.usrp.set_tx_bandwidth(float(bw), 0)
            except Exception:
                pass
        time.sleep(0.3)                       # let the LOs settle

        st = uhd.usrp.StreamArgs("fc32", "sc16")
        st.channels = [0]
        self.rx_streamer = self.usrp.get_rx_stream(st)
        self.tx_streamer = self.usrp.get_tx_stream(st)

    # ---------------------------------------------------------------- readback
    def describe(self) -> dict:
        u = self.usrp
        d = {
            "usrp_info": self.info,
            "requested_rate": self.req_rate,
            "actual_rx_rate": self.rate,
            "actual_tx_rate": self.tx_rate,
            "rate_error_ppm": (self.rate - self.req_rate) / self.req_rate * 1e6,
            "master_clock_rate": self.mcr,
            "rx_freq": float(u.get_rx_freq(0)),
            "tx_freq": float(u.get_tx_freq(0)),
            "rx_gain": float(u.get_rx_gain(0)),
            "tx_gain": float(u.get_tx_gain(0)),
        }
        for k, fn in (("rx_antenna", u.get_rx_antenna), ("tx_antenna", u.get_tx_antenna)):
            try:
                d[k] = fn(0)
            except Exception as e:
                d[k] = repr(e)
        for k, fn in (("rx_antennas", u.get_rx_antennas), ("tx_antennas", u.get_tx_antennas)):
            try:
                d[k] = list(fn(0))
            except Exception as e:
                d[k] = repr(e)
        for k, fn in (("rx_gain_range", u.get_rx_gain_range),
                      ("tx_gain_range", u.get_tx_gain_range)):
            try:
                r = fn(0)
                d[k] = [float(r.start()), float(r.stop()), float(r.step())]
            except Exception as e:
                d[k] = repr(e)
        for k, fn in (("rx_bandwidth", u.get_rx_bandwidth), ("tx_bandwidth", u.get_tx_bandwidth)):
            try:
                d[k] = float(fn(0))
            except Exception as e:
                d[k] = repr(e)
        # sensors -- lo_locked is the one that matters
        for side, names_fn, get_fn in (("rx", u.get_rx_sensor_names, u.get_rx_sensor),
                                       ("tx", u.get_tx_sensor_names, u.get_tx_sensor)):
            try:
                d[f"{side}_sensors"] = {nm: _sensor_str(get_fn(nm, 0))
                                        for nm in names_fn(0)}
            except Exception as e:
                d[f"{side}_sensors"] = repr(e)
        try:
            d["mboard_sensors"] = {nm: _sensor_str(u.get_mboard_sensor(nm, 0))
                                   for nm in u.get_mboard_sensor_names(0)}
        except Exception as e:
            d["mboard_sensors"] = repr(e)
        return d

    def set_gains(self, txg=None, rxg=None):
        if txg is not None:
            self.usrp.set_tx_gain(float(txg), 0)
        if rxg is not None:
            self.usrp.set_rx_gain(float(rxg), 0)
        time.sleep(0.05)

    # -------------------------------------------------------------- streaming
    def receive(self, nsamps: int, settle: float = 0.05) -> np.ndarray:
        uhd = self.uhd
        buf = np.zeros(nsamps, dtype=np.complex64)
        md = uhd.types.RXMetadata()
        cmd = uhd.types.StreamCMD(uhd.types.StreamMode.start_cont)
        cmd.stream_now = True
        self.rx_streamer.issue_stream_cmd(cmd)
        spb = self.rx_streamer.get_max_num_samps()
        tmp = np.zeros(spb, dtype=np.complex64)

        # throw away the first samples: the front end and any AGC need to settle
        t_end = time.time() + settle
        while time.time() < t_end:
            self.rx_streamer.recv(tmp, md, 1.0)

        got = 0
        overflows = 0
        errors = []
        while got < nsamps:
            n = self.rx_streamer.recv(tmp, md, 2.0)
            if md.error_code != uhd.types.RXMetadataErrorCode.none:
                name = str(md.error_code)
                if "overflow" in name.lower():
                    overflows += 1
                else:
                    errors.append(name)
                    if len(errors) > 20:
                        break
                continue
            take = min(n, nsamps - got)
            buf[got:got + take] = tmp[:take]
            got += take
        stop = uhd.types.StreamCMD(uhd.types.StreamMode.stop_cont)
        self.rx_streamer.issue_stream_cmd(stop)
        self.last_rx_stats = {"overflows": overflows, "errors": errors[:5], "got": got}
        return buf[:got]

    def stream_count(self, duration: float) -> dict:
        """Stream RX for `duration` seconds, discarding samples, counting errors.

        This is the USB stress test.  A B2xx on USB 2 cannot sustain full-duplex
        streaming at every rate the software will happily ask for; when it falls
        behind you get overflows, which punch holes in the sample stream.  Holes
        are fatal to this waveform specifically: acquisition coherently
        integrates 128 PN periods, and a dropped chunk in the middle of that
        integration destroys the correlation peak.
        """
        uhd = self.uhd
        md = uhd.types.RXMetadata()
        cmd = uhd.types.StreamCMD(uhd.types.StreamMode.start_cont)
        cmd.stream_now = True
        self.rx_streamer.issue_stream_cmd(cmd)
        spb = self.rx_streamer.get_max_num_samps()
        tmp = np.zeros(spb, dtype=np.complex64)
        got = 0
        overflows = 0
        others = {}
        t0 = time.time()
        while time.time() - t0 < duration:
            n = self.rx_streamer.recv(tmp, md, 1.0)
            ec = md.error_code
            if ec != uhd.types.RXMetadataErrorCode.none:
                nm = str(ec)
                if "overflow" in nm.lower():
                    overflows += 1
                else:
                    others[nm] = others.get(nm, 0) + 1
                continue
            got += n
        dt = time.time() - t0
        self.rx_streamer.issue_stream_cmd(
            uhd.types.StreamCMD(uhd.types.StreamMode.stop_cont))
        return {"seconds": dt, "samples": got, "achieved_sps": got / max(dt, 1e-9),
                "overflows": overflows, "other_errors": others}

    def transmit_loop(self, wave: np.ndarray, duration: float, stop_evt: threading.Event):
        """Repeat `wave` continuously for `duration` seconds on a worker thread."""
        uhd = self.uhd
        md = uhd.types.TXMetadata()
        md.start_of_burst = True
        md.end_of_burst = False
        md.has_time_spec = False
        w = np.asarray(wave, dtype=np.complex64)
        t_end = time.time() + duration
        underruns = 0
        try:
            while time.time() < t_end and not stop_evt.is_set():
                self.tx_streamer.send(w, md)
                md.start_of_burst = False
        finally:
            md.end_of_burst = True
            try:
                self.tx_streamer.send(np.zeros(1, dtype=np.complex64), md)
            except Exception:
                pass
        self.last_tx_underruns = underruns

    def tx_rx_simultaneous(self, wave: np.ndarray, nsamps: int,
                           tx_lead: float = 0.25) -> np.ndarray:
        """Start transmitting, let it settle, then capture."""
        stop = threading.Event()
        dur = tx_lead + nsamps / self.rate + 0.4
        th = threading.Thread(target=self.transmit_loop, args=(wave, dur, stop),
                              daemon=True)
        th.start()
        time.sleep(tx_lead)
        try:
            x = self.receive(nsamps, settle=0.05)
        finally:
            stop.set()
            th.join(timeout=2.0)
        return x


# ==================================================================== stages
def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--args", default="", help="UHD device args, e.g. type=b200")
    ap.add_argument("--freq", type=float, default=915e6)
    ap.add_argument("--rate", type=float, default=2e6)
    ap.add_argument("--txgain", type=float, default=50.0)
    ap.add_argument("--rxgain", type=float, default=40.0)
    ap.add_argument("--tx-ant", default="TX/RX")
    ap.add_argument("--rx-ant", default="RX2")
    ap.add_argument("--bw", type=float, default=None)
    ap.add_argument("--tone", type=float, default=250e3, help="CW tone offset, Hz")
    ap.add_argument("--capture", type=float, default=0.20,
                    help="capture length in seconds per test")
    ap.add_argument("--amplitude", type=float, default=0.35)
    ap.add_argument("--outdir", default="hwdata")
    ap.add_argument("--max-txgain", type=float, default=60.0,
                    help="highest TX gain the sweep is allowed to use.  Keep this "
                         "low unless there is real attenuation in the loopback "
                         "path -- a bare cable at high TX gain can damage the "
                         "receiver front end.")
    ap.add_argument("--autolevel", action="store_true",
                    help="find TX/RX gains that fill the ADC without clipping")
    ap.add_argument("--rx-start", type=float, default=20.0,
                    help="RX gain to park at while auto-levelling")
    ap.add_argument("--target-rms", type=float, default=0.08,
                    help="RX rms to aim for (leaves headroom for the waveform's "
                         "peak-to-average ratio)")
    ap.add_argument("--stability", action="store_true",
                    help="sustained full-duplex streaming test")
    ap.add_argument("--stability-s", type=float, default=6.0)
    ap.add_argument("--quick", action="store_true", help="probe + tone only")
    ap.add_argument("--rx-only", action="store_true", help="never transmit")
    ap.add_argument("--no-burst", action="store_true", help="skip the DSSS burst test")
    a = ap.parse_args()

    outdir = HERE / a.outdir
    outdir.mkdir(exist_ok=True)
    REPORT["argv"] = vars(a)
    REPORT["time"] = time.strftime("%Y-%m-%d %H:%M:%S")
    REPORT["python"] = sys.version.split()[0]

    log("=" * 72)
    log("  USRP HARDWARE DIAGNOSTIC")
    log("=" * 72)
    log(f"  args={a.args!r}  freq={a.freq/1e6:.3f} MHz  rate={a.rate/1e6:.3f} Msps")
    log(f"  txgain={a.txgain}  rxgain={a.rxgain}  tx_ant={a.tx_ant}  rx_ant={a.rx_ant}")
    log(f"  writing to {outdir}")

    try:
        import uhd
        REPORT["uhd_version"] = uhd.get_version_string()
        log(f"  UHD {REPORT['uhd_version']}")
    except Exception as e:
        log(f"  !! cannot import uhd: {e!r}")
        REPORT["errors"].append({"stage": "import", "error": repr(e)})
        finish(outdir)
        return 1

    radio = None

    @stage("1. device probe and rate readback")
    def _probe():
        nonlocal radio
        radio = Radio(a.args, a.freq, a.rate, a.txgain, a.rxgain,
                      a.tx_ant, a.rx_ant, a.bw)
        d = radio.describe()
        log(f"    mboard          : {d['usrp_info'].get('mboard_id','?')} "
            f"serial {d['usrp_info'].get('mboard_serial','?')}")
        log(f"    requested rate  : {d['requested_rate']/1e6:.6f} Msps")
        log(f"    ACTUAL rx rate  : {d['actual_rx_rate']/1e6:.6f} Msps")
        log(f"    ACTUAL tx rate  : {d['actual_tx_rate']/1e6:.6f} Msps")
        log(f"    master clock    : {d['master_clock_rate']/1e6:.6f} MHz")
        if abs(d["rate_error_ppm"]) > 1.0:
            log(f"    !! RATE MISMATCH: {d['rate_error_ppm']:.1f} ppm off. "
                f"The modem assumes the requested rate -- this alone breaks it.")
        log(f"    antennas        : tx={d.get('tx_antenna')} rx={d.get('rx_antenna')}")
        log(f"                      available tx={d.get('tx_antennas')} rx={d.get('rx_antennas')}")
        log(f"    gain ranges     : tx={d.get('tx_gain_range')} rx={d.get('rx_gain_range')}")
        log(f"    bandwidths      : tx={d.get('tx_bandwidth')} rx={d.get('rx_bandwidth')}")
        for k in ("rx_sensors", "tx_sensors", "mboard_sensors"):
            log(f"    {k:15s} : {d.get(k)}")
        return d

    if radio is None:
        finish(outdir)
        return 1

    rate = radio.rate

    def _link_waveform():
        """The REAL modulated burst, repeated back to back.

        Levelling on a CW tone is misleading: a tone has 0 dB peak-to-average,
        so it survives clipping looking fine, while this waveform has several dB
        of peak-to-average and is spread across the whole band -- clip it and the
        despread correlation collapses.  Level on the thing you actually send.
        """
        sys.path.insert(0, str(HERE))
        from dsss_qpsk import config as c
        from dsss_qpsk.framing import FT_DATA, Header
        from dsss_qpsk.modulator import Modulator
        c.SAMP_RATE_HZ = rate
        c.recompute()
        m = Modulator(c)
        return m.modulate(Header(ftype=FT_DATA, src=1, dst=255, seq=1,
                                 payload_len=32), b"autolevel test payload  ")

    if a.autolevel:
        @stage("A. AUTOLEVEL -- find gains that do not saturate the receiver")
        def _auto():
            wave = _link_waveform()
            n = int(0.04 * rate)
            txg = float(a.txgain)
            rxg = float(a.rx_start)
            target = float(a.target_rms)
            rows = []
            best = None
            log(f"    target RX rms {target:.3f} with no clipping, "
                f"RX gain parked at {rxg:.0f} dB")
            for it in range(12):
                radio.set_gains(txg=txg, rxg=rxg)
                x = radio.tx_rx_simultaneous(wave, n, tx_lead=0.12)
                m = analyse(x, rate)
                rms, clip = m["rms"], m["frac_above_0p9"]
                rows.append({"iter": it, "txgain": txg, "rxgain": rxg,
                             "rms": rms, "clip": clip, "peak": m["peak"]})
                log(f"    tx {txg:5.1f}  rx {rxg:4.1f} -> rms {rms:.5f}  "
                    f"peak {m['peak']:.3f}  clipped {clip*100:7.3f}%")
                if clip > 1e-5:
                    err = -12.0                      # railed: rms means nothing
                elif rms < 1e-7:
                    err = +20.0
                else:
                    err = 20 * np.log10(target / rms)
                if abs(err) < 1.5 and clip == 0.0:
                    best = {"txgain": txg, "rxgain": rxg, "rms": rms}
                    log("    converged.")
                    break
                # Prefer moving TX: the RX floor measurement showed the front end
                # is quantisation limited below ~40 dB of RX gain, so extra RX
                # gain buys nothing on a cabled signal this strong.
                new_tx = float(np.clip(txg + err, 0.0, a.max_txgain))
                if abs(new_tx - txg) < 0.05:
                    # TX is against a rail and cannot move any further.  Either
                    # accept where we are (no clipping, just below target) or
                    # push the remaining correction into RX gain.
                    if clip > 1e-5 or rms > target:
                        rxg = float(np.clip(rxg + err, 0.0, 76.0))
                        if rxg <= 0.0:
                            log("    at both rails and still too hot -- lower "
                                "TX_AMPLITUDE in config.py")
                            break
                    else:
                        log(f"    TX gain is at its limit ({txg:.1f} dB, "
                            f"--max-txgain).  rms {rms:.4f} is "
                            f"{20*np.log10(target/rms):.1f} dB below target but "
                            f"clean -- that is fine, taking it.")
                        best = {"txgain": txg, "rxgain": rxg, "rms": rms}
                        break
                txg = new_tx
            if best is None and rows:
                clean = [r for r in rows if r["clip"] == 0.0]
                best = min(clean, key=lambda r: abs(np.log(r["rms"] / target))) \
                    if clean else None
            if best:
                log("")
                log(f"    >>> RECOMMENDED:  TX_GAIN_DB = {best['txgain']:.1f}   "
                    f"RX_GAIN_DB = {best['rxgain']:.1f}   (RX rms {best['rms']:.4f})")
                a.txgain, a.rxgain = best["txgain"], best["rxgain"]
                radio.set_gains(txg=a.txgain, rxg=a.rxgain)
            else:
                log("    !! could not find a non-clipping operating point")
            return {"iterations": rows, "recommended": best}

    if a.stability:
        @stage("B. SUSTAINED STREAMING -- can the USB link keep up?")
        def _stab():
            wave = _link_waveform()
            stop = threading.Event()
            th = threading.Thread(target=radio.transmit_loop,
                                  args=(wave, a.stability_s + 1.0, stop), daemon=True)
            th.start()
            time.sleep(0.2)
            try:
                r = radio.stream_count(a.stability_s)
            finally:
                stop.set()
                th.join(timeout=2.0)
            r["requested_sps"] = rate
            r["shortfall_pct"] = 100.0 * (1 - r["achieved_sps"] / rate)
            log(f"    streamed {r['samples']} samples in {r['seconds']:.2f} s "
                f"= {r['achieved_sps']/1e6:.3f} Msps (asked for {rate/1e6:.3f})")
            log(f"    OVERFLOWS: {r['overflows']}   other errors: {r['other_errors']}")
            if r["overflows"]:
                log("    !! the receiver is dropping samples.  Acquisition")
                log("       coherently integrates 128 PN periods; a hole anywhere")
                log("       in that window destroys the correlation peak, which")
                log("       looks exactly like 'no signal'.")
                log("    -> use a USB 3 port and cable, or lower SAMP_RATE_HZ.")
            return r

    @stage("2. noise floor vs RX gain (transmitter idle)")
    def _noise():
        n = int(a.capture * rate)
        res = {}
        for g in (0.0, 20.0, 40.0, 60.0, 70.0):
            lo, hi = 0.0, 76.0
            try:
                r = radio.usrp.get_rx_gain_range(0)
                lo, hi = float(r.start()), float(r.stop())
            except Exception:
                pass
            if g < lo or g > hi:
                continue
            radio.set_gains(rxg=g)
            x = radio.receive(n)
            m = analyse(x, rate)
            res[f"rxgain_{g:.0f}"] = {k: v for k, v in m.items()
                                      if not k.startswith("psd_")}
            log(f"    rxgain {g:5.1f} dB : rms {m['rms']:.5f}  peak {m['peak']:.4f}  "
                f"floor {m['noise_floor_db']:6.1f} dB  DC {m['dc_mag']:.5f} "
                f"({m['dc_over_floor_db']:+.1f} dB over floor)  "
                f"clip>0.9 {m['frac_above_0p9']*100:.3f}%")
            if g == a.rxgain:
                res["capture_file"] = save_capture(x, f"noise_rxg{g:.0f}", outdir)
                res["psd_at_configured_gain"] = {"freqs": m["psd_freqs_hz"],
                                                 "db": m["psd_db"]}
        radio.set_gains(rxg=a.rxgain)
        # A front end that is working shows rms rising roughly 10x per 20 dB.
        return res

    if a.rx_only:
        log("\n  --rx-only: skipping every transmit test")
        finish(outdir)
        return 0

    tone = a.tone

    @stage("3. CW TONE LOOPBACK -- is the signal physically getting through?")
    def _tone():
        n = int(a.capture * rate)
        k = np.arange(4096)
        wave = (a.amplitude * np.exp(2j * np.pi * tone * k / rate)).astype(np.complex64)
        # make the buffer an exact number of tone cycles so the repeat is seamless
        cycles = max(1, int(round(4096 * tone / rate)))
        nper = int(round(4096 * cycles / (4096 * tone / rate))) if tone else 4096
        k = np.arange(nper)
        wave = (a.amplitude * np.exp(2j * np.pi * tone * k / rate)).astype(np.complex64)

        x = radio.tx_rx_simultaneous(wave, n)
        m = analyse(x, rate, tone_hz=tone)
        m["rx_stats"] = getattr(radio, "last_rx_stats", {})
        log(f"    captured {len(x)} samples, overflows={m['rx_stats'].get('overflows')}")
        log(f"    rms             : {m['rms']:.5f}   peak {m['peak']:.4f}  "
            f"clip>0.9 {m['frac_above_0p9']*100:.3f}%")
        log(f"    spectral peak   : {m['spectral_peak_hz']/1e3:+.1f} kHz "
            f"(tone was sent at {tone/1e3:+.1f} kHz)")
        log(f"    peak over floor : {m['peak_over_floor_db']:.1f} dB")
        log(f"    TONE SNR in chip bandwidth : {m['tone_snr_chipbw_db']:.1f} dB   <<<<<<")
        log(f"    image rejection : {m['image_rejection_db']:.1f} dB")
        log(f"    LO leakage (DC) : {m['dc_over_floor_db']:+.1f} dB over floor")
        m["capture_file"] = save_capture(x, "tone", outdir)
        if abs(m["spectral_peak_hz"] - tone) > 20e3:
            log("    !! the strongest thing in the band is NOT where the tone was sent.")
        if m["tone_snr_chipbw_db"] < 10:
            log("    !! the tone is barely above the noise -- this is an RF path")
            log("       problem (cable, port, attenuation, gains), not a DSP problem.")
        return m

    if a.quick:
        finish(outdir)
        return 0

    @stage("4. TX / RX gain sweep with the tone (find the operating point)")
    def _sweep():
        n = int(0.05 * rate)
        nper = 4096
        k = np.arange(nper)
        wave = (a.amplitude * np.exp(2j * np.pi * tone * k / rate)).astype(np.complex64)
        rows = []
        tx_points = [g for g in (10.0, 25.0, 40.0, 55.0, 70.0) if g <= a.max_txgain]
        for txg in tx_points:
            for rxg in (10.0, 30.0, 50.0, 70.0):
                try:
                    radio.set_gains(txg=txg, rxg=rxg)
                    x = radio.tx_rx_simultaneous(wave, n, tx_lead=0.12)
                    m = analyse(x, rate, tone_hz=tone)
                    row = {"txgain": txg, "rxgain": rxg, "rms": m["rms"],
                           "peak": m["peak"],
                           "tone_snr_db": m["tone_snr_chipbw_db"],
                           "clip": m["frac_above_0p9"],
                           "dc_over_floor_db": m["dc_over_floor_db"]}
                    rows.append(row)
                    log(f"    tx {txg:4.0f}  rx {rxg:4.0f} : rms {m['rms']:.5f}  "
                        f"toneSNR {m['tone_snr_chipbw_db']:6.1f} dB  "
                        f"clip {m['frac_above_0p9']*100:6.3f}%")
                except Exception as e:
                    log(f"    tx {txg} rx {rxg} : failed {e!r}")
        radio.set_gains(txg=a.txgain, rxg=a.rxgain)
        if rows:
            best = max(rows, key=lambda r: r["tone_snr_db"] - 40 * r["clip"])
            log(f"    BEST: txgain {best['txgain']:.0f}  rxgain {best['rxgain']:.0f}  "
                f"-> tone SNR {best['tone_snr_db']:.1f} dB")
            return {"rows": rows, "best": best}
        return {"rows": rows}

    if a.no_burst:
        finish(outdir)
        return 0

    @stage("5. real DSSS burst, transmitted and captured")
    def _burst():
        sys.path.insert(0, str(HERE))
        from dsss_qpsk import config as cfg
        from dsss_qpsk.framing import FT_DATA, Header
        from dsss_qpsk.modulator import Modulator

        cfg.SAMP_RATE_HZ = rate           # use what the radio ACTUALLY gave us
        cfg.recompute()
        mod = Modulator(cfg)
        payload = b"HARDWARE LOOPBACK TEST " * 3
        hdr = Header(ftype=FT_DATA, src=1, dst=255, seq=1, payload_len=len(payload))
        burst = mod.modulate(hdr, payload)
        log(f"    burst: {len(burst)} samples, {len(burst)/rate*1e3:.1f} ms, "
            f"peak {np.max(np.abs(burst)):.3f}")

        # Pad so the repeating transmit leaves a clear gap between bursts.
        gap = int(0.05 * rate)
        wave = np.concatenate([burst, np.zeros(gap, dtype=np.complex64)])
        n = int(max(a.capture, 3 * len(wave) / rate) * rate)
        x = radio.tx_rx_simultaneous(wave, n)

        m = analyse(x, rate)
        m["rx_stats"] = getattr(radio, "last_rx_stats", {})
        m["burst_samples"] = int(len(burst))
        m["payload"] = payload.decode()
        log(f"    captured {len(x)} samples  rms {m['rms']:.5f}  peak {m['peak']:.4f}")
        log(f"    peak over floor {m['peak_over_floor_db']:.1f} dB")
        m["capture_file"] = save_capture(x, "burst", outdir)

        # Try to decode it right here, offline, with the project's own receiver.
        try:
            from dsss_qpsk.receiver import Receiver
            rx = Receiver(cfg)
            frames = []
            for i in range(0, len(x), 1 << 16):
                frames += rx.process(x[i:i + (1 << 16)])
            frames += rx.flush()
            m["rx_state"] = str(rx.stats)
            good = [f for f in frames if f.ok]
            m["frames_decoded"] = len(good)
            log(f"    offline decode : {rx.stats}")
            for f in frames:
                log(f"      stage={f.stage:22s} ok={f.ok} "
                    f"acqPSR={f.acq_psr:8.1f} syncPSR={f.sync_psr:6.2f} "
                    f"chipSNR={f.snr_chip_db:+6.1f} symSNR={f.snr_sym_db:6.1f} "
                    f"EVM={f.evm_pct:5.1f}%")
            m["frames"] = [{"stage": f.stage, "ok": f.ok, "acq_psr": f.acq_psr,
                            "sync_psr": f.sync_psr, "snr_chip_db": f.snr_chip_db,
                            "snr_sym_db": f.snr_sym_db, "evm_pct": f.evm_pct,
                            "cfo_hz": f.fine_cfo_hz,
                            "payload_ok": bool(f.payload == payload)}
                           for f in frames]
        except Exception as e:
            log(f"    offline decode failed: {e!r}")
            m["decode_error"] = repr(e)
        return m

    finish(outdir)
    return 0


def finish(outdir: Path):
    (outdir / "report.json").write_text(json.dumps(REPORT, indent=2, default=str),
                                        encoding="utf-8")
    lines = []
    for name, res in REPORT["stages"].items():
        lines.append("=" * 72)
        lines.append(name)
        lines.append("=" * 72)
        lines.append(json.dumps({k: v for k, v in (res or {}).items()
                                 if not k.startswith("psd") and k != "psd_at_configured_gain"},
                                indent=2, default=str))
    (outdir / "report.txt").write_text("\n".join(lines), encoding="utf-8")
    log("\n" + "=" * 72)
    log(f"  wrote {outdir/'report.json'}")
    log(f"  wrote {outdir/'report.txt'}")
    if REPORT["errors"]:
        log(f"  {len(REPORT['errors'])} stage(s) failed -- see report.json")
    log("=" * 72)


if __name__ == "__main__":
    sys.exit(main())
