# DSSS / QPSK half-duplex comms link for GNU Radio 3.10 + USRP B206mini-i

A complete, burst-mode, below-the-noise-floor messaging link:

```
text  ->  CRC32  ->  Reed-Solomon(255,223)  ->  convolutional K=7 r=1/2
      ->  interleaver  ->  Gray QPSK  ->  x PN code (DSSS)  ->  RRC  ->  radio

radio ->  DC block -> digital IF -> RRC matched filter
      ->  ACQUISITION (delay x Doppler search, open loop, 36 dB of coherent gain)
      ->  sync word (frame start + phase + fine CFO + noise estimate)
      ->  DLL chip timing + Costas carrier loop, both running AFTER despreading
      ->  soft LLRs -> deinterleave -> soft Viterbi -> Reed-Solomon -> CRC32 -> text
```

Measured, in simulation, with the shipped defaults (SF = 31, 2 Msps, 64-byte
payloads, random ±3 kHz carrier offset, ±3 ppm clock offset, random delay and
phase, 16 trials per point):

| chip-band SNR | acquire | sync | header | **full frame** | EVM |
|---:|---:|---:|---:|---:|---:|
| −20 dB | 100 % | 25 % | – | 0 % | – |
| −16 dB | 100 % | 94 % | 75 % | 0 % | – |
| −15 dB | 100 % | 100 % | 94 % | 0 % | – |
| −14 dB | 100 % | 100 % | 100 % | 44 % | 76 % |
| **−13 dB** | 100 % | 100 % | 100 % | **100 %** | 70 % |
| −10 dB | 100 % | 100 % | 100 % | 100 % | 53 % |
| −6 dB | 100 % | 100 % | 100 % | 100 % | 36 % |

**Sensitivity: −13 dB chip-band SNR** — the signal is 13 dB *below* the noise in
its own occupied bandwidth. Acquisition still finds the burst 7 dB below that.
20 seconds of pure noise produced **zero** false acquisitions.

Reproduce all of it with `python run_sim.py sweep`.

## Verified on real hardware

USRP **B206mini** (serial 35D5F31), UHD 4.10, GNU Radio 3.10.12, Windows 11 /
radioconda, bare RF cable TX/RX -> RX2, no attenuator, USB 2.

| | 4 x 64-byte messages | 3 x 400-byte messages |
|---|---|---|
| delivered | **4 / 4** | **3 / 3** |
| retries / lost | 0 / 0 | 0 / 0 |
| EVM | 1.12 - 1.60 % | 1.20 - 1.29 % |
| chip SNR | +6.6 .. +30.7 dB | +6.8 .. +7.0 dB |
| carrier offset error | 0.3 - 0.4 Hz | 0.3 - 0.4 Hz |
| acquisition peak/median | 410 000 - 940 000 | 526 000 - 1 450 000 |
| RS corrections needed | 0 | 0 |
| samples dropped | **0** | **0** |
| round trip | 109 - 391 ms | 688 - 719 ms |

Two things had to be fixed to get there, and neither was the DSP:

1. **Receiver saturation.**  A bare cable at TX 45 / RX 40 put the receiver
   100 % clipped (RX rms 1.003).  A CW tone survives that looking fine -- it has
   0 dB peak-to-average -- which is why a tone test reported 43 dB SNR while the
   link reported -20 to -36 dB.  DSSS/QPSK does not survive it: clipping folds
   intermodulation across every chip and flattens the despread correlation.
   `python hw_diag.py --autolevel` finds the operating point; on this setup it
   is TX 40 / RX 20.
2. **Receiver throughput.**  The receiver could not keep up with 2 Msps, the
   queue filled, 13 % of samples were dropped, and every gap left a splice that
   triggered phantom acquisitions -- which cost more CPU, which dropped more
   samples.  See "Performance" below for what was wrong.

Check your own machine before blaming the radio:

```bash
python run_sim.py bench        # prints a verdict and the max sample rate to ask for
```

---

## 1. Quick start

```bash
# no radio, no GNU Radio -- simulated channel, full terminal UI
python run_link.py --sim --snr -10

# no radio, but through the real GNU Radio flowgraph
python run_link.py --grsim --snr -10

# real B206mini-i  (see the wiring section below first)
python run_link.py

# prove everything still works after you change something
python run_tests.py --full
```

Type a message, press Enter, watch it go out, come back, and get ACKed.
`/help` lists the commands.

---

## 2. Wiring the radio

### Single B206mini, cable loopback (the default, and where to start)

```
   [ TX/RX ] ---- SMA / RF cable ---- [ RX2 ]        (optionally with an attenuator)
```

**Set the gains by measurement, not by guess.** This is the thing that wasted
the most time on this project. A bare cable at TX 45 / RX 40 drove the receiver
100 % into clipping, and the symptom was not "obviously too strong" -- it was a
reported chip SNR of -20 to -36 dB, which reads like a dead link. Run:

```bash
python hw_diag.py --autolevel
```

It transmits the real modulated burst (not a tone -- a tone has 0 dB
peak-to-average and survives clipping looking perfect, which is exactly how this
hides) and converges on a gain pair that fills the ADC without clipping.
Verified good on a bare cable: **TX 40 / RX 20**, RX rms 0.038.

An attenuator gives you more headroom and is worth having, but is not required
at these levels; what matters is that the receiver stays linear.

The defaults are already set for this: `LOOPBACK_ACCEPT_OWN = True` and
`HALF_DUPLEX_MUTE_RX = False`, so the node hears its own bursts, decodes them,
and ACKs itself. Every message round-trips through the entire modem.

Because one radio's transmitter and receiver share the same LO, the carrier
offset in loopback is essentially zero — an unrealistically easy case. To see
the acquisition actually work, run `--sim` too, which injects a real offset.

### Two radios

On **each** machine:

| setting | node A | node B |
|---|---|---|
| `NODE_ID` | `1` | `2` |
| `PEER_NODE_ID` | `2` | `1` |
| `LOOPBACK_ACCEPT_OWN` | `False` | `False` |
| `HALF_DUPLEX_MUTE_RX` | `True` | `True` |
| `DEVICE_ARGS` | `"serial=XXXXXXX"` | `"serial=YYYYYYY"` |

Everything marked `[WAVEFORM]` in `config.py` **must be identical on both ends**.
The UI warns you when `/set` changes one of those.

### First-time bring-up checklist

1. `uhd_find_devices` — does UHD see the radio at all?
2. `uhd_usrp_probe` — right firmware/FPGA image? (radioconda will offer to fetch it)
3. `python run_link.py --sim` — does the modem work with no radio involved?
4. `python run_link.py --grsim` — does the GNU Radio plumbing work?
5. `python run_link.py` — real radio, cable loopback.
6. `python run_sim.py bench` — can this machine keep up with the sample rate?
   If it says MARGINAL or TOO SLOW, lower `SAMP_RATE_HZ`. A receiver that falls
   behind drops samples, and the splices that leaves behind destroy the coherent
   integration acquisition depends on — which looks exactly like a broken radio.
7. `python hw_diag.py --autolevel` — set the gains.
8. Watch the `RX rms` number in the UI. Aim for **0.03 – 0.15**.
   Too low → raise `TX_GAIN_DB`. Too high → lower it.
9. `python hw_link_test.py -n 4 -b 64` — the whole stack, end to end, headless.

---

## 3. How it works, and why it works below the noise floor

**The problem.** At −13 dB SNR there is nothing in the sample stream that looks
like a signal. A timing loop or a carrier loop cannot help you: those need
roughly positive SNR just to stay locked. You have to dig the signal out
*first*, open loop, and only then close the loops.

**The preamble is the answer.** Every burst starts with `N_PREAMBLE_PERIODS`
(default 256) repetitions of the bare PN code — the same 31 chips over and over,
with no data on them. The receiver:

1. **Correlates against one PN period at every sample delay.** That is a
   coherent sum of 31 chips → **+14.9 dB**. Done directly (31 strided
   multiply-accumulates per sample, not an FFT — the template is only 31 taps,
   and the FFT route costs ~27× more).
2. **Samples that correlator once per PN period.** At the right delay, the
   result is a pure tone whose frequency *is* the carrier offset. Everywhere
   else it is noise.
3. **FFTs that sequence of 128 values.** A tone in white noise collapses into
   one bin → another **+21.1 dB**, and the bin index hands you the frequency
   offset for free.

Total **36 dB of coherent processing gain**, before the receiver knows anything
about timing, frequency, phase or data. That is what turns a −20 dB signal into
a correlation peak thousands of times above its background.

**Then the loops close.** After acquisition:

* The **sync word** (64 known QPSK symbols) pins down the exact frame start,
  resolves the QPSK 90° ambiguity (its complex correlation gives the absolute
  carrier phase), and provides the amplitude and noise-variance estimates that
  scale the soft decisions.
* A **fine frequency estimate** runs over the sync word *and all the preamble in
  front of it* — about 320 known symbols. Estimator variance falls as N⁻³, so
  using the preamble instead of just the sync word cuts the residual offset from
  ~17 Hz to ~2 Hz. That single change moved frame success at −13 dB from 75 % to
  100 %, because 17 Hz rotates the constellation 150° across a 25 ms frame and no
  sensible loop bandwidth can fix that at 2 dB symbol SNR without cycle slipping.
* The **early/late DLL** tracks chip timing off the despread correlation peak.
  It uses magnitudes, so it is completely data-independent.
* The **Costas loop** tracks carrier phase **on the despread symbols**. This is
  the whole trick: a carrier loop cannot survive at −13 dB, but after
  despreading it is looking at +2 dB and holds lock. That is why the
  constellation is clean even though the signal is buried at the antenna.

**Then the FEC.** Soft-decision Viterbi (K=7, rate 1/2) gives ~5 dB of coding
gain and, when it does fail, fails in short bursts of 10–40 bits. The
interleaver scatters channel bursts so Viterbi sees isolated errors, and
Reed-Solomon(255,223) eats Viterbi's own error bursts — any 16 wrong bytes per
codeword, however the bit errors fall inside them. The link closes at about
2.5 dB Eb/N0, which is essentially the classic concatenated-code limit.

---

## 4. Where to change things

Everything is in **`config.py`**, one heavily commented file. The most useful
knobs:

| I want... | Change | Notes |
|---|---|---|
| to work further below the noise floor | `SPREADING_FACTOR` 31 → 63 → 127 | +3 dB per doubling, half the data rate, double the burst length. Verified: SF=63 closes at −15 dB, SF=127 at −18 dB. |
| tighter dots in the constellation | more `SPREADING_FACTOR`, or better SNR | EVM is set by post-despread SNR — physics, not code. The implementation floor is MER ≈ 40 dB. |
| faster acquisition / shorter bursts | `N_PREAMBLE_PERIODS` 256 → 128 | −3 dB of acquisition sensitivity |
| fewer false acquisitions | raise `ACQ_THRESHOLD_PSR`, `SYNC_THRESHOLD_RATIO` | defaults already give zero false frames in 20 s of noise |
| longer messages per burst | `MAX_PAYLOAD_BYTES` | 16-bit field, so <65535; sizes the RX buffer |
| more data rate | `SAMP_RATE_HZ` up, or `SPREADING_FACTOR` down, or `CC_PUNCTURE` | |
| stronger FEC | `RS_K` 223 → 191, or a rate-1/3 `CC_POLYS` | |
| to move the DC spur | `IF_OFFSET_HZ` | the transmitter generates at +250 kHz so LO leakage does not land in the middle of the constellation |
| to chase a rotating constellation | raise `COSTAS_LOOP_BW` | 3e-3 is a measured optimum; 1.5e-2 broke the link entirely |
| to survive a bad clock between two radios | raise `DLL_LOOP_BW` | |

You can also change most of these **while it is running**:

```
/show COSTAS               list every matching config value
/set COSTAS_LOOP_BW 5e-3   change one
/set SPREADING_FACTOR 63   waveform knobs rebuild the modem (change BOTH ends!)
/config                    print the full summary
```

---

## 5. The terminal console

```
/help                  command list
/ping                  unacknowledged PING burst
/send 200              send 200 random bytes
/flood 10 128          queue 10 messages of 128 bytes (throughput test)
/stats                 receiver statistics
/const out.npy         save the last constellation for matplotlib
/file report.pdf       send a whole file over the link
/files                 transfers in progress, with progress and rate
/inbox                 files that have arrived, and where they landed
/cancel 3              stop an outgoing transfer
/snr -14               simulation only: change the channel SNR live
/txgain 45  /rxgain 38 radio only: change gain live
/show  /set  /config   inspect and change configuration
/quit
```

The screen shows a live ASCII constellation heat map next to the message log,
with a metrics block underneath. The constellation auto-scales; the `o` marks
are where the ideal QPSK points sit, so you can read the link at a glance:

* clouds centred on the `o` marks → gain and phase correct
* round and tight → good SNR, loops locked
* smeared along a circle → carrier loop bandwidth too wide
* smeared along a radius → amplitude/AGC problem
* whole pattern slowly rotating → residual frequency error; raise `COSTAS_LOOP_BW`

Metrics reported per frame: chip-band and post-despread symbol SNR, EVM and MER,
acquisition peak-to-median, sync-word peak-to-background, coarse and fine carrier
offset plus what the Costas loop had left over, final timing error, Viterbi path
margin, Reed-Solomon byte corrections, CRC status, plus running counts of
acquisitions, false acquisitions, header failures, payload failures, retries,
round-trip time and goodput.

---

## 5b. The browser dashboard

```
python run_link.py --web            then open http://127.0.0.1:8731
```

Everything the terminal shows, plus the things a terminal cannot: a
density-shaded constellation with the ideal points and the 1-sigma error circle,
a histogram of symbol error magnitude, a live averaged spectrum with peak hold
and the noise floor marked, a waterfall, the acquisition delay and Doppler cuts,
four trend traces with a crosshair readout, and eight headline readouts across
the top.

It is also where you send things:

* **type a message** in the Messages panel and press enter
* **drag a file onto the page**, or click the drop zone to pick one
* **or type a path** on the machine running the link, or hit Browse and pick
  one out of a file list

A transfer shows a progress bar in each direction with rate, ETA and segment
count, and anything received lands in `inbox/` with a download link right on the
page. The Tuning panel changes any config value live — the same thing `/set`
does in the terminal — and the configuration table below it shows what is
currently in force.

It is bound to `127.0.0.1` by default. The file browser and the upload endpoint
let whoever can reach that port read files on this machine and put them on the
air, so setting `WEB_HOST = "0.0.0.0"` means exactly that on your network.

---

## 5c. Sending files

A file is not a special kind of traffic: it is the same frames as a chat
message, so it inherits the measured −13 dB sensitivity exactly. What sits on
top (`filexfer.py`) is a manifest with name, size and CRC-32, numbered segments,
and selective repair — either end can ask for the exact pieces it is missing, so
one lost segment costs one retransmission instead of the whole file.

```
python run_filetest.py                       8 kB at -13 dB, simulated
python run_filetest.py -b 65536 --drop 0.25  destroy a quarter of the bursts
python hw_file_test.py -b 32768              32 kB over the real radio
```

By default segments go out as **STREAM frames**: transmitted once, not
acknowledged, paced to the air time of the burst, with the receiver asking at
the end for whatever it did not get. Stop-and-wait ARQ costs a full round trip
per segment, and on the radio that round trip is 200–700 ms against a 166 ms
burst — more than half the time the transmitter is idle waiting for an ACK the
file layer does not need, because it already knows exactly which segments are
missing. Same waveform, same frames, same sensitivity; only the scheduling
changes. Set `FILE_STREAM_MODE = False` to go back to one ACK per segment, which
is easier to follow when you are debugging a marginal link.

Segment size is `FILE_SEGMENT_BYTES`, and 512 is not an arbitrary default:

| payload | burst | −11 dB | −12 dB | −13 dB | −14 dB |
|---|---|---|---|---|---|
| 512 B | 166 ms | 100% | 100% | **92%** | 0% |
| 1024 B | 309 ms | 100% | 100% | 83% | 0% |
| 2048 B | 603 ms | 100% | 100% | 75% | 0% |
| 4096 B | 1182 ms | 100% | 100% | 62% | 0% |

A longer frame is not harder to track — the loops hold fine — it just contains
more Reed-Solomon codewords, and one bad codeword kills the frame. The
throughput gain is small (512 B is 3.08 B/ms of air time, 2048 B is 3.40 B/ms)
because the preamble is already a small fraction of the burst. So raising it
buys about 10% speed for about 1 dB of sensitivity, which is the wrong trade for
this link.

---

## 6. Files

| file | what it is |
|---|---|
| **`config.py`** | **every knob, with what happens if you raise or lower it** |
| `pn.py` | m-sequence and Gold spreading codes |
| `filters.py` | RRC pulse shaping, DC blocker, AGC, level meter |
| `crc.py` `rs.py` `conv.py` `interleave.py` | CRC-16/32, Reed-Solomon GF(256), convolutional + soft Viterbi, block interleaver |
| `framing.py` | frame header, sync-word generation |
| `codec.py` | the FEC chain, shared by TX and RX |
| `modulator.py` | QPSK + DSSS burst transmitter |
| `acquisition.py` | the delay × Doppler search — read this one |
| `tracking.py` | DLL + Costas + fractional-delay despreader |
| `receiver.py` | the receive state machine |
| `channel.py` | simulation channel (AWGN, CFO, SFO, fractional delay, IQ imbalance) |
| `link.py` | half-duplex burst scheduling and stop-and-wait ARQ |
| `filexfer.py` | file transfer: manifest, segments, selective repair, progress |
| `webui.py` | the browser dashboard, message console and file picker |
| `transports.py` | simulated / GNU-Radio-loopback / USRP back ends |
| `blocks/gr_blocks.py` | the two GNU Radio 3.10 blocks |
| `app/terminal.py` | the console |
| `ui.py` | constellation and metrics rendering |
| `run_link.py` `run_sim.py` `run_tests.py` | entry points |
| `run_validation.py` | the 11-section validation chain |
| `run_filetest.py` | file transfer over the simulated channel, with optional burst loss |
| `hw_diag.py` `hw_link_test.py` `hw_file_test.py` `hw_sensitivity.py` | the hardware tools |

All the DSP is plain numpy and has **no GNU Radio dependency**, which is why it
can be unit tested and swept in simulation. The GNU Radio blocks are thin
wrappers around it.

---

## 7. Performance and real-time behaviour

On a modest CPU the receiver runs at about **2.4× real time when idle** and
**1.5× real time while decoding** a burst at 2 Msps. The GNU Radio sink hands
samples to a worker thread through a queue, so a slow decode never back-pressures
`uhd.usrp_source` and causes overruns; the decoder catches up in the gaps.

If the UI ever reports dropped samples: raise `TRACKER_BLOCK_SYMBOLS`, lower
`SAMP_RATE_HZ`, or shorten `N_PREAMBLE_PERIODS`.

Transmission uses tagged-stream bursts (`packet_len` → `tx_sob`/`tx_eob`), so the
transmitter is keyed only for the duration of a burst and stays silent in
between — real half-duplex behaviour, and no underrun `U`s between messages.

---

## 8. Troubleshooting

| symptom | likely cause |
|---|---|
| `acquisitions` climbing but `sync_found` stays 0 | pure noise triggering the first gate — normal; if it is constant, raise `ACQ_THRESHOLD_PSR` |
| acquisitions and syncs fine, header always fails | the two ends disagree on a `[WAVEFORM]` knob |
| constellation rotating | residual carrier offset — raise `COSTAS_LOOP_BW` |
| constellation smeared radially | front-end compression (lower `RX_GAIN_DB`) or an AGC left on |
| nothing received at all in loopback | `LOOPBACK_ACCEPT_OWN` must be `True`; check the attenuator and that TX/RX → RX2 is actually connected |
| `RX rms` ≈ 0 | wrong antenna port, or `RX_GAIN_DB` far too low |
| UHD underruns (`U`) while transmitting | USB2 port, or `SAMP_RATE_HZ` too high; try `num_send_frames=512` in `DEVICE_ARGS` |
| `ModuleNotFoundError: gnuradio` | run from the radioconda "GNU Radio Command Prompt", or use `--sim` |
