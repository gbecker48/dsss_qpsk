#!/usr/bin/env python3
r"""
hw_sensitivity.py -- find the REAL below-the-noise-floor limit, on the radio.

    python hw_sensitivity.py                    full curve, ~4 min
    python hw_sensitivity.py --quick            coarser, ~90 s
    python hw_sensitivity.py --capture          also save IQ at each point

WHAT IT DOES AND WHY

Simulation says this link closes at -13.5 dB chip-band SNR.  That is a claim
about the DSP.  This turns it into a claim about YOUR radio, YOUR cable and
YOUR front end, by doing the one experiment that settles it:

    turn the signal down until the link dies -- analogue TX gain first, then
    digital backoff of the baseband once the gain knob runs out.

The digital part matters on a good cable.  A B206mini at TX gain 0 dB into a
bare RF jumper still lands ~2 dB ABOVE the receiver's own noise, so the analogue
knob alone cannot reach the interesting region at all.  Scaling the baseband
amplitude keeps the waveform bit-identical and simply makes it quieter, which is
the same experiment with 30 more dB of range.

At each TX gain it measures the noise floor with the transmitter idle, then
transmits real frames and records how many decode and what SNR the receiver
reports.  The interesting region is where the transmitted signal is WEAKER than
the noise the receiver is sitting in -- if frames still get through there, the
processing gain is doing exactly what it is supposed to, on hardware, with no
simulation involved.

The output is a table you can read straight down: the TX gain where frame
success falls off is the hardware sensitivity, and the measured chip SNR at that
point is the number to compare against the simulated -13.5 dB.

SAFETY: this only ever LOWERS transmit gain from the value you give it.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from dsss_qpsk import config as cfg              # noqa: E402
from dsss_qpsk.framing import FT_DATA, Header    # noqa: E402
from dsss_qpsk.modulator import Modulator        # noqa: E402
from dsss_qpsk.receiver import Receiver          # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--args", default=cfg.DEVICE_ARGS)
    ap.add_argument("--freq", type=float, default=cfg.CENTER_FREQ_HZ)
    ap.add_argument("--rate", type=float, default=cfg.SAMP_RATE_HZ)
    ap.add_argument("--rxgain", type=float, default=cfg.RX_GAIN_DB)
    ap.add_argument("--txgain-max", type=float, default=cfg.TX_GAIN_DB)
    ap.add_argument("--txgain-min", type=float, default=0.0)
    ap.add_argument("--step", type=float, default=3.0)
    # Digital backoff, in dB below TX_AMPLITUDE, applied AFTER the TX gain has
    # run out.  This is what gets the signal under the noise floor on a good
    # cable without touching the hardware: a B206mini at TX gain 0 into a bare
    # RF cable is still ~2 dB ABOVE the receiver's noise, so the analogue knob
    # alone cannot answer the question this script exists to answer.  Scaling
    # the baseband instead keeps the waveform identical and just makes it
    # quieter, which is exactly the experiment.
    ap.add_argument("--digital-min", type=float, default=-30.0,
                    help="lowest digital backoff in dB (0 = none, -30 = 30 dB down)")
    ap.add_argument("--frames", type=int, default=6)
    ap.add_argument("--bytes", type=int, default=64)
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--nodigital", action="store_true",
                    help="analogue TX gain only, no digital backoff")
    ap.add_argument("--capture", action="store_true")
    ap.add_argument("--outdir", default="hwdata")
    a = ap.parse_args()
    if a.quick:
        a.step, a.frames = 6.0, 3
    if a.nodigital:
        a.digital_min = 0.0

    outdir = HERE / a.outdir
    outdir.mkdir(exist_ok=True)

    import uhd
    from hw_diag import Radio, analyse, save_capture

    cfg.SAMP_RATE_HZ = a.rate
    cfg.recompute()

    print("=" * 78)
    print("  HARDWARE SENSITIVITY -- how far below the noise floor does it really go?")
    print("=" * 78)
    radio = Radio(a.args, a.freq, a.rate, a.txgain_max, a.rxgain,
                  cfg.TX_ANTENNA, cfg.RX_ANTENNA)
    rate = radio.rate
    cfg.SAMP_RATE_HZ = rate
    cfg.recompute()
    print(f"  radio  : {radio.info.get('mboard_id','?')} "
          f"serial {radio.info.get('mboard_serial','?')}")
    print(f"  rate   : {rate/1e6:.6f} Msps      RX gain {a.rxgain:.0f} dB")
    print(f"  sweep  : TX gain {a.txgain_max:.0f} down to {a.txgain_min:.0f} dB, "
          f"then digital backoff to {a.digital_min:.0f} dB, "
          f"in {a.step:.0f} dB steps, {a.frames} frames each")
    print(f"  link   : SF {cfg.SPREADING_FACTOR}, processing gain "
          f"{cfg.PROCESSING_GAIN_DB:.1f} dB, simulated limit -13.5 dB chip SNR")
    print()

    mod = Modulator(cfg)
    rng = np.random.default_rng(3)

    # ---- noise floor with the transmitter idle -----------------------------
    radio.set_gains(txg=0.0, rxg=a.rxgain)
    time.sleep(0.2)
    n_noise = int(0.10 * rate)
    noise = radio.receive(n_noise)
    nm = analyse(noise, rate)
    noise_rms = nm["rms"]
    print(f"  noise floor with TX idle: rms {noise_rms:.6f}  "
          f"(this is what the signal has to hide under)")
    print()

    hdr = (f"  {'TXgain':>7s} {'RXrms':>9s} {'S/N est':>9s} {'frames':>7s} "
           f"{'ok%':>6s} {'chipSNR':>8s} {'symSNR':>8s} {'EVM%':>7s} "
           f"{'acqPSR':>10s} {'RS':>4s}")
    print(hdr)
    print("  " + "-" * (len(hdr) - 2))

    # The sweep runs in total-attenuation steps: analogue TX gain first, then,
    # once that is at its floor, digital backoff.  The receiver cannot tell the
    # difference -- both just make the signal smaller relative to the noise.
    steps = []
    txg = a.txgain_max
    while txg >= a.txgain_min - 1e-9:
        steps.append((txg, 0.0))
        txg -= a.step
    dig = -a.step
    while dig >= a.digital_min - 1e-9:
        steps.append((a.txgain_min, dig))
        dig -= a.step

    base_amp = cfg.TX_AMPLITUDE
    rows = []
    for txg, dig_db in steps:
        radio.set_gains(txg=txg, rxg=a.rxgain)
        cfg.TX_AMPLITUDE = base_amp * (10.0 ** (dig_db / 20.0))
        mod = Modulator(cfg)
        time.sleep(0.1)

        payloads, ok = [], 0
        chips, syms, evms, psrs, rss = [], [], [], [], []
        rx = Receiver(cfg)
        rms_seen = 0.0

        for i in range(a.frames):
            payload = bytes(rng.integers(32, 127, a.bytes, dtype=np.uint8))
            payloads.append(payload)
            h = Header(ftype=FT_DATA, src=1, dst=255, seq=i & 0xF,
                       payload_len=len(payload))
            burst = mod.modulate(h, payload)
            gap = int(0.02 * rate)
            wave = np.concatenate([burst, np.zeros(gap, dtype=np.complex64)])
            nsamp = int(len(wave) * 1.6)
            x = radio.tx_rx_simultaneous(wave, nsamp, tx_lead=0.15)
            rms_seen = max(rms_seen, float(np.sqrt(np.mean(np.abs(x) ** 2))))
            frames = []
            for j in range(0, len(x), 1 << 16):
                frames += rx.process(x[j:j + (1 << 16)])
            frames += rx.flush()   # a capture ends; a radio does not
            good = [f for f in frames if f.ok and f.payload == payload]
            if good:
                ok += 1
                f = good[0]
                chips.append(f.snr_chip_db)
                syms.append(f.snr_sym_db)
                evms.append(f.evm_pct)
                psrs.append(f.acq_psr)
                rss.append(max(f.rs_corrections, 0))
            if a.capture and i == 0:
                tag = (f"tx{int(txg):02d}" if dig_db == 0
                       else f"tx{int(txg):02d}d{int(-dig_db):02d}")
                save_capture(x, f"sens_{tag}", outdir)

        pct = 100.0 * ok / a.frames
        # Crude in-band signal-to-noise from the level alone, independent of the
        # modem: (total power - noise power) / noise power.
        sn = 10 * np.log10(max(rms_seen ** 2 - noise_rms ** 2, 1e-18)
                           / max(noise_rms ** 2, 1e-18))
        row = {"txgain": txg, "digital_db": dig_db,
               "atten_db": (a.txgain_max - txg) - dig_db,
               "rx_rms": rms_seen, "level_snr_db": sn,
               "frames": a.frames, "ok_pct": pct,
               "chip_snr_db": float(np.mean(chips)) if chips else None,
               "sym_snr_db": float(np.mean(syms)) if syms else None,
               "evm_pct": float(np.mean(evms)) if evms else None,
               "acq_psr": float(np.mean(psrs)) if psrs else None,
               "rs": float(np.mean(rss)) if rss else None}
        rows.append(row)
        mark = "  <-- signal is BELOW the noise" if sn < 0 else ""
        label = f"{txg:.0f}" if dig_db == 0 else f"{txg:.0f}{dig_db:+.0f}d"
        print(f"  {label:>7s} {rms_seen:9.6f} {sn:8.1f}d {a.frames:7d} {pct:6.0f} "
              f"{(row['chip_snr_db'] if chips else float('nan')):8.1f} "
              f"{(row['sym_snr_db'] if syms else float('nan')):8.1f} "
              f"{(row['evm_pct'] if evms else float('nan')):7.2f} "
              f"{(row['acq_psr'] if psrs else 0):10.0f} "
              f"{(row['rs'] if rss else float('nan')):4.1f}{mark}")
    cfg.TX_AMPLITUDE = base_amp

    # ---- verdict ------------------------------------------------------------
    working = [r for r in rows if r["ok_pct"] >= 80]
    print()
    print("=" * 78)
    if working:
        worst = max(working, key=lambda r: r["atten_db"])
        print(f"  MOST ATTENUATION WITH A WORKING LINK : {worst['atten_db']:.0f} dB "
              f"(TX gain {worst['txgain']:.0f} dB, digital {worst['digital_db']:.0f} dB)")
        print(f"    receiver-reported chip SNR there : "
              f"{worst['chip_snr_db']:.1f} dB")
        print(f"    level-based in-band S/N there    : {worst['level_snr_db']:.1f} dB")
        print(f"    EVM there                        : {worst['evm_pct']:.2f} %")
        below = [r for r in working if r["level_snr_db"] < 0]
        if below:
            deepest = min(below, key=lambda r: r["level_snr_db"])
            print()
            print(f"  FRAMES DECODED WITH THE SIGNAL {abs(deepest['level_snr_db']):.1f} dB")
            print(f"  BELOW THE NOISE FLOOR, ON HARDWARE. "
                  f"({deepest['ok_pct']:.0f}% of frames at TX gain "
                  f"{deepest['txgain']:.0f} dB)")
        else:
            print()
            print("  Note: the link never got weaker than the noise floor in this")
            print("  sweep.  Lower --digital-min (it is in dB below TX_AMPLITUDE)")
            print("  to push it further under.")
    else:
        print("  no TX gain produced a working link -- check gains and cabling")
    print("=" * 78)

    (outdir / "sensitivity.json").write_text(
        json.dumps({"noise_rms": noise_rms, "rx_gain": a.rxgain,
                    "txgain_max": a.txgain_max, "rows": rows},
                   indent=2), encoding="utf-8")
    print(f"  wrote {outdir/'sensitivity.json'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
