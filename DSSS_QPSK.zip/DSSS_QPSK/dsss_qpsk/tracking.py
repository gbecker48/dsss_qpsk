"""
tracking.py -- the closed-loop part of the receiver.

Once acquisition has dug the burst out of the noise and handed over a coarse
sample delay and a coarse carrier frequency, this is what keeps the two aligned
for the rest of the burst and produces the despread QPSK symbols.

Three things run per symbol:

  1. FRACTIONAL-DELAY RESAMPLING + DESPREADING
     The chips are read out of the sample buffer at the tracked instants using a
     4-tap Lagrange interpolator, de-rotated by the current carrier estimate,
     and correlated against the PN code.  That correlation IS the despreading,
     and it is where the 14.9 dB of processing gain appears.

  2. EARLY / LATE DELAY-LOCKED LOOP (chip timing)
     The same despreading is repeated half a chip early and half a chip late.
     If we are sampling exactly on the correlation peak the two are equal; the
     difference is a clean, data-independent timing error signal (it uses
     magnitudes, so it does not care what the data bits are).

  3. DECISION-DIRECTED COSTAS LOOP (carrier phase)
     Runs on the DESPREAD symbols, which sit 14.9 dB above where the raw samples
     are.  That is the whole trick: a carrier loop cannot survive at -10 dB SNR,
     but after despreading it is looking at +5 dB and locks solidly.  This is
     why the constellation can be tight even though the signal is below the
     noise floor at the antenna.

Both loops are standard second-order (proportional + integral) loops, specified
by a normalised bandwidth and a damping factor, exactly like GNU Radio's
control_loop -- so the tuning intuition carries over.
"""

from __future__ import annotations

from math import cos as _cos, sin as _sin

import numpy as np


def loop_gains(bw: float, damping: float) -> tuple[float, float]:
    """Second-order loop coefficients from normalised bandwidth + damping."""
    denom = 1.0 + 2.0 * damping * bw + bw * bw
    alpha = (4.0 * damping * bw) / denom      # proportional
    beta = (4.0 * bw * bw) / denom            # integral
    return alpha, beta


def _lagrange4(mu: float) -> np.ndarray:
    """4-tap Lagrange fractional-delay taps for mu in [0,1), centred on x[1]."""
    m1 = mu - 1.0
    m2 = mu - 2.0
    p1 = mu + 1.0
    return np.array([
        -m1 * m2 * mu / 6.0,
        p1 * m1 * m2 / 2.0,
        -p1 * mu * m2 / 2.0,
        p1 * mu * m1 / 6.0,
    ], dtype=np.float64)


def _sinc_taps(mu: float, ntaps: int) -> np.ndarray:
    """Windowed-sinc fractional-delay taps (Blackman window), centred.

    Noticeably flatter than a Lagrange interpolator across the occupied band,
    which is worth about 8 dB of MER on this waveform for a handful of extra
    multiplies.  See TRACKER_INTERP_TAPS in config.py.
    """
    c = ntaps // 2 - 1
    k = np.arange(ntaps) - c
    x = k - mu
    h = np.sinc(x)
    w = np.blackman(ntaps + 2)[1:-1]
    # Re-centre the window on the actual delay so it stays symmetric about it.
    h = h * w
    ssum = h.sum()
    return h / (ssum if abs(ssum) > 1e-12 else 1.0)


# Pre-tabulate the interpolator so the per-symbol path is a table lookup.
# _MU_STEPS phases is plenty: the residual timing quantisation is
# 1/(2*_MU_STEPS) of a sample, i.e. -60 dB of timing jitter.
_MU_STEPS = 512
_TABLES: dict[int, np.ndarray] = {
    4: np.stack([_lagrange4(i / _MU_STEPS) for i in range(_MU_STEPS)]),
}
for _nt in (6, 8, 12, 16):
    _TABLES[_nt] = np.stack([_sinc_taps(i / _MU_STEPS, _nt) for i in range(_MU_STEPS)])


class Tracker:
    """Produces despread, frequency- and phase-corrected QPSK symbols."""

    def __init__(self, cfg, code: np.ndarray, buf_view, buf_abs: int,
                 position: float, freq_hz: float, phase: float = 0.0):
        self.cfg = cfg
        self.code = code.astype(np.float64)
        self.sf = int(cfg.SPREADING_FACTOR)
        self.sps = int(cfg.SPS_CHIP)
        self.spsym = self.sf * self.sps
        self.buf = buf_view
        self.buf_abs = int(buf_abs)

        # Fractional-delay interpolator (see TRACKER_INTERP_TAPS in config.py).
        self.ntaps = int(getattr(cfg, "TRACKER_INTERP_TAPS", 8))
        if self.ntaps not in _TABLES:
            self.ntaps = 8
        self.table = _TABLES[self.ntaps]
        self.tap_off = np.arange(self.ntaps, dtype=np.int64) - (self.ntaps // 2 - 1)

        # --- timing state -----------------------------------------------------
        self.pos = float(position)              # absolute sample index, float
        self.dll_alpha, self.dll_beta = loop_gains(cfg.DLL_LOOP_BW, cfg.DLL_DAMPING)
        self.dll_int = 0.0                      # integral term, samples/symbol
        self.el_offset = cfg.DLL_EL_SPACING * self.sps   # in samples

        # --- carrier state ----------------------------------------------------
        # phase_inc is radians per SAMPLE; the loop works in radians per SYMBOL.
        self.freq_hz = float(freq_hz)
        self.phase = float(phase)
        self.cos_alpha, self.cos_beta = loop_gains(cfg.COSTAS_LOOP_BW, cfg.COSTAS_DAMPING)
        self.costas_on = False

        # --- constant scratch (allocated once; this is a hot loop) -----------
        self.chip_idx = np.arange(self.sf, dtype=np.int64) * self.sps
        self._pos3 = np.zeros(3, dtype=np.float64)
        # Early / on-time / late sampling offsets, in samples.
        self._el3 = np.array([-self.el_offset, 0.0, self.el_offset], dtype=np.float64)
        # Relative index pattern (chip, interpolator tap) -- added to each base.
        self._idx_rel = (self.chip_idx[:, None] + self.tap_off[None, :])

        # --- diagnostics ------------------------------------------------------
        self.timing_err = 0.0
        self.phase_err = 0.0
        self.positions: list[float] = []
        self.phases: list[float] = []
        self.last_mag = 0.0

    # ------------------------------------------------------------------ util
    @property
    def phase_inc_sample(self) -> float:
        return 2.0 * np.pi * self.freq_hz / self.cfg.SAMP_RATE_HZ

    def samples_needed(self, nsym: int) -> int:
        """Absolute index one past the last sample this many symbols will touch."""
        return int(np.ceil(self.pos + nsym * self.spsym + self.el_offset
                           + self.ntaps + 4))

    def enable_costas(self, on: bool = True):
        self.costas_on = bool(on)

    def set_carrier(self, freq_hz: float, phase: float):
        self.freq_hz = float(freq_hz)
        self.phase = float(phase)

    # --------------------------------------------------------------- despread
    def _despread3(self, pos: float, rot: np.ndarray):
        """Despread EARLY, ON-TIME and LATE in one vectorised pass.

        Doing all three together matters: this runs once per symbol, and at
        2 Msps with SF=31 that is 32 000 times a second.  Written as three
        separate loops over the interpolator taps it costs ~75 numpy calls per
        symbol and the receiver cannot keep up with the radio; written as one
        gather of shape (3, SF, ntaps) it is six, and it runs several times
        faster than real time.

        Returns (z_early, z_on, z_late), each already divided by SF.
        """
        b = self.buf
        el = self.el_offset
        p = self._pos3
        p[0] = pos - el
        p[1] = pos
        p[2] = pos + el
        base = p.astype(np.int64)
        mu = p - base
        taps = self.table[(mu * _MU_STEPS).astype(np.int64) & (_MU_STEPS - 1)]  # (3,ntaps)
        # idx[j, c, k] = sample index for position j, chip c, interpolator tap k
        idx = (base[:, None, None] - self.buf_abs
               + self.chip_idx[None, :, None] + self.tap_off[None, None, :])
        x = np.einsum("jck,jk->jc", b[idx], taps)      # (3, SF) interpolated chips
        z = (x * rot[None, :]) @ self.code             # (3,) despread symbols
        return z * (1.0 / self.sf)

    def _despread_at(self, pos: float, rot: np.ndarray) -> complex:
        """Single-position despread (used where the early/late pair is not needed)."""
        base = int(pos)
        mu = pos - base
        t = self.table[int(mu * _MU_STEPS) & (_MU_STEPS - 1)]
        idx = (base - self.buf_abs + self.chip_idx[:, None] + self.tap_off[None, :])
        x = self.buf[idx] @ t
        return np.dot(x * rot, self.code)

    def produce(self, nsym: int, record_positions: bool = False) -> np.ndarray:
        """Demodulate `nsym` symbols, running both loops.  Returns complex symbols.

        HOW THE BLOCKING WORKS, AND WHY IT IS STILL EXACT ENOUGH
        --------------------------------------------------------
        Doing one symbol at a time means ~8 numpy calls per symbol, and numpy's
        per-call overhead (a few microseconds) then dominates everything: the
        receiver ends up slower than the radio.  So the heavy, vectorisable part
        -- reading the chips out of the buffer, interpolating and correlating --
        is done TRACKER_BLOCK_SYMBOLS symbols at a time, while the two feedback
        loops still update every single symbol in a cheap scalar loop.

        The only approximation is that the sampling instants and the intra-symbol
        carrier rotation inside a block are PREDICTED from the loop state at the
        start of the block instead of being updated mid-block.  Over 32 symbols
        (1 ms) a locked DLL moves the sampling instant by well under a
        thousandth of a sample and the Costas loop moves the frequency by a few
        Hz, so the error is far below the noise.  Both loops are re-anchored
        exactly at every block boundary, so nothing accumulates.

        The carrier PHASE correction is not approximated at all: a phase change
        is just a scalar rotation of the despread symbol, so the per-symbol
        Costas correction is applied exactly, after the fact.

        Set TRACKER_BLOCK_SYMBOLS = 1 to get strict per-symbol feedback back
        (about 4x slower, and measurably no better).
        """
        out_r = [0.0] * nsym
        out_i = [0.0] * nsym
        chip_phase = self.chip_idx.astype(np.float64)
        dll_on = bool(self.cfg.DLL_ENABLE)
        costas_on = self.costas_on
        block = max(1, int(getattr(self.cfg, "TRACKER_BLOCK_SYMBOLS", 32)))
        el = self.el_offset
        spsym = self.spsym
        alpha_t, beta_t = self.dll_alpha, self.dll_beta
        alpha_c, beta_c = self.cos_alpha, self.cos_beta
        hz_per_rad = self.cfg.SYMBOL_RATE_HZ / (2 * np.pi)
        if record_positions:
            self.positions = []
            self.phases = []

        n0 = 0
        while n0 < nsym:
            K = min(block, nsym - n0)

            # ---- predict the sampling instants for this block ----------------
            step = spsym - self.dll_int          # current tracked symbol period
            kk = np.arange(K, dtype=np.float64)
            pos_pred = self.pos + kk * step

            # ---- one gather for the whole block ------------------------------
            # p[k, j] : k = symbol in block, j = early / on-time / late
            p = pos_pred[:, None] + self._el3[None, :]
            base = np.floor(p).astype(np.int64)
            mu = p - base
            taps = self.table[(mu * _MU_STEPS).astype(np.int64) & (_MU_STEPS - 1)]
            idx = base[:, :, None, None] - self.buf_abs + self._idx_rel[None, None]
            x = np.einsum("kjcs,kjs->kjc", self.buf[idx], taps)   # (K, 3, SF)

            # ---- open-loop carrier de-rotation --------------------------------
            dphi = self.phase_inc_sample                      # rad / sample
            phase_open = self.phase + kk * (dphi * spsym)     # rad at each symbol
            rot = np.exp(-1j * (phase_open[:, None] + dphi * chip_phase[None, :]))
            z = np.einsum("kjc,kc,c->kj", x, rot, self.code) * (1.0 / self.sf)

            # ---- per-symbol scalar feedback -----------------------------------
            # Everything below runs on PYTHON floats (.tolist()), not numpy
            # scalars: numpy scalar arithmetic is roughly 10x slower and this is
            # the innermost loop of the whole receiver.
            zr = z[:, 1].real.tolist()
            zi = z[:, 1].imag.tolist()
            if dll_on:
                mag_e = np.abs(z[:, 0])
                mag_l = np.abs(z[:, 2])
                terr_all = ((mag_e - mag_l) / (mag_e + mag_l + 1e-12)).tolist()
            else:
                terr_all = [0.0] * K
            if record_positions:
                pos_list = pos_pred.tolist()
                ph_list = phase_open.tolist()

            theta = 0.0                       # accumulated Costas phase correction
            dpos = 0.0                        # accumulated timing correction
            dfreq = 0.0                       # accumulated Costas frequency correction
            dll_int = self.dll_int
            for k in range(K):
                if record_positions:
                    self.positions.append(pos_list[k])
                    self.phases.append(ph_list[k] + theta)

                if theta:
                    c, s = _cos(theta), _sin(theta)
                    yr = zr[k] * c + zi[k] * s
                    yi = zi[k] * c - zr[k] * s
                else:
                    yr, yi = zr[k], zi[k]
                out_r[n0 + k] = yr
                out_i[n0 + k] = yi

                if dll_on:
                    terr = terr_all[k]
                    dll_int += beta_t * terr
                    dpos -= alpha_t * terr + dll_int

                if costas_on:
                    # QPSK decision-directed phase detector, amplitude-normalised
                    # so the loop gain does not depend on the signal level.
                    mag = (yr * yr + yi * yi) ** 0.5 + 1e-12
                    perr = ((yi if yr >= 0 else -yi) - (yr if yi >= 0 else -yr)) / mag
                    dfreq += beta_c * perr * hz_per_rad
                    theta += alpha_c * perr

            self.dll_int = dll_int
            self.timing_err = terr_all[-1]
            self.phase_err = theta

            # ---- re-anchor the loop state exactly at the block boundary -------
            self.pos = self.pos + K * spsym + dpos
            self.phase = phase_open[-1] + dphi * spsym + theta
            self.phase = (self.phase + np.pi) % (2 * np.pi) - np.pi
            self.freq_hz += dfreq
            self.last_mag = (out_r[n0 + K - 1] ** 2 + out_i[n0 + K - 1] ** 2) ** 0.5
            n0 += K

        return (np.asarray(out_r) + 1j * np.asarray(out_i)).astype(np.complex64)
