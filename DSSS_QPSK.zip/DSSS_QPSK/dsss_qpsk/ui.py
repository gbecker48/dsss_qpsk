"""
ui.py -- terminal rendering helpers: constellation, spectrum, metric panels.

Everything here returns plain strings, so it works in a curses window, in a
plain terminal, in a log file, or over ssh.
"""

from __future__ import annotations

import numpy as np

# Density ramp for the constellation heat map, lightest to heaviest.
_RAMP = " .:-=+*#%@"


def ascii_constellation(sym: np.ndarray, size=(49, 25), span: float | None = None,
                        title: str | None = None) -> str:
    """2-D density plot of the (normalised) constellation.

    Normalised means the ideal QPSK points sit at (+-1/sqrt2, +-1/sqrt2), marked
    with 'o'.  So you can read three things straight off the picture:
      * are the four clouds centred on the 'o' marks?   -> gain / phase correct
      * are they round and tight?                        -> good SNR, loops locked
      * are they smeared along a circle?                 -> carrier loop too wide
                                       along a radius?   -> amplitude/AGC problem
                                       rotated as a set? -> residual frequency error

    The span auto-scales to the data (with a floor at the ideal constellation)
    so a noisy cloud is not squashed against the border; points outside are
    dropped rather than piled on the edge, and the count is reported.
    """
    w, h = int(size[0]), int(size[1])
    if sym is None or len(sym) == 0:
        return "(no symbols yet)"
    x = np.real(sym).astype(np.float64)
    y = np.imag(sym).astype(np.float64)
    if span is None:
        # 98th percentile of the larger coordinate, with a sane floor/ceiling.
        r = np.percentile(np.maximum(np.abs(x), np.abs(y)), 98)
        span = float(np.clip(2.2 * r, 1.6, 8.0))

    inside = (np.abs(x) < span / 2) & (np.abs(y) < span / 2)
    n_out = int((~inside).sum())
    x, y = x[inside], y[inside]
    if len(x) == 0:
        return "(all symbols off scale)"
    # Histogram on the display grid.
    xi = np.clip(((x + span / 2) / span * (w - 1)).astype(int), 0, w - 1)
    yi = np.clip(((span / 2 - y) / span * (h - 1)).astype(int), 0, h - 1)
    grid = np.zeros((h, w), dtype=np.int32)
    np.add.at(grid, (yi, xi), 1)

    mx = grid.max()
    if mx <= 0:
        return "(no symbols in range)"
    # Logarithmic mapping: a Gaussian cloud has a huge dynamic range and a
    # linear map shows four dots and nothing else.
    norm = np.log1p(grid) / np.log1p(mx)
    idx = np.clip((norm * (len(_RAMP) - 1) + 0.5).astype(int), 0, len(_RAMP) - 1)

    cx = int((0 + span / 2) / span * (w - 1))
    cy = int((span / 2 - 0) / span * (h - 1))
    ideal = 1 / np.sqrt(2)
    ix = [int((v + span / 2) / span * (w - 1)) for v in (-ideal, ideal)]
    iy = [int((span / 2 - v) / span * (h - 1)) for v in (ideal, -ideal)]

    lines = []
    if title:
        lab = f"{title}  +/-{span/2:.2f}" + (f"  ({n_out} off scale)" if n_out else "")
        lines.append(lab.center(w))
    for r in range(h):
        row = []
        for c in range(w):
            ch = _RAMP[idx[r, c]]
            if ch == " ":
                if r == cy and c == cx:
                    ch = "+"
                elif r == cy:
                    ch = "-" if c % 2 == 0 else " "
                elif c == cx:
                    ch = "|"
                elif r in iy and c in ix:
                    ch = "o"                    # where the ideal points are
            row.append(ch)
        lines.append("".join(row))
    return "\n".join(lines)


def bar(value: float, lo: float, hi: float, width: int = 20, ch: str = "#") -> str:
    """Horizontal bar gauge, clamped to [lo, hi]."""
    if hi <= lo:
        return " " * width
    f = (float(value) - lo) / (hi - lo)
    f = 0.0 if not np.isfinite(f) else min(max(f, 0.0), 1.0)
    n = int(round(f * width))
    return "[" + ch * n + "." * (width - n) + "]"


def gain_advice(rx_rms: float) -> str:
    """Tell the operator whether RX_GAIN_DB is in a sane place."""
    if rx_rms <= 0:
        return "no samples yet"
    if rx_rms < 0.01:
        return "RX level LOW  -- raise RX_GAIN_DB by ~10 dB"
    if rx_rms > 0.3:
        return "RX level HIGH -- lower RX_GAIN_DB (front end may be compressing)"
    return "RX level OK"


def fmt_metrics(m: dict, width: int = 78) -> list[str]:
    """Render the live metrics block used by the terminal UI."""
    def g(k, d=0.0):
        v = m.get(k, d)
        return d if v is None else v

    lines = []
    lines.append(" LINK ".center(width, "="))
    lines.append(
        f" state {m.get('state','?'):<10s}"
        f" TX {int(g('tx_frames')):>5d} frames / {int(g('tx_bytes')):>7d} B"
        f"    RX {int(g('rx_frames')):>5d} / {int(g('rx_bytes')):>7d} B")
    lines.append(
        f" PER {100*g('per'):6.2f} %   retries {int(g('retries')):>4d}"
        f"   RTT {1000*g('rtt'):7.1f} ms   goodput {g('goodput')/1000:7.2f} kbit/s")
    lines.append(" SIGNAL ".center(width, "="))
    lines.append(
        f" chip SNR {g('snr_chip_db'):7.2f} dB {bar(g('snr_chip_db'), -20, 10, 18)}"
        f"   <- negative = below the noise floor")
    lines.append(
        f" sym  SNR {g('snr_sym_db'):7.2f} dB {bar(g('snr_sym_db'), -5, 25, 18)}"
        f"   (+{g('proc_gain_db'):.1f} dB processing gain)")
    lines.append(
        f" EVM      {g('evm_pct'):7.2f} %  {bar(-g('evm_pct'), -60, 0, 18)}"
        f"   MER {g('mer_db'):6.2f} dB")
    lines.append(
        f" acq PSR  {g('acq_psr'):7.1f}     sync PSR {g('sync_psr'):6.2f}"
        f"     RX rms {g('rx_rms'):.4f}  {gain_advice(g('rx_rms'))}")
    lines.append(
        f" CFO      {g('cfo_hz'):8.1f} Hz  residual {g('residual_cfo_hz'):+7.2f} Hz"
        f"   timing err {g('timing_err'):+.4f} chip")
    lines.append(
        f" FEC      Viterbi margin {g('viterbi_margin'):8.1f}"
        f"   RS corrections {int(g('rs_corrections')):>3d}/frame"
        f"   CRC {'OK' if m.get('crc_ok') else '--'}")
    lines.append(" ACQUISITION ".center(width, "="))
    lines.append(
        f" acquisitions {int(g('acquisitions')):>6d}"
        f"   rejected at sync {int(g('false_acq')):>6d}"
        f"   header fails {int(g('header_fail')):>5d}"
        f"   payload fails {int(g('payload_fail')):>5d}")
    return lines
