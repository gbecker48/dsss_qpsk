"""
filters.py -- pulse shaping and small DSP helpers.

The root-raised-cosine filter is applied at the CHIP rate (not the symbol rate)
because in DSSS it is the chips that are the transmitted pulses.  TX and RX each
use the same RRC, so the cascade is a raised cosine -> zero ISI at chip centres.
"""

from __future__ import annotations

import numpy as np
from scipy.signal import lfilter


def rrc_taps(sps: int, span_chips: int, rolloff: float) -> np.ndarray:
    """Root-raised-cosine taps, unit-energy normalised.

    sps         : samples per chip
    span_chips  : total length in chips (filter length = sps*span_chips + 1)
    rolloff     : excess bandwidth, 0 < beta <= 1
    """
    n = sps * span_chips
    t = (np.arange(n + 1) - n / 2.0) / float(sps)      # time in chips
    beta = float(rolloff)
    h = np.zeros_like(t)

    # Three cases: the general formula, and two removable singularities.
    denom = 1.0 - (4.0 * beta * t) ** 2
    z = np.abs(t) < 1e-9                      # t == 0
    ok = (np.abs(denom) > 1e-9) & (~z)        # general case
    s = (~ok) & (~z)                          # t == +/- 1/(4*beta)

    tt = t[ok]
    h[ok] = (np.sin(np.pi * tt * (1 - beta))
             + 4 * beta * tt * np.cos(np.pi * tt * (1 + beta))) / \
            (np.pi * tt * (1 - (4 * beta * tt) ** 2))

    h[z] = 1.0 - beta + 4.0 * beta / np.pi

    if beta > 0:
        if np.any(s):
            h[s] = (beta / np.sqrt(2.0)) * (
                (1 + 2 / np.pi) * np.sin(np.pi / (4 * beta))
                + (1 - 2 / np.pi) * np.cos(np.pi / (4 * beta)))

    h = h / np.sqrt(np.sum(h ** 2))
    return h.astype(np.float64)


def fft_correlate(x: np.ndarray, template: np.ndarray) -> np.ndarray:
    """'valid' cross-correlation of x against template, via FFT.

    Returns r[k] = sum_n x[k+n] * conj(template[n]),  k = 0 .. len(x)-len(t).
    Used by the acquisition engine: x is millions of samples, template is the
    RRC-shaped PN code, so the FFT route is far faster than a direct loop.
    """
    nx, nt = len(x), len(template)
    if nx < nt:
        return np.zeros(0, dtype=np.complex128)
    nfft = 1 << int(np.ceil(np.log2(nx + nt - 1)))
    X = np.fft.fft(x, nfft)
    T = np.fft.fft(np.conj(template[::-1]), nfft)
    full = np.fft.ifft(X * T)
    return full[nt - 1: nx]


class DCBlocker:
    """One-pole DC blocker:  H(z) = (1 - z^-1) / (1 - a*z^-1).

    A direct-conversion front end like the B2xx puts LO leakage and an ADC
    offset right at 0 Hz.  This removes it.

    The cutoff must be FAR below the signal, or the filter eats signal energy
    and costs you SNR -- with the default digital IF offset the signal sits at
    250 kHz and a 2 kHz cutoff is completely transparent to it.  (An earlier
    block-averaging version of this filter cost 12 dB of symbol SNR; a proper
    one-pole costs nothing measurable.)
    """

    def __init__(self, cutoff_hz: float = 2000.0, samp_rate: float = 2e6):
        self.set_cutoff(cutoff_hz, samp_rate)
        self.x1 = 0.0 + 0.0j
        self.y1 = 0.0 + 0.0j

    def set_cutoff(self, cutoff_hz: float, samp_rate: float):
        self.a = float(np.clip(1.0 - 2.0 * np.pi * cutoff_hz / samp_rate, 0.0, 0.9999999))

    def reset(self):
        self.x1 = 0.0 + 0.0j
        self.y1 = 0.0 + 0.0j

    def process(self, x: np.ndarray) -> np.ndarray:
        b = np.array([1.0, -1.0])
        a = np.array([1.0, -self.a])
        zi = np.array([self.a * self.y1 - self.x1])
        y, zf = lfilter(b, a, x, zi=zi)
        if x.dtype == np.complex64:
            y = y.astype(np.complex64)
        self.x1 = x[-1] if len(x) else self.x1
        self.y1 = y[-1] if len(y) else self.y1
        return y


class LevelMeter:
    """Passive RMS meter -- always on, used for the UI and gain advice."""

    def __init__(self, alpha: float = 0.05):
        self.alpha = float(alpha)
        self.rms = 0.0

    def update(self, x: np.ndarray) -> float:
        if len(x) == 0:
            return self.rms
        r = float(np.sqrt(np.mean(np.abs(x) ** 2)))
        self.rms = (1 - self.alpha) * self.rms + self.alpha * r if self.rms else r
        return self.rms


class AGC:
    """Optional, deliberately VERY slow automatic gain control.

    READ THIS BEFORE TURNING IT ON.  The receiver measures the signal amplitude
    and the noise variance from every frame's own sync word, so the demodulator
    does not need an AGC at all -- and an AGC whose gain moves *during* a burst
    actively hurts, because the constellation radius then changes underneath the
    slicer.  Measured cost of a fast AGC on this link: EVM 0.47% -> 8.9%.

    So: leave AGC_ENABLE False unless your front end has level swings you cannot
    fix with RX_GAIN_DB, and if you do enable it, keep AGC_TIME_CONSTANT_S at
    least 10x MAX_FRAME_DURATION_S so the gain is effectively frozen inside a
    burst.
    """

    def __init__(self, reference: float = 0.2, time_constant_s: float = 2.0,
                 samp_rate: float = 2e6, gain0: float = 1.0, max_gain: float = 1e6):
        self.reference = float(reference)
        self.tau_samples = max(1.0, float(time_constant_s) * float(samp_rate))
        self.gain = float(gain0)
        self.max_gain = float(max_gain)

    def reset(self, gain: float = 1.0):
        self.gain = gain

    def process(self, x: np.ndarray) -> np.ndarray:
        block = 4096
        y = np.empty_like(x)
        for i in range(0, len(x), block):
            seg = x[i:i + block]
            y[i:i + block] = seg * self.gain
            rms = np.sqrt(np.mean(np.abs(seg) ** 2)) * self.gain + 1e-12
            step = len(seg) / self.tau_samples
            self.gain = float(np.clip(self.gain * (1.0 + step * (self.reference - rms) / self.reference),
                                      1e-9, self.max_gain))
        return y
