"""
link.py -- the half-duplex link layer: burst scheduling, stop-and-wait ARQ,
message reassembly and the running metrics the UI displays.

HALF DUPLEX
    A node transmits one burst, then listens.  It never transmits while it is
    expecting something.  On a single B206mini-i this is enforced at the
    protocol level (the radio itself stays in receive the whole time, which is
    what you want for a TX->RX cable loopback: you hear your own burst come back
    through the attenuator and the whole chain gets exercised).  With two radios
    set HALF_DUPLEX_MUTE_RX = True so each node ignores its own transmission.

STOP AND WAIT ARQ
    Every DATA frame carries a 4-bit sequence number and must be acknowledged
    before the next one goes out.  The ACK timeout is DERIVED from the actual
    burst lengths and the measured round trip (see _ack_deadline), not fixed,
    and a retry is held back while the receiver is mid-burst -- because that
    burst is almost always the ACK we are waiting for.  Duplicate detection is
    by (source, sequence), so a lost ACK costs a retransmission but never a
    duplicate message.

TRANSPORTS
    This class does not know what a USRP is.  It is given a transport object
    with:
        transport.transmit(samples)   -- send a complex64 burst
        transport.rx_callback         -- set by us; called with received samples
    so the same link layer runs over the real radio, over a simulated channel,
    or over a file.
"""

from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass, field

import numpy as np

from .filexfer import FileTransfer, encode_text
from .framing import (FT_ACK, FT_BEACON, FT_DATA, FT_NAMES, FT_PING, FT_STREAM,
                      Header)
from .modulator import Modulator
from .receiver import Receiver

# LOCK ORDER, and it matters: FileTransfer's lock is always taken BEFORE the
# link's, never after.  FileTransfer calls _queue_payload (which takes the link
# lock) while holding its own; so the link must never call into FileTransfer
# while holding self._lock.  Every call site below releases first.


@dataclass
class LinkEvent:
    kind: str                 # "rx", "tx", "ack", "timeout", "error", "info"
    text: str = ""
    frame: object = None
    t: float = field(default_factory=time.time)


class LinkManager:
    def __init__(self, cfg, transport=None):
        self.cfg = cfg
        self.mod = Modulator(cfg)
        self.rx = Receiver(cfg)
        self.transport = transport
        if transport is not None:
            transport.rx_callback = self._on_samples

        self._lock = threading.RLock()
        self._txq: deque[bytes] = deque()
        self.events: deque[LinkEvent] = deque(maxlen=500)

        # Application layer: text messages and file transfers share the link.
        self.files = FileTransfer(cfg, self._queue_payload, self._log)

        # --- ARQ state -------------------------------------------------------
        self.seq = 0
        self.pending: bytes | None = None
        self.pending_seq = 0            # the seq actually in flight
        self.pending_deadline = 0.0     # monotonic
        self.pending_tx_time = 0.0      # monotonic
        self.pending_timeout = 0.0      # what we computed for this message
        self.retries = 0
        self.deferred_retries = 0       # retries held back because RX was busy
        self.late_acks = 0              # ACKs that arrived after we retried
        self.seen: dict[int, int] = {}         # src -> last delivered seq

        # --- muting / bulk pacing -------------------------------------------
        self.mute_until = 0.0
        self._stream_pace = 0.0         # monotonic: no new burst before this
        self.stream_frames = 0          # STREAM frames sent
        self.stream_rx = 0              # STREAM frames received

        # --- metrics ---------------------------------------------------------
        self.tx_frames = 0
        self.tx_bytes = 0
        self.tx_attempts = 0
        self.rx_frames = 0
        self.rx_bytes = 0
        self.total_retries = 0
        self.lost_messages = 0
        self.rtt = 0.0
        self.rtt_avg = 0.0
        self.last_frame = None
        self.constellation = np.zeros(0, dtype=np.complex64)
        self.t0 = time.time()

        self._running = False
        self._thread: threading.Thread | None = None

    # ------------------------------------------------------------------ public
    def reconfigure(self):
        """Rebuild the modem after a config change (see the UI's /set command).

        Waveform knobs are baked into the modulator, the receiver, the spreading
        code and the FEC objects, so they all have to be rebuilt.  Anything in
        flight is dropped; counters are kept so you can compare before/after.
        """
        with self._lock:
            self.mod = Modulator(self.cfg)
            self.rx = Receiver(self.cfg)
            self.pending = None
            self.retries = 0
            self._txq.clear()
            self.seen.clear()
        self._log("info", "modem rebuilt: " + self.cfg.summary().splitlines()[3].strip())

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._pump, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=1.0)

    def send_text(self, text: str):
        """One chat message.  Long text is split; each piece is its own frame."""
        room = self.cfg.MAX_PAYLOAD_BYTES - 1          # 1 byte of app tag
        raw = text.encode("utf-8", errors="replace")
        if len(raw) <= room:
            self._queue_payload(encode_text(text))
            return
        for i in range(0, len(raw), room):
            # Split on the byte string, then decode leniently, so a multi-byte
            # character straddling the boundary degrades to a replacement char
            # instead of raising.
            self._queue_payload(bytes([0x01]) + raw[i:i + room])

    def send_file(self, path) -> dict:
        """Send a file from disk.  Returns the initial progress record."""
        return self.files.send_file(path)

    def send_blob(self, data: bytes, name: str) -> dict:
        """Send bytes you already have (an upload from the dashboard)."""
        return self.files.send_blob(data, name)

    def cancel_transfer(self, xid: int) -> bool:
        return self.files.cancel(xid)

    def _queue_payload(self, payload: bytes, reliable: bool = True):
        """Queue exactly one link message.  Callers above enforce the size.

        reliable=False queues a STREAM frame: transmitted once, never
        acknowledged, never retried.  Only bulk file segments use it.
        """
        if len(payload) > self.cfg.MAX_PAYLOAD_BYTES:
            raise ValueError(f"payload {len(payload)} B exceeds MAX_PAYLOAD_BYTES "
                             f"{self.cfg.MAX_PAYLOAD_BYTES}")
        with self._lock:
            self._txq.append((payload, bool(reliable)))

    def send(self, payload: bytes):
        """Raw bytes, split across frames, no reassembly.  Tests use this."""
        max_len = self.cfg.MAX_PAYLOAD_BYTES
        with self._lock:
            for i in range(0, max(1, len(payload)), max_len):
                self._txq.append((payload[i:i + max_len], True))

    def send_ping(self):
        with self._lock:
            self._transmit(Header(ftype=FT_PING, src=self.cfg.NODE_ID, dst=255,
                                  seq=self.seq, payload_len=0), b"")
        self._log("tx", "PING")

    def queue_depth(self) -> int:
        with self._lock:
            return len(self._txq) + (1 if self.pending is not None else 0)

    # ------------------------------------------------------------------ engine
    def _ack_deadline(self, payload_len: int) -> float:
        """How long to wait for an ACK, derived rather than guessed.

        A fixed timeout is wrong here: the DATA burst for 512 bytes is 167 ms on
        the air and the ACK is another 14 ms, both have to be demodulated, and on
        a busy machine the receiver runs a little behind.  A constant that is
        comfortable for a 64-byte message fires early on a big one -- which is
        what produced "it ACKed fine and then retried anyway": the retry had
        already been queued before the ACK finished decoding.

        So: budget the actual air time of both bursts, the decode time for both
        (the receiver runs at roughly real time), the turnaround, the radio's own
        pipeline latency in each direction, and a few multiples of whatever round
        trip we have actually been measuring.

        On real hardware the pipeline dominates: a 400-byte message is 145 ms of
        air time but ~700 ms of round trip, almost all of it UHD buffering and
        USB.  An air-time-only budget therefore fires on the very first message,
        before there is any measured RTT to learn from.
        """
        data_air = self.mod.burst_duration(payload_len)
        ack_air = self.mod.burst_duration(0)
        budget = ((data_air + ack_air) * 2.5
                  + 2 * (self.cfg.TX_RX_TURNAROUND_S
                         + getattr(self.cfg, "RADIO_LATENCY_S", 0.15)))
        if self.rtt_avg > 0:
            budget = max(budget, 2.5 * self.rtt_avg)
        return max(self.cfg.ARQ_TIMEOUT_MIN_S,
                   min(budget + self.cfg.ARQ_TIMEOUT_SLACK_S,
                       self.cfg.ARQ_TIMEOUT_MAX_S))

    def _rx_busy(self) -> bool:
        """Is the receiver part way through demodulating a burst right now?"""
        try:
            return self.rx.state != "SEARCH"
        except Exception:
            return False

    def _pump(self):
        """ARQ timer / transmit scheduler."""
        next_tick = 0.0
        while self._running:
            # monotonic, not wall clock: time.time() on Windows has ~15 ms
            # granularity and can step backwards when the clock is adjusted,
            # both of which make a timeout fire when it should not.
            now = time.monotonic()
            gave_up = None
            streamed = None
            with self._lock:
                if now < self._stream_pace:
                    pass        # a STREAM burst is still on the air; do not pile on
                elif self.pending is not None and now >= self.pending_deadline:
                    if self._rx_busy():
                        # A burst is being decoded right now and it is very
                        # probably our ACK.  Retransmitting on top of it would
                        # be both wasteful and destructive.  Give it one more
                        # decode's worth of grace.
                        self.pending_deadline = now + self.cfg.ARQ_GRACE_S
                        self.deferred_retries += 1
                    elif self.retries < self.cfg.ARQ_MAX_RETRIES:
                        self.retries += 1
                        self.total_retries += 1
                        self._log("timeout",
                                  f"no ACK for seq {self.pending_seq} in "
                                  f"{self.pending_timeout:.2f} s, retry "
                                  f"{self.retries}/{self.cfg.ARQ_MAX_RETRIES}")
                        self._send_pending()
                    else:
                        self._log("error", f"giving up on seq {self.pending_seq} "
                                           f"after {self.retries} retries")
                        self.lost_messages += 1
                        gave_up = self.pending
                        self.pending = None
                        self.retries = 0
                        self.seq = (self.seq + 1) & 0x0F
                elif self.pending is None and self._txq:
                    payload, reliable = self._txq.popleft()
                    if reliable:
                        self.pending = payload
                        self.pending_seq = self.seq
                        self.retries = 0
                        self._send_pending()
                    else:
                        self._send_stream(payload)
                        streamed = payload
            # Outside the lock -- see the lock-order note at the top of the file.
            if gave_up is not None:
                self.files.on_lost(gave_up)
            if streamed is not None:
                # There is no ACK for a STREAM frame, so "handed to the radio" is
                # the only delivery signal the sender gets.  The receiver's repair
                # request is what corrects this if a burst did not make it.
                self.files.on_delivered(streamed)
            if now >= next_tick:
                next_tick = now + 0.25
                try:
                    self.files.tick()        # pacing + repair timers
                except Exception as e:
                    self._log("error", f"transfer tick: {e!r}")
            time.sleep(0.01)

    def _send_pending(self):
        # Arm the timer BEFORE transmitting.  Modulating and queueing a long
        # burst takes real time, and leaving the old deadline in place during
        # that window is another way to retry something that was never late.
        self.pending_timeout = self._ack_deadline(len(self.pending))
        self.pending_tx_time = time.monotonic()
        self.pending_deadline = self.pending_tx_time + self.pending_timeout
        hdr = Header(ftype=FT_DATA, src=self.cfg.NODE_ID, dst=self.cfg.PEER_NODE_ID,
                     seq=self.pending_seq, ack=0, payload_len=len(self.pending))
        self._transmit(hdr, self.pending)
        # Re-arm from the moment the burst was actually handed to the radio.
        self.pending_tx_time = time.monotonic()
        self.pending_deadline = self.pending_tx_time + self.pending_timeout
        if not self.cfg.ARQ_ENABLE:
            self.pending = None
            self.seq = (self.seq + 1) & 0x0F

    def _send_stream(self, payload: bytes):
        """One unacknowledged bulk frame, paced to its own air time.

        The pacing matters: the transmit queue below us is unbounded, so without
        it a 2 MB file would be modulated and dumped into the radio in a couple
        of seconds, the queue would grow to gigabytes, and a cancel would take
        minutes to take effect.  Waiting out the burst plus FILE_STREAM_PACE
        keeps at most one burst in flight and makes the queue self-limiting.
        """
        hdr = Header(ftype=FT_STREAM, src=self.cfg.NODE_ID,
                     dst=self.cfg.PEER_NODE_ID, seq=self.seq,
                     payload_len=len(payload))
        self.seq = (self.seq + 1) & 0x0F
        self._transmit(hdr, payload)
        dur = self.mod.burst_duration(len(payload))
        pace = float(getattr(self.cfg, "FILE_STREAM_PACE", 1.06))
        self._stream_pace = time.monotonic() + dur * pace
        self.stream_frames += 1

    def _transmit(self, hdr: Header, payload: bytes):
        burst = self.mod.modulate(hdr, payload)
        self.tx_attempts += 1
        if hdr.ftype in (FT_DATA, FT_STREAM):
            self.tx_frames += 1
            self.tx_bytes += len(payload)
        dur = len(burst) / self.cfg.SAMP_RATE_HZ
        if self.cfg.HALF_DUPLEX_MUTE_RX:
            self.mute_until = time.time() + dur + self.cfg.TX_RX_TURNAROUND_S
        if self.transport is not None:
            self.transport.transmit(burst)
        what = (f"seq={hdr.seq}" if hdr.ftype != FT_ACK else f"ack={hdr.ack}")
        self._log("tx", f"{FT_NAMES.get(hdr.ftype,'?')} {what} -> node {hdr.dst}  "
                        f"{len(payload)} B  ({dur*1e3:.1f} ms burst)")

    # --------------------------------------------------------------- rx path
    def _on_samples(self, samples: np.ndarray):
        if self.cfg.HALF_DUPLEX_MUTE_RX and time.time() < self.mute_until:
            return
        try:
            frames = self.rx.process(samples)
        except Exception as e:                      # never kill the radio thread
            self._log("error", f"receiver exception: {e!r}")
            return
        for f in frames:
            self._on_frame(f)

    def _on_frame(self, f):
        self.last_frame = f
        if f.constellation is not None and len(f.constellation):
            self.constellation = f.constellation
        if not f.ok or f.header is None:
            if f.stage not in ("sync-fail",):
                self._log("info", f"frame dropped at {f.stage} "
                                  f"(chip SNR {f.snr_chip_db:.1f} dB)")
            return

        h = f.header
        mine = self.cfg.NODE_ID
        if h.src == mine and not self.cfg.LOOPBACK_ACCEPT_OWN:
            return
        if h.dst not in (mine, 255) and not self.cfg.LOOPBACK_ACCEPT_OWN:
            return

        delivered = None        # payload whose ACK just arrived
        app_payload = None      # payload to hand to the application layer
        with self._lock:
            if h.ftype == FT_ACK:
                # Match against the sequence actually IN FLIGHT, not self.seq.
                # They are the same almost always, but "almost always" is how
                # you end up acknowledging the wrong message after a retry.
                if self.pending is not None and h.ack == self.pending_seq:
                    self.rtt = time.monotonic() - self.pending_tx_time
                    self.rtt_avg = (0.8 * self.rtt_avg + 0.2 * self.rtt) \
                        if self.rtt_avg else self.rtt
                    if self.retries:
                        self.late_acks += 1
                    delivered = self.pending
                    self.pending = None
                    self.retries = 0
                    self.seq = (self.seq + 1) & 0x0F
                    self._log("ack", f"ACK seq={h.ack}  RTT {self.rtt*1e3:.0f} ms"
                                     f"  (budget was {self.pending_timeout*1e3:.0f} ms)")
            elif h.ftype == FT_STREAM:
                # No ACK, and no duplicate suppression by sequence number: the
                # 4-bit seq wraps every 16 frames and a bulk transfer is
                # thousands.  Duplicates are harmless here because the file layer
                # keys segments by (transfer, index) -- writing the same segment
                # twice is a no-op.
                self.stream_rx += 1
                self.rx_frames += 1
                self.rx_bytes += len(f.payload)
                app_payload = f.payload
            elif h.ftype in (FT_DATA, FT_PING, FT_BEACON):
                if self.cfg.ARQ_ENABLE and h.ftype == FT_DATA:
                    self._transmit(Header(ftype=FT_ACK, src=mine, dst=h.src,
                                          seq=0, ack=h.seq, payload_len=0), b"")
                if h.ftype == FT_DATA:
                    if self.seen.get(h.src) == h.seq:
                        self._log("info", f"duplicate seq={h.seq} from {h.src}, ignored")
                        return
                    self.seen[h.src] = h.seq
                    self.rx_frames += 1
                    self.rx_bytes += len(f.payload)
                    app_payload = f.payload
                else:
                    self._log("rx", f"{FT_NAMES.get(h.ftype,'?')} from {h.src}", frame=f)

        # Everything below runs with the link lock RELEASED, because it calls
        # into FileTransfer, which takes its own lock and then ours.
        if delivered is not None:
            self.files.on_delivered(delivered)
        if app_payload is not None:
            try:
                text = self.files.on_payload(app_payload)
            except Exception as e:
                self._log("error", f"application layer: {e!r}")
                text = repr(app_payload[:64])
            if text is not None:          # a chat message, not file traffic
                self._log("rx", text, frame=f)

    # -------------------------------------------------------------- reporting
    def _log(self, kind, text, frame=None):
        self.events.append(LinkEvent(kind=kind, text=text, frame=frame))

    def metrics(self) -> dict:
        f = self.last_frame
        s = self.rx.stats
        elapsed = max(time.time() - self.t0, 1e-6)
        m = {
            "state": self.rx.state,
            "tx_frames": self.tx_frames, "tx_bytes": self.tx_bytes,
            "rx_frames": self.rx_frames, "rx_bytes": self.rx_bytes,
            "retries": self.total_retries,
            "deferred": self.deferred_retries,
            "late_acks": self.late_acks,
            "lost": self.lost_messages,
            "ack_timeout": self.pending_timeout,
            "deaf_pct": 100.0 * s.deaf_samples / max(s.samples_processed, 1),
            "buffer_aborts": s.buffer_aborts,
            "stalls": s.stalls,
            "per": (self.total_retries / self.tx_attempts) if self.tx_attempts else 0.0,
            "rtt": self.rtt_avg,
            "goodput": 8 * self.rx_bytes / elapsed,
            "proc_gain_db": self.cfg.PROCESSING_GAIN_DB,
            "rx_rms": getattr(self.rx, "rx_rms", 0.0),
            "acquisitions": s.acquisitions, "false_acq": s.false_acquisitions,
            "header_fail": s.header_fail, "payload_fail": s.payload_fail,
            "queue": self.queue_depth(),
        }
        xf = self.files.snapshot()
        m["transfers"] = xf["active"]
        m["transfer_history"] = xf["history"]
        m["transferring"] = bool(xf["active"])
        m["stream_tx"] = self.stream_frames
        m["stream_rx"] = self.stream_rx
        if f is not None:
            m.update({
                "snr_chip_db": f.snr_chip_db, "snr_sym_db": f.snr_sym_db,
                "evm_pct": f.evm_pct, "mer_db": f.mer_db,
                "acq_psr": f.acq_psr, "sync_psr": f.sync_psr,
                "cfo_hz": f.fine_cfo_hz, "residual_cfo_hz": f.residual_cfo_hz,
                "timing_err": f.timing_err, "viterbi_margin": f.viterbi_margin,
                "rs_corrections": max(f.rs_corrections, 0), "crc_ok": f.crc_ok,
            })
        return m
