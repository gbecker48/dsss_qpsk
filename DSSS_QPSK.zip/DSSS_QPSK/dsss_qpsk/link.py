"""
link.py -- the half-duplex link layer: burst scheduling, stop-and-wait ARQ,
message reassembly and the running metrics the UI displays.

HALF DUPLEX
    A node transmits one burst, then listens.  It never transmits while it is
    expecting something.  On a single B206mini-i this is enforced at the
    protocol level (the radio itself stays in receive the whole time, which is
    what you want for a TX->RX cable loopback: you hear your own burst come back
    through the attenuator and the whole chain gets exercised).  With two radios
    set HALF_DUPLEX_MUTE_RX = True so each node ignores its own transmission.

STOP AND WAIT ARQ
    Every DATA frame carries a 4-bit sequence number and must be acknowledged
    before the next one goes out.  An unacknowledged frame is retransmitted
    after ARQ_TIMEOUT_S, up to ARQ_MAX_RETRIES times.  Duplicate detection is by
    (source, sequence), so a lost ACK costs a retransmission but never a
    duplicate message.

TRANSPORTS
    This class does not know what a USRP is.  It is given a transport object
    with:
        transport.transmit(samples)   -- send a complex64 burst
        transport.rx_callback         -- set by us; called with received samples
    so the same link layer runs over the real radio, over a simulated channel,
    or over a file.
"""

from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass, field

import numpy as np

from .framing import FT_ACK, FT_BEACON, FT_DATA, FT_NAMES, FT_PING, Header
from .modulator import Modulator
from .receiver import Receiver


@dataclass
class LinkEvent:
    kind: str                 # "rx", "tx", "ack", "timeout", "error", "info"
    text: str = ""
    frame: object = None
    t: float = field(default_factory=time.time)


class LinkManager:
    def __init__(self, cfg, transport=None):
        self.cfg = cfg
        self.mod = Modulator(cfg)
        self.rx = Receiver(cfg)
        self.transport = transport
        if transport is not None:
            transport.rx_callback = self._on_samples

        self._lock = threading.RLock()
        self._txq: deque[bytes] = deque()
        self.events: deque[LinkEvent] = deque(maxlen=500)

        # --- ARQ state -------------------------------------------------------
        self.seq = 0
        self.pending: bytes | None = None
        self.pending_deadline = 0.0
        self.pending_tx_time = 0.0
        self.retries = 0
        self.seen: dict[int, int] = {}         # src -> last delivered seq

        # --- muting ----------------------------------------------------------
        self.mute_until = 0.0

        # --- metrics ---------------------------------------------------------
        self.tx_frames = 0
        self.tx_bytes = 0
        self.tx_attempts = 0
        self.rx_frames = 0
        self.rx_bytes = 0
        self.total_retries = 0
        self.lost_messages = 0
        self.rtt = 0.0
        self.rtt_avg = 0.0
        self.last_frame = None
        self.constellation = np.zeros(0, dtype=np.complex64)
        self.t0 = time.time()

        self._running = False
        self._thread: threading.Thread | None = None

    # ------------------------------------------------------------------ public
    def reconfigure(self):
        """Rebuild the modem after a config change (see the UI's /set command).

        Waveform knobs are baked into the modulator, the receiver, the spreading
        code and the FEC objects, so they all have to be rebuilt.  Anything in
        flight is dropped; counters are kept so you can compare before/after.
        """
        with self._lock:
            self.mod = Modulator(self.cfg)
            self.rx = Receiver(self.cfg)
            self.pending = None
            self.retries = 0
            self._txq.clear()
            self.seen.clear()
        self._log("info", "modem rebuilt: " + self.cfg.summary().splitlines()[3].strip())

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._pump, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=1.0)

    def send_text(self, text: str):
        self.send(text.encode("utf-8", errors="replace"))

    def send(self, payload: bytes):
        max_len = self.cfg.MAX_PAYLOAD_BYTES
        with self._lock:
            for i in range(0, max(1, len(payload)), max_len):
                self._txq.append(payload[i:i + max_len])

    def send_ping(self):
        with self._lock:
            self._transmit(Header(ftype=FT_PING, src=self.cfg.NODE_ID, dst=255,
                                  seq=self.seq, payload_len=0), b"")
        self._log("tx", "PING")

    def queue_depth(self) -> int:
        with self._lock:
            return len(self._txq) + (1 if self.pending is not None else 0)

    # ------------------------------------------------------------------ engine
    def _pump(self):
        """ARQ timer / transmit scheduler."""
        while self._running:
            now = time.time()
            with self._lock:
                if self.pending is not None and now >= self.pending_deadline:
                    if self.retries < self.cfg.ARQ_MAX_RETRIES:
                        self.retries += 1
                        self.total_retries += 1
                        self._log("timeout",
                                  f"no ACK for seq {self.seq}, retry "
                                  f"{self.retries}/{self.cfg.ARQ_MAX_RETRIES}")
                        self._send_pending()
                    else:
                        self._log("error", f"giving up on seq {self.seq} "
                                           f"after {self.retries} retries")
                        self.lost_messages += 1
                        self.pending = None
                        self.retries = 0
                        self.seq = (self.seq + 1) & 0x0F
                elif self.pending is None and self._txq:
                    self.pending = self._txq.popleft()
                    self.retries = 0
                    self._send_pending()
            time.sleep(0.01)

    def _send_pending(self):
        hdr = Header(ftype=FT_DATA, src=self.cfg.NODE_ID, dst=self.cfg.PEER_NODE_ID,
                     seq=self.seq, ack=0, payload_len=len(self.pending))
        self._transmit(hdr, self.pending)
        self.pending_tx_time = time.time()
        self.pending_deadline = self.pending_tx_time + self.cfg.ARQ_TIMEOUT_S
        if not self.cfg.ARQ_ENABLE:
            self.pending = None
            self.seq = (self.seq + 1) & 0x0F

    def _transmit(self, hdr: Header, payload: bytes):
        burst = self.mod.modulate(hdr, payload)
        self.tx_attempts += 1
        if hdr.ftype == FT_DATA:
            self.tx_frames += 1
            self.tx_bytes += len(payload)
        dur = len(burst) / self.cfg.SAMP_RATE_HZ
        if self.cfg.HALF_DUPLEX_MUTE_RX:
            self.mute_until = time.time() + dur + self.cfg.TX_RX_TURNAROUND_S
        if self.transport is not None:
            self.transport.transmit(burst)
        what = (f"seq={hdr.seq}" if hdr.ftype != FT_ACK else f"ack={hdr.ack}")
        self._log("tx", f"{FT_NAMES.get(hdr.ftype,'?')} {what} -> node {hdr.dst}  "
                        f"{len(payload)} B  ({dur*1e3:.1f} ms burst)")

    # --------------------------------------------------------------- rx path
    def _on_samples(self, samples: np.ndarray):
        if self.cfg.HALF_DUPLEX_MUTE_RX and time.time() < self.mute_until:
            return
        try:
            frames = self.rx.process(samples)
        except Exception as e:                      # never kill the radio thread
            self._log("error", f"receiver exception: {e!r}")
            return
        for f in frames:
            self._on_frame(f)

    def _on_frame(self, f):
        self.last_frame = f
        if f.constellation is not None and len(f.constellation):
            self.constellation = f.constellation
        if not f.ok or f.header is None:
            if f.stage not in ("sync-fail",):
                self._log("info", f"frame dropped at {f.stage} "
                                  f"(chip SNR {f.snr_chip_db:.1f} dB)")
            return

        h = f.header
        mine = self.cfg.NODE_ID
        if h.src == mine and not self.cfg.LOOPBACK_ACCEPT_OWN:
            return
        if h.dst not in (mine, 255) and not self.cfg.LOOPBACK_ACCEPT_OWN:
            return

        with self._lock:
            if h.ftype == FT_ACK:
                if self.pending is not None and h.ack == self.seq:
                    self.rtt = time.time() - self.pending_tx_time
                    self.rtt_avg = (0.8 * self.rtt_avg + 0.2 * self.rtt) if self.rtt_avg else self.rtt
                    self.pending = None
                    self.retries = 0
                    self.seq = (self.seq + 1) & 0x0F
                    self._log("ack", f"ACK seq={h.ack}  RTT {self.rtt*1e3:.0f} ms")
                return

            if h.ftype in (FT_DATA, FT_PING, FT_BEACON):
                if self.cfg.ARQ_ENABLE and h.ftype == FT_DATA:
                    self._transmit(Header(ftype=FT_ACK, src=mine, dst=h.src,
                                          seq=0, ack=h.seq, payload_len=0), b"")
                if h.ftype == FT_DATA:
                    if self.seen.get(h.src) == h.seq:
                        self._log("info", f"duplicate seq={h.seq} from {h.src}, ignored")
                        return
                    self.seen[h.src] = h.seq
                    self.rx_frames += 1
                    self.rx_bytes += len(f.payload)
                    try:
                        text = f.payload.decode("utf-8")
                    except UnicodeDecodeError:
                        text = repr(f.payload)
                    self._log("rx", text, frame=f)
                else:
                    self._log("rx", f"{FT_NAMES.get(h.ftype,'?')} from {h.src}", frame=f)

    # -------------------------------------------------------------- reporting
    def _log(self, kind, text, frame=None):
        self.events.append(LinkEvent(kind=kind, text=text, frame=frame))

    def metrics(self) -> dict:
        f = self.last_frame
        s = self.rx.stats
        elapsed = max(time.time() - self.t0, 1e-6)
        m = {
            "state": self.rx.state,
            "tx_frames": self.tx_frames, "tx_bytes": self.tx_bytes,
            "rx_frames": self.rx_frames, "rx_bytes": self.rx_bytes,
            "retries": self.total_retries,
            "per": (self.total_retries / self.tx_attempts) if self.tx_attempts else 0.0,
            "rtt": self.rtt_avg,
            "goodput": 8 * self.rx_bytes / elapsed,
            "proc_gain_db": self.cfg.PROCESSING_GAIN_DB,
            "rx_rms": getattr(self.rx, "rx_rms", 0.0),
            "acquisitions": s.acquisitions, "false_acq": s.false_acquisitions,
            "header_fail": s.header_fail, "payload_fail": s.payload_fail,
            "queue": self.queue_depth(),
        }
        if f is not None:
            m.update({
                "snr_chip_db": f.snr_chip_db, "snr_sym_db": f.snr_sym_db,
                "evm_pct": f.evm_pct, "mer_db": f.mer_db,
                "acq_psr": f.acq_psr, "sync_psr": f.sync_psr,
                "cfo_hz": f.fine_cfo_hz, "residual_cfo_hz": f.residual_cfo_hz,
                "timing_err": f.timing_err, "viterbi_margin": f.viterbi_margin,
                "rs_corrections": max(f.rs_corrections, 0), "crc_ok": f.crc_ok,
            })
        return m
