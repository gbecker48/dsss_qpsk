"""
modulator.py -- QPSK + DSSS burst transmitter (pure numpy, no GNU Radio).

  bits -> Gray-mapped QPSK symbols -> x PN code (spreading) -> RRC pulse shape
       -> burst amplitude ramp -> digital IF shift -> complex baseband burst

GRAY MAPPING
    bit pair (b0, b1)  ->  ( (1-2*b0) + j*(1-2*b1) ) / sqrt(2)
    b0 is carried on I, b1 on Q, each independently.  Gray coding means a
    90-degree phase slip corrupts only one of the two bits, which is exactly
    what the soft decoder handles best.

SPREADING
    Every QPSK symbol is multiplied by the whole real bipolar PN code, so one
    symbol occupies SPREADING_FACTOR chips.  Despreading at the receiver is the
    matched operation (correlate against the same code), and it raises the
    symbol SNR by 10*log10(SPREADING_FACTOR) dB -- the processing gain that lets
    the link run below the noise floor.
"""

from __future__ import annotations

import numpy as np

from . import filters, pn
from .codec import Codec
from .framing import Header, sync_word


# Gray-coded QPSK constellation, indexed by (b0 << 1) | b1
QPSK_TABLE = np.array([
    (1 + 1j),      # 00
    (1 - 1j),      # 01
    (-1 + 1j),     # 10
    (-1 - 1j),     # 11
], dtype=np.complex64) / np.sqrt(2)


def bits_to_qpsk(bits: np.ndarray) -> np.ndarray:
    """Map a bit stream to Gray-coded QPSK symbols (pads with a 0 if odd)."""
    b = np.asarray(bits, dtype=np.uint8)
    if len(b) % 2:
        b = np.concatenate([b, np.zeros(1, dtype=np.uint8)])
    idx = (b[0::2].astype(np.uint8) << 1) | b[1::2]
    return QPSK_TABLE[idx]


def qpsk_to_bits(sym: np.ndarray) -> np.ndarray:
    """Hard decision (used only for diagnostics; the decoder uses soft LLRs)."""
    b0 = (np.real(sym) < 0).astype(np.uint8)
    b1 = (np.imag(sym) < 0).astype(np.uint8)
    out = np.empty(2 * len(sym), dtype=np.uint8)
    out[0::2] = b0
    out[1::2] = b1
    return out


class Modulator:
    def __init__(self, cfg):
        self.cfg = cfg
        self.codec = Codec(cfg)
        self.code = pn.spreading_code(cfg.PN_KIND, cfg.SPREADING_FACTOR, cfg.PN_INDEX)
        self.sync = sync_word(cfg.SYNC_LEN, cfg.SYNC_SEED)
        self.rrc = filters.rrc_taps(cfg.SPS_CHIP, cfg.RRC_SPAN_CHIPS, cfg.RRC_ROLLOFF)
        # Preamble symbols: constant 1+0j, i.e. the bare PN code repeated.
        self.preamble_sym = np.ones(cfg.N_PREAMBLE_PERIODS, dtype=np.complex64)

    # ------------------------------------------------------------- symbols
    def frame_symbols(self, header: Header, payload: bytes) -> np.ndarray:
        """Full symbol sequence for one burst (preamble + sync + hdr + payload)."""
        hdr_bits = self.codec.encode_header(header.pack())
        hdr_sym = bits_to_qpsk(hdr_bits)
        if payload:
            pay_bits = self.codec.encode_payload(payload)
            pay_sym = bits_to_qpsk(pay_bits)
        else:
            pay_sym = np.zeros(0, dtype=np.complex64)
        return np.concatenate([self.preamble_sym, self.sync, hdr_sym, pay_sym])

    # ------------------------------------------------------------- samples
    def spread(self, symbols: np.ndarray) -> np.ndarray:
        """One symbol -> SPREADING_FACTOR chips."""
        return (symbols[:, None] * self.code[None, :]).reshape(-1)

    def shape(self, chips: np.ndarray) -> np.ndarray:
        """Upsample to SPS_CHIP samples/chip and apply the RRC pulse shape."""
        sps = self.cfg.SPS_CHIP
        up = np.zeros(len(chips) * sps, dtype=np.complex64)
        up[::sps] = chips
        # 'full' convolution keeps the filter's leading/trailing transient,
        # which the ramp then shapes -- this is what keeps the spectrum clean.
        return np.convolve(up, self.rrc.astype(np.complex64), mode="full")

    def ramp(self, x: np.ndarray) -> np.ndarray:
        n = int(self.cfg.RAMP_CHIPS * self.cfg.SPS_CHIP)
        if n <= 0 or len(x) < 2 * n:
            return x
        w = 0.5 * (1 - np.cos(np.pi * np.arange(n) / n))     # raised-cosine ramp
        y = x.copy()
        y[:n] *= w
        y[-n:] *= w[::-1]
        return y

    def if_shift(self, x: np.ndarray, phase0: float = 0.0) -> np.ndarray:
        f = self.cfg.IF_OFFSET_HZ
        if f == 0:
            return x
        n = np.arange(len(x))
        return (x * np.exp(1j * (2 * np.pi * f * n / self.cfg.SAMP_RATE_HZ
                                 + phase0))).astype(np.complex64)

    def modulate(self, header: Header, payload: bytes = b"") -> np.ndarray:
        """Complete burst, ready to hand to the USRP sink."""
        sym = self.frame_symbols(header, payload)
        x = self.shape(self.spread(sym))
        x = self.ramp(x)
        x = self.if_shift(x)
        peak = np.max(np.abs(x)) + 1e-12
        return (x * (self.cfg.TX_AMPLITUDE / peak)).astype(np.complex64)

    # ------------------------------------------------------------- helpers
    def burst_samples(self, payload_len: int) -> int:
        nsym = (self.cfg.N_PREAMBLE_PERIODS + self.cfg.SYNC_LEN
                + self.codec.header_symbols() + self.codec.payload_symbols(payload_len))
        return nsym * self.cfg.SAMPLES_PER_SYMBOL + len(self.rrc) - 1

    def burst_duration(self, payload_len: int) -> float:
        return self.burst_samples(payload_len) / self.cfg.SAMP_RATE_HZ
