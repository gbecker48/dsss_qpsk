"""
blocks/gr_blocks.py -- the GNU Radio 3.10 wrappers.

There are only two of them, and they are deliberately thin.  All the signal
processing lives in the pure-numpy modules, which is what makes it possible to
unit test and tune the whole link without a radio attached.  These blocks just
move samples between GNU Radio's scheduler and those objects.

  DsssBurstSource  -- a source that sits silent until a burst is queued, then
                      emits it as a tagged stream packet.  The "packet_len" tag
                      is what tells uhd.usrp_sink to key the transmitter for
                      exactly that many samples (it generates tx_sob on the
                      first sample and tx_eob on the last), which is how you get
                      clean half-duplex bursts out of a B2xx instead of a
                      continuous carrier with underruns between messages.

  DsssReceiverSink -- a sink that feeds samples to Receiver.process() and hands
                      every decoded frame to a callback.

Import this module only when you actually want GNU Radio; everything else in
the package works without it.
"""

from __future__ import annotations

import queue
import threading

import numpy as np

try:
    import pmt
    from gnuradio import gr
except ImportError as e:                                    # pragma: no cover
    raise ImportError(
        "GNU Radio is not importable in this Python.  On Windows/radioconda run "
        "from the 'GNU Radio Command Prompt' or activate the radioconda env "
        "first.  Everything except the hardware flowgraph works without it: try "
        "`python run_link.py --sim`."
    ) from e

PACKET_LEN_TAG = "packet_len"


class DsssBurstSource(gr.sync_block):
    """Complex source that emits queued bursts as tagged-stream packets."""

    def __init__(self, packet_len_tag: str = PACKET_LEN_TAG, idle_timeout: float = 0.05,
                 idle_fill: bool = False, idle_chunk: int = 4096):
        """
        idle_fill : False for a real USRP -- produce NOTHING between bursts, so
                    uhd.usrp_sink keys the transmitter only for the tagged
                    packets and stays quiet in between (true burst / half-duplex
                    operation).
                    True for the no-hardware loopback flowgraph, where something
                    downstream (the channel model, the receiver) needs a
                    continuous stream to put noise on; zeros are emitted between
                    bursts and no length tags are produced.
        """
        gr.sync_block.__init__(self, name="dsss_burst_source",
                               in_sig=None, out_sig=[np.complex64])
        self.q: "queue.Queue[np.ndarray]" = queue.Queue()
        self._cur: np.ndarray | None = None
        self._pos = 0
        self._tag = pmt.string_to_symbol(packet_len_tag)
        self._idle_timeout = float(idle_timeout)
        self._idle_fill = bool(idle_fill)
        self._idle_chunk = int(idle_chunk)
        self.bursts_sent = 0
        self.samples_sent = 0

    # called from the application thread
    def transmit(self, samples: np.ndarray):
        self.q.put(np.asarray(samples, dtype=np.complex64))

    def work(self, input_items, output_items):
        out = output_items[0]

        if self._cur is None:
            try:
                self._cur = self.q.get_nowait() if self._idle_fill else \
                    self.q.get(timeout=self._idle_timeout)
            except queue.Empty:
                if not self._idle_fill:
                    return 0                # produce nothing; stay silent
                n = min(len(out), self._idle_chunk)
                out[:n] = 0
                self.samples_sent += n
                return n
            self._pos = 0
            if not self._idle_fill:
                # Tag the first sample of the burst with its total length.
                self.add_item_tag(0, self.nitems_written(0), self._tag,
                                  pmt.from_long(len(self._cur)))
            self.bursts_sent += 1

        n = min(len(out), len(self._cur) - self._pos)
        out[:n] = self._cur[self._pos:self._pos + n]
        self._pos += n
        self.samples_sent += n
        if self._pos >= len(self._cur):
            self._cur = None
        return n


class DsssReceiverSink(gr.sync_block):
    """Complex sink that hands samples to the DSSS/QPSK receiver.

    The DSP runs on a WORKER THREAD, not inside work().  This matters on real
    hardware: decoding a burst takes a bit less time than the burst itself, but
    it is bursty, and if that work happened inside work() the back-pressure
    would reach uhd.usrp_source and you would get overruns ('O') and lost
    samples in the middle of every frame.  With a queue in between, the radio
    thread only ever does a memcpy, and the decoder catches up afterwards --
    it runs about 2.4x real time when idle, so it always does.

    If the queue ever does fill (a very slow machine, or a much larger spreading
    factor), samples are dropped and counted in `self.dropped` rather than
    stalling the radio.  The UI shows that count; if it is non-zero, raise
    TRACKER_BLOCK_SYMBOLS, lower SAMP_RATE_HZ, or shorten the preamble.
    """

    def __init__(self, receiver, on_frame=None, on_samples=None, max_queue=2048):
        gr.sync_block.__init__(self, name="dsss_receiver_sink",
                               in_sig=[np.complex64], out_sig=None)
        self.receiver = receiver
        self.on_frame = on_frame
        self.on_samples = on_samples
        self.samples_seen = 0
        self.dropped = 0
        self.errors = 0
        self.max_backlog = 0
        self._q: "queue.Queue[np.ndarray]" = queue.Queue(maxsize=int(max_queue))
        self._running = True
        self._worker = threading.Thread(target=self._loop, daemon=True)
        self._worker.start()

    def _loop(self):
        while self._running:
            try:
                x = self._q.get(timeout=0.1)
            except queue.Empty:
                continue
            try:
                if self.on_samples is not None:
                    self.on_samples(x)
                else:
                    frames = self.receiver.process(x)
                    if self.on_frame:
                        for f in frames:
                            self.on_frame(f)
            except Exception:                                # pragma: no cover
                self.errors += 1

    def stop(self):
        self._running = False
        return True

    def work(self, input_items, output_items):
        x = input_items[0]
        n = len(x)
        self.samples_seen += n
        try:
            self._q.put_nowait(np.array(x, dtype=np.complex64))
            self.max_backlog = max(self.max_backlog, self._q.qsize())
        except queue.Full:
            self.dropped += n
        return n
