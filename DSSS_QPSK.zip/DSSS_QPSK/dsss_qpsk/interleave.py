"""
interleave.py -- block interleaver applied to the CODED bits.

Why: the convolutional decoder assumes errors are independent.  Real channels
produce bursts -- a fade, a passing interferer, a momentary timing slip, a
partial collision with another burst.  Writing the coded bits into a matrix by
rows and reading them out by columns scatters them, so a burst of consecutive
channel errors arrives at the Viterbi decoder as isolated single errors, which
it fixes easily.

The parameter is the SEPARATION (`depth`): two bits that are adjacent on the
air end up `depth` coded bits apart at the decoder input.  Make it comfortably
larger than the Viterbi memory (~5*K = 35 bits for K=7); 64 is a good default.

Implementation note: rather than padding the bit stream (which would need the
padding length to be signalled), the permutation is built over the padded grid
and then filtered to the actual length.  That keeps it a true permutation of
0..n-1 for ANY n, so nothing has to be transmitted to describe it.
"""

from __future__ import annotations

import numpy as np

_CACHE: dict[tuple[int, int], np.ndarray] = {}


def permutation(n: int, depth: int) -> np.ndarray:
    """Read-order permutation: out[i] = in[perm[i]].

    Consecutive output (on-air) positions come from input positions `depth`
    apart, which is exactly the burst protection the Viterbi decoder wants.
    """
    key = (n, depth)
    p = _CACHE.get(key)
    if p is None:
        cols = max(1, min(int(depth), max(1, n)))
        rows = int(np.ceil(n / cols))
        grid = np.arange(rows * cols).reshape(rows, cols)
        p = grid.T.reshape(-1)
        p = p[p < n]
        _CACHE[key] = p
    return p


def interleave(x: np.ndarray, depth: int) -> np.ndarray:
    if depth <= 1 or len(x) <= 1:
        return x
    return x[permutation(len(x), depth)]


def deinterleave(y: np.ndarray, depth: int) -> np.ndarray:
    if depth <= 1 or len(y) <= 1:
        return y
    p = permutation(len(y), depth)
    out = np.empty_like(y)
    out[p] = y
    return out
