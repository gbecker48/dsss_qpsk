"""
webui.py -- the live browser dashboard, message console and file transfer UI.

    python run_link.py --web            then open http://127.0.0.1:8731

No extra packages: the standard library's HTTP server plus one self-contained
page.  It reads the link; it owns no DSP state and never blocks a DSP thread.

WHY A BROWSER AND NOT MATPLOTLIB
    A matplotlib window on Windows fights the Qt/Tk backend, blocks the
    interpreter, and redraws slowly.  A canvas in a browser redraws at 20 Hz
    without touching the radio threads, works over a remote desktop, and can sit
    on a second monitor while the terminal stays where it is.

WHAT IS ON THE PAGE
    READOUTS      chip SNR (with a badge when the signal is genuinely under the
                  noise), EVM/MER, round trip, goodput, frame counts, RX level.
    CONSTELLATION the despread, phase-corrected payload symbols, shaded by
                  density so you see the SHAPE of the cloud and not just its
                  extent, with the ideal points and the 1-sigma error circle.
                  Beside it, the distribution of error magnitude -- a Rayleigh
                  shape means clean additive noise, a fat tail means something
                  else (clipping, a loop bandwidth that is too wide, a spur).
    SPECTRUM      live FFT of what the radio is handing us, BEFORE any
                  de-rotation, with a peak-hold trace and the noise floor
                  marked.  This is the plot that tells you whether the RF path
                  works at all.
    WATERFALL     the same spectrum scrolling in time: intermittent
                  interference and your own bursts.
    ACQUISITION   delay and Doppler cuts through the last acquisition peak.  A
                  single clean spike means the preamble correlation is healthy.
    TRENDS        chip SNR, EVM, residual carrier offset and timing error over
                  time, with a crosshair readout.
    MESSAGES      send and receive text.
    FILES         drag a file in, pick one with the button, or browse the
                  machine running the link and pick a path.  Live progress with
                  rate and ETA both ways; received files land in the inbox and
                  are downloadable straight from the page.
    TUNING        change any config knob live (the same thing /set does in the
                  terminal) without restarting.

COLOR
    The four trend series use a categorical palette checked with a
    colour-vision-deficiency validator against this page's dark surface: worst
    adjacent pair dE 11.4 under protanopia, 17.5 normal.  Status colours
    (good/warn/bad) are reserved for state and never used as a series colour.

SECURITY
    Bound to 127.0.0.1 by default.  The file browser and the upload endpoint
    give whoever can reach this port the ability to read files on this machine
    and put them on the air, so if you set WEB_HOST to 0.0.0.0, understand that
    you are doing exactly that on your network.
"""

from __future__ import annotations

import json
import mimetypes
import os
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlparse

import numpy as np

PAGE = r"""<!doctype html>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>DSSS/QPSK link</title>
<style>
:root{
  --bg:#0f1115; --surface:#1a1a19; --panel:#171b22; --edge:#262e3a;
  --fg:#dde4ee; --dim:#8593a6; --faint:#5b6878;
  /* status -- reserved, never used as a series colour */
  --ok:#54c98a; --warn:#d8a33c; --bad:#e0655f;
  /* categorical series, validated for CVD on this surface */
  --s1:#00949F; --s2:#BC8340; --s3:#6B7ECB; --s4:#C25C83;
  --accent:#00949F;
}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--fg);
     font:13px/1.45 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
a{color:var(--s3)}
header{display:flex;gap:16px;align-items:baseline;flex-wrap:wrap;
       padding:10px 14px;background:var(--panel);border-bottom:1px solid var(--edge);
       position:sticky;top:0;z-index:5}
header h1{font-size:13px;margin:0;font-weight:700;letter-spacing:.10em}
.kv{color:var(--dim);white-space:nowrap} .kv b{color:var(--fg);font-weight:600}
.pill{padding:1px 7px;border-radius:10px;border:1px solid var(--edge);
      font-size:11px;letter-spacing:.05em}
#kpis{display:grid;gap:8px;padding:10px 10px 0;
      grid-template-columns:repeat(auto-fit,minmax(178px,1fr))}
.tile{background:var(--panel);border:1px solid var(--edge);border-radius:8px;
      padding:8px 11px;min-width:0}
.tile .lab{font-size:10px;letter-spacing:.11em;color:var(--dim);
           text-transform:uppercase}
.tile .big{font-size:22px;font-weight:700;line-height:1.25;
           font-variant-numeric:tabular-nums}
.tile .sub{font-size:10.5px;color:var(--faint);line-height:1.35;
           min-height:2.7em}
.badge{display:inline-block;font-size:9px;letter-spacing:.07em;padding:1px 5px;
       border-radius:9px;margin-left:4px;vertical-align:3px;font-weight:700;
       white-space:nowrap}
.badge.under{background:#0d3f45;color:#7fe3ee;border:1px solid #14636e}
#grid{display:grid;gap:10px;padding:10px;
      grid-template-columns:repeat(auto-fit,minmax(340px,1fr))}
.card{background:var(--panel);border:1px solid var(--edge);border-radius:8px;
      padding:10px 12px;min-width:0}
.card.wide{grid-column:span 2}
@media (max-width:760px){.card.wide{grid-column:span 1}}
h2{margin:0 0 7px;font-size:10.5px;letter-spacing:.12em;color:var(--dim);
   text-transform:uppercase;font-weight:700;display:flex;
   justify-content:space-between;gap:8px;align-items:baseline}
h2 span{color:var(--fg);letter-spacing:0;text-transform:none;font-weight:400;
        font-size:11px;text-align:right}
h2.mt{margin-top:11px}
canvas{width:100%;display:block;border-radius:4px;background:var(--surface);
       touch-action:none}
.plotwrap{position:relative}
.tip{position:absolute;pointer-events:none;background:#0b0e13ee;
     border:1px solid var(--edge);border-radius:5px;padding:4px 7px;
     font-size:11px;white-space:pre;z-index:3;transform:translate(8px,8px)}
table{width:100%;border-collapse:collapse}
td{padding:2px 0;white-space:nowrap} td:first-child{color:var(--dim)}
td:last-child{text-align:right;font-variant-numeric:tabular-nums}
.legend{display:flex;gap:12px;flex-wrap:wrap;font-size:11px;color:var(--dim);
        margin:5px 0 0}
.legend i{display:inline-block;width:9px;height:9px;border-radius:2px;
          margin-right:4px;vertical-align:-1px}
#log{height:200px;overflow:auto;font-size:12px}
#log div{padding:1px 0;border-bottom:1px solid #1a222c;word-break:break-word}
#log .rx{color:var(--ok)} #log .tx{color:var(--s3)}
#log .ack,#log .info{color:var(--dim)}
#log .timeout,#log .error{color:var(--bad)}
form{display:flex;gap:6px;margin-top:8px}
input,select{flex:1;min-width:0;background:#0c1016;border:1px solid var(--edge);
      color:var(--fg);border-radius:5px;padding:6px 8px;font:inherit}
button{background:#1f2937;border:1px solid var(--edge);color:var(--fg);font:inherit;
       border-radius:5px;padding:6px 11px;cursor:pointer;white-space:nowrap}
button.primary{background:var(--accent);border-color:var(--accent);color:#04181b;
               font-weight:700}
button:hover{border-color:var(--dim)}
button:disabled{opacity:.45;cursor:default}
.row{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}
#drop{border:1.5px dashed var(--edge);border-radius:8px;padding:14px;
      text-align:center;color:var(--dim);font-size:12px;cursor:pointer;
      transition:border-color .15s,background .15s}
#drop.hot{border-color:var(--accent);background:#0c2226;color:var(--fg)}
.xfer{margin-top:9px;font-size:11.5px}
.xfer .top{display:flex;justify-content:space-between;gap:8px}
.xfer .nm{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.bar{height:6px;background:#0c1016;border:1px solid var(--edge);border-radius:4px;
     overflow:hidden;margin-top:3px}
.bar i{display:block;height:100%;border-radius:3px 0 0 3px;
       background:var(--accent);transition:width .25s}
.bar i.rx{background:var(--ok)}
.bar i.err{background:var(--bad)}
.muted{color:var(--dim)} .good{color:var(--ok)} .warn{color:var(--warn)}
.bad{color:var(--bad)}
#browse{max-height:240px;overflow:auto;margin-top:8px;font-size:12px}
#browse div{padding:2px 4px;border-radius:4px;cursor:pointer;
            white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#browse div:hover{background:#1f2937}
#inbox div{padding:2px 0;font-size:12px}
.hint{font-size:11px;color:var(--faint);margin-top:6px;white-space:normal}
</style>

<header>
  <h1>DSSS / QPSK LINK</h1>
  <div class=kv>node <b id=h_node>-</b></div>
  <div class=kv><b id=h_freq>-</b> MHz</div>
  <div class=kv>SF <b id=h_sf>-</b> <span class=muted>(+<b id=h_pg>-</b> dB)</span></div>
  <div class=kv><b id=h_rate>-</b> sym/s</div>
  <div class=kv>state <b id=h_state>-</b></div>
  <div class=kv>queue <b id=h_q>-</b></div>
  <div class="kv pill" id=h_conn style="margin-left:auto">connecting…</div>
</header>

<div id=kpis>
  <div class=tile><div class=lab>chip-band SNR</div>
    <div class=big id=k_snr>–</div><div class=sub id=k_snr_s>waiting for a frame</div></div>
  <div class=tile><div class=lab>symbol SNR</div>
    <div class=big id=k_sym>–</div><div class=sub id=k_sym_s>after despreading</div></div>
  <div class=tile><div class=lab>EVM</div>
    <div class=big id=k_evm>–</div><div class=sub id=k_evm_s>constellation error</div></div>
  <div class=tile><div class=lab>round trip</div>
    <div class=big id=k_rtt>–</div><div class=sub id=k_rtt_s>message to ACK</div></div>
  <div class=tile><div class=lab>goodput</div>
    <div class=big id=k_gp>–</div><div class=sub id=k_gp_s>delivered payload</div></div>
  <div class=tile><div class=lab>frames</div>
    <div class=big id=k_fr>–</div><div class=sub id=k_fr_s>tx / rx</div></div>
  <div class=tile><div class=lab>errors</div>
    <div class=big id=k_err>–</div><div class=sub id=k_err_s>retries · lost</div></div>
  <div class=tile><div class=lab>rx level</div>
    <div class=big id=k_lvl>–</div><div class=sub id=k_lvl_s>rms at the ADC</div></div>
</div>

<div id=grid>

  <div class=card><h2>Constellation <span id=c_evm></span></h2>
    <div class=plotwrap><canvas id=cst height=310></canvas></div>
    <h2 class=mt>Error histogram <span id=c_hist></span></h2>
    <canvas id=hist height=96></canvas>
    <div class=hint>A Rayleigh-shaped hump is plain additive noise. A fat right
      tail or a second lobe means something structural — clipping, a loop
      bandwidth set too wide, or a spur inside the band.</div>
  </div>

  <div class=card><h2>Spectrum <span id=c_spec></span></h2>
    <div class=plotwrap><canvas id=spec height=210></canvas><div class=tip id=spectip hidden></div></div>
    <div class=legend>
      <span><i style="background:var(--s1)"></i>averaged</span>
      <span><i style="background:rgba(0,148,159,.2)"></i>instantaneous</span>
      <span><i style="background:var(--faint)"></i>peak hold</span>
      <span><i style="background:var(--warn)"></i>noise floor</span>
      <button id=pkclear style="padding:1px 7px;font-size:11px">reset peak hold</button>
    </div>
    <h2 class=mt>Waterfall <span class=muted>time ↓</span></h2>
    <canvas id=wf height=150></canvas>
  </div>

  <div class=card><h2>Acquisition <span id=c_acq></span></h2>
    <canvas id=acq height=160></canvas>
    <div class=legend>
      <span><i style="background:var(--s1)"></i>delay cut</span>
      <span><i style="background:var(--s2)"></i>Doppler cut</span>
    </div>
    <h2 class=mt>Trends <span id=c_trend></span></h2>
    <div class=plotwrap><canvas id=trend height=190></canvas><div class=tip id=trendtip hidden></div></div>
    <div class=legend>
      <span><i style="background:var(--s1)"></i>chip SNR dB</span>
      <span><i style="background:var(--s2)"></i>EVM %</span>
      <span><i style="background:var(--s3)"></i>resid CFO Hz</span>
      <span><i style="background:var(--s4)"></i>timing err chip</span>
    </div>
  </div>

  <div class=card><h2>Signal</h2><table id=t_sig></table>
    <h2 class=mt>Link</h2><table id=t_link></table></div>

  <div class=card><h2>Messages</h2><div id=log></div>
    <form id=send onsubmit="return doSend(event)">
      <input id=msg placeholder="type a message and press enter" autocomplete=off>
      <button class=primary>Send</button></form>
    <div class=row>
      <button onclick="post('ping',{})">Ping</button>
      <button onclick="document.getElementById('log').innerHTML=''">Clear log</button>
    </div>
  </div>

  <div class="card wide"><h2>Files <span id=c_files></span></h2>
    <div id=drop>drop a file here, or click to choose one
      <div class=hint style="margin-top:4px">sent over the air in segments with a
        CRC-32 manifest; the receiver asks for anything it misses</div></div>
    <input type=file id=fpick hidden>
    <form id=pathform onsubmit="return doPath(event)">
      <input id=fpath placeholder="…or a path on the machine running the link" autocomplete=off>
      <button>Send path</button>
      <button type=button onclick="toggleBrowse()">Browse</button>
    </form>
    <div id=browse hidden></div>
    <div id=xfers></div>
    <h2 class=mt>Received <span id=c_inbox></span></h2>
    <div id=inbox class=muted>nothing yet</div>
  </div>

  <div class=card><h2>Tuning <span class=muted>live, no restart</span></h2>
    <form id=setform onsubmit="return doSet(event)">
      <input id=setk placeholder="CONFIG_NAME" autocomplete=off style="flex:2">
      <input id=setv placeholder="value" autocomplete=off style="flex:1">
      <button>Apply</button>
    </form>
    <div class=row id=quickset></div>
    <div class=hint>Waveform knobs (spreading factor, preamble length, FEC) rebuild
      the modem and <b>must be changed identically on the other end</b>. Everything
      else takes effect immediately.</div>
    <h2 class=mt>Configuration</h2><table id=t_cfg></table>
  </div>

</div>

<script>
const $=id=>document.getElementById(id);
const css=n=>getComputedStyle(document.documentElement).getPropertyValue(n).trim();
function fit(c){const r=c.getBoundingClientRect(),d=devicePixelRatio||1;
  if(c.width!==Math.round(r.width*d)||c.height!==Math.round(c.clientHeight*d)){
    c.width=Math.round(r.width*d);c.height=Math.round(c.clientHeight*d);}
  const x=c.getContext('2d');x.setTransform(d,0,0,d,0,0);return x;}
function clear(x,c){x.clearRect(0,0,c.clientWidth,c.clientHeight);}
const nf=(v,d)=>(v===undefined||v===null||!isFinite(v))?'–':v.toFixed(d);
function human(n){const u=['B','kB','MB','GB'];let i=0;
  while(n>=1024&&i<3){n/=1024;i++;}
  return (i?n.toFixed(1):n.toFixed(0))+' '+u[i];}
function dur(s){if(!isFinite(s)||s<=0)return '–';
  if(s<60)return s.toFixed(0)+' s';
  const m=Math.floor(s/60);return m+'m '+Math.round(s-60*m)+'s';}

/* ======================================================= KPI readouts */
function setTile(id,val,sub,cls){const e=$(id);e.textContent=val;
  e.className='big '+(cls||'');if(sub!==null)$(id+'_s').textContent=sub;}
function drawKPIs(d){
  if(d.has_frame){
    const under=d.snr_chip_db<0;
    $('k_snr').innerHTML=nf(d.snr_chip_db,1)+' dB'+
      (under?'<span class="badge under">UNDER NOISE</span>':'');
    $('k_snr').className='big '+(d.snr_chip_db>=-12?'good':d.snr_chip_db>=-15?'warn':'bad');
    $('k_snr_s').textContent=under
      ? 'signal is '+nf(-d.snr_chip_db,1)+' dB below the noise in its own band'
      : 'signal is above the noise floor';
    setTile('k_sym',nf(d.snr_sym_db,1)+' dB',
      '+'+nf(d.proc_gain_db,1)+' dB of processing gain',
      d.snr_sym_db>=3?'good':d.snr_sym_db>=1?'warn':'bad');
    setTile('k_evm',nf(d.evm_pct,2)+' %','MER '+nf(d.mer_db,1)+' dB',
      d.evm_pct<=20?'good':d.evm_pct<=60?'warn':'bad');
  }
  setTile('k_rtt',d.rtt>0?(d.rtt*1000).toFixed(0)+' ms':'–',
    'ACK budget '+(d.ack_timeout*1000).toFixed(0)+' ms');
  setTile('k_gp',(d.goodput/1000).toFixed(2),'kbit/s delivered payload');
  setTile('k_fr',d.tx_frames+' / '+d.rx_frames,
    human(d.tx_bytes)+' out · '+human(d.rx_bytes)+' in');
  setTile('k_err',d.retries+' · '+d.lost,'retries · messages given up',
    d.lost?'bad':d.retries?'warn':'good');
  const lv=d.rx_rms;
  setTile('k_lvl',nf(lv,4),
    lv>0.3?'TOO HOT — front end is compressing':
    lv<0.005?'very low — raise RX gain':'healthy for this front end',
    lv>0.3?'bad':lv<0.005?'warn':'good');
}

/* ================================================== constellation + hist */
function drawConst(d){
  const c=$('cst'),x=fit(c),W=c.clientWidth,H=c.clientHeight;clear(x,c);
  const R=Math.min(W,H)/2-16, cx=W/2, cy=H/2, pts=d.constellation||[];
  let span=1.15;
  if(pts.length){let m=0;for(let i=0;i<pts.length;i+=2)
      m=Math.max(m,Math.abs(pts[i]),Math.abs(pts[i+1]));
    span=Math.max(1.15,Math.min(m*1.06,4));}
  const S=R/span;
  /* recessive grid */
  x.strokeStyle='#212a36';x.lineWidth=1;
  x.beginPath();x.moveTo(cx-R,cy);x.lineTo(cx+R,cy);
  x.moveTo(cx,cy-R);x.lineTo(cx,cy+R);x.stroke();
  x.strokeStyle='#19212b';
  for(const r of [0.5,1,1.5,2,3]){if(r>span)break;
    x.beginPath();x.arc(cx,cy,r*S,0,7);x.stroke();}
  /* density: bin, then one sequential hue light->dark by count */
  if(pts.length){
    const G=90,bins=new Int32Array(G*G);let mx=1;
    for(let i=0;i<pts.length;i+=2){
      const gx=Math.floor((pts[i]/span*0.5+0.5)*G),
            gy=Math.floor((-pts[i+1]/span*0.5+0.5)*G);
      if(gx>=0&&gx<G&&gy>=0&&gy<G){const k=gy*G+gx;
        bins[k]++;if(bins[k]>mx)mx=bins[k];}}
    const cell=2*R/G;
    for(let gy=0;gy<G;gy++)for(let gx=0;gx<G;gx++){
      const n=bins[gy*G+gx];if(!n)continue;
      const t=Math.pow(n/mx,0.45);
      x.fillStyle='rgba(0,190,205,'+(0.14+0.8*t).toFixed(3)+')';
      x.fillRect(cx-R+gx*cell,cy-R+gy*cell,cell+0.6,cell+0.6);}
  }
  /* ideal points + 1-sigma error circle */
  const q=Math.SQRT1_2;
  x.strokeStyle=css('--warn');x.lineWidth=1.2;
  for(const a of [1,-1])for(const b of [1,-1]){
    x.beginPath();x.arc(cx+a*q*S,cy-b*q*S,4,0,7);x.stroke();}
  if(d.evm_pct>0&&d.evm_pct<200){
    x.strokeStyle='rgba(224,101,95,.55)';x.setLineDash([3,3]);
    for(const a of [1,-1])for(const b of [1,-1]){x.beginPath();
      x.arc(cx+a*q*S,cy-b*q*S,d.evm_pct/100*S,0,7);x.stroke();}
    x.setLineDash([]);}
  x.fillStyle=css('--faint');x.font='10px ui-monospace,monospace';
  x.fillText('I',cx+R-6,cy-5);x.fillText('Q',cx+5,cy-R+10);
  $('c_evm').textContent=pts.length?
    (pts.length/2)+' symbols · EVM '+nf(d.evm_pct,2)+'% · MER '+nf(d.mer_db,1)+' dB'
    :'no frame yet';
}
function drawHist(d){
  const c=$('hist'),x=fit(c),W=c.clientWidth,H=c.clientHeight;clear(x,c);
  const pts=d.constellation||[];
  if(pts.length<8){$('c_hist').textContent='';return;}
  const q=Math.SQRT1_2,err=[];let mx=0;
  for(let i=0;i<pts.length;i+=2){
    const a=pts[i]>=0?q:-q,b=pts[i+1]>=0?q:-q;
    const e=Math.hypot(pts[i]-a,pts[i+1]-b);err.push(e);if(e>mx)mx=e;}
  const NB=48,bins=new Int32Array(NB);
  for(const e of err)bins[Math.min(NB-1,Math.floor(e/(mx||1)*NB))]++;
  const top=Math.max(...bins),bw=W/NB;
  /* 2px surface gap between adjacent bars, 4px rounded top */
  for(let i=0;i<NB;i++){
    const h=(bins[i]/top)*(H-14);if(h<=0)continue;
    const bx=i*bw+1,by=H-h,w=Math.max(1,bw-2),r=Math.min(3,w/2,h);
    x.fillStyle='rgba(0,148,159,.85)';x.beginPath();
    x.moveTo(bx,H);x.lineTo(bx,by+r);x.quadraticCurveTo(bx,by,bx+r,by);
    x.lineTo(bx+w-r,by);x.quadraticCurveTo(bx+w,by,bx+w,by+r);
    x.lineTo(bx+w,H);x.closePath();x.fill();}
  const mean=err.reduce((a,b)=>a+b,0)/err.length;
  const mline=mean/(mx||1)*W;
  x.strokeStyle=css('--warn');x.setLineDash([3,3]);x.beginPath();
  x.moveTo(mline,0);x.lineTo(mline,H);x.stroke();x.setLineDash([]);
  x.fillStyle=css('--faint');x.font='10px ui-monospace,monospace';
  x.fillText('mean',mline+3,10);x.fillText('0',2,H-2);
  x.fillText(mx.toFixed(2),W-28,H-2);
  $('c_hist').textContent='peak error '+mx.toFixed(3)+' (ideal radius 0.707)';
}

/* ============================================================== spectrum */
let peakHold=null,specAvg=null;
$('pkclear').onclick=()=>{peakHold=null;specAvg=null;};
let lastSpec=null;
function drawSpec(d){
  const c=$('spec'),x=fit(c),W=c.clientWidth,H=c.clientHeight;clear(x,c);
  const s=d.spectrum;if(!s||!s.db.length){$('c_spec').textContent='no samples yet';return;}
  lastSpec=s;
  const lo=s.min_db,hi=s.max_db,n=s.db.length,rng=Math.max(hi-lo,1);
  if(!peakHold||peakHold.length!==n)peakHold=s.db.slice();
  else for(let i=0;i<n;i++)if(s.db[i]>peakHold[i])peakHold[i]=s.db[i];
  /* One FFT of noise is a hairball -- nobody can read a shape out of it.
     An exponential average over frames is the same measurement with the
     variance taken out, and it is what a spectrum analyser shows you. */
  if(!specAvg||specAvg.length!==n)specAvg=s.db.slice();
  else for(let i=0;i<n;i++)specAvg[i]=0.82*specAvg[i]+0.18*s.db[i];
  x.strokeStyle='#1b2330';x.lineWidth=1;x.fillStyle=css('--faint');
  x.font='10px ui-monospace,monospace';
  for(let k=0;k<=4;k++){const y=H*k/4;
    x.beginPath();x.moveTo(0,y);x.lineTo(W,y);x.stroke();
    x.fillText((hi-rng*k/4).toFixed(0),3,y+10);}
  const fx=f=>(f-s.f0)/(s.f1-s.f0)*W, py=v=>H-(v-lo)/rng*H;
  /* occupied band of our own signal */
  if(s.bw_hz){const a=fx(s.if_hz-s.bw_hz/2),b=fx(s.if_hz+s.bw_hz/2);
    x.fillStyle='rgba(0,148,159,.09)';x.fillRect(a,0,b-a,H);}
  x.strokeStyle='#3b2a2a';x.beginPath();x.moveTo(fx(0),0);x.lineTo(fx(0),H);x.stroke();
  x.fillStyle='#6f4b4b';x.fillText('DC',fx(0)+3,H-4);
  if(s.if_hz){x.strokeStyle='#243c52';x.beginPath();
    x.moveTo(fx(s.if_hz),0);x.lineTo(fx(s.if_hz),H);x.stroke();
    x.fillStyle=css('--s1');x.fillText('IF',fx(s.if_hz)+3,12);}
  /* noise floor */
  x.strokeStyle=css('--warn');x.setLineDash([4,4]);x.lineWidth=1;
  x.beginPath();x.moveTo(0,py(s.floor_db));x.lineTo(W,py(s.floor_db));x.stroke();
  x.setLineDash([]);
  x.beginPath();
  for(let i=0;i<n;i++){const X=i/(n-1)*W,Y=py(peakHold[i]);i?x.lineTo(X,Y):x.moveTo(X,Y);}
  x.strokeStyle='#4e5a6b';x.lineWidth=1;x.stroke();
  x.beginPath();
  for(let i=0;i<n;i++){const X=i/(n-1)*W,Y=py(s.db[i]);i?x.lineTo(X,Y):x.moveTo(X,Y);}
  x.strokeStyle='rgba(0,148,159,.13)';x.lineWidth=1;x.stroke();
  x.beginPath();
  for(let i=0;i<n;i++){const X=i/(n-1)*W,Y=py(specAvg[i]);i?x.lineTo(X,Y):x.moveTo(X,Y);}
  x.strokeStyle=css('--s1');x.lineWidth=2;x.stroke();
  $('c_spec').textContent='peak '+s.peak_db.toFixed(1)+' dB @ '+
    (s.peak_hz/1e3).toFixed(0)+' kHz · floor '+s.floor_db.toFixed(1)+' dB';
}
attachTip($('spec'),$('spectip'),(fx)=>{
  const s=lastSpec;if(!s||!s.db.length)return null;
  const i=Math.max(0,Math.min(s.db.length-1,Math.round(fx*(s.db.length-1))));
  const f=s.f0+(s.f1-s.f0)*i/(s.db.length-1);
  return (f/1e3).toFixed(1)+' kHz\n'+
    (specAvg?'avg  '+specAvg[i].toFixed(1)+' dB\n':'')+
    'now  '+s.db[i].toFixed(1)+' dB'+
    (peakHold?'\npeak '+peakHold[i].toFixed(1)+' dB':'');
});

/* ============================================================= waterfall */
let wfImg=null;
function drawWF(d){
  const c=$('wf'),x=fit(c),W=c.clientWidth;
  const s=d.spectrum;if(!s||!s.db.length)return;
  if(!wfImg||wfImg.width!==c.width)wfImg=x.createImageData(c.width,1);
  x.drawImage(c,0,(devicePixelRatio||1));
  /* Referenced to the measured noise floor so the useful 25 dB above it fills
     the ramp.  Scaling to the frame peak makes a noise-only band solid colour. */
  const lo=s.floor_db-2,hi=s.floor_db+26,n=s.db.length,dat=wfImg.data;
  for(let px=0;px<c.width;px++){
    const t=Math.max(0,Math.min(1,(s.db[Math.min(n-1,Math.floor(px/c.width*n))]-lo)/(hi-lo)));
    /* single-hue sequential ramp, dark -> bright teal -> white */
    dat[px*4]  =Math.round(255*Math.min(1,Math.max(0,t*2.6-1.55)));
    dat[px*4+1]=Math.round(255*Math.min(1,Math.max(0,t*1.75-0.22)));
    dat[px*4+2]=Math.round(255*Math.min(1,Math.max(0,t*1.85-0.10)));
    dat[px*4+3]=255;}
  x.putImageData(wfImg,0,0);
}

/* =========================================================== acquisition */
function drawAcq(d){
  const c=$('acq'),x=fit(c),W=c.clientWidth,H=c.clientHeight;clear(x,c);
  const a=d.acq_profile;
  if(!a||!a.delay_db||!a.delay_db.length){
    x.fillStyle=css('--faint');x.font='11px ui-monospace,monospace';
    x.fillText('no acquisition yet',8,H/2);$('c_acq').textContent='';return;}
  const LAB=14, half=H/2-LAB-4;          /* reserved strip for the label */
  const plot=(arr,y0,col,label)=>{
    const lo=Math.min(...arr),hi=Math.max(...arr),r=Math.max(hi-lo,1);
    x.fillStyle=css('--faint');x.font='10px ui-monospace,monospace';
    x.fillText(label,4,y0+10);
    const top=y0+LAB;
    x.strokeStyle='#1b2330';x.beginPath();
    x.moveTo(0,top+half);x.lineTo(W,top+half);x.stroke();
    x.beginPath();
    for(let i=0;i<arr.length;i++){const X=i/(arr.length-1)*W,
      Y=top+half-(arr[i]-lo)/r*half;i?x.lineTo(X,Y):x.moveTo(X,Y);}
    x.strokeStyle=col;x.lineWidth=2;x.stroke();};
  plot(a.delay_db,0,css('--s1'),'delay cut (chips)');
  plot(a.doppler_db,H/2,css('--s2'),'Doppler cut (Hz)');
  $('c_acq').textContent='peak/median '+a.psr.toFixed(0)+' · '+a.cfo_hz.toFixed(0)+' Hz';
}

/* ================================================================ trends */
const SER=[['snr','chip SNR dB','--s1',1],['evm','EVM %','--s2',1],
           ['cfo','resid CFO Hz','--s3',2],['tim','timing err','--s4',4]];
const hist={snr:[],evm:[],cfo:[],tim:[]};
function pushHist(d){
  if(!d.has_frame)return;
  hist.snr.push(d.snr_chip_db);hist.evm.push(d.evm_pct);
  hist.cfo.push(d.residual_cfo_hz);hist.tim.push(d.timing_err);
  for(const k in hist)if(hist[k].length>300)hist[k].shift();
}
function drawTrend(){
  const c=$('trend'),x=fit(c),W=c.clientWidth,H=c.clientHeight;clear(x,c);
  const h=H/SER.length;
  SER.forEach(([k,label,col,dp],i)=>{
    const a=hist[k],y0=i*h;
    x.strokeStyle='#1b2330';x.beginPath();
    x.moveTo(0,y0+h-1);x.lineTo(W,y0+h-1);x.stroke();
    x.fillStyle=css('--faint');x.font='10px ui-monospace,monospace';
    x.fillText(label+(a.length?'  '+a[a.length-1].toFixed(dp):''),4,y0+11);
    if(a.length<2)return;
    const lo=Math.min(...a),hi=Math.max(...a),r=Math.max(hi-lo,1e-6);
    x.beginPath();
    for(let j=0;j<a.length;j++){const X=j/(a.length-1)*W,
      Y=y0+h-5-(a[j]-lo)/r*(h-16);j?x.lineTo(X,Y):x.moveTo(X,Y);}
    x.strokeStyle=css(col);x.lineWidth=2;x.stroke();});
  $('c_trend').textContent=hist.snr.length+' frames';
}
attachTip($('trend'),$('trendtip'),(fx)=>{
  if(hist.snr.length<2)return null;
  const j=Math.max(0,Math.min(hist.snr.length-1,Math.round(fx*(hist.snr.length-1))));
  return SER.map(([k,l,,dp])=>l+': '+(hist[k][j]!==undefined?hist[k][j].toFixed(dp):'–'))
            .join('\n');
});
function attachTip(canvas,tip,fmt){
  canvas.addEventListener('pointermove',e=>{
    const r=canvas.getBoundingClientRect();
    const t=fmt((e.clientX-r.left)/r.width);
    if(!t){tip.hidden=true;return;}
    tip.hidden=false;tip.textContent=t;
    tip.style.left=(e.clientX-r.left)+'px';
    tip.style.top=(e.clientY-r.top)+'px';});
  canvas.addEventListener('pointerleave',()=>{tip.hidden=true;});
}

/* ================================================================ tables */
const cls=(v,g,w)=>v>=g?'good':(v>=w?'warn':'bad');
function rows(el,list){el.innerHTML=list.map(([k,v,c])=>
  '<tr><td>'+k+'</td><td class="'+(c||'')+'">'+v+'</td></tr>').join('');}
function drawTables(d){
  rows($('t_sig'),[
    ['chip SNR',nf(d.snr_chip_db,2)+' dB',cls(d.snr_chip_db,-12,-16)],
    ['symbol SNR',nf(d.snr_sym_db,2)+' dB',cls(d.snr_sym_db,3,1)],
    ['&nbsp;&nbsp;from the preamble','measured on known symbols'],
    ['&nbsp;&nbsp;from the payload EVM',
      nf(20*Math.log10(100/Math.max(d.evm_pct,1e-9)),2)+' dB'],
    ['EVM',nf(d.evm_pct,2)+' %',cls(-d.evm_pct,-60,-80)],
    ['MER',nf(d.mer_db,2)+' dB',cls(d.mer_db,5,3)],
    ['acq peak/median',nf(d.acq_psr,0),cls(d.acq_psr,50,30)],
    ['sync peak/background',nf(d.sync_psr,2),cls(d.sync_psr,8,6)],
    ['carrier offset',nf(d.cfo_hz,1)+' Hz'],
    ['residual CFO',nf(d.residual_cfo_hz,2)+' Hz'],
    ['timing error',nf(d.timing_err,4)+' chip'],
    ['RS corrections',d.rs_corrections],
    ['Viterbi margin',nf(d.viterbi_margin,0)],
    ['RX rms',nf(d.rx_rms,5),d.rx_rms>0.3?'bad':(d.rx_rms<0.005?'warn':'good')],
  ]);
  rows($('t_link'),[
    ['TX frames / bytes',d.tx_frames+' / '+human(d.tx_bytes)],
    ['RX frames / bytes',d.rx_frames+' / '+human(d.rx_bytes)],
    ['STREAM tx / rx',d.stream_tx+' / '+d.stream_rx],
    ['retries',d.retries,d.retries?'warn':'good'],
    ['deferred retries',d.deferred],
    ['late ACKs',d.late_acks],
    ['lost messages',d.lost,d.lost?'bad':'good'],
    ['RTT (smoothed)',(d.rtt*1000).toFixed(0)+' ms'],
    ['ACK budget',(d.ack_timeout*1000).toFixed(0)+' ms'],
    ['goodput',(d.goodput/1000).toFixed(2)+' kbit/s'],
    ['acquisitions',d.acquisitions],
    ['rejected at sync',d.false_acq],
    ['header / payload fails',d.header_fail+' / '+d.payload_fail],
    ['deaf time',nf(d.deaf_pct,1)+' %',d.deaf_pct>70?'warn':'good'],
    ['buffer aborts',d.buffer_aborts,d.buffer_aborts?'bad':'good'],
  ]);
  if(d.cfg)rows($('t_cfg'),Object.entries(d.cfg).map(([k,v])=>[k,String(v)]));
}

/* =================================================================== log */
let lastLog=0;
function drawLog(d){
  if(!d.log||!d.log.length)return;
  const el=$('log'),stick=el.scrollTop+el.clientHeight>=el.scrollHeight-24;
  for(const e of d.log){if(e.i<=lastLog)continue;lastLog=e.i;
    const div=document.createElement('div');div.className=e.kind;
    div.textContent=e.t+'  '+e.kind.padEnd(7)+' '+e.text;
    el.appendChild(div);}
  while(el.children.length>500)el.removeChild(el.firstChild);
  if(stick)el.scrollTop=el.scrollHeight;
}

/* ============================================================== transfers */
function drawXfers(d){
  const list=(d.transfers||[]).concat(d.transfer_history||[]);
  const host=$('xfers');
  if(!list.length){host.innerHTML='';$('c_files').textContent='';return;}
  const act=(d.transfers||[]).length;
  $('c_files').textContent=act?act+' in progress':'idle';
  host.innerHTML=list.map(t=>{
    const bad=(t.state==='failed');
    const done=(t.state==='complete'||t.state==='confirmed');
    const right=done?human(t.size)+' · '+dur(t.elapsed)
      : bad?'failed'
      : human(t.rate)+'/s · '+dur(t.eta)+' left';
    const link=(t.dir==='rx'&&t.path&&done)
      ? ' <a href="file?name='+encodeURIComponent(t.name)+'" download>download</a>':'';
    const cancel=(t.dir==='tx'&&!done&&!bad)
      ? ' <button style="padding:0 6px;font-size:10px" onclick="post(\'cancel\',{xid:'
        +t.xid+'})">cancel</button>':'';
    return '<div class=xfer><div class=top>'
      +'<span class=nm>'+(t.dir==='tx'?'▲ ':'▼ ')+escapeHtml(t.name)+link+cancel+'</span>'
      +'<span class="'+(bad?'bad':done?'good':'muted')+'">'+right+'</span></div>'
      +'<div class=bar><i class="'+(bad?'err':t.dir)+'" style="width:'
      +Math.min(100,t.pct).toFixed(1)+'%"></i></div>'
      +'<div class=sub style="color:var(--faint);font-size:10.5px">'
      +t.seg_done+'/'+t.nseg+' segments · '+t.state
      +(t.repairs?' · '+t.repairs+' repair rounds':'')+'</div></div>';
  }).join('');
}
function escapeHtml(s){return String(s).replace(/[&<>"]/g,
  c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
function drawInbox(d){
  const el=$('inbox'),f=d.inbox||[];
  $('c_inbox').textContent=f.length?f.length+' file'+(f.length>1?'s':''):'';
  el.className=f.length?'':'muted';
  el.innerHTML=f.length?f.map(x=>'<div><a href="file?name='+
    encodeURIComponent(x.name)+'" download>'+escapeHtml(x.name)+'</a> '+
    '<span class=muted>'+human(x.size)+' · '+x.when+'</span></div>').join('')
    :'nothing yet';
}

/* ================================================================ actions */
async function post(path,body){
  const r=await fetch(path,{method:'POST',body:JSON.stringify(body)});
  return r.json().catch(()=>({}));}
async function doSend(ev){ev.preventDefault();
  const m=$('msg').value;if(!m)return false;$('msg').value='';
  await post('send',{text:m});return false;}
async function doPath(ev){ev.preventDefault();
  const p=$('fpath').value.trim();if(!p)return false;
  const r=await post('sendpath',{path:p});
  if(r.error)alert(r.error);else $('fpath').value='';
  return false;}
async function doSet(ev){ev.preventDefault();
  const k=$('setk').value.trim(),v=$('setv').value.trim();
  if(!k)return false;
  const r=await post('set',{key:k,value:v});
  if(r.error)alert(r.error);
  return false;}
/* --- file picking: click, drag-drop, or a path on the link machine --- */
$('drop').onclick=()=>$('fpick').click();
$('fpick').onchange=e=>{for(const f of e.target.files)upload(f);e.target.value='';};
for(const ev of ['dragenter','dragover'])
  $('drop').addEventListener(ev,e=>{e.preventDefault();$('drop').classList.add('hot');});
for(const ev of ['dragleave','drop'])
  $('drop').addEventListener(ev,e=>{e.preventDefault();$('drop').classList.remove('hot');});
$('drop').addEventListener('drop',e=>{
  for(const f of e.dataTransfer.files)upload(f);});
document.addEventListener('dragover',e=>e.preventDefault());
document.addEventListener('drop',e=>e.preventDefault());
async function upload(file){
  const r=await fetch('upload',{method:'POST',body:file,
    headers:{'X-Filename':encodeURIComponent(file.name)}});
  const j=await r.json().catch(()=>({}));
  if(j.error)alert(j.error);
}
/* --- server-side file browser --- */
let browsing=false,browseDir='';
async function toggleBrowse(){browsing=!browsing;$('browse').hidden=!browsing;
  if(browsing)loadBrowse(browseDir);}
async function loadBrowse(p){
  const r=await (await fetch('browse?path='+encodeURIComponent(p||''))).json();
  if(r.error){$('browse').innerHTML='<div class=bad>'+escapeHtml(r.error)+'</div>';return;}
  browseDir=r.path;
  const rows=['<div class=muted style="cursor:default">'+escapeHtml(r.path)+'</div>',
    '<div onclick="loadBrowse('+JSON.stringify(r.parent).replace(/"/g,'&quot;')+')">📁 ..</div>'];
  for(const e of r.entries)
    rows.push('<div onclick="'+(e.dir
      ?'loadBrowse('+JSON.stringify(e.path).replace(/"/g,'&quot;')+')'
      :'pick('+JSON.stringify(e.path).replace(/"/g,'&quot;')+')')+'">'
      +(e.dir?'📁 ':'📄 ')+escapeHtml(e.name)
      +(e.dir?'':' <span class=muted>'+human(e.size)+'</span>')+'</div>');
  $('browse').innerHTML=rows.join('');
}
function pick(p){$('fpath').value=p;}

/* =================================================================== poll */
let fails=0,slow=0;
async function tick(){
  try{
    const d=await (await fetch('data?since='+lastLog)).json();
    fails=0;$('h_conn').textContent='live';$('h_conn').className='kv pill good';
    $('h_node').textContent=d.node;$('h_freq').textContent=(d.freq/1e6).toFixed(4);
    $('h_sf').textContent=d.sf;$('h_pg').textContent=d.proc_gain_db.toFixed(1);
    $('h_rate').textContent=d.symbol_rate.toFixed(0);
    $('h_state').textContent=d.state;$('h_q').textContent=d.queue;
    pushHist(d);drawKPIs(d);drawConst(d);drawHist(d);drawSpec(d);drawWF(d);
    drawAcq(d);drawTrend();drawTables(d);drawLog(d);drawXfers(d);drawInbox(d);
  }catch(e){if(++fails>2){$('h_conn').textContent='disconnected';
    $('h_conn').className='kv pill bad';}}
}
/* quick-set buttons for the knobs you actually reach for */
const QUICK=[['SPREADING_FACTOR',31],['SPREADING_FACTOR',63],['SPREADING_FACTOR',127],
             ['FILE_STREAM_MODE','True'],['FILE_STREAM_MODE','False'],
             ['ARQ_MAX_RETRIES',4],['ARQ_MAX_RETRIES',8]];
$('quickset').innerHTML=QUICK.map(([k,v])=>
  '<button style="font-size:11px;padding:3px 8px" onclick="post(\'set\',{key:\''+k
  +'\',value:\''+v+'\'})">'+k.replace(/_/g,' ').toLowerCase()+' = '+v+'</button>').join('');
setInterval(tick,200);tick();
</script>
"""


# --------------------------------------------------------------------------
def _apply_setting(cfg, link, name: str, raw: str) -> str:
    """Same semantics as the terminal's /set, so both front ends agree."""
    name = name.strip().upper()
    if not hasattr(cfg, name):
        raise ValueError(f"no such config value: {name}")
    try:
        value = eval(raw, {"__builtins__": {}},
                     {"True": True, "False": False, "None": None})
    except Exception:
        value = raw
    old = getattr(cfg, name)
    try:
        setattr(cfg, name, value)
        cfg.recompute()
    except Exception as e:
        setattr(cfg, name, old)
        cfg.recompute()
        raise ValueError(f"rejected: {e!r}") from None
    if name in getattr(cfg, "WAVEFORM_KNOBS", ()):
        try:
            link.reconfigure()
        except Exception as e:
            setattr(cfg, name, old)
            cfg.recompute()
            link.reconfigure()
            raise ValueError(f"rebuild failed, reverted: {e!r}") from None
    return f"{name}: {old} -> {value}"


class _Handler(BaseHTTPRequestHandler):
    server_version = "dsss-link"
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):            # keep the console clean
        pass

    # ------------------------------------------------------------------ util
    def _send(self, code, body, ctype="application/json", extra=None):
        data = body if isinstance(body, bytes) else body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj))

    def _body(self) -> bytes:
        n = int(self.headers.get("Content-Length", 0) or 0)
        if n <= 0:
            return b""
        buf = bytearray()
        while len(buf) < n:
            chunk = self.rfile.read(min(1 << 20, n - len(buf)))
            if not chunk:
                break
            buf += chunk
        return bytes(buf)

    # ------------------------------------------------------------------- GET
    def do_GET(self):
        u = urlparse(self.path)
        path = u.path.strip("/")
        q = parse_qs(u.query)
        dash = self.server.dash
        if path in ("", "index.html"):
            return self._send(200, PAGE, "text/html; charset=utf-8")
        if path == "data":
            try:
                since = int(q.get("since", ["0"])[0])
            except ValueError:
                since = 0
            return self._json(dash.snapshot(since))
        if path == "browse":
            return self._json(dash.browse(q.get("path", [""])[0]))
        if path == "file":
            name = q.get("name", [""])[0]
            try:
                blob, fname = dash.inbox_file(name)
            except Exception as e:
                return self._json({"error": str(e)}, 404)
            ctype = mimetypes.guess_type(fname)[0] or "application/octet-stream"
            return self._send(200, blob, ctype, {
                "Content-Disposition": f'attachment; filename="{quote(fname)}"'})
        return self._json({"error": "not found"}, 404)

    # ------------------------------------------------------------------ POST
    def do_POST(self):
        path = urlparse(self.path).path.strip("/")
        dash = self.server.dash
        link = dash.link
        if path == "upload":
            name = unquote(self.headers.get("X-Filename", "upload.bin"))
            blob = self._body()
            try:
                link.send_blob(blob, os.path.basename(name) or "upload.bin")
            except Exception as e:
                return self._json({"error": str(e)}, 400)
            return self._json({"ok": True, "bytes": len(blob)})

        raw = self._body() or b"{}"
        try:
            body = json.loads(raw.decode("utf-8"))
        except Exception:
            body = {}
        try:
            if path == "send":
                txt = str(body.get("text", ""))
                if txt:
                    link.send_text(txt)
                return self._json({"ok": True})
            if path == "sendpath":
                link.send_file(str(body.get("path", "")))
                return self._json({"ok": True})
            if path == "cancel":
                return self._json({"ok": link.cancel_transfer(int(body.get("xid", -1)))})
            if path == "ping":
                link.send_ping()
                return self._json({"ok": True})
            if path == "set":
                msg = _apply_setting(dash.cfg, link, str(body.get("key", "")),
                                     str(body.get("value", "")))
                link._log("info", msg)
                return self._json({"ok": True, "message": msg})
        except Exception as e:
            return self._json({"error": str(e)}, 400)
        return self._json({"error": "not found"}, 404)


class Dashboard:
    """Serves the live page.  Owns no DSP state -- it only reads the link."""

    # Config values worth showing on the page.  Not the whole module: a wall of
    # 200 constants is not information.
    SHOW_CFG = ("CENTER_FREQ_HZ", "SAMP_RATE_HZ", "SPS_CHIP", "SPREADING_FACTOR",
                "IF_OFFSET_HZ", "TX_GAIN_DB", "RX_GAIN_DB", "N_PREAMBLE_PERIODS",
                "SYNC_LEN", "MAX_PAYLOAD_BYTES", "FILE_SEGMENT_BYTES",
                "FILE_STREAM_MODE", "USE_RS", "INTERLEAVER_DEPTH",
                "ACQ_THRESHOLD_PSR", "DLL_LOOP_BW", "COSTAS_LOOP_BW",
                "ARQ_MAX_RETRIES", "NODE_ID", "PEER_NODE_ID")

    def __init__(self, cfg, link, port=8731, host="127.0.0.1", nfft=1024):
        self.cfg = cfg
        self.link = link
        self.port = int(port)
        self.host = host
        self.nfft = int(nfft)
        self._win = np.hanning(self.nfft)
        self.httpd = None
        self._thread = None

    # ------------------------------------------------------------------ data
    def _spectrum(self) -> dict:
        x = getattr(self.link.rx, "recent_raw", None)
        blank = {"db": [], "f0": 0, "f1": 0, "min_db": -120, "max_db": 0,
                 "peak_db": 0, "peak_hz": 0, "floor_db": 0,
                 "if_hz": self.cfg.IF_OFFSET_HZ, "bw_hz": 0}
        if x is None or len(x) < self.nfft:
            return blank
        seg = np.asarray(x[-self.nfft:], dtype=np.complex128) * self._win
        sp = np.fft.fftshift(np.fft.fft(seg))
        db = 20 * np.log10(np.abs(sp) / self.nfft + 1e-12)
        freqs = np.fft.fftshift(np.fft.fftfreq(self.nfft, 1.0 / self.cfg.SAMP_RATE_HZ))
        floor = float(np.median(db))
        pk = int(np.argmax(db))
        step = max(1, self.nfft // 512)     # the page only has ~500 px anyway
        return {
            "db": [round(float(v), 1) for v in db[::step]],
            "f0": float(freqs[0]), "f1": float(freqs[-1]),
            "min_db": round(floor - 12, 1), "max_db": round(float(db.max()) + 6, 1),
            "peak_db": round(float(db[pk]), 1), "peak_hz": float(freqs[pk]),
            "floor_db": round(floor, 1), "if_hz": float(self.cfg.IF_OFFSET_HZ),
            # Occupied bandwidth of our own signal: chip rate x (1 + rolloff).
            "bw_hz": float(self.cfg.CHIP_RATE_HZ * (1.0 + self.cfg.RRC_ROLLOFF)),
        }

    def _inbox(self) -> list:
        base = self._inbox_dir()
        if not base.is_dir():
            return []
        out = []
        for p in sorted(base.iterdir(), key=lambda q: -q.stat().st_mtime)[:30]:
            if p.is_file():
                st = p.stat()
                out.append({"name": p.name, "size": st.st_size,
                            "when": time.strftime("%H:%M:%S",
                                                  time.localtime(st.st_mtime))})
        return out

    def _inbox_dir(self) -> Path:
        base = Path(getattr(self.cfg, "FILE_INBOX", "inbox")).expanduser()
        if not base.is_absolute():
            base = Path(__file__).resolve().parent.parent / base
        return base

    def inbox_file(self, name: str):
        """Read one received file.  Refuses anything outside the inbox."""
        safe = os.path.basename(unquote(name or ""))
        if not safe:
            raise ValueError("no file named")
        p = (self._inbox_dir() / safe).resolve()
        if p.parent != self._inbox_dir().resolve() or not p.is_file():
            raise ValueError("not in the inbox")
        return p.read_bytes(), p.name

    def browse(self, path: str) -> dict:
        """List a directory on the machine running the link, for the picker."""
        try:
            p = Path(path).expanduser() if path else Path.home()
            p = p.resolve()
            if not p.is_dir():
                p = p.parent
            entries = []
            for e in sorted(p.iterdir(), key=lambda q: (not q.is_dir(), q.name.lower())):
                if e.name.startswith("."):
                    continue
                try:
                    isdir = e.is_dir()
                    entries.append({"name": e.name, "path": str(e), "dir": isdir,
                                    "size": 0 if isdir else e.stat().st_size})
                except OSError:
                    continue
                if len(entries) >= 400:
                    break
            return {"path": str(p), "parent": str(p.parent), "entries": entries}
        except Exception as e:
            return {"error": str(e)}

    def snapshot(self, since: int = 0) -> dict:
        link, cfg = self.link, self.cfg
        m = link.metrics()
        d = {
            "node": cfg.NODE_ID, "freq": cfg.CENTER_FREQ_HZ,
            "sf": cfg.SPREADING_FACTOR, "symbol_rate": cfg.SYMBOL_RATE_HZ,
            "proc_gain_db": cfg.PROCESSING_GAIN_DB,
            "state": m.get("state", "?"), "queue": m.get("queue", 0),
            "has_frame": link.last_frame is not None,
        }
        for k, dflt in (("snr_chip_db", 0.0), ("snr_sym_db", 0.0), ("evm_pct", 0.0),
                        ("mer_db", 0.0), ("acq_psr", 0.0), ("sync_psr", 0.0),
                        ("cfo_hz", 0.0), ("residual_cfo_hz", 0.0),
                        ("timing_err", 0.0), ("rs_corrections", 0),
                        ("viterbi_margin", 0.0), ("rx_rms", 0.0),
                        ("tx_frames", 0), ("tx_bytes", 0), ("rx_frames", 0),
                        ("rx_bytes", 0), ("retries", 0), ("deferred", 0),
                        ("late_acks", 0), ("lost", 0), ("rtt", 0.0),
                        ("ack_timeout", 0.0), ("goodput", 0.0),
                        ("acquisitions", 0), ("false_acq", 0),
                        ("header_fail", 0), ("payload_fail", 0),
                        ("deaf_pct", 0.0), ("buffer_aborts", 0),
                        ("stream_tx", 0), ("stream_rx", 0)):
            v = m.get(k, dflt)
            d[k] = dflt if v is None else v

        c = link.constellation
        if c is not None and len(c):
            step = max(1, len(c) // 1500)
            cc = c[::step]
            flat = np.empty(2 * len(cc), dtype=np.float32)
            flat[0::2] = np.real(cc)
            flat[1::2] = np.imag(cc)
            d["constellation"] = [round(float(v), 3) for v in flat]
        else:
            d["constellation"] = []

        d["spectrum"] = self._spectrum()
        d["acq_profile"] = getattr(link.rx.acq, "last_profile", None)
        d["transfers"] = m.get("transfers", [])
        d["transfer_history"] = m.get("transfer_history", [])
        d["inbox"] = self._inbox()
        d["cfg"] = {k: getattr(cfg, k) for k in self.SHOW_CFG if hasattr(cfg, k)}

        out = []
        for i, e in enumerate(list(link.events), start=1):
            if i <= since:
                continue
            out.append({"i": i, "kind": e.kind,
                        "t": time.strftime("%H:%M:%S", time.localtime(e.t)),
                        "text": e.text[:300]})
        d["log"] = out[-200:]
        return d

    # ----------------------------------------------------------------- serve
    def start(self):
        self.httpd = ThreadingHTTPServer((self.host, self.port), _Handler)
        self.httpd.dash = self
        self.httpd.daemon_threads = True
        self._thread = threading.Thread(target=self.httpd.serve_forever,
                                        kwargs={"poll_interval": 0.2}, daemon=True)
        self._thread.start()
        return self.url

    @property
    def url(self) -> str:
        return f"http://{self.host}:{self.port}"

    def stop(self):
        if self.httpd:
            try:
                self.httpd.shutdown()
                self.httpd.server_close()
            except Exception:
                pass
