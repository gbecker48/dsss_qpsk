"""
codec.py -- the FEC chain, shared by the transmitter and the receiver.

Transmit direction (bytes -> coded bits):
    header  : 8 bytes -> conv code -> repeat HEADER_REPEAT times
    payload : msg -> +CRC32 -> Reed-Solomon -> conv code -> interleaver

Receive direction (soft LLRs -> bytes):
    header  : fold the repeats (LLRs simply add -- that is the optimal way to
              combine repetitions) -> soft Viterbi -> header CRC16
    payload : deinterleave -> soft Viterbi -> Reed-Solomon -> CRC32

Everything here is length-deterministic: given the payload length from the
header, the receiver computes exactly the same block sizes and bit counts the
transmitter used, so nothing extra has to be signalled.
"""

from __future__ import annotations

import numpy as np

from . import conv, crc, interleave, rs
from .framing import HEADER_BYTES, bits_to_bytes, bytes_to_bits


class Codec:
    def __init__(self, cfg):
        self.cfg = cfg
        self.cc = conv.ConvCode(cfg.CC_K, cfg.CC_POLYS, cfg.CC_PUNCTURE) if cfg.USE_CC else None
        self.rs = rs.ReedSolomon(cfg.RS_N, cfg.RS_K) if cfg.USE_RS else None
        self.ilv = cfg.INTERLEAVER_DEPTH if cfg.USE_INTERLEAVER else 1

    # ------------------------------------------------------------------ sizes
    def payload_coded_bits(self, payload_len: int) -> int:
        n = payload_len + 4                              # CRC32
        if self.rs is not None:
            n = self.rs.encoded_len(n)
        bits = n * 8
        if self.cc is not None:
            bits = self.cc.coded_len(bits)
        return bits

    def payload_symbols(self, payload_len: int) -> int:
        # QPSK: 2 bits/symbol, rounded up (a stray bit is padded with a 0).
        return int(np.ceil(self.payload_coded_bits(payload_len) / 2))

    def header_coded_bits(self) -> int:
        bits = HEADER_BYTES * 8
        if self.cc is not None:
            bits = self.cc.coded_len(bits)
        return bits * self.cfg.HEADER_REPEAT

    def header_symbols(self) -> int:
        return int(np.ceil(self.header_coded_bits() / 2))

    # ----------------------------------------------------------------- encode
    def encode_header(self, header_bytes: bytes) -> np.ndarray:
        bits = bytes_to_bits(header_bytes)
        if self.cc is not None:
            bits = self.cc.encode(bits)
        return np.tile(bits, self.cfg.HEADER_REPEAT)

    def encode_payload(self, payload: bytes) -> np.ndarray:
        data = crc.append_crc32(payload)
        if self.rs is not None:
            data = self.rs.encode(data)
        bits = bytes_to_bits(data)
        if self.cc is not None:
            bits = self.cc.encode(bits)
        if self.ilv > 1:
            bits = interleave.interleave(bits, self.ilv)
        return bits

    # ----------------------------------------------------------------- decode
    def decode_header(self, llrs: np.ndarray):
        """LLRs for header_coded_bits() -> (header_bytes, viterbi_margin)."""
        rep = self.cfg.HEADER_REPEAT
        n = len(llrs) // rep
        # Maximum-ratio combining of the repeats is just a sum of LLRs.
        folded = llrs[:n * rep].reshape(rep, n).sum(axis=0)
        if self.cc is not None:
            bits, margin = self.cc.decode(folded, HEADER_BYTES * 8)
        else:
            bits, margin = (folded < 0).astype(np.uint8), 0.0
        return bits_to_bytes(bits[:HEADER_BYTES * 8]), margin

    def decode_payload(self, llrs: np.ndarray, payload_len: int):
        """Returns (payload_bytes or None, stats dict)."""
        stats = {"viterbi_margin": 0.0, "rs_corrections": -1,
                 "rs_ok": False, "crc_ok": False}
        bits = llrs
        if self.ilv > 1:
            bits = interleave.deinterleave(bits, self.ilv)
        if self.cc is not None:
            n_info = self._info_bits(payload_len)
            dec, margin = self.cc.decode(bits, n_info)
            stats["viterbi_margin"] = float(margin)
        else:
            dec = (bits < 0).astype(np.uint8)
        data = bits_to_bytes(dec)

        if self.rs is not None:
            n_pre_rs = payload_len + 4
            out, ncorr = self.rs.decode(data, n_pre_rs)
            stats["rs_corrections"] = ncorr
            if out is None:
                return None, stats
            stats["rs_ok"] = True
            data = out
        else:
            data = data[:payload_len + 4]

        ok, body = crc.check_crc32(data)
        stats["crc_ok"] = bool(ok)
        return (body if ok else None), stats

    def _info_bits(self, payload_len: int) -> int:
        n = payload_len + 4
        if self.rs is not None:
            n = self.rs.encoded_len(n)
        return n * 8
