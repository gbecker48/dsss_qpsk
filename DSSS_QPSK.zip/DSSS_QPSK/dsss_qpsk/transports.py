"""
transports.py -- what the link layer plugs into.

Three of them:

  SimTransport    pure numpy, no GNU Radio, no radio.  Generates a continuous
                  noisy stream and injects your own bursts into it through the
                  channel model.  This is what `run_link.py --sim` uses, and it
                  is the fastest way to try a config change.

  GrLoopbackTransport   GNU Radio flowgraph with no hardware:
                  burst source -> channel model -> receiver sink.
                  Use it to confirm the GNU Radio blocks themselves are wired
                  correctly before you plug a radio in.

  UsrpTransport   GNU Radio flowgraph driving a real B206mini-i:
                  burst source -> usrp_sink      (tagged bursts, tx_sob/tx_eob)
                  usrp_source  -> receiver sink

All three expose the same tiny interface:
    t.rx_callback = fn      # called with numpy complex64 blocks
    t.transmit(samples)     # queue one burst
    t.start() / t.stop()
"""

from __future__ import annotations

import queue
import threading
import time

import numpy as np

from . import channel


class SimTransport:
    """Simulated radio: continuous noise with your own bursts folded back in."""

    def __init__(self, cfg, snr_db=None, cfo_hz=None, sfo_ppm=None,
                 delay=None, loop_latency_s=0.02, chunk=1 << 15, seed=0,
                 realtime=True):
        self.cfg = cfg
        self.rx_callback = None
        self.snr_db = cfg.SIM_SNR_DB if snr_db is None else snr_db
        self.cfo_hz = cfg.SIM_CFO_HZ if cfo_hz is None else cfo_hz
        self.sfo_ppm = cfg.SIM_SFO_PPM if sfo_ppm is None else sfo_ppm
        self.delay = cfg.SIM_DELAY_CHIPS if delay is None else delay
        self.chunk = int(chunk)
        self.realtime = realtime
        self.rng = np.random.default_rng(seed)
        self._lock = threading.Lock()
        self._future = np.zeros(0, dtype=np.complex128)   # samples still to come
        self._latency = int(loop_latency_s * cfg.SAMP_RATE_HZ)
        self._running = False
        self._thread = None
        # The receiver runs on its own thread, exactly like the GNU Radio sink
        # does, so a slow decode never stalls the sample stream and stretch the
        # wall clock the ARQ timers run on.
        self._rxq: "queue.Queue" = queue.Queue(maxsize=256)
        self._rxthread = None
        self.dropped = 0

        # Reference burst power, so SNR means what it says.
        from .framing import Header
        from .modulator import Modulator
        ref = Modulator(cfg).modulate(Header(payload_len=0), b"")
        self._p_sig = float(np.mean(np.abs(ref) ** 2))
        self._sigma2 = self._p_sig * cfg.SPS_CHIP / (10 ** (self.snr_db / 10.0))

    def set_snr(self, snr_db: float):
        self.snr_db = float(snr_db)
        self._sigma2 = self._p_sig * self.cfg.SPS_CHIP / (10 ** (self.snr_db / 10.0))

    def transmit(self, samples: np.ndarray):
        x = np.asarray(samples, dtype=np.complex128)
        # Channel: fractional delay + clock offset, then carrier offset/phase.
        y = channel.fractional_resample(
            np.concatenate([np.zeros(32), x, np.zeros(64)]),
            self.delay, self.sfo_ppm)
        n = np.arange(len(y))
        ph = self.rng.uniform(-np.pi, np.pi)
        y = y * np.exp(1j * (2 * np.pi * self.cfo_hz * n / self.cfg.SAMP_RATE_HZ + ph))
        with self._lock:
            need = self._latency + len(y)
            if len(self._future) < need:
                self._future = np.concatenate(
                    [self._future, np.zeros(need - len(self._future), dtype=np.complex128)])
            self._future[self._latency:self._latency + len(y)] += y

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._pump, daemon=True)
        self._rxthread = threading.Thread(target=self._rx_worker, daemon=True)
        self._thread.start()
        self._rxthread.start()

    def stop(self):
        self._running = False
        for t in (self._thread, self._rxthread):
            if t:
                t.join(timeout=1.0)

    def _rx_worker(self):
        while self._running:
            try:
                x = self._rxq.get(timeout=0.1)
            except queue.Empty:
                continue
            if self.rx_callback:
                self.rx_callback(x)

    def _pump(self):
        period = self.chunk / self.cfg.SAMP_RATE_HZ
        next_t = time.time()
        while self._running:
            n = self.chunk
            noise = np.sqrt(self._sigma2 / 2) * (
                self.rng.standard_normal(n) + 1j * self.rng.standard_normal(n))
            with self._lock:
                if len(self._future):
                    take = min(n, len(self._future))
                    noise[:take] += self._future[:take]
                    self._future = self._future[take:]
            try:
                self._rxq.put_nowait(noise.astype(np.complex64))
            except queue.Full:
                self.dropped += n
            if self.realtime:
                next_t += period
                dt = next_t - time.time()
                if dt > 0:
                    time.sleep(dt)
                else:
                    next_t = time.time()


# ============================================================ GNU Radio based
def _require_gr():
    try:
        from gnuradio import blocks, gr  # noqa: F401
    except ImportError as e:
        raise SystemExit(
            "GNU Radio could not be imported.\n"
            "  Windows/radioconda : open the 'GNU Radio Command Prompt', or run\n"
            "                       `conda activate radioconda` first.\n"
            "  Linux              : sudo apt install gnuradio\n"
            "You can still run everything in simulation:  python run_link.py --sim"
        ) from e


class GrLoopbackTransport:
    """GNU Radio flowgraph, no hardware: source -> channel model -> sink."""

    def __init__(self, cfg, snr_db=None, cfo_hz=None, seed=0):
        _require_gr()
        from gnuradio import analog, blocks, channels, gr

        from .blocks.gr_blocks import DsssBurstSource, DsssReceiverSink
        from .framing import Header
        from .modulator import Modulator

        self.cfg = cfg
        self.rx_callback = None
        snr_db = cfg.SIM_SNR_DB if snr_db is None else snr_db
        cfo_hz = cfg.SIM_CFO_HZ if cfo_hz is None else cfo_hz

        ref = Modulator(cfg).modulate(Header(payload_len=0), b"")
        p_sig = float(np.mean(np.abs(ref) ** 2))
        sigma = np.sqrt(p_sig * cfg.SPS_CHIP / (10 ** (snr_db / 10.0)))

        self.tb = gr.top_block("dsss_loopback")
        # idle_fill so samples flow (and therefore noise exists) between bursts,
        # and a throttle so the flowgraph runs at the real sample rate instead of
        # as fast as the CPU allows -- otherwise the ARQ timers are meaningless.
        self.src = DsssBurstSource(idle_fill=True)
        self.throttle = blocks.throttle(gr.sizeof_gr_complex, cfg.SAMP_RATE_HZ, True)
        self.chan = channels.channel_model(
            noise_voltage=float(sigma),
            frequency_offset=float(cfo_hz / cfg.SAMP_RATE_HZ),
            epsilon=1.0 + cfg.SIM_SFO_PPM * 1e-6,
            taps=[1.0 + 0.0j],
            noise_seed=seed,
            block_tags=False)
        self.sink = DsssReceiverSink(None, on_samples=self._on_samples)
        self.tb.connect(self.src, self.throttle, self.chan, self.sink)

    def _on_samples(self, x):
        if self.rx_callback:
            self.rx_callback(x)

    def transmit(self, samples):
        self.src.transmit(samples)

    def start(self):
        self.tb.start()

    def stop(self):
        self.tb.stop()
        self.tb.wait()


class UsrpTransport:
    """GNU Radio flowgraph driving a real USRP (B206mini-i and friends)."""

    def __init__(self, cfg):
        _require_gr()
        from gnuradio import gr, uhd

        from .blocks.gr_blocks import PACKET_LEN_TAG, DsssBurstSource, DsssReceiverSink

        self.cfg = cfg
        self.rx_callback = None
        self.tb = gr.top_block("dsss_qpsk_link")

        stream_args = uhd.stream_args(cpu_format="fc32", args="", channels=[0])

        # ---------------------------------------------------------- receive
        self.usrp_src = uhd.usrp_source(cfg.DEVICE_ARGS, stream_args)
        self.usrp_src.set_clock_source(cfg.CLOCK_SOURCE, 0)
        self.usrp_src.set_time_source(cfg.TIME_SOURCE, 0)
        self.usrp_src.set_samp_rate(cfg.SAMP_RATE_HZ)
        self.usrp_src.set_center_freq(uhd.tune_request(cfg.CENTER_FREQ_HZ), 0)
        self.usrp_src.set_gain(cfg.RX_GAIN_DB, 0)
        self.usrp_src.set_antenna(cfg.RX_ANTENNA, 0)
        if cfg.RX_BANDWIDTH_HZ:
            self.usrp_src.set_bandwidth(cfg.RX_BANDWIDTH_HZ, 0)

        # --------------------------------------------------------- transmit
        # The third argument is the length tag: uhd.usrp_sink turns each tagged
        # packet into one burst with tx_sob on the first sample and tx_eob on
        # the last, and transmits nothing in between.  That is exactly the
        # half-duplex burst behaviour we want, and it is why the transmitter
        # does not spew underrun 'U' characters between messages.
        self.usrp_sink = uhd.usrp_sink(cfg.DEVICE_ARGS, stream_args, PACKET_LEN_TAG)
        self.usrp_sink.set_samp_rate(cfg.SAMP_RATE_HZ)
        self.usrp_sink.set_center_freq(uhd.tune_request(cfg.CENTER_FREQ_HZ), 0)
        self.usrp_sink.set_gain(cfg.TX_GAIN_DB, 0)
        self.usrp_sink.set_antenna(cfg.TX_ANTENNA, 0)
        if cfg.TX_BANDWIDTH_HZ:
            self.usrp_sink.set_bandwidth(cfg.TX_BANDWIDTH_HZ, 0)

        self.src = DsssBurstSource()
        self.sink = DsssReceiverSink(None, on_samples=self._on_samples)
        self.tb.connect(self.src, self.usrp_sink)
        self.tb.connect(self.usrp_src, self.sink)

    def _on_samples(self, x):
        if self.rx_callback:
            self.rx_callback(x)

    def transmit(self, samples):
        self.src.transmit(samples)

    def start(self):
        self.tb.start()

    def stop(self):
        self.tb.stop()
        self.tb.wait()

    def describe(self) -> str:
        try:
            info = self.usrp_src.get_usrp_info()
            mb = info.get("mboard_id", "?")
            serial = info.get("mboard_serial", "?")
            return f"{mb} serial {serial}"
        except Exception:
            return "USRP"
