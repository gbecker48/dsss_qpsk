"""
app/terminal.py -- the operator console.

Two modes, both pure terminal (no curses, so it works unchanged in Windows
Terminal, cmd.exe under radioconda, PuTTY, and over ssh):

  FULL SCREEN (default)   live metrics, an ASCII constellation heat map, a
                          message log, and a command line, redrawn at
                          UI_REFRESH_HZ.
  SIMPLE (--simple)       plain line-by-line I/O.  Use it if your terminal does
                          not do ANSI escapes, or if you are piping the output
                          to a file.

Type a message and press Enter to send it.  Anything starting with '/' is a
command -- type /help.
"""

from __future__ import annotations

import os
import sys
import threading
import time
from collections import deque

import numpy as np

from .. import ui

IS_WINDOWS = os.name == "nt"


# ------------------------------------------------------------------ key input
class KeyReader:
    """Non-blocking single-character reader, portable."""

    def __init__(self):
        self.queue: deque[str] = deque()
        self._running = True
        self._old = None
        if IS_WINDOWS:
            self._thread = threading.Thread(target=self._win_loop, daemon=True)
        else:
            self._thread = threading.Thread(target=self._posix_loop, daemon=True)

    def start(self):
        if not IS_WINDOWS:
            import termios
            import tty
            try:
                self._old = termios.tcgetattr(sys.stdin.fileno())
                tty.setcbreak(sys.stdin.fileno())
            except Exception:
                self._old = None
        self._thread.start()

    def stop(self):
        self._running = False
        if not IS_WINDOWS and self._old is not None:
            import termios
            try:
                termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, self._old)
            except Exception:
                pass

    def _win_loop(self):
        import msvcrt
        while self._running:
            if msvcrt.kbhit():
                ch = msvcrt.getwch()
                if ch in ("\x00", "\xe0"):        # function/arrow key prefix
                    msvcrt.getwch()
                    continue
                self.queue.append(ch)
            else:
                time.sleep(0.01)

    def _posix_loop(self):
        import select
        while self._running:
            r, _, _ = select.select([sys.stdin], [], [], 0.1)
            if r:
                ch = sys.stdin.read(1)
                if ch:
                    self.queue.append(ch)

    def get(self):
        return self.queue.popleft() if self.queue else None


def enable_ansi():
    """Windows 10+ consoles need virtual terminal processing switched on."""
    if not IS_WINDOWS:
        return True
    try:
        import ctypes
        k = ctypes.windll.kernel32
        h = k.GetStdHandle(-11)
        mode = ctypes.c_uint32()
        if not k.GetConsoleMode(h, ctypes.byref(mode)):
            return False
        return bool(k.SetConsoleMode(h, mode.value | 0x0004))
    except Exception:
        return False


# --------------------------------------------------------------------- the app
HELP = """
  COMMANDS
    /help                  this text
    /quit  /q              exit
    /ping                  send an unacknowledged PING burst
    /send <n>              send n bytes of random test data
    /flood <count> <n>     queue <count> messages of n random bytes
    /file <path>           send a whole file over the link
    /files                 show transfers in progress and what has finished
    /inbox                 list files that have arrived, and where they landed
    /cancel <id>           stop an outgoing transfer (id comes from /files)
    /stats                 dump receiver statistics to the log
    /clear                 clear the message log
    /const [file.npy]      save the last constellation (default from config)
    /snr <dB>              simulation only: set the channel chip SNR
    /txgain <dB>           radio only: set transmit gain
    /rxgain <dB>           radio only: set receive gain
    /show [pattern]        show config values (e.g. /show COSTAS)
    /set NAME VALUE        change a config value live, e.g. /set SPREADING_FACTOR 63
                           (waveform knobs restart the modem; both ends must match)
    /config                print the full configuration summary
"""


class TerminalApp:
    def __init__(self, cfg, link, transport=None, simple=False):
        self.cfg = cfg
        self.link = link
        self.transport = transport
        self.simple = simple or not enable_ansi()
        self.input = ""
        self.log: deque[str] = deque(maxlen=2000)
        self.running = True
        self._seen_events = 0
        self._last_draw = 0.0

    # --------------------------------------------------------------- logging
    def say(self, text: str, tag: str = "  "):
        stamp = time.strftime("%H:%M:%S")
        for line in str(text).splitlines() or [""]:
            self.log.append(f"{stamp} {tag} {line}")
            if self.simple:
                print(f"{stamp} {tag} {line}", flush=True)

    def drain_events(self):
        ev = list(self.link.events)
        new = ev[self._seen_events:]
        self._seen_events = len(ev)
        for e in new:
            if e.kind == "rx":
                f = e.frame
                extra = ""
                if f is not None:
                    extra = (f"   [chipSNR {f.snr_chip_db:+.1f} dB  EVM {f.evm_pct:.1f}%"
                             f"  RS {max(f.rs_corrections,0)}]")
                self.say(f"{e.text}{extra}", "<<")
            elif e.kind == "tx":
                self.say(e.text, ">>")
            elif e.kind == "ack":
                self.say(e.text, "ok")
            elif e.kind == "timeout":
                self.say(e.text, "!!")
            elif e.kind == "error":
                self.say(e.text, "XX")
            else:
                self.say(e.text, "..")

    # -------------------------------------------------------------- commands
    def handle_line(self, line: str):
        line = line.strip()
        if not line:
            return
        if not line.startswith("/"):
            self.link.send_text(line)
            return
        parts = line.split()
        cmd, args = parts[0].lower(), parts[1:]

        if cmd in ("/quit", "/q", "/exit"):
            self.running = False
        elif cmd == "/help":
            self.say(HELP)
        elif cmd == "/ping":
            self.link.send_ping()
        elif cmd == "/send":
            n = int(args[0]) if args else 64
            n = min(n, self.cfg.MAX_PAYLOAD_BYTES)
            self.link.send(bytes(np.random.default_rng().integers(0, 256, n, dtype=np.uint8)))
            self.say(f"queued {n} random bytes")
        elif cmd == "/flood":
            count = int(args[0]) if args else 5
            n = int(args[1]) if len(args) > 1 else 64
            rng = np.random.default_rng()
            for _ in range(count):
                self.link.send(bytes(rng.integers(0, 256, n, dtype=np.uint8)))
            self.say(f"queued {count} x {n} bytes")
        elif cmd == "/file":
            if not args:
                self.say("usage: /file <path>      (tab completion is your shell's, "
                         "not ours -- paste the path)")
            else:
                path = " ".join(args)
                try:
                    p = self.link.send_file(path)
                    self.say(f"sending {p['name']}: {p['size']} B in {p['nseg']} "
                             f"segments  (transfer {p['xid']})")
                except Exception as e:
                    self.say(f"cannot send {path}: {e}", "XX")
        elif cmd == "/files":
            snap = self.link.files.snapshot()
            rows = snap["active"] + snap["history"]
            if not rows:
                self.say("no transfers")
            for t in rows:
                arrow = "->" if t["dir"] == "tx" else "<-"
                self.say(f"  [{t['xid']:3d}] {arrow} {t['name']:<28s} "
                         f"{t['seg_done']:5d}/{t['nseg']:<5d} seg  {t['pct']:5.1f}%  "
                         f"{t['rate']/1024:6.2f} kB/s  {t['state']}")
        elif cmd == "/inbox":
            import pathlib
            base = pathlib.Path(getattr(self.cfg, "FILE_INBOX", "inbox"))
            if not base.is_absolute():
                base = pathlib.Path(__file__).resolve().parents[2] / base
            files = sorted(base.glob("*")) if base.is_dir() else []
            if not files:
                self.say(f"nothing received yet (inbox is {base})")
            for f in files:
                self.say(f"  {f.stat().st_size:9d} B  {f}")
        elif cmd == "/cancel":
            if not args:
                self.say("usage: /cancel <id>      (see /files)")
            else:
                ok = self.link.cancel_transfer(int(args[0]))
                self.say("cancelled" if ok else "no such transfer")
        elif cmd == "/stats":
            self.say(str(self.link.rx.stats))
            self.say(f"tx_frames={self.link.tx_frames} rx_frames={self.link.rx_frames} "
                     f"retries={self.link.total_retries} lost={self.link.lost_messages}")
        elif cmd == "/clear":
            self.log.clear()
        elif cmd == "/const":
            path = args[0] if args else (self.cfg.CONSTELLATION_DUMP or "constellation.npy")
            c = self.link.constellation
            if c is None or not len(c):
                self.say("no constellation yet")
            else:
                np.save(path, c)
                self.say(f"saved {len(c)} symbols to {path}")
        elif cmd == "/snr":
            if self.transport is not None and hasattr(self.transport, "set_snr"):
                self.transport.set_snr(float(args[0]))
                self.say(f"simulated chip SNR set to {float(args[0]):.1f} dB")
            else:
                self.say("not in simulation mode")
        elif cmd in ("/txgain", "/rxgain"):
            self._set_gain(cmd, args)
        elif cmd == "/show":
            self._show(args[0].upper() if args else "")
        elif cmd == "/set":
            self._set(args)
        elif cmd == "/config":
            self.say(self.cfg.summary())
        else:
            self.say(f"unknown command {cmd} -- try /help")

    def _set_gain(self, cmd, args):
        t = self.transport
        if t is None or not hasattr(t, "usrp_sink"):
            self.say("no radio attached")
            return
        try:
            v = float(args[0])
        except (IndexError, ValueError):
            self.say("usage: /txgain <dB>")
            return
        if cmd == "/txgain":
            t.usrp_sink.set_gain(v, 0)
            self.cfg.TX_GAIN_DB = v
        else:
            t.usrp_src.set_gain(v, 0)
            self.cfg.RX_GAIN_DB = v
        self.say(f"{cmd[1:]} = {v:.1f} dB")

    def _show(self, pattern: str):
        rows = []
        for k in sorted(dir(self.cfg)):
            if not k.isupper():
                continue
            if pattern and pattern not in k:
                continue
            v = getattr(self.cfg, k)
            if isinstance(v, (int, float, str, bool, tuple, list, type(None))):
                rows.append(f"    {k:28s} = {v}")
        self.say("\n".join(rows) if rows else f"nothing matches {pattern!r}")

    def _set(self, args):
        if len(args) < 2:
            self.say("usage: /set NAME VALUE      (see /show)")
            return
        name = args[0].upper()
        if not hasattr(self.cfg, name):
            self.say(f"no such config value: {name}")
            return
        raw = " ".join(args[1:])
        try:
            value = eval(raw, {"__builtins__": {}}, {"True": True, "False": False,
                                                     "None": None})
        except Exception:
            value = raw
        old = getattr(self.cfg, name)
        try:
            setattr(self.cfg, name, value)
            self.cfg.recompute()
        except Exception as e:
            setattr(self.cfg, name, old)
            self.cfg.recompute()
            self.say(f"rejected: {e!r}")
            return
        self.say(f"{name}: {old} -> {value}")
        if name in self.cfg.WAVEFORM_KNOBS:
            self.say("waveform knob changed -- rebuilding modem "
                     "(the OTHER end must be changed to match!)", "!!")
            try:
                self.link.reconfigure()
            except Exception as e:
                self.say(f"rebuild failed, reverting: {e!r}", "XX")
                setattr(self.cfg, name, old)
                self.cfg.recompute()
                self.link.reconfigure()

    # ----------------------------------------------------------------- render
    def _frame_text(self, w: int, h: int) -> str:
        m = self.link.metrics()
        m["state"] = self.link.rx.state
        metrics = ui.fmt_metrics(m, width=min(w, 96))
        const_w, const_h = self.cfg.CONSTELLATION_SIZE
        side_by_side = w >= const_w + 46

        head = (f" DSSS/QPSK LINK  node {self.cfg.NODE_ID}  "
                f"{self.cfg.CENTER_FREQ_HZ/1e6:.3f} MHz  "
                f"SF={self.cfg.SPREADING_FACTOR} (+{self.cfg.PROCESSING_GAIN_DB:.1f} dB)  "
                f"{self.cfg.SYMBOL_RATE_HZ/1e3:.1f} kBd  "
                f"queue {m.get('queue',0)}")
        lines = [head[:w].ljust(w)]

        body_h = max(4, h - len(metrics) - 4)
        const = ui.ascii_constellation(self.link.constellation,
                                       self.cfg.CONSTELLATION_SIZE,
                                       title="CONSTELLATION").splitlines()

        if side_by_side:
            log_w = w - const_w - 2
            logs = list(self.log)[-body_h:]
            logs = [""] * (body_h - len(logs)) + logs
            const = const[:body_h] + [""] * max(0, body_h - len(const))
            for i in range(body_h):
                left = logs[i][:log_w].ljust(log_w)
                right = const[i][:const_w].ljust(const_w)
                lines.append(f"{left}| {right}"[:w])
        else:
            logs = list(self.log)[-body_h:]
            logs = [""] * (body_h - len(logs)) + logs
            for l in logs:
                lines.append(l[:w].ljust(w))

        for l in metrics:
            lines.append(l[:w].ljust(w))
        lines.append("-" * w)
        prompt = f"> {self.input}"
        lines.append(prompt[-w:].ljust(w))
        return "\n".join(lines)

    def draw(self):
        try:
            w, h = os.get_terminal_size()
        except OSError:
            w, h = 100, 40
        w = max(60, min(w, 200))
        h = max(24, min(h, 70))
        txt = self._frame_text(w, h)
        sys.stdout.write("\x1b[H\x1b[2J" + txt)
        sys.stdout.flush()

    # ------------------------------------------------------------------- loop
    def run(self):
        keys = KeyReader()
        keys.start()
        if not self.simple:
            sys.stdout.write("\x1b[2J\x1b[?25l")     # clear, hide cursor
        self.say("type a message and press Enter to send it; /help for commands")
        period = 1.0 / max(1.0, self.cfg.UI_REFRESH_HZ)
        try:
            while self.running:
                ch = keys.get()
                while ch is not None:
                    if ch in ("\r", "\n"):
                        line, self.input = self.input, ""
                        if self.simple:
                            print()
                        self.handle_line(line)
                    elif ch in ("\x7f", "\b"):
                        self.input = self.input[:-1]
                    elif ch == "\x03":               # Ctrl-C
                        self.running = False
                    elif ch == "\x15":               # Ctrl-U
                        self.input = ""
                    elif ch.isprintable():
                        self.input += ch
                    ch = keys.get()

                self.drain_events()
                now = time.time()
                if not self.simple and now - self._last_draw >= period:
                    self.draw()
                    self._last_draw = now
                time.sleep(0.01)
        except KeyboardInterrupt:
            pass
        finally:
            keys.stop()
            if not self.simple:
                sys.stdout.write("\x1b[?25h\n")
                sys.stdout.flush()
