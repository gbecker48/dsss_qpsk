"""
================================================================================
 config.py  --  THE ONE PLACE YOU CHANGE THINGS
================================================================================

 Everything that defines the waveform, the framing, the receiver loops and the
 radio lives in this file.  Both ends of the link MUST use identical values for
 anything marked  [WAVEFORM]  -- those are baked into the over-the-air signal.
 Anything marked  [RX-ONLY]  or  [LOCAL]  can differ between the two radios.

 Quick orientation -- the signal chain this config describes:

   TX:  text -> CRC32 -> Reed-Solomon(255,223) -> convolutional K=7 r=1/2
        -> bit interleaver -> Gray QPSK -> x PN code (DSSS spreading)
        -> RRC pulse shape -> digital IF shift -> burst ramp -> USRP

   RX:  USRP -> DC block -> digital IF de-shift -> RRC matched filter
        -> ACQUISITION (despread-then-FFT search over delay x Doppler)
        -> coarse CFO correct -> despread + early/late DLL (chip timing)
        -> sync-word correlation (frame start + phase ambiguity + fine CFO)
        -> decision-directed Costas loop (carrier phase)
        -> soft LLRs -> deinterleave -> soft Viterbi -> RS decode -> CRC32

 HOW TO READ THE KNOBS
   Every knob below has:   what it does / what happens if you raise it /
   what happens if you lower it / safe range.
   Derived values are computed at the bottom -- do not edit those, edit the
   knobs they come from.

================================================================================
"""

import numpy as np

# ==============================================================================
# SECTION 1 -- RADIO / RF FRONT END                                   [LOCAL]
# ==============================================================================
# These do not have to match between the two ends except CENTER_FREQ_HZ and
# SAMP_RATE_HZ (those obviously do).

# USRP device arguments.  Examples:
#   ""                            -> first USRP found (fine for one radio)
#   "serial=31ABC12"              -> pick a specific B206mini-i
#   "type=b200"                   -> any B2xx
#   "type=b200,num_recv_frames=512,num_send_frames=512"  -> bigger USB buffers
# NOTE for the B206mini-i: it is a B200-family device, so "type=b200" is right.
DEVICE_ARGS = ""

# Center (LO) frequency in Hz.  915 MHz ISM.
#   Raise/lower: must be inside the B206mini-i tuning range (70 MHz - 6 GHz).
#   For CABLE / attenuator loopback testing anything in range is fine.
#   For OVER THE AIR keep it in a band you are licensed / permitted to use and
#   keep TX_GAIN_DB low.
CENTER_FREQ_HZ = 915e6

# Complex sample rate into/out of the USRP, in samples/second.
#   This sets the chip rate:  CHIP_RATE = SAMP_RATE / SPS_CHIP.
#   Raise: more bandwidth, more processing gain available per second, more USB
#          throughput (B200 over USB3 handles 2-30 Msps fine; USB2 ~8 Msps max).
#   Lower: narrower, more sensitive (less noise power in band), less CPU.
#   Safe range for this code: 1e6 .. 10e6.  Keep it an integer multiple of
#   CHIP_RATE * SPS_CHIP.
SAMP_RATE_HZ = 2e6

# Transmit gain in dB (B206mini-i range is roughly 0..89.8 dB).
#   CABLE LOOPBACK with a 30-40 dB attenuator: start at 40-50.
#   DIRECT SMA CABLE WITH NO ATTENUATOR: start at 0-10 and DO NOT exceed ~20;
#          you can damage the RX front end.  Always use attenuation.
#   OVER THE AIR short range: 50-70.
TX_GAIN_DB = 50.0

# Receive gain in dB (0..76 dB on B2xx).
#   Too high -> front-end compression, spurs, and a fuzzy constellation.
#   Too low  -> quantization noise dominates.
#   Good practice: raise until the reported RX_RMS in the UI is ~0.03-0.15,
#   then stop.  The UI prints a warning outside that window.
RX_GAIN_DB = 40.0

# Analog front-end filter bandwidth in Hz.  None -> UHD picks (usually = rate).
#   Setting it to ~1.2 x the occupied bandwidth improves out-of-band rejection,
#   which matters when you are trying to receive below the noise floor.
RX_BANDWIDTH_HZ = None      # e.g. 1.5e6
TX_BANDWIDTH_HZ = None

# Antenna ports on the B206mini-i.
#   Single-radio LOOPBACK on a B2xx:  TX/RX port transmits, RX2 port receives.
#   Connect TX/RX --[30-40 dB attenuator]--> RX2.
TX_ANTENNA = "TX/RX"
RX_ANTENNA = "RX2"

# Clock / time source: "internal", "external", "gpsdo".
CLOCK_SOURCE = "internal"
TIME_SOURCE = "internal"

# --- Digital IF offset -------------------------------------------------------
# [WAVEFORM] (must match on both ends -- actually it only needs to match if you
# want interop; the RX de-rotates by exactly this amount.)
#
# WHY THIS EXISTS, AND WHY IT MATTERS A LOT FOR A CLEAN CONSTELLATION:
# A direct-conversion radio like the B2xx has LO leakage and a DC offset that
# land exactly at 0 Hz baseband.  If your signal sits on DC, that spur lands in
# the middle of your spectrum and smears the constellation.  We therefore
# generate the signal at +IF_OFFSET_HZ in software, and the receiver shifts it
# back down.  The DC spur then sits harmlessly at the edge of the band and is
# removed by the DC blocker and the matched filter.
#
#   Raise: moves the spur further away, but the signal must stay inside the
#          front-end bandwidth:  |IF_OFFSET| + occupied_BW/2 < SAMP_RATE/2.
#   Lower: 0 disables it (you will see a dot of energy at the constellation
#          origin and a dirtier EVM on real hardware).
#   Good default: about 1/8 of the sample rate.
IF_OFFSET_HZ = 250e3

# ==============================================================================
# SECTION 2 -- DSSS / MODULATION                                   [WAVEFORM]
# ==============================================================================

# Samples per chip out of the modulator.  2 is the standard choice: it is the
# minimum for a fractionally-spaced matched filter + early/late timing loop.
#   Raise to 4: better fractional-delay resolution and a slightly tighter
#        constellation on hardware, at 2x the sample rate for the same chip
#        rate.  The code handles any even value >= 2.
#   Lower: 1 is NOT supported (the early/late DLL needs >= 2).
SPS_CHIP = 2

# Spreading factor: number of PN chips per QPSK symbol.
#   This is the single most important knob for working below the noise floor.
#   Processing gain = 10*log10(SPREADING_FACTOR) dB.
#        31  -> 14.9 dB   (default; symbol rate 32.3 kBd at 2 Msps)
#        63  -> 18.0 dB
#       127  -> 21.0 dB
#       255  -> 24.1 dB   (very robust, very slow)
#   Raise: deeper below the noise floor, tighter dots for the same input SNR,
#          proportionally lower data rate, proportionally longer frames.
#   Lower: faster, less robust.
#   MUST be one of the lengths PN_KIND can produce (see pn.py):
#     'mls'  -> 2^m - 1  : 15, 31, 63, 127, 255, 511, 1023
#     'gold' -> 2^m - 1  : same lengths, better cross-correlation between users
SPREADING_FACTOR = 31

# Which family of spreading code to use, and which member.
#   'mls'  : maximal-length shift register sequence.  Best autocorrelation
#            (single peak of N, sidelobes of exactly -1).  Use this for a
#            single link -- it gives the cleanest acquisition peak.
#   'gold' : Gold code.  Slightly worse autocorrelation but a whole family of
#            codes with bounded cross-correlation -> use if you ever want
#            several links sharing the band (CDMA) or a TX/RX code pair.
PN_KIND = "mls"
PN_INDEX = 0            # which member of the family (0..N for gold, ignored for mls)

# Use DIFFERENT spreading codes for the two directions?
#   False -> both directions use PN_INDEX (simplest; correct for half duplex).
#   True  -> node A transmits with PN_INDEX, node B with PN_INDEX_REVERSE.
#            Useful if you ever go full duplex or want to reject your own echo.
USE_SEPARATE_CODES = False
PN_INDEX_REVERSE = 1

# Root-raised-cosine pulse shaping applied at the CHIP rate.
#   Rolloff: 0.35 is a good default.
#     Raise (-> 0.5): wider spectrum, shorter time response, more tolerant of
#          timing error -> slightly easier sync, slightly worse adjacent-channel.
#     Lower (-> 0.2): narrower spectrum, longer ringing, more sensitive to
#          timing error.
RRC_ROLLOFF = 0.35
# Filter span in chips (total length = RRC_SPAN_CHIPS * SPS_CHIP + 1).
#   Raise: closer to ideal RRC, better ISI, more CPU and more group delay.
#   Lower: cheaper, more ISI.  Do not go below 6.
RRC_SPAN_CHIPS = 12

# ==============================================================================
# SECTION 3 -- FRAME STRUCTURE                                     [WAVEFORM]
# ==============================================================================
#
#  A burst on the air looks like this:
#
#  |<-RAMP->|<------- PREAMBLE ------->|<-SYNC->|<-HEADER->|<--- PAYLOAD --->|<-RAMP->|
#             N_PREAMBLE_PERIODS x PN    SYNC_LEN   fixed      variable
#             (unmodulated, all +1)      symbols    symbols    symbols
#
#  The PREAMBLE is what lets us find the signal *below the noise floor*: it is
#  the raw PN code repeated with no data on it, so the receiver can coherently
#  integrate over the whole thing (despread -> FFT) and pull ~36 dB of gain out
#  of the noise before it knows anything about timing or frequency.
#
#  The SYNC word is a known QPSK sequence.  It marks the exact frame start,
#  resolves the 90-degree QPSK phase ambiguity, gives a data-aided fine
#  frequency estimate and a noise-variance estimate for the LLR scaling.

# Number of PN periods in the acquisition preamble.
#   Acquisition coherent gain = 10*log10(SPREADING_FACTOR * N_ACQ_PERIODS) dB,
#   where N_ACQ_PERIODS = N_PREAMBLE_PERIODS // 2 (see RX section for why).
#     128 -> 31*64  = 1984  -> 33.0 dB
#     256 -> 31*128 = 3968  -> 36.0 dB   (default)
#     512 -> 31*256 = 7936  -> 39.0 dB
#   Raise: acquires deeper below the noise floor, finer frequency resolution,
#          BUT the unambiguous frequency search range does not change, the
#          preamble takes longer to send, and a large frequency offset will
#          start to de-cohere the integration (see FREQ_SEARCH_* below).
#   Lower: shorter bursts, less sensitivity.
#   Must be EVEN.
N_PREAMBLE_PERIODS = 256

# Length of the sync word in QPSK symbols.
#   Raise: more reliable frame detection and a better fine-CFO / noise estimate,
#          at the cost of a few more symbols of overhead.
#   Lower: below 32 the phase-ambiguity resolution starts to make mistakes at
#          very low SNR.
SYNC_LEN = 64

# Seed for the deterministic sync-word generator.  Both ends must match.
# Change it if you want a "private" sync word so a second link on the same
# frequency does not false-trigger on yours.
SYNC_SEED = 0xC0FFEE

# Header: 8 bytes, see framing.py for the exact layout.
# Repetition of the (already convolutionally coded) header bits.
#   Raise to 3-4: the header survives even when the payload does not, which is
#        the failure mode you want (you learn a frame arrived and was too weak).
#   Lower to 1: saves symbols, header becomes the weakest link.
HEADER_REPEAT = 2

# Maximum payload bytes in one frame (before CRC/FEC).
#   Raise: more efficient for long messages, longer bursts, bigger RX buffer.
#   Lower: shorter bursts, faster ARQ turnaround.
#   Hard cap is 65535 because payload_len is a 16-bit header field, but the RX
#   buffer sizing below assumes this value -- keep it sane.
MAX_PAYLOAD_BYTES = 512

# Burst amplitude ramp, in chips.  Prevents spectral splatter at burst edges
# (a hard on/off keyed burst has infinite bandwidth).
#   Raise: cleaner spectrum, slightly longer burst.
#   Lower: 0 disables ramping -- you will see splatter on a spectrum analyzer.
RAMP_CHIPS = 16

# Peak amplitude of the transmitted baseband signal (before the USRP).
#   Keep <= 0.7 so the DAC and the RRC overshoot do not clip.  Clipping is a
#   top cause of a smeared constellation on real hardware.
TX_AMPLITUDE = 0.35

# ==============================================================================
# SECTION 4 -- FORWARD ERROR CORRECTION                            [WAVEFORM]
# ==============================================================================
#
#  Concatenated CCSDS-style code:
#     payload+CRC32  --RS(255,223)-->  --CC K=7 r=1/2-->  --interleave-->  QPSK
#  The inner convolutional code with SOFT decisions gives ~5 dB of coding gain
#  and turns random bit errors into occasional short bursts.  The outer
#  Reed-Solomon code eats those bursts (up to 16 wrong bytes per 255-byte
#  codeword), buying another ~2 dB and, more importantly, making the failure
#  cliff very sharp instead of a long tail of almost-good frames.

# --- Outer code: Reed-Solomon over GF(256) -----------------------------------
USE_RS = True                 # False -> convolutional code only (~2 dB worse)
RS_N = 255                    # codeword length in bytes (fixed by GF(256))
RS_K = 223                    # data bytes per codeword -> corrects 16 bytes
#   Lower RS_K (e.g. 191 -> corrects 32 bytes): stronger, more overhead.
#   Raise RS_K (e.g. 239 -> corrects 8 bytes):  weaker, less overhead.

# --- Inner code: convolutional, soft-decision Viterbi ------------------------
USE_CC = True                 # False -> uncoded (you will lose ~5 dB)
# Constraint length and generator polynomials, in OCTAL, MSB-first.
#   (7, [0o171, 0o133]) is the industry-standard rate-1/2 K=7 code.
#   (7, [0o171, 0o133, 0o165]) makes it rate 1/3: ~0.5 dB better, 50% more
#   symbols.  The code below supports any K<=9 and any number of polynomials.
CC_K = 7
CC_POLYS = [0o171, 0o133]
# Puncturing pattern, or None for no puncturing.
#   None            -> rate 1/2 (default)
#   [[1,1],[1,0]]   -> rate 2/3 (faster, ~1 dB worse)
#   [[1,1,1],[1,0,0]] -> rate 3/4
CC_PUNCTURE = None

# --- Interleaver -------------------------------------------------------------
# Block interleaver applied to the CODED bits, right before QPSK mapping.
# It spreads a burst of channel errors (a fade, an interferer, a timing slip)
# across the Viterbi trellis so the decoder sees them as isolated errors.
USE_INTERLEAVER = True
# Interleaver depth = the SEPARATION, in coded bits, between two bits that were
# adjacent on the air.  A burst of N consecutive channel errors therefore
# arrives at the Viterbi decoder as N isolated errors spaced INTERLEAVER_DEPTH
# apart.
#   Raise (128): better burst protection, slightly more latency.
#   Lower (16):  less protection; below ~40 the errors start landing inside one
#        Viterbi traceback window and stop looking isolated.
#   Should be comfortably larger than 5*CC_K (the decoder memory) -- 64 is good.
INTERLEAVER_DEPTH = 64

# ==============================================================================
# SECTION 5 -- RECEIVER: ACQUISITION                                 [RX-ONLY]
# ==============================================================================

# Detection threshold for the acquisition correlator, expressed as the ratio of
# the peak power to the *median* power of the whole delay-Doppler search grid.
# (Median, not mean, so a strong peak does not raise its own threshold.)
#   Typical values with the default waveform:
#       no signal present   -> peak/median around 8-15
#       signal at -15 dB    -> peak/median in the hundreds
#   Raise (e.g. 60): fewer false alarms, may miss the weakest signals.
#   Lower (e.g. 20): catches weaker signals, more false acquisitions (which are
#        harmless -- they fail the sync-word check a few ms later -- but they
#        cost CPU).
ACQ_THRESHOLD_PSR = 30.0

# Fraction of the preamble used for the coherent acquisition integration.
# The receiver searches in overlapping windows; using the second half of each
# window guarantees the integration lands entirely inside a preamble no matter
# where the burst starts.  Do not change unless you understand acquisition.py.
ACQ_FRACTION = 0.5

# Limit the Doppler search to +/- this many Hz (None -> search the full
# unambiguous range, which is +/- chip_rate / (2*SPREADING_FACTOR) ).
#   With the default waveform the full range is +/- 16.1 kHz, which is +/- 17.6
#   ppm at 915 MHz -- far more than the +/- 2 ppm a B2xx TCXO will ever drift.
#   Narrowing it to, say, 5000 Hz makes false alarms less likely and speeds up
#   the search.  Set to None to search everything.
FREQ_SEARCH_LIMIT_HZ = 6000.0

# Sync-word detection threshold, as the ratio of the sync correlation peak to
# the median of the correlation away from the peak.
#   This is the SECOND gate: a false acquisition that gets past ACQ_THRESHOLD_PSR
#   almost never produces a sync-word peak, so this is what actually keeps false
#   frames out of the decoder.
#   Raise (10): fewer false frames, may drop the very weakest bursts.
#   Lower (4):  more sensitive, more wasted header decodes.
SYNC_THRESHOLD_RATIO = 6.0

# Zero-padding factor for the acquisition FFT.  1 = no padding.
#   Raise to 2: the frequency grid is twice as fine, so the coarse CFO estimate
#   is better and less energy is lost between bins (scalloping).  Cheap.
ACQ_FFT_OVERSAMPLE = 2

# ==============================================================================
# SECTION 6 -- RECEIVER: TRACKING LOOPS                              [RX-ONLY]
# ==============================================================================
# All loop bandwidths are given as a FRACTION OF THE SYMBOL RATE.  That makes
# them independent of SPREADING_FACTOR and SAMP_RATE -- change those and the
# loops stay sensibly tuned.

# --- Chip timing: early/late delay-locked loop (DLL) -------------------------
# Operates on the despread correlation peak: it compares the energy half a chip
# early against half a chip late and steers a fractional-delay interpolator.
DLL_ENABLE = True
# Normalized loop bandwidth.
#   Raise (1e-2): tracks a bad sample-clock offset between two radios quickly,
#        but lets more noise into the timing estimate -> fuzzier dots.
#   Lower (1e-4): very clean timing, slow to pull in.  Because acquisition
#        already gives sub-sample timing, LOW IS GOOD here.
DLL_LOOP_BW = 1e-3
DLL_DAMPING = 1.0
# Fractional-delay interpolator used to read chips at the tracked instants.
#   4  -> cubic Lagrange.  Cheapest, but its amplitude response droops near the
#         band edge; costs about 8 dB of MER on this waveform.
#   8  -> 8-tap windowed sinc.  The default: flat across the band, and the extra
#         cost is four more multiply-accumulates per chip.
#   12 / 16 -> diminishing returns, measurably slower.
TRACKER_INTERP_TAPS = 8

# How many symbols the tracker processes per vectorised block.
#   The two feedback loops still update on EVERY symbol; only the sampling
#   instants and the intra-symbol carrier rotation are predicted across a block
#   and re-anchored exactly at its end.  Over 32 symbols (1 ms) a locked loop
#   moves by far less than the noise, and the measured constellation is
#   bit-identical to strict per-symbol processing.
#   MEASURED decode speed (200-byte frame, relative to real time):
#       1 -> 0.56x   8 -> 1.07x   32 -> 1.49x   64 -> 1.49x
#   Below 1.0x the receiver is slower than the radio and will eventually drop
#   samples, so do not set this to 1 on hardware unless you also slow the link
#   down.  Set it to 1 if you want to prove to yourself the blocking is exact.
TRACKER_BLOCK_SYMBOLS = 32

# Early/late spacing in chips.  0.5 is standard.  Narrower (0.25) gives a
# steeper discriminator (less jitter) but a smaller pull-in range.
DLL_EL_SPACING = 0.5

# --- Carrier phase: decision-directed Costas loop ----------------------------
# Runs on the DESPREAD symbols, so it sees the full processing gain -- this is
# why the constellation can be tight even when the signal is below the noise
# floor at the antenna.
COSTAS_ENABLE = True
# Normalized loop bandwidth.
#   Raise (5e-2): tracks fast phase noise / big residual CFO, noisier phase
#        estimate -> the dots smear tangentially (a "banana" shape).
#   Lower (2e-3): very tight dots, but if the residual frequency error is large
#        the loop will not hold and you get a slowly rotating constellation.
#   The preamble-aided fine-CFO estimate leaves only ~2 Hz, so a low bandwidth
#   is safe and gives the tightest dots.  If you see the constellation rotating,
#   raise this first; if the dots smear tangentially, lower it.
#   MEASURED on the simulated link at -14 dB chip SNR (frame success rate):
#       1e-3 -> 33%,  2e-3 -> 50%,  3e-3 -> 54%,  5e-3 -> 50%,  1.5e-2 -> 0%
#   i.e. it is a real optimum, not a guess.  Re-run
#       python run_sim.py sweep
#   after you change SPREADING_FACTOR or the frame length, because the best
#   value moves with both.
COSTAS_LOOP_BW = 3e-3
COSTAS_DAMPING = 0.707
# Use pilot-aided (known symbol) phase correction on the sync word before
# switching to decision-directed mode.  Strongly recommended.
COSTAS_SEED_FROM_SYNC = True

# --- Automatic gain control --------------------------------------------------
# OFF BY DEFAULT, ON PURPOSE.  The receiver estimates the signal amplitude and
# the noise variance from every frame's own sync word, so the demodulator does
# not need an AGC.  Worse, an AGC whose gain moves while a burst is being
# demodulated changes the constellation radius underneath the slicer: measured
# on this link, a fast AGC took EVM from 0.47% to 8.9%.  The level meter in the
# UI still tells you whether RX_GAIN_DB is sensible.
#   Turn it on only if your front-end level swings more than you can handle with
#   RX_GAIN_DB, and then keep AGC_TIME_CONSTANT_S >= 10 x MAX_FRAME_DURATION_S
#   so the gain is effectively frozen inside a burst.
AGC_ENABLE = False
AGC_REFERENCE = 0.2           # target RMS out of the AGC
AGC_TIME_CONSTANT_S = 5.0     # raise -> slower and gentler; never go below ~1 s

# --- DC blocker --------------------------------------------------------------
# Removes the direct-conversion DC offset / LO leakage with a one-pole highpass.
# It runs BEFORE the digital IF de-shift, so with IF_OFFSET_HZ non-zero the
# notch sits 250 kHz away from the signal and costs nothing.
#   Raise the cutoff: settles faster, starts to eat signal if it approaches the
#        occupied band.  Keep it below ~1% of IF_OFFSET_HZ.
#   Lower: gentler, slower to settle after a gain change.
DC_BLOCK_ENABLE = True
DC_BLOCK_CUTOFF_HZ = 50.0

# --- Frame-level fine frequency estimate -------------------------------------
# After the sync word is found, re-estimate the residual carrier offset from the
# KNOWN symbols with a Luise-Reggiannini estimator and retune the tracker.  This
# is the single most important thing for a tight constellation on a long frame.
FINE_CFO_ENABLE = True

# Include the preamble in that estimate, not just the sync word.  The preamble
# is known too (it is the constant symbol repeated), so this is free accuracy.
#   Frequency-estimator variance falls as N^-3, so 320 known symbols instead of
#   64 cuts the residual CFO roughly 8x -- about 17 Hz down to about 2 Hz at the
#   sensitivity limit.  Measured effect on frame success at -13 dB chip SNR:
#   75% -> 100%.  There is no reason to turn this off.
FINE_CFO_USE_PREAMBLE = True
# Cap on how many known symbols to use (preamble + sync).  More is better until
# you hit the preamble length; beyond that it does nothing.
FINE_CFO_MAX_SYMBOLS = 320
# Fraction of the record length used as the maximum autocorrelation lag in the
# Luise-Reggiannini estimator.
#   Raise (0.5): lower variance, but HALVES the unambiguous frequency range.
#   Lower (0.1): wider range, noisier.
#   0.25 gives about +/- 200 Hz of range here, which is plenty.
FINE_CFO_LAG_FRACTION = 0.25

# ==============================================================================
# SECTION 7 -- LINK LAYER / HALF-DUPLEX ARQ                          [LOCAL-ish]
# ==============================================================================
# The link is half duplex: a node transmits a burst, then listens.  Stop-and-
# wait ARQ: every DATA frame must be acknowledged before the next one is sent.

# Node identity.  Two nodes on the same link must differ.  This is also used to
# ignore your own transmissions when you are running a single-radio loopback
# (set LOOPBACK_ACCEPT_OWN = True in that case).
NODE_ID = 1                   # 1..254 ; 255 = broadcast
PEER_NODE_ID = 255            # who DATA frames are addressed to (255 = broadcast)

# Accept frames addressed from ourselves.  MUST be True for single-radio
# TX->RX cable loopback, otherwise the receiver discards everything it hears
# and the loopback looks dead.
#   TWO-RADIO SETUP: set this False, give each node a different NODE_ID, and
#   point PEER_NODE_ID at the other one.
LOOPBACK_ACCEPT_OWN = True

# Ignore received samples while we are transmitting (plus the turnaround).
#   False -> needed for single-radio loopback: you WANT to hear your own burst.
#   True  -> correct for two radios: stops your own transmitter leaking into
#            your receiver and desensitising the acquisition.
HALF_DUPLEX_MUTE_RX = False

# Send an ACK for every received DATA frame, and wait for one after sending.
ARQ_ENABLE = True
# How long to wait for an ACK before retransmitting, in seconds.
#   Must comfortably exceed: DATA burst + decode + ACK burst + decode.
#   Measured round trip with the defaults: ~140 ms for a 64-byte message,
#   ~500 ms for a full 512-byte one.  The UI shows the live RTT -- keep this at
#   roughly 3x whatever you actually see.
#   Too short and you retransmit frames that were going to arrive anyway; too
#   long and a genuinely lost frame stalls the queue.
ARQ_TIMEOUT_S = 2.0
# How many times to retransmit before giving up on a message.
ARQ_MAX_RETRIES = 4
# Gap inserted between the end of our TX burst and when we trust the receiver
# again, in seconds.  Covers the TX/RX switch and the USRP pipeline.
TX_RX_TURNAROUND_S = 0.02

# ==============================================================================
# SECTION 8 -- USER INTERFACE / METRICS                                 [LOCAL]
# ==============================================================================

# How many recent symbols to keep for the constellation display / EVM.
CONSTELLATION_HISTORY = 2048
# Terminal constellation plot size in characters (width, height).
CONSTELLATION_SIZE = (49, 25)
# Refresh rate of the terminal UI, in Hz.
UI_REFRESH_HZ = 10.0
# Write every received/transmitted frame and its metrics to this CSV.
# None disables logging.
METRICS_CSV = "link_metrics.csv"
# Dump the raw complex constellation of the last good frame to a .npy file so
# you can plot it in matplotlib later.  None disables.
CONSTELLATION_DUMP = "last_constellation.npy"

# ==============================================================================
# SECTION 9 -- SIMULATION (no hardware) DEFAULTS                        [LOCAL]
# ==============================================================================
# Used by run_sim.py and by  run_link.py --sim  so you can develop and tune
# without a radio attached.

SIM_SNR_DB = -10.0            # SNR in the CHIP bandwidth.  Negative = below the
                              # noise floor.  The link should still close down
                              # to about -12 dB with the default settings.
SIM_CFO_HZ = 1200.0           # carrier frequency offset
SIM_SFO_PPM = 2.0             # sample clock offset in ppm
SIM_DELAY_CHIPS = 3.37        # fractional propagation delay
SIM_PHASE_RAD = 1.1           # initial carrier phase
SIM_SEED = 12345

# ==============================================================================
# ==============================================================================
#   DERIVED VALUES -- computed from the knobs above.  DO NOT EDIT BY HAND.
# ==============================================================================
# ==============================================================================

def recompute():
    """Recalculate every derived value from the knobs above.

    Called once at import, and again by the terminal UI's `/set` command so you
    can change SPREADING_FACTOR, N_PREAMBLE_PERIODS, MAX_PAYLOAD_BYTES ... while
    the program is running and have everything downstream follow.
    """
    g = globals()

    g["CHIP_RATE_HZ"] = SAMP_RATE_HZ / SPS_CHIP
    g["SYMBOL_RATE_HZ"] = g["CHIP_RATE_HZ"] / SPREADING_FACTOR
    g["SAMPLES_PER_SYMBOL"] = SPS_CHIP * SPREADING_FACTOR
    g["PROCESSING_GAIN_DB"] = 10.0 * np.log10(SPREADING_FACTOR)

    # Number of PN periods coherently integrated during acquisition.
    g["N_ACQ_PERIODS"] = int(N_PREAMBLE_PERIODS * ACQ_FRACTION)
    # The window is ACQ_GUARD_PERIODS longer than the preamble and the
    # integration block is taken that far back from its end; together with a hop
    # of half a preamble that guarantees the integration always lands entirely
    # inside a preamble, wherever the burst happens to start.
    g["ACQ_GUARD_PERIODS"] = 2
    g["ACQ_WINDOW_SAMPLES"] = ((N_PREAMBLE_PERIODS + g["ACQ_GUARD_PERIODS"])
                               * g["SAMPLES_PER_SYMBOL"])
    g["ACQ_HOP_SAMPLES"] = g["N_ACQ_PERIODS"] * g["SAMPLES_PER_SYMBOL"]

    # Unambiguous Doppler search range of the despread-then-FFT acquisition.
    g["ACQ_FREQ_SPAN_HZ"] = g["SYMBOL_RATE_HZ"]
    g["ACQ_FREQ_RESOLUTION_HZ"] = g["SYMBOL_RATE_HZ"] / (g["N_ACQ_PERIODS"]
                                                         * ACQ_FFT_OVERSAMPLE)

    # --- code rates ---
    g["RS_RATE"] = (RS_K / RS_N) if USE_RS else 1.0
    cc_rate = 1.0 / len(CC_POLYS)
    kept = total = 1
    if CC_PUNCTURE is not None:
        kept = sum(sum(row) for row in CC_PUNCTURE)
        total = len(CC_PUNCTURE) * len(CC_PUNCTURE[0])
        cc_rate = cc_rate * (total / kept)
    g["CC_RATE"] = cc_rate if USE_CC else 1.0
    g["TOTAL_CODE_RATE"] = g["RS_RATE"] * g["CC_RATE"]
    g["NET_BITRATE_BPS"] = g["SYMBOL_RATE_HZ"] * 2.0 * g["TOTAL_CODE_RATE"]

    # --- frame sizing (worst case) ---
    g["HEADER_BYTES"] = 8
    hdr_bits = g["HEADER_BYTES"] * 8
    hdr_coded = (hdr_bits + (CC_K - 1)) * len(CC_POLYS) if USE_CC else hdr_bits
    g["HEADER_SYMBOLS"] = int(np.ceil(hdr_coded * HEADER_REPEAT / 2))

    n = MAX_PAYLOAD_BYTES + 4                       # + CRC32
    if USE_RS:
        nblocks = int(np.ceil(n / RS_K))
        n = n + nblocks * (RS_N - RS_K)
    bits = n * 8
    if USE_CC:
        bits = (bits + (CC_K - 1)) * len(CC_POLYS)
        if CC_PUNCTURE is not None:
            bits = int(np.ceil(bits * kept / total))
    g["MAX_PAYLOAD_SYMBOLS"] = int(np.ceil(bits / 2))

    g["MAX_FRAME_SYMBOLS"] = (N_PREAMBLE_PERIODS + SYNC_LEN + g["HEADER_SYMBOLS"]
                              + g["MAX_PAYLOAD_SYMBOLS"])
    g["MAX_FRAME_SAMPLES"] = (g["MAX_FRAME_SYMBOLS"] * g["SAMPLES_PER_SYMBOL"]
                              + 4 * RAMP_CHIPS * SPS_CHIP)
    g["MAX_FRAME_DURATION_S"] = g["MAX_FRAME_SAMPLES"] / SAMP_RATE_HZ

    # Receiver buffer: a whole worst-case frame plus a couple of search windows.
    g["RX_BUFFER_SAMPLES"] = int(g["MAX_FRAME_SAMPLES"] + 2 * g["ACQ_WINDOW_SAMPLES"])


recompute()


def summary() -> str:
    """Human-readable summary of the configured link.  Printed at startup."""
    lines = [
        "=" * 74,
        " DSSS / QPSK LINK CONFIGURATION",
        "=" * 74,
        f"  Center frequency      : {CENTER_FREQ_HZ/1e6:10.4f} MHz",
        f"  Sample rate           : {SAMP_RATE_HZ/1e6:10.4f} Msps  ({SPS_CHIP} samples/chip)",
        f"  Digital IF offset     : {IF_OFFSET_HZ/1e3:10.2f} kHz",
        f"  Chip rate             : {CHIP_RATE_HZ/1e6:10.4f} Mchip/s",
        f"  Spreading factor      : {SPREADING_FACTOR:10d}  ({PN_KIND} code #{PN_INDEX})",
        f"  Processing gain       : {PROCESSING_GAIN_DB:10.2f} dB",
        f"  Symbol rate           : {SYMBOL_RATE_HZ/1e3:10.3f} kBd  (QPSK)",
        "-" * 74,
        f"  FEC                   : "
        + ("RS(%d,%d) + " % (RS_N, RS_K) if USE_RS else "")
        + ("CC K=%d r=1/%d" % (CC_K, len(CC_POLYS)) if USE_CC else "none")
        + (" + interleave(%d)" % INTERLEAVER_DEPTH if USE_INTERLEAVER else ""),
        f"  Total code rate       : {TOTAL_CODE_RATE:10.4f}",
        f"  Net payload rate      : {NET_BITRATE_BPS/1e3:10.3f} kbit/s",
        "-" * 74,
        f"  Preamble              : {N_PREAMBLE_PERIODS:10d} PN periods "
        f"({N_PREAMBLE_PERIODS*SPREADING_FACTOR/CHIP_RATE_HZ*1e3:.2f} ms)",
        f"  Acquisition gain      : "
        f"{10*np.log10(SPREADING_FACTOR*N_ACQ_PERIODS):10.2f} dB coherent",
        f"  Doppler search        : +/-{ACQ_FREQ_SPAN_HZ/2/1e3:8.2f} kHz "
        f"@ {ACQ_FREQ_RESOLUTION_HZ:.1f} Hz resolution",
        f"  Sync word             : {SYNC_LEN:10d} symbols",
        f"  Header                : {HEADER_SYMBOLS:10d} symbols (x{HEADER_REPEAT} repeat)",
        f"  Max payload           : {MAX_PAYLOAD_BYTES:10d} bytes "
        f"-> {MAX_PAYLOAD_SYMBOLS} symbols",
        f"  Max burst duration    : {MAX_FRAME_DURATION_S*1e3:10.2f} ms",
        "=" * 74,
    ]
    return "\n".join(lines)


# Knobs that change the transmitted waveform: both ends must agree on these, and
# `/set`-ing one at run time restarts the modem objects.  Used by the UI to warn
# you when a change will not interoperate with a peer you did not also change.
WAVEFORM_KNOBS = (
    "SPS_CHIP", "SPREADING_FACTOR", "PN_KIND", "PN_INDEX", "RRC_ROLLOFF",
    "RRC_SPAN_CHIPS", "N_PREAMBLE_PERIODS", "SYNC_LEN", "SYNC_SEED",
    "HEADER_REPEAT", "USE_RS", "RS_N", "RS_K", "USE_CC", "CC_K", "CC_POLYS",
    "CC_PUNCTURE", "USE_INTERLEAVER", "INTERLEAVER_DEPTH", "IF_OFFSET_HZ",
    "SAMP_RATE_HZ", "MAX_PAYLOAD_BYTES", "RAMP_CHIPS",
)


if __name__ == "__main__":
    print(summary())
