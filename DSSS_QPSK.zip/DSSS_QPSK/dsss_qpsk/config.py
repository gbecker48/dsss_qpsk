"""
================================================================================
 config.py  --  THE ONE PLACE YOU CHANGE THINGS
================================================================================

 Everything that defines the waveform, the framing, the receiver loops and the
 radio lives in this file.  Both ends of the link MUST use identical values for
 anything marked  [WAVEFORM]  -- those are baked into the over-the-air signal.
 Anything marked  [RX-ONLY]  or  [LOCAL]  can differ between the two radios.

 Quick orientation -- the signal chain this config describes:

   TX:  text -> CRC32 -> Reed-Solomon(255,223) -> convolutional K=7 r=1/2
        -> bit interleaver -> Gray QPSK -> x PN code (DSSS spreading)
        -> RRC pulse shape -> digital IF shift -> burst ramp -> USRP

   RX:  USRP -> DC block -> digital IF de-shift -> RRC matched filter
        -> ACQUISITION (despread-then-FFT search over delay x Doppler)
        -> coarse CFO correct -> despread + early/late DLL (chip timing)
        -> sync-word correlation (frame start + phase ambiguity + fine CFO)
        -> decision-directed Costas loop (carrier phase)
        -> soft LLRs -> deinterleave -> soft Viterbi -> RS decode -> CRC32

 HOW TO READ THE KNOBS
   Every knob below has:   what it does / what happens if you raise it /
   what happens if you lower it / safe range.
   Derived values are computed at the bottom -- do not edit those, edit the
   knobs they come from.

================================================================================
"""

import numpy as np

# ==============================================================================
# SECTION 1 -- RADIO / RF FRONT END                                   [LOCAL]
# ==============================================================================
# These do not have to match between the two ends except CENTER_FREQ_HZ and
# SAMP_RATE_HZ (those obviously do).

# USRP device arguments.  Examples:
#   ""                            -> first USRP found (fine for one radio)
#   "serial=31ABC12"              -> pick a specific B206mini-i
#   "type=b200"                   -> any B2xx
#   "type=b200,num_recv_frames=512,num_send_frames=512"  -> bigger USB buffers
# NOTE for the B206mini-i: it is a B200-family device, so "type=b200" is right.
DEVICE_ARGS = ""

# Center (LO) frequency in Hz.  915 MHz ISM.
#   Raise/lower: must be inside the B206mini-i tuning range (70 MHz - 6 GHz).
#   For CABLE / attenuator loopback testing anything in range is fine.
#   For OVER THE AIR keep it in a band you are licensed / permitted to use and
#   keep TX_GAIN_DB low.
CENTER_FREQ_HZ = 915e6

# Complex sample rate into/out of the USRP, in samples/second.
#   This sets the chip rate:  CHIP_RATE = SAMP_RATE / SPS_CHIP.
#   Raise: more bandwidth, more processing gain available per second, more USB
#          throughput (B200 over USB3 handles 2-30 Msps fine; USB2 ~8 Msps max).
#   Lower: narrower, more sensitive (less noise power in band), less CPU.
#   Safe range for this code: 1e6 .. 10e6.  Keep it an integer multiple of
#   CHIP_RATE * SPS_CHIP.
SAMP_RATE_HZ = 2e6

# Transmit gain in dB (B206mini range is 0 .. 89.75, step 0.25).
#
# MEASURED ON THIS SETUP -- READ THIS BEFORE RAISING IT.
#   Bare RF cable TX/RX -> RX2, no attenuator, TX 45 dB / RX 40 dB gave an RX
#   rms of 1.003 with 100% of samples clipped.  The receiver was hard against
#   the rails the entire time.
#
#   That is survivable for a CW tone -- a clipped sinusoid is still a sinusoid,
#   which is why the tone test happily reported 43 dB SNR -- but it destroys
#   THIS waveform.  DSSS/QPSK has several dB of peak-to-average and occupies the
#   whole band, so clipping folds intermodulation across every chip, flattens
#   the despread correlation peak, and the receiver reports a chip SNR of -20 to
#   -36 dB.  That is the symptom, and saturation is the cause.
#
#   So on a bare cable, START LOW.  Run
#       python hw_diag.py --autolevel
#   and it will tell you the right pair for your cable.
#   MEASURED GOOD OPERATING POINT on this exact setup (bare cable, no
#   attenuator, B206mini serial 35D5F31):  TX 40 / RX 20 -> RX rms 0.038, no
#   clipping, and the real burst decoded with chip SNR +28 dB and EVM 0.8%.
#   Bare cable, no attenuator : TX 35-45, RX 15-25
#   With 30-40 dB attenuation : TX 40-50, RX 30-40
#   Over the air, short range : TX 50-70, RX 40-60
TX_GAIN_DB = 40.0

# Receive gain in dB (0 .. 76 on the B206mini).
#   Too high -> front-end compression: spurs, a fuzzy constellation, and on a
#        cabled loopback, outright clipping (see TX_GAIN_DB above).
#   Too low  -> ADC quantisation noise dominates.
#   MEASURED on this radio with the transmitter idle: the noise floor barely
#   moves between 0 and 40 dB of RX gain (rms 0.00016 -> 0.00033) and only
#   starts tracking gain properly above ~50 dB.  So below 40 dB the front end
#   is quantisation limited, which means extra RX gain buys you nothing on a
#   strong cabled signal -- take the level down at the TRANSMITTER instead and
#   keep RX gain low and linear.
#   Aim for an RX rms of 0.03-0.15 (shown live in the UI and the dashboard).
RX_GAIN_DB = 20.0

# Analog front-end filter bandwidth in Hz.  None -> UHD picks (usually = rate).
#   Setting it to ~1.2 x the occupied bandwidth improves out-of-band rejection,
#   which matters when you are trying to receive below the noise floor.
RX_BANDWIDTH_HZ = None      # e.g. 1.5e6
TX_BANDWIDTH_HZ = None

# Antenna ports on the B206mini-i.
#   Single-radio LOOPBACK on a B2xx:  TX/RX port transmits, RX2 port receives.
#   Connect TX/RX --[30-40 dB attenuator]--> RX2.
TX_ANTENNA = "TX/RX"
RX_ANTENNA = "RX2"

# Clock / time source: "internal", "external", "gpsdo".
CLOCK_SOURCE = "internal"
TIME_SOURCE = "internal"

# --- Digital IF offset -------------------------------------------------------
# [WAVEFORM] (must match on both ends -- actually it only needs to match if you
# want interop; the RX de-rotates by exactly this amount.)
#
# WHY THIS EXISTS, AND WHY IT MATTERS A LOT FOR A CLEAN CONSTELLATION:
# A direct-conversion radio like the B2xx has LO leakage and a DC offset that
# land exactly at 0 Hz baseband.  If your signal sits on DC, that spur lands in
# the middle of your spectrum and smears the constellation.  We therefore
# generate the signal at +IF_OFFSET_HZ in software, and the receiver shifts it
# back down.  The DC spur then sits harmlessly at the edge of the band and is
# removed by the DC blocker and the matched filter.
#
#   Raise: moves the spur further away, but the signal must stay inside the
#          front-end bandwidth:  |IF_OFFSET| + occupied_BW/2 < SAMP_RATE/2.
#   Lower: 0 disables it (you will see a dot of energy at the constellation
#          origin and a dirtier EVM on real hardware).
#   Good default: about 1/8 of the sample rate.
IF_OFFSET_HZ = 250e3

# ==============================================================================
# SECTION 2 -- DSSS / MODULATION                                   [WAVEFORM]
# ==============================================================================

# Samples per chip out of the modulator.  2 is the standard choice: it is the
# minimum for a fractionally-spaced matched filter + early/late timing loop.
#   Raise to 4: better fractional-delay resolution and a slightly tighter
#        constellation on hardware, at 2x the sample rate for the same chip
#        rate.  The code handles any even value >= 2.
#   Lower: 1 is NOT supported (the early/late DLL needs >= 2).
SPS_CHIP = 2

# Spreading factor: number of PN chips per QPSK symbol.
#   This is the single most important knob for working below the noise floor.
#   Processing gain = 10*log10(SPREADING_FACTOR) dB.
#        31  -> 14.9 dB   (default; symbol rate 32.3 kBd at 2 Msps)
#        63  -> 18.0 dB
#       127  -> 21.0 dB
#       255  -> 24.1 dB   (very robust, very slow)
#   Raise: deeper below the noise floor, tighter dots for the same input SNR,
#          proportionally lower data rate, proportionally longer frames.
#   Lower: faster, less robust.
#   MUST be one of the lengths PN_KIND can produce (see pn.py):
#     'mls'  -> 2^m - 1  : 15, 31, 63, 127, 255, 511, 1023
#     'gold' -> 2^m - 1  : same lengths, better cross-correlation between users
SPREADING_FACTOR = 31

# Which family of spreading code to use, and which member.
#   'mls'  : maximal-length shift register sequence.  Best autocorrelation
#            (single peak of N, sidelobes of exactly -1).  Use this for a
#            single link -- it gives the cleanest acquisition peak.
#   'gold' : Gold code.  Slightly worse autocorrelation but a whole family of
#            codes with bounded cross-correlation -> use if you ever want
#            several links sharing the band (CDMA) or a TX/RX code pair.
PN_KIND = "mls"
PN_INDEX = 0            # which member of the family (0..N for gold, ignored for mls)

# Use DIFFERENT spreading codes for the two directions?
#   False -> both directions use PN_INDEX (simplest; correct for half duplex).
#   True  -> node A transmits with PN_INDEX, node B with PN_INDEX_REVERSE.
#            Useful if you ever go full duplex or want to reject your own echo.
USE_SEPARATE_CODES = False
PN_INDEX_REVERSE = 1

# Root-raised-cosine pulse shaping applied at the CHIP rate.
#   Rolloff: 0.35 is a good default.
#     Raise (-> 0.5): wider spectrum, shorter time response, more tolerant of
#          timing error -> slightly easier sync, slightly worse adjacent-channel.
#     Lower (-> 0.2): narrower spectrum, longer ringing, more sensitive to
#          timing error.
RRC_ROLLOFF = 0.35
# Filter span in chips (total length = RRC_SPAN_CHIPS * SPS_CHIP + 1).
#   Raise: closer to ideal RRC, better ISI, more CPU and more group delay.
#   Lower: cheaper, more ISI.  Do not go below 6.
RRC_SPAN_CHIPS = 12

# ==============================================================================
# SECTION 3 -- FRAME STRUCTURE                                     [WAVEFORM]
# ==============================================================================
#
#  A burst on the air looks like this:
#
#  |<-RAMP->|<------- PREAMBLE ------->|<-SYNC->|<-HEADER->|<--- PAYLOAD --->|<-RAMP->|
#             N_PREAMBLE_PERIODS x PN    SYNC_LEN   fixed      variable
#             (unmodulated, all +1)      symbols    symbols    symbols
#
#  The PREAMBLE is what lets us find the signal *below the noise floor*: it is
#  the raw PN code repeated with no data on it, so the receiver can coherently
#  integrate over the whole thing (despread -> FFT) and pull ~36 dB of gain out
#  of the noise before it knows anything about timing or frequency.
#
#  The SYNC word is a known QPSK sequence.  It marks the exact frame start,
#  resolves the 90-degree QPSK phase ambiguity, gives a data-aided fine
#  frequency estimate and a noise-variance estimate for the LLR scaling.

# Number of PN periods in the acquisition preamble.
#   Acquisition coherent gain = 10*log10(SPREADING_FACTOR * N_ACQ_PERIODS) dB,
#   where N_ACQ_PERIODS = N_PREAMBLE_PERIODS // 2 (see RX section for why).
#     128 -> 31*64  = 1984  -> 33.0 dB
#     256 -> 31*128 = 3968  -> 36.0 dB   (default)
#     512 -> 31*256 = 7936  -> 39.0 dB
#   Raise: acquires deeper below the noise floor, finer frequency resolution,
#          BUT the unambiguous frequency search range does not change, the
#          preamble takes longer to send, and a large frequency offset will
#          start to de-cohere the integration (see FREQ_SEARCH_* below).
#   Lower: shorter bursts, less sensitivity.
#   Must be EVEN.
N_PREAMBLE_PERIODS = 256

# Length of the sync word in QPSK symbols.
#   Raise: more reliable frame detection and a better fine-CFO / noise estimate,
#          at the cost of a few more symbols of overhead.
#   Lower: below 32 the phase-ambiguity resolution starts to make mistakes at
#          very low SNR.
SYNC_LEN = 64

# Seed for the deterministic sync-word generator.  Both ends must match.
# Change it if you want a "private" sync word so a second link on the same
# frequency does not false-trigger on yours.
SYNC_SEED = 0xC0FFEE

# Header: 8 bytes, see framing.py for the exact layout.
# Repetition of the (already convolutionally coded) header bits.
#   Raise to 3-4: the header survives even when the payload does not, which is
#        the failure mode you want (you learn a frame arrived and was too weak).
#   Lower to 1: saves symbols, header becomes the weakest link.
HEADER_REPEAT = 2

# Maximum payload bytes in one frame (before CRC/FEC).
#   Raise: more efficient for long messages, longer bursts, bigger RX buffer.
#   Lower: shorter bursts, faster ARQ turnaround.
#   Hard cap is 65535 because payload_len is a 16-bit header field, but the RX
#   buffer sizing below assumes this value -- keep it sane.
MAX_PAYLOAD_BYTES = 512

# Burst amplitude ramp, in chips.  Prevents spectral splatter at burst edges
# (a hard on/off keyed burst has infinite bandwidth).
#   Raise: cleaner spectrum, slightly longer burst.
#   Lower: 0 disables ramping -- you will see splatter on a spectrum analyzer.
RAMP_CHIPS = 16

# Peak amplitude of the transmitted baseband signal (before the USRP).
#   Keep <= 0.7 so the DAC and the RRC overshoot do not clip.  Clipping is a
#   top cause of a smeared constellation on real hardware.
TX_AMPLITUDE = 0.35

# ==============================================================================
# SECTION 4 -- FORWARD ERROR CORRECTION                            [WAVEFORM]
# ==============================================================================
#
#  Concatenated CCSDS-style code:
#     payload+CRC32  --RS(255,223)-->  --CC K=7 r=1/2-->  --interleave-->  QPSK
#  The inner convolutional code with SOFT decisions gives ~5 dB of coding gain
#  and turns random bit errors into occasional short bursts.  The outer
#  Reed-Solomon code eats those bursts (up to 16 wrong bytes per 255-byte
#  codeword), buying another ~2 dB and, more importantly, making the failure
#  cliff very sharp instead of a long tail of almost-good frames.

# --- Outer code: Reed-Solomon over GF(256) -----------------------------------
USE_RS = True                 # False -> convolutional code only (~2 dB worse)
RS_N = 255                    # codeword length in bytes (fixed by GF(256))
RS_K = 223                    # data bytes per codeword -> corrects 16 bytes
#   Lower RS_K (e.g. 191 -> corrects 32 bytes): stronger, more overhead.
#   Raise RS_K (e.g. 239 -> corrects 8 bytes):  weaker, less overhead.

# --- Inner code: convolutional, soft-decision Viterbi ------------------------
USE_CC = True                 # False -> uncoded (you will lose ~5 dB)
# Constraint length and generator polynomials, in OCTAL, MSB-first.
#   (7, [0o171, 0o133]) is the industry-standard rate-1/2 K=7 code.
#   (7, [0o171, 0o133, 0o165]) makes it rate 1/3: ~0.5 dB better, 50% more
#   symbols.  The code below supports any K<=9 and any number of polynomials.
CC_K = 7
CC_POLYS = [0o171, 0o133]
# Puncturing pattern, or None for no puncturing.
#   None            -> rate 1/2 (default)
#   [[1,1],[1,0]]   -> rate 2/3 (faster, ~1 dB worse)
#   [[1,1,1],[1,0,0]] -> rate 3/4
CC_PUNCTURE = None

# --- Interleaver -------------------------------------------------------------
# Block interleaver applied to the CODED bits, right before QPSK mapping.
# It spreads a burst of channel errors (a fade, an interferer, a timing slip)
# across the Viterbi trellis so the decoder sees them as isolated errors.
USE_INTERLEAVER = True
# Interleaver depth = the SEPARATION, in coded bits, between two bits that were
# adjacent on the air.  A burst of N consecutive channel errors therefore
# arrives at the Viterbi decoder as N isolated errors spaced INTERLEAVER_DEPTH
# apart.
#   Raise (128): better burst protection, slightly more latency.
#   Lower (16):  less protection; below ~40 the errors start landing inside one
#        Viterbi traceback window and stop looking isolated.
#   Should be comfortably larger than 5*CC_K (the decoder memory) -- 64 is good.
INTERLEAVER_DEPTH = 64

# ==============================================================================
# SECTION 5 -- RECEIVER: ACQUISITION                                 [RX-ONLY]
# ==============================================================================

# Detection threshold for the acquisition correlator, expressed as the ratio of
# the peak power to the *median* power of the whole delay-Doppler search grid.
# (Median, not mean, so a strong peak does not raise its own threshold.)
# MEASURED peak/median for REAL bursts, 6 trials per point:
#       chip SNR -18 dB ->  60 ..  110
#       chip SNR -16 dB -> 103 ..  133
#       chip SNR -14 dB -> 138 ..  251      (near this link's decoding limit)
#       chip SNR -12 dB -> 221 ..  342
#       chip SNR   0 dB ->       ~4 600
#       chip SNR +28 dB ->     ~850 000     (a cabled loopback)
#   The link itself stops decoding around -13 dB, where PSR is at least ~200.
#   So 100 catches everything the decoder could ever use, with 2x margin.
#
# MEASURED noise-only peak/median, 15 120 windows = 60 s of pure noise:
#       median 12.9   99th 19.4   99.9th 22.6   WORST 28.2
#   So the old default of 30 sat essentially ON the noise distribution -- which
#   is why hardware logged 147 false acquisitions in two minutes, each paying
#   for a full sync search.  That is CPU the receiver did not have, and the
#   dropped samples it caused looked exactly like a bad radio.
#
#   45 sits 1.6x above the worst noise window seen in a minute and still below
#   the weakest burst the decoder could ever use (60, at -18 dB).  False
#   acquisitions are also cheap now: PREAMBLE_CHECK kills one in 48 symbols
#   instead of 528, so a few per minute cost nothing.
#   Raise (1000+): sensible on a strong cabled link, fewer wasted searches.
#   Lower: more sensitive acquisition, more CPU spent on phantoms.
ACQ_THRESHOLD_PSR = 45.0

# Cheap early-out before the expensive sync-word search.
#   Despread just this many symbols from the acquisition point and check that
#   they look like the constant preamble (a strong mean against a small
#   variance).  Noise scores about -15 dB here; even a -18 dB chip SNR burst
#   scores about -3 dB, so the two are cleanly separated.
#   This makes rejecting a false acquisition ~16x cheaper than despreading the
#   full search span, which is what keeps the receiver ahead of the radio when
#   the band is busy.
#   Probed at PREAMBLE_CHECK_PROBES points spread across the acquisition
#   integration block, keeping the best score, because acquisition can fire with
#   the block only partly overlapping the burst -- probing one point rejects
#   good frames.  It stops early as soon as one probe passes, so on a real
#   signal it usually costs a single probe.
#   With 48 symbols, pure noise scores about -17 dB and a -18 dB chip SNR burst
#   scores about -3 dB, so -9 dB sits cleanly between them.
#   Set PREAMBLE_CHECK_SYMBOLS = 0 to disable the early-out entirely.
PREAMBLE_CHECK_SYMBOLS = 48
PREAMBLE_CHECK_PROBES = 3
PREAMBLE_CHECK_MIN_DB = -9.0

# Fraction of the preamble used for the coherent acquisition integration.
# The receiver searches in overlapping windows; using the second half of each
# window guarantees the integration lands entirely inside a preamble no matter
# where the burst starts.  Do not change unless you understand acquisition.py.
ACQ_FRACTION = 0.5

# Limit the Doppler search to +/- this many Hz (None -> search the full
# unambiguous range, which is +/- chip_rate / (2*SPREADING_FACTOR) ).
#   With the default waveform the full range is +/- 16.1 kHz, which is +/- 17.6
#   ppm at 915 MHz -- far more than the +/- 2 ppm a B2xx TCXO will ever drift.
#   Narrowing it to, say, 5000 Hz makes false alarms less likely and speeds up
#   the search.  Set to None to search everything.
FREQ_SEARCH_LIMIT_HZ = 6000.0

# How much slack the receiver's sample buffer gets, as a multiple of one
# worst-case frame plus two search windows.
#   The buffer must be able to hold a whole frame while it is being decoded.  If
#   it ever hits this cap the receiver ABANDONS the frame in progress (cleanly --
#   see Receiver._trim) rather than trimming samples it still needs, and counts
#   it in stats.buffer_aborts.  That counter should stay at zero.
#   Raise if you see buffer_aborts > 0; lower only if memory is tight.
RX_BUFFER_MARGIN = 4

# Reject a frame at the sync stage if the symbol SNR measured on its own known
# symbols is below this.  A partial burst -- the receiver catching the tail of
# one, or a capture that starts mid-preamble -- can still produce a big sync
# correlation peak while half its "preamble" is silence.  The amplitude estimate
# then comes out tiny and the noise estimate huge, the frame fails at the header
# anyway, and on the way it reports nonsense like "chip SNR -26 dB, EVM 285%" --
# which is exactly the kind of number that makes you think the radio is broken.
#   Real frames at the sensitivity limit measure about +0.6 dB here, so -5 dB
#   leaves ~5 dB of margin.  Lower it if you ever see good frames rejected with
#   stage "sync-low-snr".
SYNC_MIN_SNR_DB = -5.0

# Sync-word detection threshold, as the ratio of the sync correlation peak to
# the median of the correlation away from the peak.
#   This is the SECOND gate: a false acquisition that gets past ACQ_THRESHOLD_PSR
#   almost never produces a sync-word peak, so this is what actually keeps false
#   frames out of the decoder.
#   Raise (10): fewer false frames, may drop the very weakest bursts.
#   Lower (4):  more sensitive, more wasted header decodes.
# Minimum Doppler concentration for an acquisition to be believed: the peak
# power divided by the MEAN power across the whole Doppler axis at that delay.
#
#   WHAT IT IS FOR.  The payload of a burst is spread by the same PN code as its
#   preamble, so the despreading correlator finds it too.  On a strong signal
#   that in-burst correlation easily clears ACQ_THRESHOLD_PSR, and since a failed
#   sync search only advances the scan by one hop, ONE such detection turns into
#   dozens as the scan walks through the rest of the burst.  Measured on
#   hardware during a 32 kB file transfer: 350 acquisitions, 263 of them junk,
#   50% deaf time, and 22 bursts retransmitted for nothing.
#
#   WHY THIS TEST AND NOT A HIGHER PSR.  PSR scales with signal strength, so no
#   single value separates the two: a -18 dB preamble gives PSR 60-110 while a
#   strong burst's payload gives 1400-2200.  Concentration does not scale with
#   strength, because it asks a structural question instead: a preamble is one
#   symbol repeated, so its correlation is identical every PN period and the FFT
#   across periods puts all of it in one bin.  Data changes sign period to
#   period, so the same FFT smears it everywhere.
#
#   MEASURED:
#       true preamble   -13 dB: 59-67   -16 dB: 42-48   -19 dB: 25-31
#       burst payload     0 dB: 2.8-8.0  +14 dB: 2.9-8.1  +30 dB: 2.9-8.0
#   20 passes real preambles 6 dB below the rated sensitivity and still sits at
#   2.5x the worst payload value.
#   Raise towards 35: rejects more junk, starts cutting into deep acquisition.
#   Lower towards 15: more tolerant; set 0 to disable the test entirely.
ACQ_MIN_DOPPLER_CONC = 20.0

SYNC_THRESHOLD_RATIO = 6.0

# Second sync test: the peak divided by the LARGEST other correlation peak.
#   Why two tests?  SYNC_THRESHOLD_RATIO compares the peak to the MEDIAN
#   background, which is a noise measurement -- and on a strong signal the
#   background inside a burst is not noise, it is a stretch of constant
#   preamble, which is nearly silent.  That makes the ratio enormous for any
#   spurious peak and the test stops discriminating exactly when the link is
#   working best.  This one is immune to that: a real sync peak stands alone.
#   MEASURED, 12 frames per point, margin on frames that actually decoded:
#       SNR    -14   -13   -12    -8     0   +10   +24   +40
#       min   1.76  1.86  1.97  2.35  2.92  3.12  3.10  3.10
#       med   2.60  2.81  2.89  3.28  3.46  3.46  3.45  3.44
#   Spurious peaks measure 1.0-1.3.  1.5 sits clear of both: 0.36 of headroom
#   under the worst decoding frame at the -13 dB sensitivity limit, and well
#   above anything a spurious peak produces.
#   Raise towards 2.0: fewer false syncs, starts costing sensitivity.
#   Lower towards 1.2: more tolerant, lets more garbage through to the header.
SYNC_PEAK_MARGIN = 1.5

# Zero-padding factor for the acquisition FFT.  1 = no padding.
#   Raise to 2: the frequency grid is twice as fine, so the coarse CFO estimate
#   is better and less energy is lost between bins (scalloping).  Cheap.
ACQ_FFT_OVERSAMPLE = 2

# ==============================================================================
# SECTION 6 -- RECEIVER: TRACKING LOOPS                              [RX-ONLY]
# ==============================================================================
# All loop bandwidths are given as a FRACTION OF THE SYMBOL RATE.  That makes
# them independent of SPREADING_FACTOR and SAMP_RATE -- change those and the
# loops stay sensibly tuned.

# --- Chip timing: early/late delay-locked loop (DLL) -------------------------
# Operates on the despread correlation peak: it compares the energy half a chip
# early against half a chip late and steers a fractional-delay interpolator.
DLL_ENABLE = True
# Normalized loop bandwidth.
#   Raise (1e-2): tracks a bad sample-clock offset between two radios quickly,
#        but lets more noise into the timing estimate -> fuzzier dots.
#   Lower (1e-4): very clean timing, slow to pull in.  Because acquisition
#        already gives sub-sample timing, LOW IS GOOD here.
DLL_LOOP_BW = 1e-3
DLL_DAMPING = 1.0
# Fractional-delay interpolator used to read chips at the tracked instants.
#   4  -> cubic Lagrange.  Cheapest, but its amplitude response droops near the
#         band edge; costs about 8 dB of MER on this waveform.
#   8  -> 8-tap windowed sinc.  The default: flat across the band, and the extra
#         cost is four more multiply-accumulates per chip.
#   12 / 16 -> diminishing returns, measurably slower.
TRACKER_INTERP_TAPS = 8

# How many symbols the tracker processes per vectorised block.
#   The two feedback loops still update on EVERY symbol; only the sampling
#   instants and the intra-symbol carrier rotation are predicted across a block
#   and re-anchored exactly at its end.  Over 32 symbols (1 ms) a locked loop
#   moves by far less than the noise, and the measured constellation is
#   bit-identical to strict per-symbol processing.
#   MEASURED decode speed (200-byte frame, relative to real time):
#       1 -> 0.56x   8 -> 1.07x   32 -> 1.49x   64 -> 1.49x
#   Below 1.0x the receiver is slower than the radio and will eventually drop
#   samples, so do not set this to 1 on hardware unless you also slow the link
#   down.  Set it to 1 if you want to prove to yourself the blocking is exact.
TRACKER_BLOCK_SYMBOLS = 32

# Early/late spacing in chips.  0.5 is standard.  Narrower (0.25) gives a
# steeper discriminator (less jitter) but a smaller pull-in range.
DLL_EL_SPACING = 0.5

# --- Carrier phase: decision-directed Costas loop ----------------------------
# Runs on the DESPREAD symbols, so it sees the full processing gain -- this is
# why the constellation can be tight even when the signal is below the noise
# floor at the antenna.
COSTAS_ENABLE = True
# Normalized loop bandwidth.
#   Raise (5e-2): tracks fast phase noise / big residual CFO, noisier phase
#        estimate -> the dots smear tangentially (a "banana" shape).
#   Lower (2e-3): very tight dots, but if the residual frequency error is large
#        the loop will not hold and you get a slowly rotating constellation.
#   The preamble-aided fine-CFO estimate leaves only ~2 Hz, so a low bandwidth
#   is safe and gives the tightest dots.  If you see the constellation rotating,
#   raise this first; if the dots smear tangentially, lower it.
#   MEASURED on the simulated link at -14 dB chip SNR (frame success rate):
#       1e-3 -> 33%,  2e-3 -> 50%,  3e-3 -> 54%,  5e-3 -> 50%,  1.5e-2 -> 0%
#   i.e. it is a real optimum, not a guess.  Re-run
#       python run_sim.py sweep
#   after you change SPREADING_FACTOR or the frame length, because the best
#   value moves with both.
COSTAS_LOOP_BW = 3e-3
COSTAS_DAMPING = 0.707
# Use pilot-aided (known symbol) phase correction on the sync word before
# switching to decision-directed mode.  Strongly recommended.
COSTAS_SEED_FROM_SYNC = True

# --- Automatic gain control --------------------------------------------------
# OFF BY DEFAULT, ON PURPOSE.  The receiver estimates the signal amplitude and
# the noise variance from every frame's own sync word, so the demodulator does
# not need an AGC.  Worse, an AGC whose gain moves while a burst is being
# demodulated changes the constellation radius underneath the slicer: measured
# on this link, a fast AGC took EVM from 0.47% to 8.9%.  The level meter in the
# UI still tells you whether RX_GAIN_DB is sensible.
#   Turn it on only if your front-end level swings more than you can handle with
#   RX_GAIN_DB, and then keep AGC_TIME_CONSTANT_S >= 10 x MAX_FRAME_DURATION_S
#   so the gain is effectively frozen inside a burst.
AGC_ENABLE = False
AGC_REFERENCE = 0.2           # target RMS out of the AGC
AGC_TIME_CONSTANT_S = 5.0     # raise -> slower and gentler; never go below ~1 s

# --- DC blocker --------------------------------------------------------------
# Removes the direct-conversion DC offset / LO leakage with a one-pole highpass.
# It runs BEFORE the digital IF de-shift, so with IF_OFFSET_HZ non-zero the
# notch sits 250 kHz away from the signal and costs nothing.
#   Raise the cutoff: settles faster, starts to eat signal if it approaches the
#        occupied band.  Keep it below ~1% of IF_OFFSET_HZ.
#   Lower: gentler, slower to settle after a gain change.
DC_BLOCK_ENABLE = True
DC_BLOCK_CUTOFF_HZ = 50.0

# --- Frame-level fine frequency estimate -------------------------------------
# After the sync word is found, re-estimate the residual carrier offset from the
# KNOWN symbols with a Luise-Reggiannini estimator and retune the tracker.  This
# is the single most important thing for a tight constellation on a long frame.
FINE_CFO_ENABLE = True

# Include the preamble in that estimate, not just the sync word.  The preamble
# is known too (it is the constant symbol repeated), so this is free accuracy.
#   Frequency-estimator variance falls as N^-3, so 320 known symbols instead of
#   64 cuts the residual CFO roughly 8x -- about 17 Hz down to about 2 Hz at the
#   sensitivity limit.  Measured effect on frame success at -13 dB chip SNR:
#   75% -> 100%.  There is no reason to turn this off.
FINE_CFO_USE_PREAMBLE = True
# Cap on how many known symbols to use (preamble + sync).  More is better until
# you hit the preamble length; beyond that it does nothing.
FINE_CFO_MAX_SYMBOLS = 320
# Fraction of the record length used as the maximum autocorrelation lag in the
# Luise-Reggiannini estimator.
#   Raise (0.5): lower variance, but HALVES the unambiguous frequency range.
#   Lower (0.1): wider range, noisier.
#   0.25 gives about +/- 200 Hz of range here, which is plenty.
FINE_CFO_LAG_FRACTION = 0.25

# ==============================================================================
# SECTION 7 -- LINK LAYER / HALF-DUPLEX ARQ                          [LOCAL-ish]
# ==============================================================================
# The link is half duplex: a node transmits a burst, then listens.  Stop-and-
# wait ARQ: every DATA frame must be acknowledged before the next one is sent.

# Node identity.  Two nodes on the same link must differ.  This is also used to
# ignore your own transmissions when you are running a single-radio loopback
# (set LOOPBACK_ACCEPT_OWN = True in that case).
NODE_ID = 1                   # 1..254 ; 255 = broadcast
PEER_NODE_ID = 255            # who DATA frames are addressed to (255 = broadcast)

# Accept frames addressed from ourselves.  MUST be True for single-radio
# TX->RX cable loopback, otherwise the receiver discards everything it hears
# and the loopback looks dead.
#   TWO-RADIO SETUP: set this False, give each node a different NODE_ID, and
#   point PEER_NODE_ID at the other one.
LOOPBACK_ACCEPT_OWN = True

# Ignore received samples while we are transmitting (plus the turnaround).
#   False -> needed for single-radio loopback: you WANT to hear your own burst.
#   True  -> correct for two radios: stops your own transmitter leaking into
#            your receiver and desensitising the acquisition.
HALF_DUPLEX_MUTE_RX = False

# Send an ACK for every received DATA frame, and wait for one after sending.
ARQ_ENABLE = True
# --- ACK timeout ------------------------------------------------------------
# The timeout is DERIVED per message, not fixed: the link budgets the real air
# time of the DATA burst and the ACK burst, the time to demodulate both, the
# turnaround, and a few multiples of the round trip it has actually been
# measuring.  A fixed timeout that is comfortable for a 64-byte message fires
# early on a 512-byte one -- which is what caused "it ACKed fine and then
# retried anyway": the retry was queued before the ACK had finished decoding.
# These three just bound that calculation.
# Round trip through the radio itself: UHD's transmit pipeline, the USB link,
# and the receive buffering, in EACH direction.  Measured on a B206mini over
# USB 2 the total round trip is ~110-390 ms for a 64-byte message and ~690-720 ms
# for a 400-byte one, against burst air times of only 54 ms and 145 ms -- so most
# of the round trip is pipeline, not air time, and a budget built from air time
# alone comes out marginally too small.  Raise this if you see a retry fire on
# the FIRST message of a run (later ones self-correct from the measured RTT).
RADIO_LATENCY_S = 0.15
ARQ_TIMEOUT_MIN_S = 0.40      # never fire sooner than this
ARQ_TIMEOUT_MAX_S = 8.0       # never wait longer than this
ARQ_TIMEOUT_SLACK_S = 0.35    # headroom added to the computed budget
# If a burst is being demodulated when the timer expires, it is very probably
# our ACK.  Hold the retry back by this much rather than transmitting on top of
# it.  Applied repeatedly, so a slow decode simply delays the retry.
ARQ_GRACE_S = 0.30
# How many times to retransmit before giving up on a message.
ARQ_MAX_RETRIES = 4
# Gap inserted between the end of our TX burst and when we trust the receiver
# again, in seconds.  Covers the TX/RX switch and the USRP pipeline.
TX_RX_TURNAROUND_S = 0.02

# ==============================================================================
# SECTION 7b -- FILE TRANSFER                                           [LOCAL]
# ==============================================================================
#
#  Files ride on top of the same messages as chat (see filexfer.py): a manifest
#  with name/size/CRC-32, then numbered segments, then whatever repair the
#  receiver asks for.  None of this changes the waveform -- a file segment and a
#  typed message are the identical frame on the air -- so file transfer inherits
#  the measured -13 dB sensitivity exactly.

# Payload bytes per segment.  Capped at MAX_PAYLOAD_BYTES; the 4-byte segment
# header comes out of it.
#
#   MEASURED, 24 frames per point, simulation, whole-frame success:
#       payload   burst    -11 dB   -12 dB   -13 dB   -14 dB
#         512 B   166 ms     100%     100%      92%      0%
#        1024 B   309 ms     100%     100%      83%      0%
#        2048 B   603 ms     100%     100%      75%      0%
#        4096 B  1182 ms     100%     100%      62%      0%
#
#   A longer frame is not harder to track -- the loops hold fine -- it just
#   contains more Reed-Solomon codewords, and one bad codeword kills the frame.
#   The throughput gain is small (512 B is 3.08 B/ms of air time, 2048 B is
#   3.40 B/ms) because the preamble is already a small fraction of the burst.
#   So: 512 is the default.  You buy 10% speed for 1 dB of sensitivity if you
#   raise it, which is the wrong trade for this link.
FILE_SEGMENT_BYTES = 512

# Send bulk segments as unacknowledged STREAM frames and repair the holes at the
# end, instead of waiting for an ACK after every one.
#   True  (default): ~5x faster on hardware, identical frames on the air.
#   False: every segment gets its own stop-and-wait ARQ.  Slower, but each
#          segment is confirmed before the next goes out, which is easier to
#          follow when you are debugging a marginal link.
FILE_STREAM_MODE = True

# Guard factor on the burst air time before the next STREAM burst is queued.
#   1.06 leaves a 6% gap so consecutive bursts never overlap in the radio.
#   Lower (1.01): slightly faster, less margin if the host stutters.
#   Higher (1.2): more idle air, more robust on a loaded machine.
FILE_STREAM_PACE = 1.06

# How many segments to keep queued at the link at once.  Deliberately small so
# a message you type in the middle of a 2 MB transfer goes out next, not after
# four thousand segments.
FILE_QUEUE_AHEAD = 4

# Receiver: how long a transfer may sit with holes in it before asking for them,
# and how many times it will ask before declaring the file failed.
#   The sender also announces the end of a transfer explicitly, so in the normal
#   lossless case the receiver never waits out this timer at all.  It only
#   matters when the end-of-transfer marker itself is lost.
#   Measured: 25% of all bursts deliberately destroyed still converges, using
#   about 5 repair rounds on a 17-segment file.
FILE_REPAIR_IDLE_S = 2.5
FILE_REPAIR_MAX = 12

# Where received files are written (relative paths are relative to the project
# folder).  Name collisions get "(1)", "(2)" and so on -- nothing is overwritten.
FILE_INBOX = "inbox"

# Refuse to start a transfer bigger than this.  At ~3 kB/s a 16 MB file is
# roughly an hour and a half of air time; raise it only if you mean it.
FILE_MAX_BYTES = 16 << 20

# How long a finished transfer stays on the live list before moving to history.
FILE_RETIRE_S = 20.0

# ==============================================================================
# SECTION 8 -- USER INTERFACE / METRICS                                 [LOCAL]
# ==============================================================================

# How many raw samples to keep for the dashboard's live spectrum / waterfall.
# 1024-4096 is plenty; this is a ring buffer, not a capture.
SPECTRUM_SAMPLES = 4096
# Web dashboard (run_link.py --web).  Bound to localhost by default; set
# WEB_HOST = "0.0.0.0" if you want to watch it from another machine.
WEB_PORT = 8731
WEB_HOST = "127.0.0.1"

# How many recent symbols to keep for the constellation display / EVM.
CONSTELLATION_HISTORY = 2048
# Terminal constellation plot size in characters (width, height).
CONSTELLATION_SIZE = (49, 25)
# Refresh rate of the terminal UI, in Hz.
UI_REFRESH_HZ = 10.0
# Write every received/transmitted frame and its metrics to this CSV.
# None disables logging.
METRICS_CSV = "link_metrics.csv"
# Dump the raw complex constellation of the last good frame to a .npy file so
# you can plot it in matplotlib later.  None disables.
CONSTELLATION_DUMP = "last_constellation.npy"

# ==============================================================================
# SECTION 9 -- SIMULATION (no hardware) DEFAULTS                        [LOCAL]
# ==============================================================================
# Used by run_sim.py and by  run_link.py --sim  so you can develop and tune
# without a radio attached.

SIM_SNR_DB = -10.0            # SNR in the CHIP bandwidth.  Negative = below the
                              # noise floor.  The link should still close down
                              # to about -12 dB with the default settings.
SIM_CFO_HZ = 1200.0           # carrier frequency offset
SIM_SFO_PPM = 2.0             # sample clock offset in ppm
SIM_DELAY_CHIPS = 3.37        # fractional propagation delay
SIM_PHASE_RAD = 1.1           # initial carrier phase
SIM_SEED = 12345

# ==============================================================================
# ==============================================================================
#   DERIVED VALUES -- computed from the knobs above.  DO NOT EDIT BY HAND.
# ==============================================================================
# ==============================================================================

def recompute():
    """Recalculate every derived value from the knobs above.

    Called once at import, and again by the terminal UI's `/set` command so you
    can change SPREADING_FACTOR, N_PREAMBLE_PERIODS, MAX_PAYLOAD_BYTES ... while
    the program is running and have everything downstream follow.
    """
    g = globals()

    g["CHIP_RATE_HZ"] = SAMP_RATE_HZ / SPS_CHIP
    g["SYMBOL_RATE_HZ"] = g["CHIP_RATE_HZ"] / SPREADING_FACTOR
    g["SAMPLES_PER_SYMBOL"] = SPS_CHIP * SPREADING_FACTOR
    g["PROCESSING_GAIN_DB"] = 10.0 * np.log10(SPREADING_FACTOR)

    # Number of PN periods coherently integrated during acquisition.
    g["N_ACQ_PERIODS"] = int(N_PREAMBLE_PERIODS * ACQ_FRACTION)
    # The window is ACQ_GUARD_PERIODS longer than the preamble and the
    # integration block is taken that far back from its end; together with a hop
    # of half a preamble that guarantees the integration always lands entirely
    # inside a preamble, wherever the burst happens to start.
    g["ACQ_GUARD_PERIODS"] = 2
    g["ACQ_WINDOW_SAMPLES"] = ((N_PREAMBLE_PERIODS + g["ACQ_GUARD_PERIODS"])
                               * g["SAMPLES_PER_SYMBOL"])
    g["ACQ_HOP_SAMPLES"] = g["N_ACQ_PERIODS"] * g["SAMPLES_PER_SYMBOL"]

    # Unambiguous Doppler search range of the despread-then-FFT acquisition.
    g["ACQ_FREQ_SPAN_HZ"] = g["SYMBOL_RATE_HZ"]
    g["ACQ_FREQ_RESOLUTION_HZ"] = g["SYMBOL_RATE_HZ"] / (g["N_ACQ_PERIODS"]
                                                         * ACQ_FFT_OVERSAMPLE)

    # --- code rates ---
    g["RS_RATE"] = (RS_K / RS_N) if USE_RS else 1.0
    cc_rate = 1.0 / len(CC_POLYS)
    kept = total = 1
    if CC_PUNCTURE is not None:
        kept = sum(sum(row) for row in CC_PUNCTURE)
        total = len(CC_PUNCTURE) * len(CC_PUNCTURE[0])
        cc_rate = cc_rate * (total / kept)
    g["CC_RATE"] = cc_rate if USE_CC else 1.0
    g["TOTAL_CODE_RATE"] = g["RS_RATE"] * g["CC_RATE"]
    g["NET_BITRATE_BPS"] = g["SYMBOL_RATE_HZ"] * 2.0 * g["TOTAL_CODE_RATE"]

    # --- frame sizing (worst case) ---
    g["HEADER_BYTES"] = 8
    hdr_bits = g["HEADER_BYTES"] * 8
    hdr_coded = (hdr_bits + (CC_K - 1)) * len(CC_POLYS) if USE_CC else hdr_bits
    g["HEADER_SYMBOLS"] = int(np.ceil(hdr_coded * HEADER_REPEAT / 2))

    n = MAX_PAYLOAD_BYTES + 4                       # + CRC32
    if USE_RS:
        nblocks = int(np.ceil(n / RS_K))
        n = n + nblocks * (RS_N - RS_K)
    bits = n * 8
    if USE_CC:
        bits = (bits + (CC_K - 1)) * len(CC_POLYS)
        if CC_PUNCTURE is not None:
            bits = int(np.ceil(bits * kept / total))
    g["MAX_PAYLOAD_SYMBOLS"] = int(np.ceil(bits / 2))

    # The fine-CFO estimate uses the known symbols immediately before the sync
    # word -- which are exactly the preamble -- so it can never ask for more
    # preamble than there is.
    g["FINE_CFO_SYMBOLS"] = min(FINE_CFO_MAX_SYMBOLS,
                                N_PREAMBLE_PERIODS + SYNC_LEN)

    g["MAX_FRAME_SYMBOLS"] = (N_PREAMBLE_PERIODS + SYNC_LEN + g["HEADER_SYMBOLS"]
                              + g["MAX_PAYLOAD_SYMBOLS"])
    g["MAX_FRAME_SAMPLES"] = (g["MAX_FRAME_SYMBOLS"] * g["SAMPLES_PER_SYMBOL"]
                              + 4 * RAMP_CHIPS * SPS_CHIP)
    g["MAX_FRAME_DURATION_S"] = g["MAX_FRAME_SAMPLES"] / SAMP_RATE_HZ

    # Receiver buffer: a whole worst-case frame plus a couple of search windows.
    g["RX_BUFFER_SAMPLES"] = int(g["MAX_FRAME_SAMPLES"] + 2 * g["ACQ_WINDOW_SAMPLES"])


recompute()


def summary() -> str:
    """Human-readable summary of the configured link.  Printed at startup."""
    lines = [
        "=" * 74,
        " DSSS / QPSK LINK CONFIGURATION",
        "=" * 74,
        f"  Center frequency      : {CENTER_FREQ_HZ/1e6:10.4f} MHz",
        f"  Sample rate           : {SAMP_RATE_HZ/1e6:10.4f} Msps  ({SPS_CHIP} samples/chip)",
        f"  Digital IF offset     : {IF_OFFSET_HZ/1e3:10.2f} kHz",
        f"  Chip rate             : {CHIP_RATE_HZ/1e6:10.4f} Mchip/s",
        f"  Spreading factor      : {SPREADING_FACTOR:10d}  ({PN_KIND} code #{PN_INDEX})",
        f"  Processing gain       : {PROCESSING_GAIN_DB:10.2f} dB",
        f"  Symbol rate           : {SYMBOL_RATE_HZ/1e3:10.3f} kBd  (QPSK)",
        "-" * 74,
        f"  FEC                   : "
        + ("RS(%d,%d) + " % (RS_N, RS_K) if USE_RS else "")
        + ("CC K=%d r=1/%d" % (CC_K, len(CC_POLYS)) if USE_CC else "none")
        + (" + interleave(%d)" % INTERLEAVER_DEPTH if USE_INTERLEAVER else ""),
        f"  Total code rate       : {TOTAL_CODE_RATE:10.4f}",
        f"  Net payload rate      : {NET_BITRATE_BPS/1e3:10.3f} kbit/s",
        "-" * 74,
        f"  Preamble              : {N_PREAMBLE_PERIODS:10d} PN periods "
        f"({N_PREAMBLE_PERIODS*SPREADING_FACTOR/CHIP_RATE_HZ*1e3:.2f} ms)",
        f"  Acquisition gain      : "
        f"{10*np.log10(SPREADING_FACTOR*N_ACQ_PERIODS):10.2f} dB coherent",
        f"  Doppler search        : +/-{ACQ_FREQ_SPAN_HZ/2/1e3:8.2f} kHz "
        f"@ {ACQ_FREQ_RESOLUTION_HZ:.1f} Hz resolution",
        f"  Sync word             : {SYNC_LEN:10d} symbols",
        f"  Header                : {HEADER_SYMBOLS:10d} symbols (x{HEADER_REPEAT} repeat)",
        f"  Max payload           : {MAX_PAYLOAD_BYTES:10d} bytes "
        f"-> {MAX_PAYLOAD_SYMBOLS} symbols",
        f"  Max burst duration    : {MAX_FRAME_DURATION_S*1e3:10.2f} ms",
        "=" * 74,
    ]
    return "\n".join(lines)


# Knobs that change the transmitted waveform: both ends must agree on these, and
# `/set`-ing one at run time restarts the modem objects.  Used by the UI to warn
# you when a change will not interoperate with a peer you did not also change.
WAVEFORM_KNOBS = (
    "SPS_CHIP", "SPREADING_FACTOR", "PN_KIND", "PN_INDEX", "RRC_ROLLOFF",
    "RRC_SPAN_CHIPS", "N_PREAMBLE_PERIODS", "SYNC_LEN", "SYNC_SEED",
    "HEADER_REPEAT", "USE_RS", "RS_N", "RS_K", "USE_CC", "CC_K", "CC_POLYS",
    "CC_PUNCTURE", "USE_INTERLEAVER", "INTERLEAVER_DEPTH", "IF_OFFSET_HZ",
    "SAMP_RATE_HZ", "MAX_PAYLOAD_BYTES", "RAMP_CHIPS",
)


if __name__ == "__main__":
    print(summary())
