"""End-to-end link test over the simulation channel.

Run:  python -m dsss_qpsk.tests.test_link [snr_db]
"""

import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import numpy as np

from dsss_qpsk import config as cfg
from dsss_qpsk import channel
from dsss_qpsk.framing import Header, FT_DATA
from dsss_qpsk.modulator import Modulator
from dsss_qpsk.receiver import Receiver


def run_one(snr_db, payload=b"Hello from the DSSS/QPSK link!", cfo=1200.0,
            delay=3.37, sfo=2.0, phase=1.1, seed=1, chunk=65536, verbose=True):
    mod = Modulator(cfg)
    hdr = Header(ftype=FT_DATA, src=1, dst=2, seq=3, ack=0, payload_len=len(payload))
    burst = mod.modulate(hdr, payload)
    stream = channel.apply_channel(burst, cfg, snr_db, cfo_hz=cfo, phase=phase,
                                   delay=delay, sfo_ppm=sfo, seed=seed)
    rx = Receiver(cfg)
    frames = []
    t0 = time.time()
    for i in range(0, len(stream), chunk):
        frames += rx.process(stream[i:i + chunk])
    frames += rx.flush()
    dt = time.time() - t0
    if verbose:
        print(f"  burst {len(burst)} samples ({len(burst)/cfg.SAMP_RATE_HZ*1e3:.1f} ms), "
              f"stream {len(stream)} samples, processed in {dt*1e3:.0f} ms "
              f"({len(stream)/dt/1e6:.2f} Msps)")
        print(f"  rx stats: {rx.stats}")
        for f in frames:
            print(f"  frame stage={f.stage:20s} ok={f.ok} "
                  f"acqPSR={f.acq_psr:7.1f} syncPSR={f.sync_psr:6.2f}")
            print(f"     CFO coarse={f.coarse_cfo_hz:8.1f} fine={f.fine_cfo_hz:8.1f} "
                  f"(true {cfo:.1f})  residual={f.residual_cfo_hz:7.2f} Hz")
            print(f"     SNR chip={f.snr_chip_db:6.2f} dB (true {snr_db:.2f})  "
                  f"sym={f.snr_sym_db:6.2f} dB   EVM={f.evm_pct:5.2f}%  MER={f.mer_db:5.2f} dB")
            print(f"     header={f.header.describe() if f.header else None}")
            print(f"     RS corrections={f.rs_corrections}  CRC={f.crc_ok}  "
                  f"payload={f.payload[:60]!r}")
    good = [f for f in frames if f.ok and f.payload == payload]
    return len(good) > 0, frames, rx


if __name__ == "__main__":
    snr = float(sys.argv[1]) if len(sys.argv) > 1 else 10.0
    print(cfg.summary())
    print(f"\n--- single frame at chip SNR = {snr} dB ---")
    ok, frames, rx = run_one(snr)
    print("\nRESULT:", "PASS" if ok else "FAIL")
    sys.exit(0 if ok else 1)
