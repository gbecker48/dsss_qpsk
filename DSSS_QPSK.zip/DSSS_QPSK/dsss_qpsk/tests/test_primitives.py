"""Unit tests for the DSP / FEC primitives.  Run:  python -m dsss_qpsk.tests.test_primitives"""

import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import numpy as np

from dsss_qpsk import pn, filters, crc, conv, rs, interleave

FAIL = 0


def check(name, cond, extra=""):
    global FAIL
    print(("  PASS  " if cond else "  FAIL  ") + name + ("   " + extra if extra else ""))
    if not cond:
        FAIL += 1


print("=" * 70); print("PN CODES"); print("=" * 70)
for L in (31, 63, 127, 255):
    c = pn.mls(L)
    ac = pn.periodic_autocorr(c)
    check(f"mls({L}) peak == L", abs(ac[0] - L) < 1e-6, f"peak={ac[0]:.1f}")
    check(f"mls({L}) sidelobes == -1", np.allclose(ac[1:], -1.0, atol=1e-6),
          f"max|side|={np.max(np.abs(ac[1:])):.3f}")
    check(f"mls({L}) balanced", abs(c.sum()) == 1, f"sum={c.sum():.0f}")
g0, g1 = pn.gold(31, 3), pn.gold(31, 7)
xc = np.max(np.abs(np.real(np.fft.ifft(np.fft.fft(g0) * np.conj(np.fft.fft(g1))))))
check("gold(31) cross-correlation bounded", xc <= 9.001, f"max|xc|={xc:.2f}")

print("=" * 70); print("RRC FILTER"); print("=" * 70)
h = filters.rrc_taps(2, 12, 0.35)
check("rrc unit energy", abs(np.sum(h ** 2) - 1.0) < 1e-9)
check("rrc symmetric", np.allclose(h, h[::-1]))
rc = np.convolve(h, h)
c = len(rc) // 2
# A truncated RRC has a small residual ISI; -45 dB is plenty.
check("raised-cosine ISI below -45 dB at chip spacing",
      np.max(np.abs(rc[c + 2::2])) < 5.6e-3,
      f"max ISI={20*np.log10(np.max(np.abs(rc[c+2::2]))):.1f} dB")

print("=" * 70); print("CRC"); print("=" * 70)
check("crc16 known vector", crc.crc16(b"123456789") == 0x29B1, hex(crc.crc16(b'123456789')))
check("crc32 known vector", crc.crc32(b"123456789") == 0xCBF43926, hex(crc.crc32(b'123456789')))
ok, body = crc.check_crc32(crc.append_crc32(b"hello world"))
check("crc32 round trip", ok and body == b"hello world")
bad = bytearray(crc.append_crc32(b"hello world")); bad[3] ^= 0x20
check("crc32 detects error", not crc.check_crc32(bytes(bad))[0])

print("=" * 70); print("REED-SOLOMON"); print("=" * 70)
R = rs.ReedSolomon(255, 223)
rng = np.random.default_rng(1)
msg = bytes(rng.integers(0, 256, 223, dtype=np.uint8))
cw = R.encode_block(msg)
check("rs encode length", len(cw) == 255, str(len(cw)))
d, nc = R.decode_block(cw)
check("rs clean decode", d == msg and nc == 0)
for nerr in (1, 8, 16):
    bad = bytearray(cw)
    pos = rng.choice(255, nerr, replace=False)
    for p in pos:
        bad[p] ^= int(rng.integers(1, 256))
    d, nc = R.decode_block(bytes(bad))
    check(f"rs corrects {nerr} byte errors", d == msg and nc == nerr, f"ncorr={nc}")
bad = bytearray(cw)
for p in rng.choice(255, 17, replace=False):
    bad[p] ^= int(rng.integers(1, 256))
d, nc = R.decode_block(bytes(bad))
check("rs flags 17 errors as uncorrectable (or corrects harmlessly)", d != msg or d is None)
# shortened
short = bytes(rng.integers(0, 256, 40, dtype=np.uint8))
cws = R.encode_block(short)
bad = bytearray(cws)
for p in rng.choice(len(cws), 16, replace=False):
    bad[p] ^= int(rng.integers(1, 256))
d, nc = R.decode_block(bytes(bad))
check("rs shortened codeword corrects 16", d == short, f"ncorr={nc}")
# multi-block
big = bytes(rng.integers(0, 256, 500, dtype=np.uint8))
enc = R.encode(big)
check("rs multiblock length", len(enc) == R.encoded_len(500), f"{len(enc)} vs {R.encoded_len(500)}")
bad = bytearray(enc)
for p in rng.choice(len(enc), 40, replace=False):
    bad[p] ^= int(rng.integers(1, 256))
d, nc = R.decode(bytes(bad), 500)
check("rs multiblock corrects spread errors", d == big, f"ncorr={nc}")

print("=" * 70); print("CONVOLUTIONAL + SOFT VITERBI"); print("=" * 70)
cc = conv.ConvCode(7, [0o171, 0o133])
bits = rng.integers(0, 2, 1000, dtype=np.uint8)
coded = cc.encode(bits)
check("cc coded length", len(coded) == cc.coded_len(1000) == 2 * (1000 + 6), str(len(coded)))
llr = (1.0 - 2.0 * coded) * 10.0
dec, marg = cc.decode(llr, 1000)
check("cc noiseless decode", np.array_equal(dec, bits))

def cc_ber(ebn0_db, nbits=20000, seed=7):
    r = np.random.default_rng(seed)
    b = r.integers(0, 2, nbits, dtype=np.uint8)
    c = cc.encode(b)
    rate = 0.5
    ebn0 = 10 ** (ebn0_db / 10.0)
    esn0 = ebn0 * rate                 # energy per CODED bit
    sigma = np.sqrt(1.0 / (2 * esn0))
    x = 1.0 - 2.0 * c
    y = x + r.normal(0, sigma, len(x))
    l = 2 * y / (sigma ** 2)
    d, _ = cc.decode(l, nbits)
    return np.mean(d != b)

for ebn0 in (2.0, 3.0, 4.0, 5.0):
    ber = cc_ber(ebn0)
    print(f"        Eb/N0={ebn0:4.1f} dB  ->  BER = {ber:.2e}")
check("cc BER at 4 dB < 1e-3", cc_ber(4.0) < 1e-3)
check("cc BER at 5 dB < 2e-4", cc_ber(5.0) < 2e-4)
from scipy.special import erfc as _erfc
_uncoded = 0.5 * _erfc(np.sqrt(10 ** 0.4))
check("cc soft beats uncoded by >100x at 4 dB", cc_ber(4.0) < _uncoded / 100,
      f"uncoded BER={_uncoded:.2e}")

t0 = time.time(); cc.decode(np.zeros(20000, dtype=np.float32), 9994); dt = time.time() - t0
print(f"        Viterbi speed: {dt*1000:.1f} ms for 10 kbit -> {10000/dt/1000:.0f} kbit/s")
check("viterbi fast enough for the link", dt < 1.0, f"{dt:.3f} s")

print("=" * 70); print("INTERLEAVER"); print("=" * 70)
for n in (1, 2, 63, 640, 1001):
    x = np.arange(n)
    y = interleave.interleave(x, 64)
    check(f"interleave({n}) is a permutation", sorted(y.tolist()) == list(range(n)))
    check(f"deinterleave({n}) inverts", np.array_equal(interleave.deinterleave(y, 64), x))
# A burst on the AIR hits consecutive transmitted positions; after
# deinterleaving those must be far apart in the coded-bit stream.
y = interleave.interleave(np.arange(4096), 64)
src = np.sort(y[1000:1040])                # 40 consecutive on-air positions
check("interleaver spreads a 40-bit on-air burst by >= 40 coded bits",
      np.min(np.diff(src)) >= 40, f"min spacing={np.min(np.diff(src))}")

print()
print("=" * 70)
print(f"  {'ALL PRIMITIVE TESTS PASSED' if FAIL == 0 else str(FAIL) + ' FAILURES'}")
print("=" * 70)
sys.exit(1 if FAIL else 0)
