"""
Receiver robustness tests -- the failure modes that actually bit us on hardware.

    python -m dsss_qpsk.tests.test_robustness

1. BUFFER OVERRUN RECOVERY
   The sample buffer hitting its cap while a frame is being decoded used to trim
   the front out from under the in-progress tracker.  The receiver then sat in
   SYNC/HEADER/PAYLOAD, unable ever to satisfy its bounds check, deaf to
   everything, until a timeout fired ~0.7 s later.  The message that arrived in
   that window was silently lost and the link layer timed out.
   The receiver must now abandon the frame cleanly and hear the NEXT burst.

2. TRUNCATED BURST
   A burst that stops mid-payload (transmitter stopped, samples dropped) must not
   wedge the receiver.

3. BACK TO BACK BURSTS
   Short gaps, like DATA immediately followed by an ACK, must all decode.

4. DEAF TIME
   The fraction of samples during which the receiver cannot detect a new preamble
   must stay small on a normally loaded link.

5. STRONG SIGNAL, BACK TO BACK
   The one that only showed up once bulk file transfer started streaming bursts
   back to back on a cable.  The sync search used to accept the narrow window on
   a peak-to-MEDIAN ratio; inside a strong burst that "background" is a stretch
   of constant preamble rather than noise, so the ratio passed on a spurious
   peak and the wide search never ran.  Result: 2/2 frames at -13 dB and 1/2 at
   +6 dB -- a receiver that got WORSE as the signal got better.  This sweeps the
   gap and the SNR together, because either one alone hides it.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import numpy as np

from dsss_qpsk import channel
from dsss_qpsk import config as cfg
from dsss_qpsk.framing import FT_ACK, FT_DATA, Header
from dsss_qpsk.modulator import Modulator
from dsss_qpsk.receiver import Receiver

FAIL = 0


def check(name, cond, extra=""):
    global FAIL
    print(("  PASS  " if cond else "  FAIL  ") + name + ("   " + extra if extra else ""))
    if not cond:
        FAIL += 1


def build_stream(specs, snr_db=-8.0, seed=3):
    """specs: list of (gap_ms, payload_bytes or None for ACK, truncate_frac)."""
    rng = np.random.default_rng(seed)
    mod = Modulator(cfg)
    parts, sent = [], []
    p_sig = None
    for i, (gap_ms, nbytes, trunc) in enumerate(specs):
        if nbytes is None:
            pl = b""
            h = Header(ftype=FT_ACK, src=1, dst=2, seq=0, ack=i & 0xF, payload_len=0)
        else:
            pl = bytes(rng.integers(0, 256, nbytes, dtype=np.uint8))
            h = Header(ftype=FT_DATA, src=1, dst=2, seq=i & 0xF, payload_len=len(pl))
        b = mod.modulate(h, pl)
        if p_sig is None:
            p_sig = float(np.mean(np.abs(b) ** 2))
        if trunc < 1.0:
            b = b[:int(len(b) * trunc)]
        else:
            sent.append(pl)
        parts.append(np.zeros(int(gap_ms * 1e-3 * cfg.SAMP_RATE_HZ), dtype=np.complex128))
        bb = channel.fractional_resample(
            np.concatenate([np.zeros(32), b.astype(np.complex128), np.zeros(64)]), 3.3, 1.0)
        n = np.arange(len(bb))
        bb = bb * np.exp(1j * (2 * np.pi * 800.0 * n / cfg.SAMP_RATE_HZ
                               + rng.uniform(-np.pi, np.pi)))
        parts.append(bb)
    parts.append(np.zeros(int(0.25 * cfg.SAMP_RATE_HZ), dtype=np.complex128))
    x = np.concatenate(parts)
    sigma2 = p_sig * cfg.SPS_CHIP / (10 ** (snr_db / 10.0))
    x = x + np.sqrt(sigma2 / 2) * (rng.standard_normal(len(x))
                                   + 1j * rng.standard_normal(len(x)))
    return x.astype(np.complex64), sent


def run(stream, chunk=1 << 15):
    rx = Receiver(cfg)
    frames = []
    for i in range(0, len(stream), chunk):
        frames += rx.process(stream[i:i + chunk])
    frames += rx.flush()
    return rx, frames


print("=" * 72)
print("1. BUFFER OVERRUN RECOVERY  (the bug that lost the following message)")
print("=" * 72)
saved_margin = cfg.RX_BUFFER_MARGIN
# Squeeze the buffer so the cap is guaranteed to trip while a big frame decodes.
cfg.RX_BUFFER_MARGIN = 1
big = cfg.MAX_PAYLOAD_BYTES
stream, sent = build_stream([(30, big, 1.0), (40, 96, 1.0), (40, 96, 1.0)])
rx, frames = run(stream)
good = [f for f in frames if f.ok and f.payload]
print(f"      stats: {rx.stats}")
print(f"      decoded {len(good)} of {len(sent)} messages; "
      f"buffer_aborts={rx.stats.buffer_aborts} stalls={rx.stats.stalls}")
# The point is not that every frame survives a deliberately undersized buffer --
# it is that the receiver RECOVERS and still hears the ones that follow.
later = [f for f in good if len(f.payload) == 96]
check("receiver still decodes bursts after a buffer abort", len(later) >= 2,
      f"got {len(later)}/2 of the later messages")
check("state machine returns to SEARCH", rx.state == "SEARCH", rx.state)
cfg.RX_BUFFER_MARGIN = saved_margin

print()
print("=" * 72)
print("2. NORMAL BUFFER, SAME TRAFFIC -- nothing should be lost at all")
print("=" * 72)
stream, sent = build_stream([(30, big, 1.0), (40, 96, 1.0), (40, 96, 1.0)])
rx, frames = run(stream)
good = [f for f in frames if f.ok and f.payload]
print(f"      stats: {rx.stats}")
check("all messages decoded", len(good) == len(sent), f"{len(good)}/{len(sent)}")
check("payloads match", all(g.payload in sent for g in good))
check("no buffer aborts", rx.stats.buffer_aborts == 0, str(rx.stats.buffer_aborts))
check("peak buffer below the cap",
      rx.stats.max_buffer_samples <= cfg.RX_BUFFER_SAMPLES * cfg.RX_BUFFER_MARGIN,
      f"{rx.stats.max_buffer_samples} vs cap "
      f"{cfg.RX_BUFFER_SAMPLES*cfg.RX_BUFFER_MARGIN}")

print()
print("=" * 72)
print("3. TRUNCATED BURST must not wedge the receiver")
print("=" * 72)
stream, sent = build_stream([(20, 256, 0.55), (60, 128, 1.0), (40, 128, 1.0)])
rx, frames = run(stream)
good = [f for f in frames if f.ok and f.payload]
print(f"      stats: {rx.stats}")
check("the two complete bursts after a truncated one still decode",
      len(good) == 2, f"{len(good)}/2")
check("state machine recovered", rx.state == "SEARCH", rx.state)

print()
print("=" * 72)
print("4. BACK TO BACK  (DATA then ACK with a 5 ms gap, repeatedly)")
print("=" * 72)
specs = []
for i in range(4):
    specs.append((25, 64, 1.0))
    specs.append((5, None, 1.0))
stream, sent = build_stream(specs)
rx, frames = run(stream)
good = [f for f in frames if f.ok]
data = [f for f in good if f.header and f.header.ftype == FT_DATA]
acks = [f for f in good if f.header and f.header.ftype == FT_ACK]
print(f"      stats: {rx.stats}")
check("all 4 DATA decoded", len(data) == 4, f"{len(data)}/4")
check("all 4 ACK decoded", len(acks) == 4, f"{len(acks)}/4")

deaf = rx.stats.deaf_samples / max(rx.stats.samples_processed, 1)
print(f"      deaf fraction: {deaf*100:.1f}% of samples "
      f"({rx.stats.deaf_samples/cfg.SAMP_RATE_HZ*1e3:.0f} ms)")
check("receiver is listening most of the time", deaf < 0.75, f"{deaf*100:.1f}%")

print()
print("=" * 72)
print("5. STRONG SIGNAL, BACK TO BACK  (the bug that got worse as SNR improved)")
print("=" * 72)
worst = ((0.0, 0), 1e9)
for snr in (-13.0, -6.0, 0.0, 6.0, 14.0, 24.0, 40.0):
    for gap in (2, 5, 20, 60, 120, 200):
        stream, sent = build_stream([(20, 256, 1.0), (gap, 256, 1.0)], snr_db=snr)
        rx, frames = run(stream)
        got = {bytes(f.payload) for f in frames if f.ok}
        pct = 100.0 * sum(1 for p in sent if p in got) / max(len(sent), 1)
        if pct < worst[1]:
            worst = ((snr, gap), pct)

print(f"      swept 7 SNRs x 6 gaps; worst case {worst[1]:.0f}% at "
      f"SNR {worst[0][0]:+.0f} dB, gap {worst[0][1]} ms")
check("both bursts decode at every SNR and every gap", worst[1] >= 100.0,
      f"worst {worst[1]:.0f}% at SNR {worst[0][0]:+.0f} dB / {worst[0][1]} ms gap")

print()
print("=" * 72)
print(f"  {'ALL ROBUSTNESS TESTS PASSED' if FAIL == 0 else str(FAIL) + ' FAILURES'}")
print("=" * 72)
sys.exit(1 if FAIL else 0)
