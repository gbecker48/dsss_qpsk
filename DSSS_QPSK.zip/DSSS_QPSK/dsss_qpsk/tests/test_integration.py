"""
Headless end-to-end test of the LINK layer (framing + ARQ + metrics) over a
transport.  This is the closest thing to running the real radio that does not
need a radio.

    python -m dsss_qpsk.tests.test_integration            # numpy sim transport
    python -m dsss_qpsk.tests.test_integration --gr       # GNU Radio flowgraph
    python -m dsss_qpsk.tests.test_integration --snr -12
"""

import argparse
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import numpy as np

from dsss_qpsk import config as cfg
from dsss_qpsk.link import LinkManager


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--gr", action="store_true", help="use the GNU Radio flowgraph")
    p.add_argument("--snr", type=float, default=-10.0)
    p.add_argument("--messages", type=int, default=4)
    p.add_argument("--bytes", type=int, default=64)
    p.add_argument("--timeout", type=float, default=90.0)
    a = p.parse_args()

    from dsss_qpsk import transports
    if a.gr:
        transport = transports.GrLoopbackTransport(cfg, snr_db=a.snr)
        name = "GrLoopbackTransport (GNU Radio)"
    else:
        transport = transports.SimTransport(cfg, snr_db=a.snr)
        name = "SimTransport (numpy)"

    print(cfg.summary())
    print(f"\ntransport: {name}   chip SNR {a.snr:+.1f} dB")
    print(f"sending {a.messages} messages of {a.bytes} bytes\n")

    link = LinkManager(cfg, transport)
    transport.start()
    link.start()

    rng = np.random.default_rng(4)
    sent = []
    for i in range(a.messages):
        msg = f"msg {i:03d} " + "".join(
            chr(int(c)) for c in rng.integers(33, 126, max(0, a.bytes - 9)))
        sent.append(msg.encode())
        link.send_text(msg)

    t0 = time.time()
    received = []
    seen = 0
    while time.time() - t0 < a.timeout:
        ev = list(link.events)
        for e in ev[seen:]:
            tag = {"rx": "<<", "tx": ">>", "ack": "ok", "timeout": "!!",
                   "error": "XX"}.get(e.kind, "..")
            extra = ""
            if e.kind == "rx" and e.frame is not None:
                f = e.frame
                extra = (f"   [chipSNR {f.snr_chip_db:+5.1f} dB  symSNR {f.snr_sym_db:5.1f} dB"
                         f"  EVM {f.evm_pct:5.1f}%  RS {max(f.rs_corrections,0):2d}"
                         f"  CFO {f.fine_cfo_hz:+7.1f} Hz]")
                received.append(e.text.encode())
            print(f"  {tag} {e.text[:52]:52s}{extra}")
        seen = len(ev)
        if len(received) >= a.messages and link.queue_depth() == 0:
            break
        time.sleep(0.1)

    time.sleep(0.5)
    link.stop()
    transport.stop()

    print("\n" + "=" * 74)
    ok = all(s in received for s in sent)
    print(f"  messages sent     : {len(sent)}")
    print(f"  messages received : {len(received)}")
    print(f"  all matched       : {ok}")
    print(f"  retries           : {link.total_retries}   lost: {link.lost_messages}")
    print(f"  mean RTT          : {link.rtt_avg*1e3:.0f} ms")
    print(f"  rx stats          : {link.rx.stats}")
    if hasattr(transport, "sink"):
        print(f"  gr sink dropped   : {transport.sink.dropped} samples, "
              f"max queue backlog {transport.sink.max_backlog}, "
              f"errors {transport.sink.errors}")
        print(f"  gr source bursts  : {transport.src.bursts_sent}")
    print(f"  RESULT            : {'PASS' if ok else 'FAIL'}")
    print("=" * 74)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
