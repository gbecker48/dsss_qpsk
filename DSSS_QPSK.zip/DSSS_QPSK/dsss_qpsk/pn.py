"""
pn.py -- spreading code generation.

Two families:
  * m-sequence (maximal length LFSR sequence).  Period N = 2^m - 1.
    Periodic autocorrelation is perfect: N at zero lag, exactly -1 everywhere
    else.  This is the best choice for a single link because the acquisition
    correlation peak has no sidelobe structure to trip the detector.
  * Gold codes.  Built by XOR-ing a "preferred pair" of m-sequences at every
    relative shift.  Autocorrelation is slightly worse (3-valued sidelobes) but
    you get 2^m + 1 codes with bounded cross-correlation, so several links can
    share the band.

Both return bipolar numpy arrays of +1.0 / -1.0 (float32), which is what the
spreader multiplies the QPSK symbols by.
"""

from __future__ import annotations

import numpy as np

# Primitive polynomials (taps) for maximal-length LFSRs, given as the list of
# tap positions (register stages that feed the XOR), 1-indexed, MSB first.
# Source: standard tables.  Each entry: m -> (poly_a, poly_b) where poly_b is
# the "preferred pair" partner used for Gold code generation.
_MLS_TAPS = {
    4:  ([4, 1],          [4, 3, 2, 1]),
    5:  ([5, 3],          [5, 4, 3, 2]),
    6:  ([6, 1],          [6, 5, 2, 1]),
    7:  ([7, 3],          [7, 3, 2, 1]),
    8:  ([8, 6, 5, 3],    [8, 6, 5, 2]),
    9:  ([9, 5],          [9, 6, 4, 3]),
    10: ([10, 7],         [10, 9, 8, 5]),
}


def _lfsr(taps: list[int], m: int, seed: int | None = None) -> np.ndarray:
    """Generate one full period (2^m - 1) of a binary LFSR sequence (0/1)."""
    n = (1 << m) - 1
    reg = np.ones(m, dtype=np.uint8)
    if seed is not None:
        for i in range(m):
            reg[i] = (seed >> i) & 1
        if not reg.any():
            reg[:] = 1
    out = np.empty(n, dtype=np.uint8)
    for i in range(n):
        out[i] = reg[-1]
        fb = 0
        for t in taps:
            fb ^= int(reg[t - 1])
        reg[1:] = reg[:-1]
        reg[0] = fb
    return out


def mls(length: int) -> np.ndarray:
    """Maximal-length sequence of the given period (must be 2^m - 1)."""
    m = int(round(np.log2(length + 1)))
    if (1 << m) - 1 != length:
        raise ValueError(
            f"m-sequence length must be 2^m-1; got {length}. "
            f"Valid: {[ (1<<k)-1 for k in _MLS_TAPS ]}")
    if m not in _MLS_TAPS:
        raise ValueError(f"no tap table for m={m}")
    bits = _lfsr(_MLS_TAPS[m][0], m)
    return (1.0 - 2.0 * bits).astype(np.float32)


def gold(length: int, index: int) -> np.ndarray:
    """Gold code number `index` from the preferred pair of the given length.

    index 0        -> first m-sequence
    index 1        -> second m-sequence
    index 2..N+1   -> XOR of the pair at relative shift (index-2)
    """
    m = int(round(np.log2(length + 1)))
    if (1 << m) - 1 != length or m not in _MLS_TAPS:
        raise ValueError(f"gold code length must be 2^m-1 with a known pair; got {length}")
    ta, tb = _MLS_TAPS[m]
    a = _lfsr(ta, m)
    b = _lfsr(tb, m)
    if index == 0:
        bits = a
    elif index == 1:
        bits = b
    else:
        bits = a ^ np.roll(b, -(index - 2))
    return (1.0 - 2.0 * bits).astype(np.float32)


def spreading_code(kind: str, length: int, index: int = 0) -> np.ndarray:
    """Dispatch on config.PN_KIND."""
    kind = kind.lower()
    if kind == "mls":
        return mls(length)
    if kind == "gold":
        return gold(length, index)
    raise ValueError(f"unknown PN_KIND {kind!r} (use 'mls' or 'gold')")


def periodic_autocorr(code: np.ndarray) -> np.ndarray:
    """Periodic (circular) autocorrelation -- useful for sanity checks/plots."""
    n = len(code)
    f = np.fft.fft(code.astype(np.float64), n)
    return np.real(np.fft.ifft(f * np.conj(f)))


def peak_to_sidelobe_db(code: np.ndarray) -> float:
    ac = periodic_autocorr(code)
    peak = ac[0]
    side = np.max(np.abs(ac[1:]))
    return 20.0 * np.log10(peak / max(side, 1e-12))
