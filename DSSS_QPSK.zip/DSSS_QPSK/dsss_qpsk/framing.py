"""
framing.py -- frame header, sync word, and the byte-level encode/decode chain.

FRAME LAYOUT ON THE AIR
-----------------------
  [ramp] [ PREAMBLE ] [ SYNC ] [ HEADER ] [ PAYLOAD ] [ramp]

  PREAMBLE : N_PREAMBLE_PERIODS symbols, every one of them the constant value
             1+0j, so the transmitted chips are just the PN code repeated.
             This is what makes below-the-noise-floor acquisition possible: the
             receiver can coherently integrate the whole thing without knowing
             any data.
  SYNC     : SYNC_LEN known QPSK symbols.  Marks the exact frame start, resolves
             the 90-degree QPSK phase ambiguity, and provides the data-aided
             fine-frequency / amplitude / noise-variance estimates.
  HEADER   : 8 bytes -> CRC16 -> convolutional code -> repeated HEADER_REPEAT
             times -> QPSK.  Fixed length, so the receiver can always decode it
             without knowing the payload size.
  PAYLOAD  : message -> CRC32 -> Reed-Solomon -> convolutional code ->
             interleaver -> QPSK.  Length is carried in the header.

HEADER BYTES
------------
  0 : version (high 4 bits) | frame type (low 4 bits)
  1 : source node id
  2 : destination node id   (255 = broadcast)
  3 : sequence number (high 4 bits) | acknowledged sequence (low 4 bits)
  4 : payload length, high byte
  5 : payload length, low byte
  6 : CRC-16 high byte
  7 : CRC-16 low byte
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from . import crc

PROTOCOL_VERSION = 1

FT_DATA = 0
FT_ACK = 1
FT_NAK = 2
FT_PING = 3
FT_BEACON = 4
# STREAM is a DATA frame that is deliberately NOT acknowledged.  Bulk file
# segments use it: the file layer already knows exactly which pieces it is
# missing and asks for them by index, so paying a round trip per segment buys
# nothing.  Identical waveform to DATA -- only the scheduling differs.
FT_STREAM = 5
FT_NAMES = {FT_DATA: "DATA", FT_ACK: "ACK", FT_NAK: "NAK",
            FT_PING: "PING", FT_BEACON: "BEACON", FT_STREAM: "STREAM"}

HEADER_BYTES = 8


@dataclass
class Header:
    ftype: int = FT_DATA
    src: int = 1
    dst: int = 255
    seq: int = 0
    ack: int = 0
    payload_len: int = 0
    version: int = PROTOCOL_VERSION

    def pack(self) -> bytes:
        b = bytearray(6)
        b[0] = ((self.version & 0x0F) << 4) | (self.ftype & 0x0F)
        b[1] = self.src & 0xFF
        b[2] = self.dst & 0xFF
        b[3] = ((self.seq & 0x0F) << 4) | (self.ack & 0x0F)
        b[4] = (self.payload_len >> 8) & 0xFF
        b[5] = self.payload_len & 0xFF
        c = crc.crc16(bytes(b))
        return bytes(b) + bytes([(c >> 8) & 0xFF, c & 0xFF])

    @staticmethod
    def unpack(data: bytes):
        """Returns (Header, ok).  ok is False if the header CRC fails."""
        if len(data) != HEADER_BYTES:
            return None, False
        body, tail = data[:6], data[6:]
        if crc.crc16(body) != ((tail[0] << 8) | tail[1]):
            return None, False
        h = Header(
            version=(body[0] >> 4) & 0x0F,
            ftype=body[0] & 0x0F,
            src=body[1],
            dst=body[2],
            seq=(body[3] >> 4) & 0x0F,
            ack=body[3] & 0x0F,
            payload_len=(body[4] << 8) | body[5],
        )
        return h, True

    def describe(self) -> str:
        return (f"{FT_NAMES.get(self.ftype, '?%d' % self.ftype)} "
                f"{self.src}->{self.dst} seq={self.seq} ack={self.ack} "
                f"len={self.payload_len}")


# ---------------------------------------------------------------- sync word
_SYNC_CACHE: dict[tuple[int, int], np.ndarray] = {}


def sync_word(length: int, seed: int) -> np.ndarray:
    """Deterministic QPSK sync word with good aperiodic autocorrelation.

    Search a few thousand seeded random QPSK sequences and keep the one with
    the lowest peak autocorrelation sidelobe.  A low sidelobe means the
    correlator gives one sharp, unambiguous frame-start peak; a low DC term
    (|sum|) means the constant-valued PREAMBLE that precedes it does not
    produce a false peak of its own.

    Deterministic given (length, seed), so both ends generate the same word
    without transmitting it.
    """
    key = (int(length), int(seed))
    cached = _SYNC_CACHE.get(key)
    if cached is not None:
        return cached

    rng = np.random.default_rng(seed)
    n = int(length)
    best, best_score = None, np.inf
    qpsk = np.array([1 + 1j, -1 + 1j, -1 - 1j, 1 - 1j], dtype=np.complex128) / np.sqrt(2)
    for _ in range(3000):
        s = qpsk[rng.integers(0, 4, n)]
        # aperiodic autocorrelation sidelobes
        ac = np.correlate(s, s, mode="full")
        ac = np.abs(ac) / n
        ac[n - 1] = 0.0
        side = ac.max()
        dc = abs(s.sum()) / n
        score = side + 2.0 * dc          # weight the DC term: it is what the
        if score < best_score:           # constant preamble looks like
            best_score, best = score, s
    _SYNC_CACHE[key] = best.astype(np.complex64)
    return _SYNC_CACHE[key]


def sync_quality(s: np.ndarray) -> tuple[float, float]:
    n = len(s)
    ac = np.abs(np.correlate(s, s, mode="full")) / n
    ac[n - 1] = 0.0
    return float(ac.max()), float(abs(s.sum()) / n)


# ------------------------------------------------------------ bit utilities
def bytes_to_bits(data: bytes) -> np.ndarray:
    return np.unpackbits(np.frombuffer(data, dtype=np.uint8))


def bits_to_bytes(bits: np.ndarray) -> bytes:
    b = np.asarray(bits, dtype=np.uint8)
    if len(b) % 8:
        b = np.concatenate([b, np.zeros(8 - len(b) % 8, dtype=np.uint8)])
    return np.packbits(b).tobytes()
