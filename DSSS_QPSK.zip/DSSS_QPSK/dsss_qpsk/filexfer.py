"""
filexfer.py -- send whole files (or any blob) over the link, reliably.

WHY THIS EXISTS
    The link layer below this one moves ONE message of at most
    cfg.MAX_PAYLOAD_BYTES bytes at a time, with stop-and-wait ARQ.  That is the
    right primitive for a chat message and the wrong one for a 200 kB file: you
    would have to split it by hand, you would not know if a piece went missing,
    and you would have no idea how far along you were.

    This module is the application layer that sits on top.  It adds:
      * a one-byte tag so text and file traffic can share the same link,
      * segmentation and reassembly with a manifest (name, size, CRC-32),
      * selective repair -- either end can ask for the exact pieces it is
        missing, so a single permanently-lost segment costs one retransmission
        instead of the whole file,
      * pacing, so a big transfer never starves an interactive message,
      * live progress: bytes, segments, rate, ETA, per-transfer.

WIRE FORMAT (inside the link payload, after FEC -- this layer adds no coding)

    TEXT      [0x01] utf-8 bytes
    MANIFEST  [0x02][xid][nseg u16][size u32][crc32 u32][namelen u8][name...]
    SEGMENT   [0x03][xid][index u16][data...]
    REPAIR    [0x04][xid][count u16][index u16] x count      (0xFFFF = manifest)
    DONE      [0x05][xid][status]      status 0 = ok, 1 = CRC mismatch
    END       [0x06][xid]               sender has transmitted every segment

    xid is a transfer id, 0..255, wrapping.  It only has to be unique among the
    transfers in flight, which in practice is one or two.

HOW RELIABILITY IS LAYERED
    Each segment is an ordinary link message, so it already gets the link's own
    stop-and-wait ARQ and its retries.  This layer only handles what the link
    gives UP on: when the link reports a message lost after ARQ_MAX_RETRIES,
    the sender re-queues that segment.  Independently, the receiver notices a
    transfer that has gone quiet with holes in it and asks for them by index.
    Both paths converge on the same result; either alone is enough.

TUNING (all in config.py)
    FILE_SEGMENT_BYTES   payload bytes per segment.  Bigger = fewer round trips
                         = much faster, since stop-and-wait is latency-bound.
                         Must be <= MAX_PAYLOAD_BYTES.
    FILE_QUEUE_AHEAD     how many segments to keep queued at the link.  Small,
                         so a chat message you type mid-transfer goes out next
                         instead of behind 2000 segments.
    FILE_REPAIR_IDLE_S   how long a receiver waits with holes before asking.
    FILE_REPAIR_MAX      how many times it will ask before giving up.
    FILE_INBOX           where received files are written.
"""

from __future__ import annotations

import os
import struct
import threading
import time
import zlib
from dataclasses import dataclass, field
from pathlib import Path

APP_TEXT = 0x01
APP_MANIFEST = 0x02
APP_SEGMENT = 0x03
APP_REPAIR = 0x04
APP_DONE = 0x05
APP_END = 0x06

MANIFEST_INDEX = 0xFFFF        # "I am missing the manifest itself"

_MANIFEST_FMT = ">BBHIIB"      # tag, xid, nseg, size, crc32, namelen
_MANIFEST_HEAD = struct.calcsize(_MANIFEST_FMT)
_SEG_FMT = ">BBH"              # tag, xid, index
SEG_HEADER = struct.calcsize(_SEG_FMT)


# --------------------------------------------------------------------------
# encoding helpers -- kept as free functions so the tests can call them alone
# --------------------------------------------------------------------------
def encode_text(text: str) -> bytes:
    return bytes([APP_TEXT]) + text.encode("utf-8", errors="replace")


def encode_manifest(xid: int, name: str, nseg: int, size: int, crc: int) -> bytes:
    nb = name.encode("utf-8", errors="replace")[:255]
    return struct.pack(_MANIFEST_FMT, APP_MANIFEST, xid & 0xFF, nseg & 0xFFFF,
                       size & 0xFFFFFFFF, crc & 0xFFFFFFFF, len(nb)) + nb


def encode_segment(xid: int, index: int, data: bytes) -> bytes:
    return struct.pack(_SEG_FMT, APP_SEGMENT, xid & 0xFF, index & 0xFFFF) + data


def encode_repair(xid: int, indices) -> bytes:
    idx = list(indices)[:200]
    return (struct.pack(">BBH", APP_REPAIR, xid & 0xFF, len(idx))
            + b"".join(struct.pack(">H", i & 0xFFFF) for i in idx))


def encode_done(xid: int, status: int) -> bytes:
    return struct.pack(">BBB", APP_DONE, xid & 0xFF, status & 0xFF)


def encode_end(xid: int) -> bytes:
    return struct.pack(">BB", APP_END, xid & 0xFF)


def decode(payload: bytes):
    """Returns (tag, dict) or (None, {}) if it is not something we understand.

    Anything unrecognised is handed back as text, so an old build on the far end
    -- or a hand-crafted frame -- still shows up in the log instead of vanishing.
    """
    if not payload:
        return APP_TEXT, {"text": ""}
    tag = payload[0]
    try:
        if tag == APP_TEXT:
            return APP_TEXT, {"text": payload[1:].decode("utf-8", errors="replace")}
        if tag == APP_MANIFEST:
            _, xid, nseg, size, crc, nlen = struct.unpack(
                _MANIFEST_FMT, payload[:_MANIFEST_HEAD])
            name = payload[_MANIFEST_HEAD:_MANIFEST_HEAD + nlen].decode(
                "utf-8", errors="replace")
            return APP_MANIFEST, {"xid": xid, "nseg": nseg, "size": size,
                                  "crc": crc, "name": name}
        if tag == APP_SEGMENT:
            _, xid, index = struct.unpack(_SEG_FMT, payload[:SEG_HEADER])
            return APP_SEGMENT, {"xid": xid, "index": index,
                                 "data": payload[SEG_HEADER:]}
        if tag == APP_REPAIR:
            _, xid, count = struct.unpack(">BBH", payload[:4])
            idx = [struct.unpack(">H", payload[4 + 2 * i:6 + 2 * i])[0]
                   for i in range(min(count, (len(payload) - 4) // 2))]
            return APP_REPAIR, {"xid": xid, "indices": idx}
        if tag == APP_DONE:
            _, xid, status = struct.unpack(">BBB", payload[:3])
            return APP_DONE, {"xid": xid, "status": status}
        if tag == APP_END:
            _, xid = struct.unpack(">BB", payload[:2])
            return APP_END, {"xid": xid}
    except (struct.error, IndexError):
        return None, {}
    return APP_TEXT, {"text": payload.decode("utf-8", errors="replace")}


def human(n: float) -> str:
    for unit in ("B", "kB", "MB", "GB"):
        if abs(n) < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024.0
    return f"{n:.1f} GB"


# --------------------------------------------------------------------------
@dataclass
class Outgoing:
    xid: int
    name: str
    data: bytes
    seg_bytes: int
    crc: int
    started: float = field(default_factory=time.monotonic)
    manifest_sent: bool = False
    queued: set = field(default_factory=set)      # handed to the link
    done: set = field(default_factory=set)        # link confirmed delivery
    lost: list = field(default_factory=list)      # link gave up; resend these
    finished: float = 0.0
    cancelled: bool = False
    peer_status: int | None = None                # what the far end reported
    cursor: int = 0                               # first segment never queued

    @property
    def nseg(self) -> int:
        return max(1, -(-len(self.data) // self.seg_bytes))

    def segment(self, i: int) -> bytes:
        return self.data[i * self.seg_bytes:(i + 1) * self.seg_bytes]

    def progress(self) -> dict:
        n = self.nseg
        sent = len(self.done)
        el = max((self.finished or time.monotonic()) - self.started, 1e-6)
        bytes_done = min(sent * self.seg_bytes, len(self.data))
        rate = bytes_done / el
        left = len(self.data) - bytes_done
        return {
            "dir": "tx", "xid": self.xid, "name": self.name,
            "size": len(self.data), "nseg": n, "seg_done": sent,
            "bytes_done": bytes_done,
            "pct": 100.0 * sent / n,
            "rate": rate, "eta": (left / rate) if rate > 1 and left else 0.0,
            "elapsed": el,
            "state": ("cancelled" if self.cancelled else
                      "failed" if self.peer_status not in (None, 0) else
                      "confirmed" if self.peer_status == 0 else
                      "awaiting confirmation" if self.finished else "sending"),
            "status": self.peer_status,
        }


@dataclass
class Incoming:
    xid: int
    started: float = field(default_factory=time.monotonic)
    name: str = ""
    size: int = 0
    nseg: int = 0
    crc: int = 0
    have_manifest: bool = False
    parts: dict = field(default_factory=dict)
    last_rx: float = field(default_factory=time.monotonic)
    repairs: int = 0
    finished: float = 0.0
    path: str = ""
    ok: bool | None = None

    def missing(self):
        if not self.have_manifest:
            return [MANIFEST_INDEX]
        return [i for i in range(self.nseg) if i not in self.parts]

    def progress(self) -> dict:
        n = self.nseg or max(len(self.parts), 1)
        got = len(self.parts)
        el = max((self.finished or time.monotonic()) - self.started, 1e-6)
        bytes_done = sum(len(v) for v in self.parts.values())
        rate = bytes_done / el
        left = max(self.size - bytes_done, 0)
        return {
            "dir": "rx", "xid": self.xid,
            "name": self.name or f"(xid {self.xid})",
            "size": self.size, "nseg": n, "seg_done": got,
            "bytes_done": bytes_done,
            "pct": 100.0 * got / n,
            "rate": rate, "eta": (left / rate) if rate > 1 and left else 0.0,
            "elapsed": el, "repairs": self.repairs,
            "state": ("complete" if self.ok else
                      "failed" if self.ok is False else "receiving"),
            "path": self.path,
        }


# --------------------------------------------------------------------------
class FileTransfer:
    """Owns every transfer in both directions.  The link calls into this."""

    def __init__(self, cfg, send_payload, log):
        self.cfg = cfg
        # callable(payload_bytes, reliable) -> queue exactly one link message.
        # reliable=True  : normal stop-and-wait ARQ, retried until acknowledged.
        # reliable=False : an unacknowledged STREAM frame (see stream_mode).
        self._send = send_payload
        self._log = log                    # callable(kind, text)
        self._lock = threading.RLock()
        self._next_xid = 0
        self.out: dict[int, Outgoing] = {}
        self.inc: dict[int, Incoming] = {}
        self.history: list[dict] = []      # finished transfers, newest last
        self._pending_seg: dict[bytes, tuple] = {}   # payload -> (xid, index)

    # ------------------------------------------------------------- send side
    def stream_mode(self) -> bool:
        """Send file segments unacknowledged, and repair the holes afterwards.

        Stop-and-wait ARQ costs one full round trip per segment.  On the radio
        that round trip is ~200-700 ms while the burst itself is 166 ms, so more
        than half the time the transmitter is idle waiting for an ACK that the
        file layer does not actually need -- it already knows exactly which
        segments are missing and can ask for them by index.

        With STREAM frames the segments go out back to back, paced to the air
        time of the burst, and the receiver asks once at the end for whatever it
        did not get.  Same waveform, same frames, same sensitivity: this changes
        only WHEN we transmit, never WHAT.  Measured ~5x faster on hardware.

        Control traffic (manifest, repair requests, the final confirmation) stays
        reliable, because losing one of those stalls the whole transfer.
        """
        return bool(getattr(self.cfg, "FILE_STREAM_MODE", True))

    def seg_bytes(self) -> int:
        n = int(getattr(self.cfg, "FILE_SEGMENT_BYTES", self.cfg.MAX_PAYLOAD_BYTES))
        return max(16, min(n, self.cfg.MAX_PAYLOAD_BYTES) - SEG_HEADER)

    def send_file(self, path) -> dict:
        p = Path(path).expanduser()
        data = p.read_bytes()
        return self.send_blob(data, p.name)

    def send_blob(self, data: bytes, name: str) -> dict:
        limit = int(getattr(self.cfg, "FILE_MAX_BYTES", 16 << 20))
        if len(data) > limit:
            raise ValueError(f"{human(len(data))} exceeds FILE_MAX_BYTES "
                             f"({human(limit)})")
        with self._lock:
            xid = self._next_xid
            self._next_xid = (self._next_xid + 1) & 0xFF
            t = Outgoing(xid=xid, name=name, data=data,
                         seg_bytes=self.seg_bytes(), crc=zlib.crc32(data) & 0xFFFFFFFF)
            self.out[xid] = t
        self._log("info", f"sending {name}  {human(len(data))} in {t.nseg} segments "
                          f"of {t.seg_bytes} B  (xid {xid})")
        self.tick()
        return t.progress()

    def cancel(self, xid: int) -> bool:
        with self._lock:
            t = self.out.get(int(xid))
            if t is None:
                return False
            t.cancelled = True
            t.finished = time.monotonic()
        self._log("info", f"transfer {xid} cancelled")
        self._retire()
        return True

    def tick(self):
        """Pacing + repair timers.  Safe to call often; does nothing when idle."""
        ahead = int(getattr(self.cfg, "FILE_QUEUE_AHEAD", 4))
        now = time.monotonic()
        with self._lock:
            for t in list(self.out.values()):
                if t.cancelled or t.finished:
                    continue
                inflight = len(t.queued) - len(t.done)
                if not t.manifest_sent:
                    t.manifest_sent = True
                    self._send(encode_manifest(t.xid, t.name, t.nseg,
                                               len(t.data), t.crc), True)
                    inflight += 1
                # Anything the link gave up on goes first -- it is the piece
                # holding the whole transfer open.
                while t.lost and inflight < ahead:
                    i = t.lost.pop(0)
                    self._queue_segment(t, i)
                    inflight += 1
                # cursor, not a rescan: with 4000 segments a full scan on every
                # delivery is quadratic and shows up as a stuttering progress bar.
                while inflight < ahead and t.cursor < t.nseg:
                    if t.cursor not in t.queued:
                        self._queue_segment(t, t.cursor)
                        inflight += 1
                    t.cursor += 1
                if len(t.done) >= t.nseg and not t.finished:
                    t.finished = now
                    el = t.finished - t.started
                    # Tell the far end we are done rather than making it wait out
                    # FILE_REPAIR_IDLE_S to discover it.  In the normal lossless
                    # case this turns the tail of a transfer from a 2.5 s pause
                    # into nothing at all.
                    self._send(encode_end(t.xid), True)
                    self._log("info",
                              f"sent {t.name}  {human(len(t.data))} in {el:.1f} s "
                              f"({human(len(t.data)/max(el,1e-6))}/s)")

            # ---- receive side: ask for holes in anything that has gone quiet
            idle = float(getattr(self.cfg, "FILE_REPAIR_IDLE_S", 3.0))
            maxrep = int(getattr(self.cfg, "FILE_REPAIR_MAX", 6))
            for r in list(self.inc.values()):
                if r.finished or now - r.last_rx < idle:
                    continue
                miss = r.missing()
                if not miss:
                    continue
                if r.repairs >= maxrep:
                    r.finished = now
                    r.ok = False
                    self._log("error", f"gave up on {r.name or r.xid}: "
                                       f"{len(miss)} segments never arrived")
                    continue
                r.repairs += 1
                r.last_rx = now
                self._log("info", f"asking for {len(miss)} missing segment(s) of "
                                  f"{r.name or r.xid} (repair {r.repairs})")
                self._send(encode_repair(r.xid, miss[:200]), True)
        self._retire()

    def _queue_segment(self, t: Outgoing, i: int):
        payload = encode_segment(t.xid, i, t.segment(i))
        t.queued.add(i)
        self._pending_seg[payload] = (t.xid, i)
        self._send(payload, not self.stream_mode())

    # --- the link tells us what happened to each message we handed it -------
    def on_delivered(self, payload: bytes):
        with self._lock:
            hit = self._pending_seg.pop(payload, None)
            if hit is None:
                return
            xid, i = hit
            t = self.out.get(xid)
            if t is not None:
                t.done.add(i)
        self.tick()

    def on_lost(self, payload: bytes):
        with self._lock:
            hit = self._pending_seg.pop(payload, None)
            if hit is None:
                return
            xid, i = hit
            t = self.out.get(xid)
            if t is not None and i not in t.done:
                t.queued.discard(i)
                if i not in t.lost:
                    t.lost.append(i)
                self._log("info", f"segment {i} of {t.name} was dropped, requeued")
        self.tick()

    # ---------------------------------------------------------- receive side
    def on_payload(self, payload: bytes):
        """Returns a text string if this was a chat message, else None."""
        tag, f = decode(payload)
        if tag == APP_TEXT:
            return f.get("text", "")
        if tag == APP_MANIFEST:
            self._on_manifest(f)
        elif tag == APP_SEGMENT:
            self._on_segment(f)
        elif tag == APP_REPAIR:
            self._on_repair(f)
        elif tag == APP_DONE:
            self._on_done(f)
        elif tag == APP_END:
            self._on_end(f)
        return None

    def _on_manifest(self, f):
        with self._lock:
            r = self.inc.get(f["xid"])
            if r is None or r.finished:
                r = Incoming(xid=f["xid"])
                self.inc[f["xid"]] = r
            r.name = f["name"] or f"blob_{f['xid']}"
            r.size, r.nseg, r.crc = f["size"], f["nseg"], f["crc"]
            r.have_manifest = True
            r.last_rx = time.monotonic()
        self._log("info", f"incoming {r.name}  {human(r.size)} in {r.nseg} segments")
        self._maybe_complete(r)

    def _on_segment(self, f):
        with self._lock:
            r = self.inc.get(f["xid"])
            if r is None:
                # Segments before the manifest: keep them, ask for the manifest.
                r = Incoming(xid=f["xid"])
                self.inc[f["xid"]] = r
            if r.finished:
                return
            r.parts[f["index"]] = f["data"]
            r.last_rx = time.monotonic()
        self._maybe_complete(r)

    def _on_repair(self, f):
        with self._lock:
            t = self.out.get(f["xid"])
            if t is None or t.cancelled:
                return
            asked = 0
            for i in f["indices"]:
                if i == MANIFEST_INDEX:
                    t.manifest_sent = False
                    continue
                if 0 <= i < t.nseg:
                    t.done.discard(i)
                    t.queued.discard(i)
                    if i not in t.lost:
                        t.lost.append(i)
                    asked += 1
            if asked or not t.manifest_sent:
                t.finished = 0.0
                self._log("info", f"peer asked for {asked} segment(s) of {t.name}")
        self.tick()

    def _on_end(self, f):
        """The sender says it has transmitted everything.  Check now, not later."""
        with self._lock:
            r = self.inc.get(f["xid"])
            if r is None or r.finished:
                return
            miss = r.missing()
            if not miss:
                pass                      # _maybe_complete below will finish it
            else:
                r.repairs += 1
                r.last_rx = time.monotonic()
                self._log("info", f"sender finished; {len(miss)} segment(s) of "
                                  f"{r.name or r.xid} still missing, asking now")
                self._send(encode_repair(r.xid, miss[:200]), True)
                return
        self._maybe_complete(r)

    def _on_done(self, f):
        with self._lock:
            t = self.out.get(f["xid"])
            if t is None:
                return
            t.peer_status = f["status"]
            if f["status"] == 0:
                t.finished = t.finished or time.monotonic()
                self._log("info", f"peer confirmed {t.name} arrived intact")
            else:
                self._log("error", f"peer says {t.name} failed its CRC")
        self._retire()

    def _maybe_complete(self, r: Incoming):
        with self._lock:
            if r.finished or not r.have_manifest or len(r.parts) < r.nseg:
                return
            blob = b"".join(r.parts[i] for i in range(r.nseg))
            blob = blob[:r.size] if r.size else blob
            got = zlib.crc32(blob) & 0xFFFFFFFF
            r.ok = (got == r.crc) and (len(blob) == r.size)
            r.finished = time.monotonic()
            if r.ok:
                r.path = str(self._write_inbox(r.name, blob))
        el = r.finished - r.started
        if r.ok:
            self._log("rx", f"file received: {r.name}  {human(r.size)} in "
                            f"{el:.1f} s ({human(r.size/max(el,1e-6))}/s) "
                            f"-> {r.path}")
        else:
            self._log("error", f"{r.name} reassembled but the CRC-32 does not "
                               f"match -- discarded")
        self._send(encode_done(r.xid, 0 if r.ok else 1), True)
        self._retire()

    def _write_inbox(self, name: str, blob: bytes) -> Path:
        base = Path(getattr(self.cfg, "FILE_INBOX", "inbox")).expanduser()
        if not base.is_absolute():
            base = Path(__file__).resolve().parent.parent / base
        base.mkdir(parents=True, exist_ok=True)
        safe = os.path.basename(name).replace("\\", "_") or "received.bin"
        p = base / safe
        stem, suf, k = p.stem, p.suffix, 1
        while p.exists():
            p = base / f"{stem}({k}){suf}"
            k += 1
        p.write_bytes(blob)
        return p

    # -------------------------------------------------------------- reporting
    def _retire(self):
        """Move anything finished into history, keeping the live lists short."""
        keep = float(getattr(self.cfg, "FILE_RETIRE_S", 6.0))
        now = time.monotonic()
        with self._lock:
            for d, src in (("out", self.out), ("inc", self.inc)):
                for k, t in list(src.items()):
                    if t.finished and now - t.finished > keep:
                        self.history.append(t.progress())
                        del src[k]
            del self.history[:-40]

    def snapshot(self) -> dict:
        with self._lock:
            active = ([t.progress() for t in self.out.values()]
                      + [r.progress() for r in self.inc.values()])
            return {"active": active, "history": list(reversed(self.history[-20:]))}

    def busy(self) -> bool:
        with self._lock:
            return any(not t.finished and not t.cancelled for t in self.out.values())
