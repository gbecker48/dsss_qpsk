"""
receiver.py -- the complete burst receiver, as a state machine over a sample
stream.  Pure numpy: no GNU Radio dependency, so it can be unit tested and
simulated, and the GNU Radio block is a thin wrapper around it.

    SEARCH   scan the stream in overlapping windows with the delay x Doppler
             acquisition engine until a preamble pops above the threshold
      |
      v
    SYNC     with the coarse timing/frequency, despread forward through the
             rest of the preamble and correlate for the sync word.  That gives
             the exact frame start, the absolute carrier phase (which resolves
             the QPSK 90-degree ambiguity), a data-aided fine frequency
             estimate, and the amplitude + noise variance used to scale the
             soft decisions.
      |
      v
    HEADER   demodulate the fixed-length header with the Costas loop closed,
             combine its repeats, Viterbi decode, check CRC-16 -> payload length
      |
      v
    PAYLOAD  demodulate that many symbols, deinterleave, Viterbi, Reed-Solomon,
             CRC-32 -> deliver the message, then go back to SEARCH.

Any stage can fail (false acquisition, bad header, uncorrectable payload); every
failure just returns the receiver to SEARCH and is counted in the statistics.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from scipy.signal import oaconvolve

from . import filters, pn
from .acquisition import Acquisition, AcqResult
from .codec import Codec
from .framing import Header, sync_word
from .tracking import Tracker

# Receiver states
S_SEARCH = "SEARCH"
S_SYNC = "SYNC"
S_HEADER = "HEADER"
S_PAYLOAD = "PAYLOAD"


@dataclass
class RxFrame:
    """One decoded (or failed) burst, with everything measured about it."""
    ok: bool = False
    header: Header | None = None
    payload: bytes = b""
    stage: str = ""                 # where it got to / where it failed

    # --- acquisition ---
    acq_psr: float = 0.0            # peak-to-median of the delay x Doppler grid
    coarse_cfo_hz: float = 0.0
    # --- sync ---
    sync_psr: float = 0.0           # sync-word correlation peak / background
    fine_cfo_hz: float = 0.0
    residual_cfo_hz: float = 0.0    # what the Costas loop had left at the end
    phase_deg: float = 0.0
    # --- signal quality ---
    snr_sym_db: float = 0.0         # post-despread symbol SNR
    snr_chip_db: float = 0.0        # pre-despread, i.e. "below the noise floor?"
    evm_pct: float = 0.0
    mer_db: float = 0.0
    amplitude: float = 0.0
    # --- decoder ---
    viterbi_margin: float = 0.0
    rs_corrections: int = -1
    header_ok: bool = False
    crc_ok: bool = False
    # --- timing ---
    timing_err: float = 0.0
    n_known_symbols: int = 0
    start_sample: int = 0
    n_symbols: int = 0
    # --- constellation snapshot (payload symbols, normalised) ---
    constellation: np.ndarray | None = field(default=None, repr=False)


@dataclass
class RxStats:
    acquisitions: int = 0
    false_acquisitions: int = 0
    sync_found: int = 0
    header_ok: int = 0
    header_fail: int = 0
    payload_ok: int = 0
    payload_fail: int = 0
    samples_processed: int = 0


class Receiver:
    def __init__(self, cfg, code_index: int | None = None):
        self.cfg = cfg
        idx = cfg.PN_INDEX if code_index is None else code_index
        self.code = pn.spreading_code(cfg.PN_KIND, cfg.SPREADING_FACTOR, idx)
        self.sync = sync_word(cfg.SYNC_LEN, cfg.SYNC_SEED).astype(np.complex128)
        self.codec = Codec(cfg)
        self.acq = Acquisition(cfg, self.code)
        self.rrc = filters.rrc_taps(cfg.SPS_CHIP, cfg.RRC_SPAN_CHIPS,
                                    cfg.RRC_ROLLOFF).astype(np.complex128)
        self.spsym = cfg.SAMPLES_PER_SYMBOL
        self.stats = RxStats()

        # --- front-end state -------------------------------------------------
        self.dc = filters.DCBlocker(cfg.DC_BLOCK_CUTOFF_HZ, cfg.SAMP_RATE_HZ)
        self.agc = filters.AGC(cfg.AGC_REFERENCE, cfg.AGC_TIME_CONSTANT_S,
                               cfg.SAMP_RATE_HZ)
        self.meter = filters.LevelMeter()
        self._if_n = 0                                   # sample counter for IF
        self._mf_tail = np.zeros(len(self.rrc) - 1, dtype=np.complex128)

        # --- stream buffer ---------------------------------------------------
        self.buf = np.zeros(0, dtype=np.complex128)
        self.buf_abs = 0                                  # abs index of buf[0]
        self.scan_pos = 0                                 # next acquisition window

        # --- state machine ---------------------------------------------------
        self.state = S_SEARCH
        self._acq: AcqResult | None = None
        self._tracker: Tracker | None = None
        self._frame = RxFrame()
        self._wait_since = 0
        self._noise_var = 1.0
        self._amp = 1.0

        # how far forward of the acquisition point the sync word can possibly be
        self._sync_span = cfg.N_PREAMBLE_PERIODS + cfg.SYNC_LEN + 8

    # ================================================================== ingest
    def process(self, samples: np.ndarray) -> list[RxFrame]:
        """Feed raw complex baseband from the radio.  Returns completed frames."""
        x = np.asarray(samples, dtype=np.complex128)
        self.stats.samples_processed += len(x)

        if self.cfg.DC_BLOCK_ENABLE:
            x = self.dc.process(x)

        # Undo the transmitter's digital IF offset (continuous phase).
        if self.cfg.IF_OFFSET_HZ:
            n = np.arange(self._if_n, self._if_n + len(x))
            x = x * np.exp(-2j * np.pi * self.cfg.IF_OFFSET_HZ * n / self.cfg.SAMP_RATE_HZ)
        self._if_n += len(x)

        # Chip matched filter, with state carried across calls.
        # oaconvolve (overlap-add FFT) instead of np.convolve: with a 25-tap
        # filter and 32k-sample blocks it is several times faster, which matters
        # because this runs on every sample at the full radio rate.
        cat = np.concatenate([self._mf_tail, x])
        y = oaconvolve(cat, self.rrc, mode="valid")
        self._mf_tail = cat[len(cat) - (len(self.rrc) - 1):]

        self.rx_rms = self.meter.update(x)
        if self.cfg.AGC_ENABLE:
            y = self.agc.process(y)

        self.buf = np.concatenate([self.buf, y])
        frames = self._run()
        self._trim()
        return frames

    def _buf_end(self) -> int:
        return self.buf_abs + len(self.buf)

    def _trim(self):
        keep = self.scan_pos
        if self._tracker is not None:
            keep = min(keep, int(self._tracker.pos))
        if self._acq is not None:
            keep = min(keep, int(self._acq.position))
        keep -= 64
        if keep > self.buf_abs:
            cut = keep - self.buf_abs
            self.buf = self.buf[cut:]
            self.buf_abs += cut
        # Hard cap so a stuck state cannot grow memory without bound.
        cap = self.cfg.RX_BUFFER_SAMPLES * 3
        if len(self.buf) > cap:
            cut = len(self.buf) - cap
            self.buf = self.buf[cut:]
            self.buf_abs += cut
            self.scan_pos = max(self.scan_pos, self.buf_abs)

    # ============================================================ state machine
    def _run(self) -> list[RxFrame]:
        out: list[RxFrame] = []
        progress = True
        while progress:
            progress = False
            if self.state == S_SEARCH:
                progress = self._do_search()
            elif self.state == S_SYNC:
                progress, f = self._do_sync()
                if f is not None:
                    out.append(f)
            elif self.state == S_HEADER:
                progress, f = self._do_header()
                if f is not None:
                    out.append(f)
            elif self.state == S_PAYLOAD:
                progress, f = self._do_payload()
                if f is not None:
                    out.append(f)
        return out

    # ------------------------------------------------------------------ SEARCH
    def _do_search(self) -> bool:
        W = self.cfg.ACQ_WINDOW_SAMPLES
        if self._buf_end() - self.scan_pos < W:
            return False
        i0 = self.scan_pos - self.buf_abs
        win = self.buf[i0:i0 + W]
        res = self.acq.search(win, self.scan_pos)
        self.scan_pos += self.cfg.ACQ_HOP_SAMPLES
        if not res.detected:
            return True
        self.stats.acquisitions += 1
        self._acq = res
        self._frame = RxFrame(acq_psr=res.psr, coarse_cfo_hz=res.freq_hz,
                              snr_chip_db=res.snr_chip_db,
                              snr_sym_db=res.snr_sym_db,
                              start_sample=int(res.position), stage="acquired")
        self.state = S_SYNC
        self._wait_since = self._buf_end()
        return True

    # -------------------------------------------------------------------- SYNC
    def _do_sync(self):
        cfg = self.cfg
        acq = self._acq
        nsearch = self._sync_span
        need = int(acq.position) + (nsearch + 2) * self.spsym + 8
        if self._buf_end() < need:
            return self._stall()

        # Disposable tracker: despread forward from the acquisition point with
        # the carrier loop OPEN (we do not have a phase reference yet).
        t = Tracker(cfg, self.code, self.buf, self.buf_abs,
                    acq.position, acq.freq_hz, 0.0)
        if not self._bounds_ok(t, nsearch):
            return self._stall()
        syms = t.produce(nsearch, record_positions=True)

        # Correlate against the known sync word.
        corr = np.correlate(syms.astype(np.complex128), self.sync, mode="valid")
        mag = np.abs(corr)
        d = int(np.argmax(mag))
        peak = mag[d]
        # Background = median away from the peak.
        mask = np.ones(len(mag), dtype=bool)
        lo, hi = max(0, d - cfg.SYNC_LEN), min(len(mag), d + cfg.SYNC_LEN)
        mask[lo:hi] = False
        bg = np.median(mag[mask]) if mask.any() else 1e-12
        psr = float(peak / (bg + 1e-12))
        self._frame.sync_psr = psr

        if psr < cfg.SYNC_THRESHOLD_RATIO or d + cfg.SYNC_LEN >= len(syms):
            self.stats.false_acquisitions += 1
            self._frame.stage = "sync-fail"
            self._abort()
            return True, None

        self.stats.sync_found += 1

        # ---- data-aided estimates -------------------------------------------
        # Use EVERY known symbol we have, not just the sync word: the whole
        # stretch of preamble in front of it is known too (it is the constant
        # 1+0j symbol repeated).  Frequency-estimator variance falls as N^-3, so
        # going from 64 known symbols to ~320 cuts the residual CFO by about 8x
        # -- from ~17 Hz to ~2 Hz.  That matters enormously: 17 Hz of residual
        # rotates the constellation 150 degrees over a 25 ms frame, and no
        # sensible Costas bandwidth can clean that up at 3 dB symbol SNR without
        # cycle slipping.
        L = cfg.SYNC_LEN
        d0 = max(0, d - int(cfg.FINE_CFO_MAX_SYMBOLS) + L) if cfg.FINE_CFO_USE_PREAMBLE else d
        known = np.empty(d + L - d0, dtype=np.complex128)
        known[:d - d0] = 1.0 + 0.0j            # preamble symbols
        known[d - d0:] = self.sync             # sync word
        r = syms[d0:d + L].astype(np.complex128) * np.conj(known)

        fine_cfo = _lr_cfo(r, cfg.SYMBOL_RATE_HZ, cfg.FINE_CFO_LAG_FRACTION) \
            if cfg.FINE_CFO_ENABLE else 0.0

        # Index the de-rotation relative to the symbol AFTER the sync word, so
        # the phase that falls out is exactly the phase the next tracker needs.
        nn = np.arange(d0, d + L) - (d + L)
        r_corr = r * np.exp(-2j * np.pi * fine_cfo * nn / cfg.SYMBOL_RATE_HZ)
        mean = r_corr.mean()
        amp = float(abs(mean))
        noise_var = max(float(np.mean(np.abs(r_corr - mean) ** 2)), 1e-12)
        phase = float(np.angle(mean))

        self._amp = amp
        self._noise_var = noise_var
        snr_sym = amp * amp / noise_var
        self._frame.fine_cfo_hz = acq.freq_hz + fine_cfo
        self._frame.phase_deg = np.degrees(phase)
        self._frame.amplitude = amp
        self._frame.snr_sym_db = 10 * np.log10(max(snr_sym, 1e-12))
        self._frame.snr_chip_db = self._frame.snr_sym_db - 10 * np.log10(cfg.SPREADING_FACTOR)
        self._frame.stage = "sync"
        self._frame.n_known_symbols = len(r)

        # ---- restart the tracker right after the sync word, loops closed -----
        # The phase handed over must be the TOTAL carrier phase at that symbol:
        # what the search tracker already de-rotated away (t.phases) plus the
        # residual we just measured.  Forgetting the first term reintroduces the
        # QPSK 90-degree ambiguity and the header fails three times out of four.
        k = d + L
        start = t.positions[k]
        phase0 = t.phases[k] + phase
        tr = Tracker(cfg, self.code, self.buf, self.buf_abs, start,
                     acq.freq_hz + fine_cfo, phase0)
        tr.enable_costas(cfg.COSTAS_ENABLE)
        self._tracker = tr
        self.state = S_HEADER
        self._wait_since = self._buf_end()
        return True, None

    # ------------------------------------------------------------------ HEADER
    def _do_header(self):
        nsym = self.codec.header_symbols()
        tr = self._tracker
        tr.buf, tr.buf_abs = self.buf, self.buf_abs
        if not self._bounds_ok(tr, nsym):
            return self._stall()

        syms = tr.produce(nsym)
        llr = self._llrs(syms)[: self.codec.header_coded_bits()]
        hdr_bytes, margin = self.codec.decode_header(llr)
        hdr, ok = Header.unpack(hdr_bytes)
        self._frame.viterbi_margin = float(margin)
        self._frame.header_ok = bool(ok)

        if not ok:
            self.stats.header_fail += 1
            self._frame.stage = "header-crc-fail"
            f = self._finish(False)
            return True, f

        self.stats.header_ok += 1
        self._frame.header = hdr
        self._frame.stage = "header"
        if hdr.payload_len == 0:
            self._frame.crc_ok = True
            f = self._finish(True)
            return True, f
        if hdr.payload_len > self.cfg.MAX_PAYLOAD_BYTES:
            self._frame.stage = "header-length-invalid"
            f = self._finish(False)
            return True, f
        self.state = S_PAYLOAD
        self._wait_since = self._buf_end()
        return True, None

    # ----------------------------------------------------------------- PAYLOAD
    def _do_payload(self):
        hdr = self._frame.header
        nsym = self.codec.payload_symbols(hdr.payload_len)
        tr = self._tracker
        tr.buf, tr.buf_abs = self.buf, self.buf_abs
        if not self._bounds_ok(tr, nsym):
            return self._stall()

        syms = tr.produce(nsym)
        llr = self._llrs(syms)[: self.codec.payload_coded_bits(hdr.payload_len)]
        payload, st = self.codec.decode_payload(llr, hdr.payload_len)

        self._frame.rs_corrections = st["rs_corrections"]
        self._frame.crc_ok = st["crc_ok"]
        self._frame.viterbi_margin = st["viterbi_margin"]
        self._frame.n_symbols = nsym
        self._frame.timing_err = tr.timing_err
        self._frame.residual_cfo_hz = tr.freq_hz - self._frame.fine_cfo_hz

        # Constellation + EVM from the payload symbols themselves.
        norm = syms / (self._amp + 1e-12)
        dec = (np.sign(norm.real) + 1j * np.sign(norm.imag)) / np.sqrt(2)
        err = norm - dec
        evm = float(np.sqrt(np.mean(np.abs(err) ** 2)))
        self._frame.evm_pct = evm * 100.0
        self._frame.mer_db = -20 * np.log10(max(evm, 1e-9))
        keep = min(len(norm), self.cfg.CONSTELLATION_HISTORY)
        self._frame.constellation = norm[:keep].astype(np.complex64)

        if payload is None:
            self.stats.payload_fail += 1
            self._frame.stage = "payload-fail"
            return True, self._finish(False)

        self.stats.payload_ok += 1
        self._frame.payload = payload
        self._frame.stage = "ok"
        return True, self._finish(True)

    # ----------------------------------------------------------------- helpers
    def _llrs(self, syms: np.ndarray) -> np.ndarray:
        """Gray-QPSK soft bits.  LLR > 0 means bit 0.

        For a symbol y whose ideal value is A*(+-1 +- j)/sqrt(2) in complex
        Gaussian noise of total variance sigma^2 (so sigma^2/2 per real axis):
            LLR(I bit) = 2 * sqrt(2) * A * Re(y) / sigma^2
        Getting this scaling right matters: the Viterbi metric is linear in the
        LLRs, so a wrong scale still decodes, but combining the header repeats
        and mixing in erasures from puncturing both rely on true LLR units.
        """
        k = 2.0 * np.sqrt(2.0) * self._amp / self._noise_var
        out = np.empty(2 * len(syms), dtype=np.float32)
        out[0::2] = k * np.real(syms)
        out[1::2] = k * np.imag(syms)
        return out

    def _bounds_ok(self, tr: Tracker, nsym: int) -> bool:
        """Is every sample this demodulation will touch inside the buffer?"""
        first = int(tr.pos) - int(tr.el_offset) - tr.ntaps - 4
        last = tr.samples_needed(nsym) + tr.ntaps + 4
        return first >= self.buf_abs and last <= self._buf_end()

    def _stall(self):
        """Waiting for more samples.  Only ever called from SYNC/HEADER/PAYLOAD.

        If the stream has run far past what we were waiting for and we still
        cannot proceed, the burst was truncated -- give up and resume searching.
        """
        if self._buf_end() - self._wait_since > 4 * self.cfg.MAX_FRAME_SAMPLES:
            self._frame.stage = "stalled"
            self._abort()
            return True, None
        return False, None

    def _abort(self):
        if self._acq is not None:
            self.scan_pos = max(self.scan_pos,
                                int(self._acq.position) + self.cfg.ACQ_HOP_SAMPLES)
        self.state = S_SEARCH
        self._acq = None
        self._tracker = None

    def _finish(self, ok: bool) -> RxFrame:
        f = self._frame
        f.ok = bool(ok)
        if self._tracker is not None:
            # Resume searching just after this burst so we do not re-detect it.
            self.scan_pos = max(self.scan_pos, int(self._tracker.pos) + self.spsym)
        self.state = S_SEARCH
        self._acq = None
        self._tracker = None
        self._frame = RxFrame()
        return f


def _lr_cfo(r: np.ndarray, symbol_rate: float, m_frac: float = 0.25) -> float:
    """Luise & Reggiannini data-aided frequency estimator.

    r is the sync word after removing the known modulation, so ideally it is
    A*exp(j(theta + 2*pi*df*n*T)).  Averaging the autocorrelation over several
    lags before taking the angle is far less noisy than a single-lag estimate,
    which is what gets the residual offset down to a few Hz and keeps the
    constellation from rotating across a long frame.
    """
    n = len(r)
    M = max(1, int(n * m_frac))
    acc = 0.0 + 0.0j
    for m in range(1, M + 1):
        acc += np.sum(r[m:] * np.conj(r[:n - m]))
    ang = np.angle(acc)
    # Unambiguous range is +/- symbol_rate / (2*(M+1)); with m_frac = 0.25 and
    # ~320 known symbols that is about +/- 200 Hz, comfortably more than the
    # +/- half an acquisition FFT bin the coarse stage leaves behind.
    return float(ang * symbol_rate / (np.pi * (M + 1)))
