"""
receiver.py -- the complete burst receiver, as a state machine over a sample
stream.  Pure numpy: no GNU Radio dependency, so it can be unit tested and
simulated, and the GNU Radio block is a thin wrapper around it.

    SEARCH   scan the stream in overlapping windows with the delay x Doppler
             acquisition engine until a preamble pops above the threshold
      |
      v
    SYNC     with the coarse timing/frequency, despread forward through the
             rest of the preamble and correlate for the sync word.  That gives
             the exact frame start, the absolute carrier phase (which resolves
             the QPSK 90-degree ambiguity), a data-aided fine frequency
             estimate, and the amplitude + noise variance used to scale the
             soft decisions.
      |
      v
    HEADER   demodulate the fixed-length header with the Costas loop closed,
             combine its repeats, Viterbi decode, check CRC-16 -> payload length
      |
      v
    PAYLOAD  demodulate that many symbols, deinterleave, Viterbi, Reed-Solomon,
             CRC-32 -> deliver the message, then go back to SEARCH.

Any stage can fail (false acquisition, bad header, uncorrectable payload); every
failure just returns the receiver to SEARCH and is counted in the statistics.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from scipy.signal import oaconvolve

from . import filters, pn
from .acquisition import Acquisition, AcqResult
from .codec import Codec
from .framing import Header, sync_word
from .tracking import Tracker

# Receiver states
S_SEARCH = "SEARCH"
S_SYNC = "SYNC"
S_HEADER = "HEADER"
S_PAYLOAD = "PAYLOAD"


@dataclass
class RxFrame:
    """One decoded (or failed) burst, with everything measured about it."""
    ok: bool = False
    header: Header | None = None
    payload: bytes = b""
    stage: str = ""                 # where it got to / where it failed

    # --- acquisition ---
    acq_psr: float = 0.0            # peak-to-median of the delay x Doppler grid
    coarse_cfo_hz: float = 0.0
    # --- sync ---
    sync_psr: float = 0.0           # sync-word correlation peak / background
    # Sync peak divided by the LARGEST other peak outside it.  Unlike sync_psr
    # this does not depend on how noisy the background is, which is what makes
    # it a usable test on a strong signal -- see _do_sync.
    sync_margin: float = 0.0
    fine_cfo_hz: float = 0.0
    residual_cfo_hz: float = 0.0    # what the Costas loop had left at the end
    phase_deg: float = 0.0
    # --- signal quality ---
    snr_sym_db: float = 0.0         # post-despread symbol SNR
    snr_chip_db: float = 0.0        # pre-despread, i.e. "below the noise floor?"
    evm_pct: float = 0.0
    mer_db: float = 0.0
    amplitude: float = 0.0
    # --- decoder ---
    viterbi_margin: float = 0.0
    rs_corrections: int = -1
    header_ok: bool = False
    crc_ok: bool = False
    # --- timing ---
    timing_err: float = 0.0
    preamble_score_db: float = 0.0
    n_known_symbols: int = 0
    start_sample: int = 0
    n_symbols: int = 0
    # --- constellation snapshot (payload symbols, normalised) ---
    constellation: np.ndarray | None = field(default=None, repr=False)


@dataclass
class RxStats:
    acquisitions: int = 0
    false_acquisitions: int = 0
    sync_found: int = 0
    header_ok: int = 0
    header_fail: int = 0
    payload_ok: int = 0
    payload_fail: int = 0
    samples_processed: int = 0
    # --- health / instrumentation -------------------------------------------
    # Samples that arrived while the receiver was busy with a frame and could
    # therefore NOT detect a new preamble.  If this is a large fraction of
    # samples_processed, the receiver is deaf too often and will miss messages.
    deaf_samples: int = 0
    # Frames abandoned because the sample buffer was trimmed out from under them.
    # This should stay at zero; if it does not, RX_BUFFER_MARGIN is too small.
    buffer_aborts: int = 0
    # Frames abandoned because the burst was truncated mid-decode.
    stalls: int = 0
    # False acquisitions killed by the cheap preamble check, before paying for
    # a full sync search.  A large number here is good: it is work avoided.
    early_rejects: int = 0
    max_buffer_samples: int = 0


class Receiver:
    def __init__(self, cfg, code_index: int | None = None):
        self.cfg = cfg
        idx = cfg.PN_INDEX if code_index is None else code_index
        self.code = pn.spreading_code(cfg.PN_KIND, cfg.SPREADING_FACTOR, idx)
        self.sync = sync_word(cfg.SYNC_LEN, cfg.SYNC_SEED).astype(np.complex128)
        self.codec = Codec(cfg)
        self.acq = Acquisition(cfg, self.code)
        self.rrc = filters.rrc_taps(cfg.SPS_CHIP, cfg.RRC_SPAN_CHIPS,
                                    cfg.RRC_ROLLOFF).astype(np.complex64)
        self.spsym = cfg.SAMPLES_PER_SYMBOL
        self.stats = RxStats()

        # --- front-end state -------------------------------------------------
        self.dc = filters.DCBlocker(cfg.DC_BLOCK_CUTOFF_HZ, cfg.SAMP_RATE_HZ)
        self.agc = filters.AGC(cfg.AGC_REFERENCE, cfg.AGC_TIME_CONSTANT_S,
                               cfg.SAMP_RATE_HZ)
        self.meter = filters.LevelMeter()
        self._if_n = 0                                   # sample counter for IF
        self._if_cache: dict[int, np.ndarray] = {}
        self._mf_tail = np.zeros(len(self.rrc) - 1, dtype=np.complex64)

        # --- stream buffer ---------------------------------------------------
        self.recent_raw = np.zeros(0, dtype=np.complex64)
        self.rx_rms = 0.0
        # complex64, not complex128: halves the memory traffic and the FFT cost
        # of everything downstream, and the dynamic range needed here is ~50 dB.
        self.buf = np.zeros(0, dtype=np.complex64)
        self.buf_abs = 0                                  # abs index of buf[0]
        self.scan_pos = 0                                 # next acquisition window
        # True only while flush() is running: "no more samples are coming".
        self._eos = False

        # --- state machine ---------------------------------------------------
        self.state = S_SEARCH
        self._acq: AcqResult | None = None
        self._tracker: Tracker | None = None
        self._frame = RxFrame()
        self._wait_since = 0
        self._wait_target = 0
        self._noise_var = 1.0
        self._amp = 1.0

        # How many symbols to despread while hunting for the sync word.
        #
        # SUBTLE AND IT COST US A LOT OF FRAMES.  The correlation is 'valid'
        # mode, so producing N symbols only lets the sync word START anywhere in
        # [0, N - SYNC_LEN].  Acquisition integrates over a block that is
        # guaranteed to OVERLAP the preamble, but that block can begin somewhat
        # BEFORE the burst does (it still detects, on partial overlap, with a
        # strong peak).  When that happened the sync word sat just past the end
        # of the searchable range, the correlator locked onto the best wrong
        # place, and the header failed CRC on a burst with 700:1 acquisition
        # margin -- which looks exactly like "the radio is broken".
        #
        # So allow the sync word to start anywhere up to a full preamble plus a
        # whole acquisition block beyond the acquisition point.
        self._sync_span = (cfg.N_PREAMBLE_PERIODS + cfg.N_ACQ_PERIODS
                           + 2 * cfg.SYNC_LEN + 16)
        self._frame_start_pos = 0

    # ================================================================== ingest
    def process(self, samples: np.ndarray) -> list[RxFrame]:
        """Feed raw complex baseband from the radio.  Returns completed frames."""
        x = np.asarray(samples, dtype=np.complex64)
        self.stats.samples_processed += len(x)

        # Keep a short ring of RAW samples -- exactly what the radio handed us,
        # before the DC blocker and before the IF de-rotation -- so the
        # dashboard's spectrum shows the real band, DC spur and all.  That plot
        # is what tells you whether the RF path is working, independently of
        # whether the modem is locking.
        keep = self.cfg.SPECTRUM_SAMPLES
        self.recent_raw = (x[-keep:] if len(x) >= keep else
                           np.concatenate([self.recent_raw, x])[-keep:])

        if self.cfg.DC_BLOCK_ENABLE:
            x = self.dc.process(x)

        # Undo the transmitter's digital IF offset, with continuous phase.
        #
        # The obvious np.exp(...) over arange(n) costs a complex exponential per
        # SAMPLE and was ~23% of the receiver's idle CPU.  The rotation only
        # depends on the offset WITHIN the chunk, so cache that vector per chunk
        # size and fold the running phase in as a single scalar.  One exp per
        # chunk instead of one per sample, bit-for-bit the same answer.
        if self.cfg.IF_OFFSET_HZ:
            n = len(x)
            vec = self._if_cache.get(n)
            if vec is None:
                k = np.arange(n, dtype=np.float64)
                vec = np.exp(-2j * np.pi * self.cfg.IF_OFFSET_HZ * k
                             / self.cfg.SAMP_RATE_HZ).astype(np.complex64)
                if len(self._if_cache) < 8:      # a couple of chunk sizes, no more
                    self._if_cache[n] = vec
            start = np.exp(-2j * np.pi * self.cfg.IF_OFFSET_HZ * self._if_n
                           / self.cfg.SAMP_RATE_HZ)
            x = x * (np.complex64(start) * vec)
        self._if_n += len(x)

        # Chip matched filter, with state carried across calls.
        # oaconvolve (overlap-add FFT) instead of np.convolve: with a 25-tap
        # filter and 32k-sample blocks it is several times faster, which matters
        # because this runs on every sample at the full radio rate.
        cat = np.concatenate([self._mf_tail, x])
        y = oaconvolve(cat, self.rrc, mode="valid")
        self._mf_tail = cat[len(cat) - (len(self.rrc) - 1):]

        self.rx_rms = self.meter.update(x)
        if self.cfg.AGC_ENABLE:
            y = self.agc.process(y)

        if self.state != S_SEARCH:
            # We are mid-frame, so these samples cannot be searched for a new
            # preamble.  Tracking this is how you tell "the link is lossy" from
            # "the receiver was not listening".
            self.stats.deaf_samples += len(y)

        self.buf = np.concatenate([self.buf, y])
        frames = self._run()
        self._trim()
        return frames

    def _buf_end(self) -> int:
        return self.buf_abs + len(self.buf)

    def _front_needed(self) -> int:
        """Oldest absolute sample index anything still in flight needs."""
        keep = self.scan_pos
        if self._tracker is not None:
            keep = min(keep, int(self._tracker.pos) - int(self._tracker.el_offset)
                       - self._tracker.ntaps - 8)
        if self._acq is not None:
            keep = min(keep, int(self._acq.position) - 8)
        return keep - 64

    def _trim(self):
        """Drop samples nothing needs any more.

        THE BUG THIS FIXES.  The hard memory cap used to cut the front of the
        buffer past the position an in-progress acquisition or tracker was still
        pointing at.  Those objects then referenced samples that no longer
        existed, _bounds_ok could never be satisfied again, and the receiver sat
        in SYNC/HEADER/PAYLOAD -- completely deaf -- until a timeout fired about
        0.7 s later.  Any message that arrived in that window was simply never
        heard, and the link layer timed out and retransmitted.

        Now the cap ABORTS the in-progress frame first and only then cuts, so the
        receiver is never left holding a reference to data it has thrown away.
        """
        keep = self._front_needed()
        if keep > self.buf_abs:
            cut = keep - self.buf_abs
            self.buf = self.buf[cut:]
            self.buf_abs += cut

        cap = int(self.cfg.RX_BUFFER_SAMPLES * self.cfg.RX_BUFFER_MARGIN)
        if len(self.buf) > cap:
            # Give up on whatever is in flight BEFORE discarding its samples.
            if self.state != S_SEARCH:
                self.stats.buffer_aborts += 1
                self._frame.stage = "buffer-overrun"
                self._abort()
            cut = len(self.buf) - cap
            self.buf = self.buf[cut:]
            self.buf_abs += cut
            self.scan_pos = max(self.scan_pos, self.buf_abs)
        self.stats.max_buffer_samples = max(self.stats.max_buffer_samples,
                                            len(self.buf))

    # ============================================================ state machine
    def _run(self) -> list[RxFrame]:
        out: list[RxFrame] = []
        progress = True
        while progress:
            progress = False
            if self.state == S_SEARCH:
                progress = self._do_search()
            elif self.state == S_SYNC:
                progress, f = self._do_sync()
                if f is not None:
                    out.append(f)
            elif self.state == S_HEADER:
                progress, f = self._do_header()
                if f is not None:
                    out.append(f)
            elif self.state == S_PAYLOAD:
                progress, f = self._do_payload()
                if f is not None:
                    out.append(f)
        return out

    # ------------------------------------------------------------------ SEARCH
    def _do_search(self) -> bool:
        W = self.cfg.ACQ_WINDOW_SAMPLES
        if self._buf_end() - self.scan_pos < W:
            return False
        i0 = self.scan_pos - self.buf_abs
        win = self.buf[i0:i0 + W]
        res = self.acq.search(win, self.scan_pos)
        self.scan_pos += self.cfg.ACQ_HOP_SAMPLES
        if not res.detected:
            return True
        self.stats.acquisitions += 1
        self._acq = res
        self._frame = RxFrame(acq_psr=res.psr, coarse_cfo_hz=res.freq_hz,
                              snr_chip_db=res.snr_chip_db,
                              snr_sym_db=res.snr_sym_db,
                              start_sample=int(res.position), stage="acquired")
        self.state = S_SYNC
        self._wait_since = self._buf_end()
        return True

    # -------------------------------------------------------------------- SYNC
    def _do_sync(self):
        cfg = self.cfg
        acq = self._acq

        # Sync search: WIDE span first, narrow only as a fallback.
        #
        # The sync word can sit anywhere from one preamble to one preamble plus
        # a whole acquisition block past the acquisition point, because
        # acquisition can fire with its integration block starting before the
        # burst (see _sync_span).  np.correlate('valid') only searches lags
        # [0, N-SYNC_LEN], so a short search window silently cannot see a sync
        # word that landed past its end.
        #
        # This used to try the narrow window first and accept it if the
        # peak-to-background RATIO passed, which is wrong in a way that only
        # shows up on a STRONG signal.  In the narrow window the "background" is
        # a stretch of constant preamble; at -13 dB that background is noise
        # (median ~1.7) and a spurious peak of 4.5 is a ratio of 2.6 and gets
        # rejected, so the wide stage runs and finds the real peak.  At +6 dB
        # the same background is nearly silent (median 0.24), the SAME spurious
        # peak becomes a ratio of 19, it passes, and the wide stage never runs:
        # the frame is demodulated from the wrong place and fails its header
        # CRC.  Measured, two bursts 60 ms apart: 2/2 frames at -13 dB and 1/2
        # at +6 dB -- a receiver that got worse as the signal got better.
        #
        # The narrow span is a strict prefix of the wide one, so the wide search
        # covers every lag the narrow one does and can only find a better peak.
        # The only reason to use the narrow span at all is when the samples for
        # the wide one have not arrived: an ACK is ~460 symbols end to end, and
        # demanding the full wide span before even looking adds latency to every
        # ACK and fails outright for a frame at the end of a capture.
        narrow = cfg.N_PREAMBLE_PERIODS + cfg.SYNC_LEN + 8
        wide = max(self._sync_span, narrow)

        probe = Tracker(cfg, self.code, self.buf, self.buf_abs,
                        acq.position, acq.freq_hz, 0.0, dll=False)
        wide_state = self._bounds_state(probe, wide)
        if wide_state == "ok":
            nsearch = wide
        elif wide_state == "lost":
            self.stats.buffer_aborts += 1
            self._frame.stage = "buffer-underrun"
            self._abort()
            return True, None
        else:
            # The wide span's samples have not arrived yet.  WAIT for them --
            # do not settle for the narrow window, which is how a real sync word
            # at lag 287 gets missed by a 265-lag search and the frame is
            # demodulated from a spurious peak instead.  Waiting costs ~16 ms,
            # and on a live radio the samples always come.
            #
            # The narrow fallback exists for the one case where they never will:
            # a finite capture that ends just after the burst.  An ACK is only
            # ~460 symbols end to end, so a recording that stops there can never
            # satisfy the wide span, and refusing to look at all would throw the
            # frame away.  So: wait, and only drop to narrow once the stream has
            # run half a frame past what we were waiting for.
            waited = self._buf_end() - self._wait_since
            if not self._eos and waited <= cfg.MAX_FRAME_SAMPLES // 2:
                return self._stall()
            nsearch = narrow

        t = Tracker(cfg, self.code, self.buf, self.buf_abs,
                    acq.position, acq.freq_hz, 0.0, dll=False)
        blocked = self._need(t, nsearch)
        if blocked is not None:
            return blocked
        syms = t.produce(nsearch, record_positions=True)

        corr = np.correlate(syms.astype(np.complex128), self.sync, mode="valid")
        mag = np.abs(corr)
        d = int(np.argmax(mag))
        peak = float(mag[d])
        mask = np.ones(len(mag), dtype=bool)
        lo, hi = max(0, d - cfg.SYNC_LEN), min(len(mag), d + cfg.SYNC_LEN)
        mask[lo:hi] = False
        rest = mag[mask]
        bg = float(np.median(rest)) if rest.size else 1e-12
        psr = float(peak / (bg + 1e-12))
        # Second test, and the one that does not care how quiet the background
        # is: a real sync peak stands alone.  Measured margins over the peak of
        # everything else are 2.7-3.7 for a true peak and 1.0-1.3 for a spurious
        # one, at every SNR from -14 dB to +24 dB, so the two populations do not
        # overlap and a threshold between them is not a tuning exercise.
        second = float(rest.max()) if rest.size else 0.0
        margin = peak / (second + 1e-12)
        self._frame.sync_psr = psr
        self._frame.sync_margin = margin

        if (psr < cfg.SYNC_THRESHOLD_RATIO
                or margin < getattr(cfg, "SYNC_PEAK_MARGIN", 1.8)
                or d + cfg.SYNC_LEN >= len(syms)):
            self.stats.false_acquisitions += 1
            self._frame.stage = "sync-fail"
            self._abort()
            return True, None

        self.stats.sync_found += 1

        # ---- data-aided estimates -------------------------------------------
        # Use EVERY known symbol we have, not just the sync word: the whole
        # stretch of preamble in front of it is known too (it is the constant
        # 1+0j symbol repeated).  Frequency-estimator variance falls as N^-3, so
        # going from 64 known symbols to ~320 cuts the residual CFO by about 8x
        # -- from ~17 Hz to ~2 Hz.  That matters enormously: 17 Hz of residual
        # rotates the constellation 150 degrees over a 25 ms frame, and no
        # sensible Costas bandwidth can clean that up at 3 dB symbol SNR without
        # cycle slipping.
        L = cfg.SYNC_LEN
        d0 = max(0, d - int(cfg.FINE_CFO_SYMBOLS) + L) if cfg.FINE_CFO_USE_PREAMBLE else d
        known = np.empty(d + L - d0, dtype=np.complex128)
        known[:d - d0] = 1.0 + 0.0j            # preamble symbols
        known[d - d0:] = self.sync             # sync word
        r = syms[d0:d + L].astype(np.complex128) * np.conj(known)

        fine_cfo = _lr_cfo(r, cfg.SYMBOL_RATE_HZ, cfg.FINE_CFO_LAG_FRACTION) \
            if cfg.FINE_CFO_ENABLE else 0.0

        # Index the de-rotation relative to the symbol AFTER the sync word, so
        # the phase that falls out is exactly the phase the next tracker needs.
        nn = np.arange(d0, d + L) - (d + L)
        r_corr = r * np.exp(-2j * np.pi * fine_cfo * nn / cfg.SYMBOL_RATE_HZ)
        mean = r_corr.mean()
        amp = float(abs(mean))
        noise_var = max(float(np.mean(np.abs(r_corr - mean) ** 2)), 1e-12)
        phase = float(np.angle(mean))

        self._amp = amp
        self._noise_var = noise_var
        snr_sym = amp * amp / noise_var
        self._frame.fine_cfo_hz = acq.freq_hz + fine_cfo
        self._frame.phase_deg = np.degrees(phase)
        self._frame.amplitude = amp
        self._frame.snr_sym_db = 10 * np.log10(max(snr_sym, 1e-12))
        self._frame.snr_chip_db = self._frame.snr_sym_db - 10 * np.log10(cfg.SPREADING_FACTOR)
        self._frame.stage = "sync"
        self._frame.n_known_symbols = len(r)

        # Sanity gate -- see SYNC_MIN_SNR_DB in config.py.  Without this, a
        # partial burst sails through to the header with a wildly wrong
        # amplitude estimate and reports impossible metrics on its way out.
        if self._frame.snr_sym_db < cfg.SYNC_MIN_SNR_DB:
            self.stats.false_acquisitions += 1
            self._frame.stage = "sync-low-snr"
            self._abort()
            return True, None

        # ---- restart the tracker right after the sync word, loops closed -----
        # The phase handed over must be the TOTAL carrier phase at that symbol:
        # what the search tracker already de-rotated away (t.phases) plus the
        # residual we just measured.  Forgetting the first term reintroduces the
        # QPSK 90-degree ambiguity and the header fails three times out of four.
        k = d + L
        start = t.positions[k]
        phase0 = t.phases[k] + phase
        tr = Tracker(cfg, self.code, self.buf, self.buf_abs, start,
                     acq.freq_hz + fine_cfo, phase0)
        tr.enable_costas(cfg.COSTAS_ENABLE)
        self._tracker = tr
        self._frame_start_pos = int(start)
        self.state = S_HEADER
        self._wait_since = self._buf_end()
        return True, None

    # ------------------------------------------------------------------ HEADER
    def _do_header(self):
        nsym = self.codec.header_symbols()
        tr = self._tracker
        tr.buf, tr.buf_abs = self.buf, self.buf_abs
        blocked = self._need(tr, nsym)
        if blocked is not None:
            return blocked

        syms = tr.produce(nsym)
        # Measure quality on the header too.  ACK frames carry no payload, so
        # without this the dashboard shows EVM 0 whenever the last thing heard
        # was an ACK -- and on a struggling link the ACK may be the only thing
        # that decodes at all.
        self._quality(syms)
        llr = self._llrs(syms)[: self.codec.header_coded_bits()]
        hdr_bytes, margin = self.codec.decode_header(llr)
        hdr, ok = Header.unpack(hdr_bytes)
        self._frame.viterbi_margin = float(margin)
        self._frame.header_ok = bool(ok)

        if not ok:
            self.stats.header_fail += 1
            self._frame.stage = "header-crc-fail"
            f = self._finish(False)
            return True, f

        self.stats.header_ok += 1
        self._frame.header = hdr
        self._frame.stage = "header"
        if hdr.payload_len == 0:
            self._frame.crc_ok = True
            f = self._finish(True)
            return True, f
        if hdr.payload_len > self.cfg.MAX_PAYLOAD_BYTES:
            self._frame.stage = "header-length-invalid"
            f = self._finish(False)
            return True, f
        self.state = S_PAYLOAD
        self._wait_since = self._buf_end()
        return True, None

    # ----------------------------------------------------------------- PAYLOAD
    def _do_payload(self):
        hdr = self._frame.header
        nsym = self.codec.payload_symbols(hdr.payload_len)
        tr = self._tracker
        tr.buf, tr.buf_abs = self.buf, self.buf_abs
        blocked = self._need(tr, nsym)
        if blocked is not None:
            return blocked

        syms = tr.produce(nsym)
        llr = self._llrs(syms)[: self.codec.payload_coded_bits(hdr.payload_len)]
        payload, st = self.codec.decode_payload(llr, hdr.payload_len)

        self._frame.rs_corrections = st["rs_corrections"]
        self._frame.crc_ok = st["crc_ok"]
        self._frame.viterbi_margin = st["viterbi_margin"]
        self._frame.n_symbols = nsym
        self._frame.timing_err = tr.timing_err
        self._frame.residual_cfo_hz = tr.freq_hz - self._frame.fine_cfo_hz

        # Constellation + EVM from the payload symbols themselves.
        self._quality(syms)

        if payload is None:
            self.stats.payload_fail += 1
            self._frame.stage = "payload-fail"
            return True, self._finish(False)

        self.stats.payload_ok += 1
        self._frame.payload = payload
        self._frame.stage = "ok"
        return True, self._finish(True)

    # ----------------------------------------------------------------- helpers
    def _quality(self, syms: np.ndarray):
        """EVM / MER / constellation snapshot from a block of despread symbols.

        Normalised by the amplitude measured on this frame's own sync word, so
        the ideal points land on (+-1 +- j)/sqrt(2) regardless of gain.
        """
        if len(syms) == 0:
            return
        norm = syms / (self._amp + 1e-12)
        dec = (np.sign(norm.real) + 1j * np.sign(norm.imag)) / np.sqrt(2)
        evm = float(np.sqrt(np.mean(np.abs(norm - dec) ** 2)))
        self._frame.evm_pct = evm * 100.0
        self._frame.mer_db = -20 * np.log10(max(evm, 1e-9))
        keep = min(len(norm), self.cfg.CONSTELLATION_HISTORY)
        self._frame.constellation = norm[:keep].astype(np.complex64)

    def _llrs(self, syms: np.ndarray) -> np.ndarray:
        """Gray-QPSK soft bits.  LLR > 0 means bit 0.

        For a symbol y whose ideal value is A*(+-1 +- j)/sqrt(2) in complex
        Gaussian noise of total variance sigma^2 (so sigma^2/2 per real axis):
            LLR(I bit) = 2 * sqrt(2) * A * Re(y) / sigma^2
        Getting this scaling right matters: the Viterbi metric is linear in the
        LLRs, so a wrong scale still decodes, but combining the header repeats
        and mixing in erasures from puncturing both rely on true LLR units.
        """
        k = 2.0 * np.sqrt(2.0) * self._amp / self._noise_var
        out = np.empty(2 * len(syms), dtype=np.float32)
        out[0::2] = k * np.real(syms)
        out[1::2] = k * np.imag(syms)
        return out

    def _bounds_state(self, tr: Tracker, nsym: int) -> str:
        """Can this demodulation run?  'ok' | 'wait' (need more) | 'lost' (gone).

        The 'lost' case is the important one: it means the front of the buffer
        was trimmed past where this frame started, so no amount of waiting will
        help.  Treating that as 'wait' is what used to make the receiver go deaf.
        """
        first = int(tr.pos) - int(tr.el_offset) - tr.ntaps - 4
        last = tr.samples_needed(nsym) + tr.ntaps + 4
        if first < self.buf_abs:
            return "lost"
        self._wait_target = last
        return "ok" if last <= self._buf_end() else "wait"

    def _need(self, tr: Tracker, nsym: int):
        """Shared guard for the three demodulating states.

        Returns None if it is safe to proceed, otherwise the (progress, frame)
        tuple the caller should return.
        """
        st = self._bounds_state(tr, nsym)
        if st == "ok":
            return None
        if st == "lost":
            self.stats.buffer_aborts += 1
            self._frame.stage = "buffer-underrun"
            self._abort()
            return True, None
        return self._stall()

    def _stall(self):
        """Waiting for more samples.  Only ever called from SYNC/HEADER/PAYLOAD.

        The wait ends by itself as soon as the stream reaches _wait_target, so
        this guard only catches a genuinely truncated burst: the stream has run
        a whole extra frame past what we were waiting for and it still has not
        arrived -- or flush() has told us nothing more is coming.
        """
        over = self._buf_end() - max(self._wait_target, self._wait_since)
        if self._eos or over > self.cfg.MAX_FRAME_SAMPLES:
            self.stats.stalls += 1
            self._frame.stage = "stalled"
            self._abort()
            return True, None
        return False, None

    def flush(self) -> list[RxFrame]:
        """Tell the receiver the stream has ENDED, and collect what is left.

        A radio never stops, so the receiver is free to wait for more samples
        whenever it needs a few more to be sure of something -- that is what
        makes the wide sync search safe.  A CAPTURE does stop.  Without this, a
        burst near the end of a recording sits waiting forever for samples that
        will never arrive, and the last message in the file is silently lost.

        Call it once after the final process().  Offline tools (run_sim,
        run_validation, hw_diag's capture decode) all do.
        """
        self._eos = True
        out = []
        try:
            for _ in range(8):
                got = self._run()
                out += got
                if not got and self.state == S_SEARCH:
                    break
        finally:
            self._eos = False
        return out

    def _abort(self):
        if self._acq is not None:
            self.scan_pos = max(self.scan_pos,
                                int(self._acq.position) + self.cfg.ACQ_HOP_SAMPLES)
        self.state = S_SEARCH
        self._acq = None
        self._tracker = None

    def _finish(self, ok: bool) -> RxFrame:
        f = self._frame
        f.ok = bool(ok)
        if self._tracker is not None:
            if ok:
                # Resume just after this burst so we do not re-detect it.
                self.scan_pos = max(self.scan_pos,
                                    int(self._tracker.pos) + self.spsym)
            else:
                # A FAILED frame may have read far past the real burst -- a
                # truncated burst makes us demodulate a payload length that was
                # never transmitted.  Skipping all of that would swallow the
                # next message whole.  Resume from the start of the frame body
                # instead, so at worst we re-scan a payload we could not decode.
                self.scan_pos = max(self.scan_pos,
                                    self._frame_start_pos + self.spsym)
        self.state = S_SEARCH
        self._acq = None
        self._tracker = None
        self._frame = RxFrame()
        return f


def _lr_cfo(r: np.ndarray, symbol_rate: float, m_frac: float = 0.25) -> float:
    """Luise & Reggiannini data-aided frequency estimator.

    r is the sync word after removing the known modulation, so ideally it is
    A*exp(j(theta + 2*pi*df*n*T)).  Averaging the autocorrelation over several
    lags before taking the angle is far less noisy than a single-lag estimate,
    which is what gets the residual offset down to a few Hz and keeps the
    constellation from rotating across a long frame.
    """
    n = len(r)
    M = max(1, int(n * m_frac))
    acc = 0.0 + 0.0j
    for m in range(1, M + 1):
        acc += np.sum(r[m:] * np.conj(r[:n - m]))
    ang = np.angle(acc)
    # Unambiguous range is +/- symbol_rate / (2*(M+1)); with m_frac = 0.25 and
    # ~320 known symbols that is about +/- 200 Hz, comfortably more than the
    # +/- half an acquisition FFT bin the coarse stage leaves behind.
    return float(ang * symbol_rate / (np.pi * (M + 1)))
