"""crc.py -- CRC-16/CCITT-FALSE (header) and CRC-32/ISO-HDLC (payload)."""

from __future__ import annotations

import numpy as np


def _make_table(poly: int, width: int) -> np.ndarray:
    top = 1 << (width - 1)
    mask = (1 << width) - 1
    tbl = np.zeros(256, dtype=np.uint32)
    for i in range(256):
        c = (i << (width - 8)) & mask
        for _ in range(8):
            c = ((c << 1) ^ poly) & mask if (c & top) else ((c << 1) & mask)
        tbl[i] = c
    return tbl


_T16 = _make_table(0x1021, 16)
_T32 = _make_table(0x04C11DB7, 32)


def crc16(data: bytes, init: int = 0xFFFF) -> int:
    """CRC-16/CCITT-FALSE.  Used for the 8-byte frame header."""
    c = init
    for b in data:
        c = ((c << 8) & 0xFFFF) ^ int(_T16[((c >> 8) ^ b) & 0xFF])
    return c & 0xFFFF


def crc32(data: bytes) -> int:
    """CRC-32/ISO-HDLC (same polynomial and reflection as zlib.crc32)."""
    import zlib
    return zlib.crc32(data) & 0xFFFFFFFF


def append_crc32(data: bytes) -> bytes:
    return data + crc32(data).to_bytes(4, "big")


def check_crc32(data_with_crc: bytes) -> tuple[bool, bytes]:
    if len(data_with_crc) < 4:
        return False, b""
    body, tail = data_with_crc[:-4], data_with_crc[-4:]
    return crc32(body) == int.from_bytes(tail, "big"), body
