"""
acquisition.py -- finding a burst that is BELOW THE NOISE FLOOR.

THE PROBLEM
    At the antenna the signal is buried: with SPREADING_FACTOR = 31 the link is
    designed to work at a chip-band SNR of roughly -10 dB, i.e. the noise is ten
    times stronger than the signal.  Nothing in the sample stream looks like a
    signal.  You cannot run a timing loop or a carrier loop on it, because those
    loops need an SNR above roughly 0 dB to hold lock.  You have to dig the
    signal out FIRST, open loop, and only then close the loops.

THE METHOD -- "despread, then FFT"
    The preamble is the bare PN code repeated N times.  So:

    1. Correlate the incoming stream against ONE period of the PN code.  That
       is a coherent sum of SPREADING_FACTOR chips -> +10*log10(SF) dB.
       Done for every possible sample delay, so we do not need to know timing.

    2. At the correct delay, the correlator output, sampled once per PN period,
       is a constant times exp(j*2*pi*df*t) -- a pure tone whose frequency is
       the carrier offset.  Everywhere else it is noise.

    3. FFT that sequence of N per-period correlator outputs.  A tone in white
       noise concentrates into one bin -> another +10*log10(N) dB, AND the bin
       index tells you the carrier frequency offset for free.

    Total coherent gain with the defaults: 10*log10(31 * 128) = 36 dB.  That is
    what makes a -15 dB signal show up as a peak 20 dB above its background.

    The search is therefore a 2-D grid over (sample delay, Doppler bin), and it
    costs a handful of FFTs -- microseconds, not a brute-force sweep.

WHY THE SEARCH RANGE IS WHAT IT IS
    Sampling the correlator once per PN period means the Doppler estimate is
    unambiguous only over +/- 1/(2*T_pn) = +/- symbol_rate/2.  With the defaults
    that is +/- 16.1 kHz, which at 915 MHz is +/- 17.6 ppm -- far beyond
    anything a B2xx TCXO will drift.  FREQ_SEARCH_LIMIT_HZ narrows it further to
    cut false alarms.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy import fft as sfft


@dataclass
class AcqResult:
    detected: bool
    # Absolute sample index of the first chip of the first integrated PN period.
    position: float = 0.0
    # Coarse carrier frequency offset, Hz.
    freq_hz: float = 0.0
    # Peak power divided by the median power of the whole search grid.
    psr: float = 0.0
    # Correlation peak magnitude (post-despread, post-FFT), linear.
    peak: float = 0.0
    # Estimated symbol SNR implied by the peak, dB.
    snr_sym_db: float = 0.0
    # Estimated chip-band (pre-despread) SNR, dB -- the "is it below the noise
    # floor?" number.
    snr_chip_db: float = 0.0
    # Doppler concentration: peak power divided by the MEAN power across the
    # whole Doppler axis at the winning delay.  A preamble is the same symbol
    # repeated, so its correlation is constant from PN period to PN period and
    # the FFT across periods puts everything in one bin -- this comes out large.
    # The DATA part of a burst is spread by the same code but modulated, so its
    # correlation changes sign period to period and the FFT smears it across
    # every bin -- this comes out near 1.  That difference is what separates a
    # real preamble from the middle of a burst we are already past, and unlike
    # the peak-to-median ratio it does not depend on how strong the signal is.
    doppler_conc: float = 0.0


class Acquisition:
    def __init__(self, cfg, code: np.ndarray):
        self.cfg = cfg
        self.code = code.astype(np.float32)
        self.sf = int(cfg.SPREADING_FACTOR)
        self.sps = int(cfg.SPS_CHIP)
        self.spsym = self.sf * self.sps
        self.n_acq = int(cfg.N_ACQ_PERIODS)
        self.nfft = int(self.n_acq * cfg.ACQ_FFT_OVERSAMPLE)
        self.t_pn = self.spsym / cfg.SAMP_RATE_HZ           # PN period, seconds

        # Frequency axis of the acquisition FFT (signed, Hz).
        self.freqs = np.fft.fftfreq(self.nfft, d=self.t_pn)
        if cfg.FREQ_SEARCH_LIMIT_HZ:
            self.freq_mask = np.abs(self.freqs) <= float(cfg.FREQ_SEARCH_LIMIT_HZ)
            if not self.freq_mask.any():           # guard against a silly limit
                self.freq_mask = np.ones(self.nfft, dtype=bool)
        else:
            self.freq_mask = np.ones(self.nfft, dtype=bool)
        self.freq_idx = np.nonzero(self.freq_mask)[0]
        # Frequency order of the searched bins, for the dashboard's Doppler cut.
        self._freq_order = np.argsort(self.freqs[self.freq_idx])
        # Cuts through the last search grid -- populated on EVERY search, hit or
        # miss, because "what does the correlator see when there is no signal"
        # is exactly as diagnostic as "what does it see when there is".
        self.last_profile = None
        self._since_profile = 0

    # ------------------------------------------------------------------ search
    def search(self, x: np.ndarray, x_abs_index: int) -> AcqResult:
        """Run one delay x Doppler search over `x` (already matched-filtered).

        x            : complex baseband window, at least ACQ_WINDOW_SAMPLES long
        x_abs_index  : absolute stream index of x[0]
        """
        sf, sps, spsym = self.sf, self.sps, self.spsym
        n_acq, nfft = self.n_acq, self.nfft
        need = spsym * n_acq + spsym          # integration + one period of slack
        if len(x) < need:
            return AcqResult(False)

        # ---- step 1: correlate against one PN period, at every sample delay.
        # Because the code is only non-zero at chip centres after the matched
        # filter, we do it phase by phase: decimate by sps, then correlate the
        # decimated stream with the length-SF code.  Same answer, sps times less
        # work than a dense correlation.
        # How many whole PN periods can the decimated correlator actually
        # produce?  (One code length is consumed by the correlation itself.)
        nper_avail = (((len(x) - sps + 1) // sps) - sf + 1) // sf
        # Integrate over the block that ends GUARD periods before the end of the
        # window.  With ACQ_WINDOW = (N_PREAMBLE+2) periods and a hop of
        # N_PREAMBLE/2 periods, that block is guaranteed to lie entirely inside
        # the preamble no matter where the burst starts -- see the note in
        # config.py under ACQ_FRACTION.
        j0 = nper_avail - n_acq - int(self.cfg.ACQ_GUARD_PERIODS)
        if j0 < 0:
            return AcqResult(False)

        # grid[d, j] = correlation at sample delay d, PN period j
        grid = np.empty((spsym, n_acq), dtype=np.complex64)
        for p in range(sps):
            y = x[p::sps]
            # correlation of y with the code, 'valid' part, via FFT
            c = _corr_valid(y, self.code)
            # c[q] corresponds to sample offset p + sps*q
            need_q = (j0 + n_acq) * sf
            if len(c) < need_q:
                return AcqResult(False)
            blk = c[:need_q].reshape(-1, sf).T          # (sf, nper)
            grid[p::sps, :] = blk[:, j0:j0 + n_acq]

        # ---- step 2: FFT across PN periods -> Doppler.
        spec = sfft.fft(grid, n=nfft, axis=1)
        power = np.abs(spec) ** 2
        power_searched = power[:, self.freq_idx]

        # ---- step 3: peak, and a threshold that is immune to the peak itself.
        flat = np.argmax(power_searched)
        d_idx, f_sub = np.unravel_index(flat, power_searched.shape)
        f_idx = int(self.freq_idx[f_sub])
        peak_pow = float(power_searched[d_idx, f_sub])
        # Median over a subsample: this grid has thousands of cells, the median
        # only needs to estimate the noise floor, and np.median's partition was
        # showing up as a measurable slice of the idle CPU budget.
        flat_pow = power_searched.reshape(-1)
        sub = flat_pow[::7] if flat_pow.size > 2000 else flat_pow
        median_pow = float(np.median(sub)) + 1e-30
        psr = peak_pow / median_pow
        # Mean over the full Doppler axis at the winning delay (all nfft bins,
        # not just the searched ones) -- one row of an array we already have.
        conc = peak_pow / (float(np.mean(power[d_idx, :])) + 1e-30)

        # Only build the diagnostic cuts when they are worth having: on a
        # detection, or occasionally so the dashboard still shows what the
        # correlator sees on an idle channel.  Building them on every single
        # window cost ~20 000 round() calls per second for nothing.
        self._since_profile += 1
        if psr >= self.cfg.ACQ_THRESHOLD_PSR or self._since_profile >= 20:
            self._since_profile = 0
            self._store_profile(power, power_searched, d_idx, f_sub, f_idx, psr,
                                median_pow)

        if psr < self.cfg.ACQ_THRESHOLD_PSR:
            return AcqResult(False, psr=psr, doppler_conc=conc)
        if conc < float(getattr(self.cfg, "ACQ_MIN_DOPPLER_CONC", 0.0)):
            # Strong correlation, but smeared across Doppler: this is the data
            # part of a burst, not its preamble.  Rejecting it here costs one
            # comparison; letting it through costs a full sync search, and then
            # forty more of them as the scan walks through the rest of the burst.
            return AcqResult(False, psr=psr, doppler_conc=conc)

        # ---- step 4: sub-sample delay and sub-bin frequency by parabolic fit.
        d_fine = d_idx + _parabolic(
            power_searched[(d_idx - 1) % spsym, f_sub],
            peak_pow,
            power_searched[(d_idx + 1) % spsym, f_sub])

        fl = power[d_idx, (f_idx - 1) % nfft]
        fr = power[d_idx, (f_idx + 1) % nfft]
        f_fine = f_idx + _parabolic(fl, peak_pow, fr)
        # unwrap the FFT bin index to a signed frequency
        if f_fine > nfft / 2:
            f_fine -= nfft
        freq_hz = f_fine / (nfft * self.t_pn)

        # ---- step 5: SNR estimate.
        # The FFT of noise-only bins has mean power = n_acq * sigma_z^2 where
        # sigma_z^2 is the noise power on one despread symbol.  The peak holds
        # n_acq^2 * A^2 of signal plus that noise floor.
        # |FFT|^2 of complex Gaussian noise is exponentially distributed, whose
        # MEDIAN is ln(2) times its MEAN -- correct for that or the SNR estimate
        # reads ~1.6 dB high.
        noise_mean = float(np.median(power_searched)) / np.log(2.0)
        sig = max(peak_pow - noise_mean, 1e-30)
        # peak_signal / noise_mean = n_acq * SNR_symbol   (see module docstring)
        snr_sym = (sig / noise_mean) / n_acq
        snr_sym_db = 10 * np.log10(max(snr_sym, 1e-12))
        snr_chip_db = snr_sym_db - 10 * np.log10(self.sf)

        if self.last_profile is not None:
            self.last_profile["cfo_hz"] = float(freq_hz)

        pos = x_abs_index + d_fine + j0 * spsym
        return AcqResult(True, position=float(pos), freq_hz=float(freq_hz),
                         psr=float(psr), peak=float(np.sqrt(peak_pow)),
                         snr_sym_db=float(snr_sym_db),
                         snr_chip_db=float(snr_chip_db),
                         doppler_conc=float(conc))


def _corr_valid(y: np.ndarray, template: np.ndarray) -> np.ndarray:
    """r[k] = sum_n y[k+n] * template[n] for k = 0 .. len(y)-len(t).

    DIRECTLY, not via FFT, and that is deliberate.

    The FFT is the right tool when the template is long.  Here it is one PN
    period -- 31 taps -- against a window of ~8000 samples, and the FFT route
    needs a 16384-point transform (three of them) to do what 31 multiply-adds
    per output sample would do.  Counting flops for the default waveform: the
    FFT path is about 27 Mflop per 32k-sample chunk, the direct path about
    1 Mflop.  This correlation runs on every sample the radio produces, forever,
    so that ratio is most of the receiver's idle CPU budget.

    Written as `sf` strided AXPYs so numpy does the work in compiled code, and
    in single precision because the accumulation is only 31 terms deep.
    """
    ny, nt = len(y), len(template)
    if ny < nt:
        return np.zeros(0, dtype=np.complex64)
    n_out = ny - nt + 1
    y = np.ascontiguousarray(y, dtype=np.complex64)
    t = np.asarray(template, dtype=np.float32)
    acc = y[0:n_out] * t[0]
    for k in range(1, nt):
        acc += y[k:k + n_out] * t[k]
    return acc


def _parabolic(ym1: float, y0: float, yp1: float) -> float:
    """Sub-sample offset of the peak of a parabola through three points."""
    denom = (ym1 - 2.0 * y0 + yp1)
    if abs(denom) < 1e-30:
        return 0.0
    d = 0.5 * (ym1 - yp1) / denom
    return float(np.clip(d, -0.5, 0.5))


def _db(v):
    return 10.0 * np.log10(np.asarray(v) + 1e-30)


def _profile_method(self, power, power_searched, d_idx, f_sub, f_idx, psr, med=None):
    """Two 1-D cuts through the delay x Doppler grid, in dB above its median.

    The delay cut should be a single clean spike about one chip wide; a flat
    smear means the correlator is not finding a preamble.  The Doppler cut
    should be one peak; two peaks or a wandering one means the frequency
    estimate is unreliable.
    """
    med = float(med if med is not None else np.median(power_searched)) + 1e-30
    delay = _db(power_searched[:, f_sub] / med)
    dop_all = power[d_idx, self.freq_idx][self._freq_order]
    step = max(1, len(dop_all) // 256)
    self.last_profile = {
        "delay_db": [round(float(v), 2) for v in delay],
        "doppler_db": [round(float(v), 2) for v in _db(dop_all[::step] / med)],
        "psr": float(psr),
        "cfo_hz": 0.0,
    }


Acquisition._store_profile = _profile_method
