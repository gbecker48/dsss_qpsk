"""
acquisition.py -- finding a burst that is BELOW THE NOISE FLOOR.

THE PROBLEM
    At the antenna the signal is buried: with SPREADING_FACTOR = 31 the link is
    designed to work at a chip-band SNR of roughly -10 dB, i.e. the noise is ten
    times stronger than the signal.  Nothing in the sample stream looks like a
    signal.  You cannot run a timing loop or a carrier loop on it, because those
    loops need an SNR above roughly 0 dB to hold lock.  You have to dig the
    signal out FIRST, open loop, and only then close the loops.

THE METHOD -- "despread, then FFT"
    The preamble is the bare PN code repeated N times.  So:

    1. Correlate the incoming stream against ONE period of the PN code.  That
       is a coherent sum of SPREADING_FACTOR chips -> +10*log10(SF) dB.
       Done for every possible sample delay, so we do not need to know timing.

    2. At the correct delay, the correlator output, sampled once per PN period,
       is a constant times exp(j*2*pi*df*t) -- a pure tone whose frequency is
       the carrier offset.  Everywhere else it is noise.

    3. FFT that sequence of N per-period correlator outputs.  A tone in white
       noise concentrates into one bin -> another +10*log10(N) dB, AND the bin
       index tells you the carrier frequency offset for free.

    Total coherent gain with the defaults: 10*log10(31 * 128) = 36 dB.  That is
    what makes a -15 dB signal show up as a peak 20 dB above its background.

    The search is therefore a 2-D grid over (sample delay, Doppler bin), and it
    costs a handful of FFTs -- microseconds, not a brute-force sweep.

WHY THE SEARCH RANGE IS WHAT IT IS
    Sampling the correlator once per PN period means the Doppler estimate is
    unambiguous only over +/- 1/(2*T_pn) = +/- symbol_rate/2.  With the defaults
    that is +/- 16.1 kHz, which at 915 MHz is +/- 17.6 ppm -- far beyond
    anything a B2xx TCXO will drift.  FREQ_SEARCH_LIMIT_HZ narrows it further to
    cut false alarms.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class AcqResult:
    detected: bool
    # Absolute sample index of the first chip of the first integrated PN period.
    position: float = 0.0
    # Coarse carrier frequency offset, Hz.
    freq_hz: float = 0.0
    # Peak power divided by the median power of the whole search grid.
    psr: float = 0.0
    # Correlation peak magnitude (post-despread, post-FFT), linear.
    peak: float = 0.0
    # Estimated symbol SNR implied by the peak, dB.
    snr_sym_db: float = 0.0
    # Estimated chip-band (pre-despread) SNR, dB -- the "is it below the noise
    # floor?" number.
    snr_chip_db: float = 0.0


class Acquisition:
    def __init__(self, cfg, code: np.ndarray):
        self.cfg = cfg
        self.code = code.astype(np.float64)
        self.sf = int(cfg.SPREADING_FACTOR)
        self.sps = int(cfg.SPS_CHIP)
        self.spsym = self.sf * self.sps
        self.n_acq = int(cfg.N_ACQ_PERIODS)
        self.nfft = int(self.n_acq * cfg.ACQ_FFT_OVERSAMPLE)
        self.t_pn = self.spsym / cfg.SAMP_RATE_HZ           # PN period, seconds

        # Frequency axis of the acquisition FFT (signed, Hz).
        self.freqs = np.fft.fftfreq(self.nfft, d=self.t_pn)
        if cfg.FREQ_SEARCH_LIMIT_HZ:
            self.freq_mask = np.abs(self.freqs) <= float(cfg.FREQ_SEARCH_LIMIT_HZ)
            if not self.freq_mask.any():           # guard against a silly limit
                self.freq_mask = np.ones(self.nfft, dtype=bool)
        else:
            self.freq_mask = np.ones(self.nfft, dtype=bool)
        self.freq_idx = np.nonzero(self.freq_mask)[0]

    # ------------------------------------------------------------------ search
    def search(self, x: np.ndarray, x_abs_index: int) -> AcqResult:
        """Run one delay x Doppler search over `x` (already matched-filtered).

        x            : complex baseband window, at least ACQ_WINDOW_SAMPLES long
        x_abs_index  : absolute stream index of x[0]
        """
        sf, sps, spsym = self.sf, self.sps, self.spsym
        n_acq, nfft = self.n_acq, self.nfft
        need = spsym * n_acq + spsym          # integration + one period of slack
        if len(x) < need:
            return AcqResult(False)

        # ---- step 1: correlate against one PN period, at every sample delay.
        # Because the code is only non-zero at chip centres after the matched
        # filter, we do it phase by phase: decimate by sps, then correlate the
        # decimated stream with the length-SF code.  Same answer, sps times less
        # work than a dense correlation.
        # How many whole PN periods can the decimated correlator actually
        # produce?  (One code length is consumed by the correlation itself.)
        nper_avail = (((len(x) - sps + 1) // sps) - sf + 1) // sf
        # Integrate over the block that ends GUARD periods before the end of the
        # window.  With ACQ_WINDOW = (N_PREAMBLE+2) periods and a hop of
        # N_PREAMBLE/2 periods, that block is guaranteed to lie entirely inside
        # the preamble no matter where the burst starts -- see the note in
        # config.py under ACQ_FRACTION.
        j0 = nper_avail - n_acq - int(self.cfg.ACQ_GUARD_PERIODS)
        if j0 < 0:
            return AcqResult(False)

        # grid[d, j] = correlation at sample delay d, PN period j
        grid = np.empty((spsym, n_acq), dtype=np.complex128)
        for p in range(sps):
            y = x[p::sps]
            # correlation of y with the code, 'valid' part, via FFT
            c = _corr_valid(y, self.code)
            # c[q] corresponds to sample offset p + sps*q
            need_q = (j0 + n_acq) * sf
            if len(c) < need_q:
                return AcqResult(False)
            blk = c[:need_q].reshape(-1, sf).T          # (sf, nper)
            grid[p::sps, :] = blk[:, j0:j0 + n_acq]

        # ---- step 2: FFT across PN periods -> Doppler.
        spec = np.fft.fft(grid, n=nfft, axis=1)
        power = np.abs(spec) ** 2
        power_searched = power[:, self.freq_idx]

        # ---- step 3: peak, and a threshold that is immune to the peak itself.
        flat = np.argmax(power_searched)
        d_idx, f_sub = np.unravel_index(flat, power_searched.shape)
        f_idx = int(self.freq_idx[f_sub])
        peak_pow = float(power_searched[d_idx, f_sub])
        median_pow = float(np.median(power_searched)) + 1e-30
        psr = peak_pow / median_pow

        if psr < self.cfg.ACQ_THRESHOLD_PSR:
            return AcqResult(False, psr=psr)

        # ---- step 4: sub-sample delay and sub-bin frequency by parabolic fit.
        d_fine = d_idx + _parabolic(
            power_searched[(d_idx - 1) % spsym, f_sub],
            peak_pow,
            power_searched[(d_idx + 1) % spsym, f_sub])

        fl = power[d_idx, (f_idx - 1) % nfft]
        fr = power[d_idx, (f_idx + 1) % nfft]
        f_fine = f_idx + _parabolic(fl, peak_pow, fr)
        # unwrap the FFT bin index to a signed frequency
        if f_fine > nfft / 2:
            f_fine -= nfft
        freq_hz = f_fine / (nfft * self.t_pn)

        # ---- step 5: SNR estimate.
        # The FFT of noise-only bins has mean power = n_acq * sigma_z^2 where
        # sigma_z^2 is the noise power on one despread symbol.  The peak holds
        # n_acq^2 * A^2 of signal plus that noise floor.
        # |FFT|^2 of complex Gaussian noise is exponentially distributed, whose
        # MEDIAN is ln(2) times its MEAN -- correct for that or the SNR estimate
        # reads ~1.6 dB high.
        noise_mean = float(np.median(power_searched)) / np.log(2.0)
        sig = max(peak_pow - noise_mean, 1e-30)
        # peak_signal / noise_mean = n_acq * SNR_symbol   (see module docstring)
        snr_sym = (sig / noise_mean) / n_acq
        snr_sym_db = 10 * np.log10(max(snr_sym, 1e-12))
        snr_chip_db = snr_sym_db - 10 * np.log10(self.sf)

        pos = x_abs_index + d_fine + j0 * spsym
        return AcqResult(True, position=float(pos), freq_hz=float(freq_hz),
                         psr=float(psr), peak=float(np.sqrt(peak_pow)),
                         snr_sym_db=float(snr_sym_db),
                         snr_chip_db=float(snr_chip_db))


def _corr_valid(y: np.ndarray, template: np.ndarray) -> np.ndarray:
    """r[k] = sum_n y[k+n] * conj(template[n]) for k = 0 .. len(y)-len(t)."""
    ny, nt = len(y), len(template)
    if ny < nt:
        return np.zeros(0, dtype=np.complex128)
    nfft = 1 << int(np.ceil(np.log2(ny + nt)))
    Y = np.fft.fft(y, nfft)
    T = np.fft.fft(np.conj(template[::-1]), nfft)
    full = np.fft.ifft(Y * T)
    return full[nt - 1:ny]


def _parabolic(ym1: float, y0: float, yp1: float) -> float:
    """Sub-sample offset of the peak of a parabola through three points."""
    denom = (ym1 - 2.0 * y0 + yp1)
    if abs(denom) < 1e-30:
        return 0.0
    d = 0.5 * (ym1 - yp1) / denom
    return float(np.clip(d, -0.5, 0.5))
