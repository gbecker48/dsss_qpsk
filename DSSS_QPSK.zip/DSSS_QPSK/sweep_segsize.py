#!/usr/bin/env python3
"""Find the largest frame payload that still closes the link below the noise.

File transfer is latency-bound (stop-and-wait), so every doubling of the
segment size nearly halves the transfer time.  The question is whether a longer
burst costs sensitivity: the carrier and timing loops have to hold phase for
longer, and one uncorrectable RS codeword kills the whole frame instead of half
of it.  This measures that instead of guessing.
"""
import sys
import numpy as np
sys.path.insert(0, ".")
from dsss_qpsk import config as cfg            # noqa: E402
from run_sim import one_frame                  # noqa: E402

SIZES = [512, 1024, 2048, 4096]
SNRS = [-11, -12, -13, -14]
N = 24

print(f"{'bytes':>6s} {'burst ms':>9s} " +
      " ".join(f"{s:>6.0f}dB" for s in SNRS) + "   EVM%@-12")
for nb in SIZES:
    cfg.MAX_PAYLOAD_BYTES = nb
    cfg.recompute()
    from dsss_qpsk.modulator import Modulator
    dur = Modulator(cfg).burst_duration(nb) * 1e3
    row, evms = [], []
    for snr in SNRS:
        ok = 0
        for k in range(N):
            rng = np.random.default_rng(1000 + k)
            payload = bytes(rng.integers(0, 256, nb, dtype=np.uint8))
            frames, _, _ = one_frame(snr, payload, seed=1000 + k)
            good = [f for f in frames if f.ok and f.payload == payload]
            if good:
                ok += 1
                if snr == -12:
                    evms.append(good[0].evm_pct)
        row.append(100.0 * ok / N)
    print(f"{nb:6d} {dur:9.1f} " + " ".join(f"{v:7.0f}%" for v in row) +
          f"   {np.mean(evms) if evms else float('nan'):8.1f}")
