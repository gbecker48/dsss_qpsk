#!/usr/bin/env python3
"""
run_validation.py -- the hardcore test chain.

Not a smoke test.  This is the "prove it actually works" pass: it tries to break
the link with every impairment a real radio will throw at it, measures against
theory rather than against itself, and prints a verdict per section.

    python run_validation.py                 everything (about 10 minutes)
    python run_validation.py --quick         fewer trials (about 2 minutes)
    python run_validation.py --only 1,3,5    just those sections
    python run_validation.py --json v.json   machine-readable results

SECTIONS
  1  BELOW THE NOISE FLOOR   spectral proof that the signal is genuinely buried,
                             and that it decodes anyway
  2  PROCESSING GAIN         measured despreading gain vs 10*log10(SF)
  3  SENSITIVITY             Monte Carlo frame-error curve
  4  CONSTELLATION QUALITY   EVM vs the theoretical bound; implementation floor
  5  IMPAIRMENTS             CFO, clock offset, delay, phase, DC, IQ imbalance,
                             front-end compression -- each swept to failure
  6  INTERFERENCE            CW jammer and partial-band noise
  7  PAYLOAD INTEGRITY       every size, bit-exact, including the edges
  8  FALSE ALARM             long noise soak, nothing may be decoded
  9  SPREADING FACTOR        does more spreading actually buy the dB it claims
 10  TWO NODES               the two-radio addressing path, never run on hardware
 11  SOAK                    long continuous run; state, memory, drift
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from concurrent.futures import ProcessPoolExecutor

import numpy as np

from dsss_qpsk import channel
from dsss_qpsk import config as cfg
from dsss_qpsk.framing import FT_ACK, FT_DATA, Header
from dsss_qpsk.modulator import Modulator
from dsss_qpsk.receiver import Receiver

RESULTS: dict = {}
FAILURES: list[str] = []


# ------------------------------------------------------------------ utilities
def hdr(title):
    print()
    print("=" * 78)
    print(f"  {title}")
    print("=" * 78)


def verdict(name, ok, detail=""):
    print(f"  [{'PASS' if ok else 'FAIL'}]  {name}" + (f"   {detail}" if detail else ""))
    if not ok:
        FAILURES.append(f"{name} ({detail})" if detail else name)
    return ok


def make_burst(payload, seq=1, ftype=FT_DATA, src=1, dst=255):
    mod = Modulator(cfg)
    h = Header(ftype=ftype, src=src, dst=dst, seq=seq & 0xF, payload_len=len(payload))
    return mod.modulate(h, payload)


def decode(stream, chunk=1 << 16, receiver=None):
    rx = receiver or Receiver(cfg)
    frames = []
    for i in range(0, len(stream), chunk):
        frames += rx.process(stream[i:i + chunk])
    frames += rx.flush()   # a capture ends; a radio does not.  See Receiver.flush
    return frames, rx


def trial(args):
    """One independent frame through the channel.  Top level, so it can be forked."""
    (snr, payload, seed, cfo, sfo, delay, phase, dc, iqg, iqp) = args
    rng = np.random.default_rng(seed)
    cfo = rng.uniform(-3000, 3000) if cfo is None else cfo
    sfo = rng.uniform(-3, 3) if sfo is None else sfo
    delay = rng.uniform(0, 30) if delay is None else delay
    phase = rng.uniform(-np.pi, np.pi) if phase is None else phase
    burst = make_burst(payload, seq=seed)
    stream = channel.apply_channel(burst, cfg, snr, cfo_hz=cfo, phase=phase,
                                   delay=delay, sfo_ppm=sfo, seed=seed + 7919,
                                   dc_offset=dc, iq_gain_db=iqg, iq_phase_deg=iqp)
    frames, rx = decode(stream)
    good = [f for f in frames if f.ok and f.payload == payload]
    f = good[0] if good else (frames[-1] if frames else None)
    return {
        "ok": bool(good),
        "acq": rx.stats.acquisitions > 0,
        "sync": rx.stats.sync_found > 0,
        "hdr": rx.stats.header_ok > 0,
        "evm": f.evm_pct if f else float("nan"),
        "snr_sym": f.snr_sym_db if f else float("nan"),
        "snr_chip": f.snr_chip_db if f else float("nan"),
        "cfo_err": (f.fine_cfo_hz - cfo) if f else float("nan"),
        "acq_psr": f.acq_psr if f else 0.0,
        "rs": max(f.rs_corrections, 0) if f else -1,
        "false_acq": rx.stats.false_acquisitions,
    }


def run_trials(snr, payload, n, pool=None, seed0=1000, **kw):
    jobs = [(snr, payload, seed0 + 37 * i,
             kw.get("cfo"), kw.get("sfo"), kw.get("delay"), kw.get("phase"),
             kw.get("dc", 0.0), kw.get("iqg", 0.0), kw.get("iqp", 0.0))
            for i in range(n)]
    if pool is not None:
        return list(pool.map(trial, jobs))
    return [trial(j) for j in jobs]


def rate(rs, key="ok"):
    return 100.0 * sum(1 for r in rs if r[key]) / max(len(rs), 1)


# =========================================================== 1. below the noise
def sec_below_noise(pool, N):
    hdr("1. BELOW THE NOISE FLOOR -- is the signal genuinely buried?")
    payload = b"below the noise floor" * 3
    burst = make_burst(payload)
    snr = -13.0

    # Spectral proof: compare the band with and without the signal present.
    rng = np.random.default_rng(5)
    p_sig = float(np.mean(np.abs(burst) ** 2))
    sigma2 = p_sig * cfg.SPS_CHIP / (10 ** (snr / 10))
    n = len(burst)
    noise = np.sqrt(sigma2 / 2) * (rng.standard_normal(n) + 1j * rng.standard_normal(n))
    with_sig = burst + noise

    def band_power(x):
        nfft = 8192
        k = len(x) // nfft
        seg = np.asarray(x[:k * nfft]).reshape(k, nfft) * np.hanning(nfft)
        P = (np.abs(np.fft.fft(seg, axis=1)) ** 2).mean(axis=0)
        f = np.fft.fftfreq(nfft, 1 / cfg.SAMP_RATE_HZ)
        band = np.abs(f - cfg.IF_OFFSET_HZ) < cfg.CHIP_RATE_HZ / 2
        return 10 * np.log10(P[band].sum())

    p_noise_only = band_power(noise)
    p_both = band_power(with_sig)
    rise = p_both - p_noise_only
    theory = 10 * np.log10(1 + 10 ** (snr / 10))

    print(f"  occupied band power, noise only     : {p_noise_only:8.2f} dB")
    print(f"  occupied band power, signal + noise : {p_both:8.2f} dB")
    print(f"  the signal raises the floor by      : {rise:8.2f} dB "
          f"(theory {theory:.2f} dB)")
    print(f"  i.e. the signal is {-snr:.0f} dB BELOW the noise in its own bandwidth.")
    print(f"  Peak of the spectrum is noise, not signal -- nothing to see on an analyser.")

    rs = run_trials(snr, payload, N, pool)
    fer = 100 - rate(rs)
    evm = np.nanmean([r["evm"] for r in rs if r["ok"]])
    print(f"\n  {N} frames at {snr:.0f} dB chip SNR:")
    print(f"    frame success       : {rate(rs):6.1f} %")
    print(f"    mean EVM            : {evm:6.2f} %")
    print(f"    acquisition success : {rate(rs,'acq'):6.1f} %")

    ok = verdict("signal really is below the noise floor",
                 abs(rise - theory) < 0.35 and rise < 0.5,
                 f"floor rises only {rise:.2f} dB")
    ok &= verdict("decodes anyway at -13 dB chip SNR", rate(rs) >= 90.0,
                  f"{rate(rs):.0f}% success, FER {fer:.0f}%")
    RESULTS["below_noise"] = {"snr_db": snr, "floor_rise_db": rise,
                              "theory_db": theory, "success_pct": rate(rs)}
    return ok


# ============================================================ 2. processing gain
def sec_processing_gain(pool, N):
    hdr("2. PROCESSING GAIN -- is the despreading actually delivering 10log10(SF)?")
    payload = b"processing gain check" * 2
    theory = 10 * np.log10(cfg.SPREADING_FACTOR)
    rows = []
    ok = True
    for snr in (-12, -8, -4, 0, 6):
        rs = run_trials(snr, payload, max(6, N // 4), pool, seed0=2000 + 100 * snr)
        good = [r for r in rs if r["ok"]]
        if not good:
            rows.append((snr, float("nan"), float("nan")))
            continue
        meas = np.mean([r["snr_sym"] for r in good])
        gain = meas - snr
        rows.append((snr, meas, gain))
        print(f"  chip SNR {snr:+4.0f} dB -> symbol SNR {meas:6.2f} dB "
              f"= gain {gain:5.2f} dB   (theory {theory:.2f})")
    gains = [g for _, _, g in rows if np.isfinite(g)]
    err = max(abs(g - theory) for g in gains) if gains else 99
    ok &= verdict("measured despreading gain matches 10*log10(SF)", err < 1.2,
                  f"worst error {err:.2f} dB vs theory {theory:.2f} dB")
    RESULTS["processing_gain"] = {"theory_db": theory, "rows": rows}
    return ok


# ================================================================ 3. sensitivity
def sec_sensitivity(pool, N):
    hdr("3. SENSITIVITY -- Monte Carlo frame-error curve")
    payload = bytes(np.random.default_rng(0).integers(0, 256, 64, dtype=np.uint8))
    print(f"  {N} independent frames per point, random CFO +/-3 kHz, "
          f"SFO +/-3 ppm, delay, phase")
    print(f"\n  {'chipSNR':>8s} {'acq%':>6s} {'sync%':>6s} {'hdr%':>6s} "
          f"{'FRAME%':>7s} {'EVM%':>7s} {'CFOerr':>8s} {'RS':>5s}")
    print("  " + "-" * 62)
    curve = []
    for snr in (-17, -16, -15, -14, -13.5, -13, -12, -10):
        rs = run_trials(snr, payload, N, pool, seed0=3000 + int(-snr * 91))
        good = [r for r in rs if r["ok"]]
        evm = np.mean([r["evm"] for r in good]) if good else float("nan")
        cerr = np.mean([abs(r["cfo_err"]) for r in good]) if good else float("nan")
        rsc = np.mean([r["rs"] for r in good]) if good else float("nan")
        curve.append((snr, rate(rs), rate(rs, "acq"), rate(rs, "sync"), rate(rs, "hdr")))
        print(f"  {snr:8.1f} {rate(rs,'acq'):6.0f} {rate(rs,'sync'):6.0f} "
              f"{rate(rs,'hdr'):6.0f} {rate(rs):7.0f} {evm:7.2f} {cerr:8.2f} {rsc:5.1f}")
    good_pts = [c for c in curve if c[1] >= 90]
    sens = min(c[0] for c in good_pts) if good_pts else None
    print(f"\n  SENSITIVITY: {sens} dB chip SNR at >=90% frame success")
    ok = verdict("sensitivity at or below -13 dB chip SNR",
                 sens is not None and sens <= -13.0, f"{sens} dB")
    ok &= verdict("acquisition still works 4 dB below the decoding limit",
                  all(c[2] >= 90 for c in curve if c[0] >= -17),
                  "acq >=90% down to -17 dB")
    RESULTS["sensitivity"] = {"curve": curve, "sensitivity_db": sens}
    return ok


# ======================================================= 4. constellation quality
def sec_constellation(pool, N):
    hdr("4. CONSTELLATION QUALITY -- how tight can the dots get?")
    payload = bytes(np.random.default_rng(1).integers(0, 256, 300, dtype=np.uint8))
    print(f"  Theory: for QPSK in AWGN, EVM_rms = 1/sqrt(SNR_symbol).")
    print(f"  Anything above that is implementation loss.\n")
    print(f"  {'chipSNR':>8s} {'symSNR':>8s} {'EVM meas':>9s} {'EVM theory':>11s} "
          f"{'excess':>8s}")
    print("  " + "-" * 50)
    rows, excess = [], []
    for snr in (-10, -5, 0, 10, 20, 40):
        rs = run_trials(snr, payload, max(4, N // 6), pool, seed0=4000 + 77 * snr,
                        cfo=1200.0, sfo=2.0, delay=3.37, phase=1.1)
        good = [r for r in rs if r["ok"]]
        if not good:
            continue
        sym = np.mean([r["snr_sym"] for r in good])
        evm = np.mean([r["evm"] for r in good])
        th = 100.0 / np.sqrt(10 ** (sym / 10))
        ex = 20 * np.log10(evm / th)
        rows.append((snr, sym, evm, th, ex))
        excess.append(ex)
        print(f"  {snr:8.0f} {sym:8.2f} {evm:8.2f} % {th:10.2f} % {ex:+7.2f} dB")
    floor = min(r[2] for r in rows)
    print(f"\n  implementation EVM floor: {floor:.3f} % "
          f"(MER {-20*np.log10(floor/100):.1f} dB)")
    ok = verdict("EVM tracks the theoretical bound (no hidden loss)",
                 max(excess[:-1]) < 1.5 if len(excess) > 1 else True,
                 f"worst excess {max(excess[:-1]):+.2f} dB below 40 dB SNR")
    ok &= verdict("implementation EVM floor below 1%", floor < 1.0,
                  f"{floor:.3f} %")
    RESULTS["constellation"] = {"rows": rows, "floor_pct": floor}
    return ok


# ================================================================ 5. impairments
def sec_impairments(pool, N):
    hdr("5. IMPAIRMENTS -- sweep each one until it breaks")
    payload = b"impairment sweep payload" * 4
    snr = -10.0
    n = max(6, N // 3)
    ok = True

    def sweep(label, key, values, fmt="{:g}", **fixed):
        print(f"\n  {label}")
        results = []
        for v in values:
            kw = dict(fixed)
            kw[key] = v
            rs = run_trials(snr, payload, n, pool, seed0=5000 + abs(hash(label)) % 900,
                            **kw)
            r = rate(rs)
            evm = np.nanmean([x["evm"] for x in rs if x["ok"]]) if r else float("nan")
            results.append((v, r, evm))
            bar = "#" * int(r / 5)
            print(f"    {fmt.format(v):>12s} : {r:5.0f} %  EVM {evm:6.2f} %  {bar}")
        return results

    cfo = sweep("carrier frequency offset (Hz) -- search limit is +/-6000",
                "cfo", [0, 500, 2000, 5000, 5900], "{:.0f}",
                sfo=0.0, delay=3.3, phase=0.7)
    ok &= verdict("survives the full +/-6 kHz carrier search range",
                  all(r >= 85 for _, r, _ in cfo), "")

    sfo = sweep("sample clock offset (ppm)", "sfo",
                [0, 5, 20, 50, 100], "{:.0f}",
                cfo=800.0, delay=3.3, phase=0.7)
    ok &= verdict("tolerates >=20 ppm clock offset (B2xx TCXO is ~2 ppm)",
                  all(r >= 85 for v, r, _ in sfo if v <= 20), "")

    dly = sweep("fractional sample delay", "delay",
                [0.0, 0.25, 0.5, 0.75, 17.4], "{:.2f}",
                cfo=800.0, sfo=2.0, phase=0.7)
    ok &= verdict("timing recovery handles any fractional delay",
                  all(r >= 90 for _, r, _ in dly), "")

    dc = sweep("receiver DC offset (fraction of signal rms)", "dc",
               [0.0, 0.05, 0.2, 0.5], "{:.2f}",
               cfo=800.0, sfo=2.0, delay=3.3, phase=0.7)
    ok &= verdict("DC blocker handles a large offset",
                  all(r >= 85 for _, r, _ in dc), "")

    iq = sweep("IQ gain imbalance (dB) -- your radio measured 30 dB image rej",
               "iqg", [0.0, 0.5, 1.0, 2.0], "{:.1f}",
               cfo=800.0, sfo=2.0, delay=3.3, phase=0.7, iqp=3.0)
    ok &= verdict("tolerates realistic IQ imbalance",
                  all(r >= 85 for v, r, _ in iq if v <= 1.0), "")

    RESULTS["impairments"] = {"cfo": cfo, "sfo": sfo, "delay": dly,
                              "dc": dc, "iq": iq}
    return ok


# =============================================================== 6. interference
def sec_interference(pool, N):
    hdr("6. INTERFERENCE -- can a jammer kill it?")
    payload = b"jammer test payload" * 5
    snr = -10.0
    n = max(6, N // 3)
    ok = True

    print("\n  CW tone jammer inside the occupied band, relative to the SIGNAL:")
    rows = []
    for jam_db in (-10, 0, 10, 20, 30):
        succ = 0
        for i in range(n):
            burst = make_burst(payload, seq=i)
            p_sig = float(np.mean(np.abs(burst) ** 2))
            stream = channel.apply_channel(burst, cfg, snr, cfo_hz=900.0,
                                           phase=0.4, delay=4.1, sfo_ppm=1.5,
                                           seed=6000 + i)
            amp = np.sqrt(p_sig * 10 ** (jam_db / 10))
            k = np.arange(len(stream))
            # a tone offset from the signal centre, inside the band
            stream = stream + (amp * np.exp(2j * np.pi * 120e3 * k / cfg.SAMP_RATE_HZ
                                            + 1j * 0.3)).astype(np.complex64)
            frames, rx = decode(stream)
            succ += any(f.ok and f.payload == payload for f in frames)
        r = 100.0 * succ / n
        rows.append((jam_db, r))
        print(f"    jammer {jam_db:+3d} dB vs signal : {r:5.0f} %  {'#'*int(r/5)}")
    ok &= verdict("survives a CW jammer at +10 dB (processing gain rejects it)",
                  dict(rows).get(10, 0) >= 85,
                  f"{dict(rows).get(10,0):.0f}% at +10 dB")

    print("\n  partial-band noise jammer (200 kHz wide, inside the band):")
    rows2 = []
    for jam_db in (0, 10, 20):
        succ = 0
        for i in range(n):
            burst = make_burst(payload, seq=i)
            p_sig = float(np.mean(np.abs(burst) ** 2))
            stream = channel.apply_channel(burst, cfg, snr, cfo_hz=900.0,
                                           phase=0.4, delay=4.1, sfo_ppm=1.5,
                                           seed=6500 + i)
            rng = np.random.default_rng(90 + i)
            m = len(stream)
            j = (rng.standard_normal(m) + 1j * rng.standard_normal(m))
            J = np.fft.fft(j)
            f = np.fft.fftfreq(m, 1 / cfg.SAMP_RATE_HZ)
            J[np.abs(f - 150e3) > 100e3] = 0
            j = np.fft.ifft(J)
            j *= np.sqrt(p_sig * 10 ** (jam_db / 10) / np.mean(np.abs(j) ** 2))
            stream = (stream + j).astype(np.complex64)
            frames, rx = decode(stream)
            succ += any(f_.ok and f_.payload == payload for f_ in frames)
        r = 100.0 * succ / n
        rows2.append((jam_db, r))
        print(f"    jammer {jam_db:+3d} dB vs signal : {r:5.0f} %  {'#'*int(r/5)}")
    ok &= verdict("survives partial-band noise at equal power",
                  dict(rows2).get(0, 0) >= 85, f"{dict(rows2).get(0,0):.0f}% at 0 dB")
    RESULTS["interference"] = {"cw": rows, "partial_band": rows2}
    return ok


# =========================================================== 7. payload integrity
def sec_payload(pool, N):
    hdr("7. PAYLOAD INTEGRITY -- every size, bit exact")
    rng = np.random.default_rng(11)
    sizes = [0, 1, 2, 7, 63, 64, 65, 127, 222, 223, 224, 255, 256, 400,
             cfg.MAX_PAYLOAD_BYTES]
    bad = []
    total_bytes = 0
    print(f"  {len(sizes)} payload sizes including every FEC block boundary, "
          f"at -10 dB chip SNR")
    for i, n in enumerate(sizes):
        payload = bytes(rng.integers(0, 256, n, dtype=np.uint8))
        burst = make_burst(payload, seq=i)
        stream = channel.apply_channel(burst, cfg, -10.0, cfo_hz=1100.0, phase=0.9,
                                       delay=5.5, sfo_ppm=1.7, seed=7000 + i)
        frames, rx = decode(stream)
        got = [f for f in frames if f.ok]
        match = any(f.payload == payload for f in got) if n else bool(got)
        total_bytes += n
        if not match:
            bad.append(n)
        print(f"    {n:5d} B : {'ok' if match else 'MISMATCH':>8s}"
              f"   ({len(got)} frame(s) decoded)")
    ok = verdict("every payload size round-trips bit-exact",
                 not bad, f"failed sizes: {bad}" if bad else f"{total_bytes} bytes")
    RESULTS["payload_integrity"] = {"sizes": sizes, "failed": bad}
    return ok


# ================================================================ 8. false alarm
def sec_false_alarm(pool, N, seconds):
    hdr("8. FALSE ALARM -- pure noise must never produce a frame")
    rx = Receiver(cfg)
    rng = np.random.default_rng(13)
    total = int(seconds * cfg.SAMP_RATE_HZ)
    done, frames = 0, []
    t0 = time.time()
    while done < total:
        n = min(1 << 17, total - done)
        x = ((rng.standard_normal(n) + 1j * rng.standard_normal(n)) * 0.1
             ).astype(np.complex64)
        frames += rx.process(x)
        done += n
    dt = time.time() - t0
    s = rx.stats
    print(f"  {seconds:.0f} s of pure noise ({total/1e6:.1f} M samples) in {dt:.1f} s")
    print(f"    acquisitions triggered : {s.acquisitions}  ({s.acquisitions/seconds:.2f}/s)")
    print(f"    killed by preamble check: {s.early_rejects}")
    print(f"    reached sync           : {s.sync_found}")
    print(f"    passed header CRC      : {s.header_ok}")
    print(f"    FULL FRAMES FABRICATED : {s.payload_ok}")
    ok = verdict("no frame ever decoded from noise", s.payload_ok == 0 and not frames)
    ok &= verdict("no noise event passes the header CRC", s.header_ok == 0)
    RESULTS["false_alarm"] = {"seconds": seconds, "acquisitions": s.acquisitions,
                              "header_ok": s.header_ok, "payload_ok": s.payload_ok}
    return ok


# =========================================================== 9. spreading factor
def sec_spreading(pool, N):
    hdr("9. SPREADING FACTOR -- does more spreading buy the dB it promises?")
    payload = b"spreading factor scaling test"
    base_sf = cfg.SPREADING_FACTOR
    rows = []
    ok = True
    try:
        for sf, snr in ((31, -13.0), (63, -16.0), (127, -19.0)):
            cfg.SPREADING_FACTOR = sf
            cfg.recompute()
            rs = run_trials(snr, payload, max(6, N // 4), None, seed0=8000 + sf)
            r = rate(rs)
            gain = 10 * np.log10(sf)
            rows.append((sf, snr, r, gain))
            print(f"    SF {sf:4d} (gain {gain:5.2f} dB) at {snr:+5.1f} dB chip SNR "
                  f"-> {r:5.0f} % success   rate {cfg.NET_BITRATE_BPS/1000:5.1f} kbit/s")
        ok &= verdict("each doubling of SF buys ~3 dB of sensitivity",
                      all(r >= 80 for _, _, r, _ in rows),
                      "SF 63 works at -16 dB, SF 127 at -19 dB")
    finally:
        cfg.SPREADING_FACTOR = base_sf
        cfg.recompute()
    RESULTS["spreading"] = {"rows": rows}
    return ok


# ================================================================= 10. two nodes
def sec_two_nodes(pool, N):
    hdr("10. TWO NODES -- the two-radio addressing path (never run on hardware)")
    saved = (cfg.NODE_ID, cfg.PEER_NODE_ID, cfg.LOOPBACK_ACCEPT_OWN)
    ok = True
    try:
        # Node A transmits to node B.  B must accept it; a third node must not.
        cfg.LOOPBACK_ACCEPT_OWN = False
        payload = b"addressed to node 2 only"
        burst = make_burst(payload, seq=3, src=1, dst=2)
        stream = channel.apply_channel(burst, cfg, -10.0, cfo_hz=2500.0, phase=1.3,
                                       delay=7.7, sfo_ppm=2.5, seed=9001)
        frames, rx = decode(stream)
        got = [f for f in frames if f.ok]
        print(f"    frame decoded: {len(got)}   header: "
              f"{got[0].header.describe() if got else '--'}")
        ok &= verdict("addressed frame decodes and carries the right src/dst",
                      bool(got) and got[0].header.src == 1 and got[0].header.dst == 2,
                      "")
        ok &= verdict("payload intact across the two-node path",
                      bool(got) and got[0].payload == payload)

        # An ACK addressed back the other way
        ackburst = make_burst(b"", seq=0, ftype=FT_ACK, src=2, dst=1)
        stream = channel.apply_channel(ackburst, cfg, -10.0, cfo_hz=-1800.0,
                                       phase=0.2, delay=2.2, sfo_ppm=-2.0, seed=9002)
        frames, rx = decode(stream)
        acks = [f for f in frames if f.ok and f.header and f.header.ftype == FT_ACK]
        print(f"    ACK decoded: {len(acks)}   header: "
              f"{acks[0].header.describe() if acks else '--'}")
        ok &= verdict("zero-payload ACK decodes in the reverse direction",
                      bool(acks) and acks[0].header.src == 2)
    finally:
        cfg.NODE_ID, cfg.PEER_NODE_ID, cfg.LOOPBACK_ACCEPT_OWN = saved
    RESULTS["two_nodes"] = {"ok": ok}
    return ok


# ====================================================================== 11. soak
def sec_soak(pool, N, nframes):
    hdr("11. SOAK -- many frames through ONE receiver instance")
    print(f"  {nframes} frames back to back through a single Receiver, so any state")
    print(f"  leak, buffer growth or slow drift shows up.\n")
    rx = Receiver(cfg)
    rng = np.random.default_rng(17)
    okc = 0
    evms, bufs = [], []
    t0 = time.time()
    for i in range(nframes):
        n = int(rng.integers(16, 400))
        payload = bytes(rng.integers(0, 256, n, dtype=np.uint8))
        burst = make_burst(payload, seq=i)
        stream = channel.apply_channel(
            burst, cfg, float(rng.uniform(-12, -6)),
            cfo_hz=float(rng.uniform(-3000, 3000)), phase=float(rng.uniform(-3, 3)),
            delay=float(rng.uniform(0, 30)), sfo_ppm=float(rng.uniform(-3, 3)),
            seed=int(rng.integers(0, 1 << 30)))
        frames, _ = decode(stream, receiver=rx)
        hit = [f for f in frames if f.ok and f.payload == payload]
        okc += bool(hit)
        if hit:
            evms.append(hit[0].evm_pct)
        bufs.append(len(rx.buf))
        if (i + 1) % 10 == 0:
            print(f"    {i+1:4d} frames : {100*okc/(i+1):5.1f} % ok   "
                  f"buffer {len(rx.buf):7d} samples   "
                  f"deaf {100*rx.stats.deaf_samples/max(rx.stats.samples_processed,1):4.1f} %")
    dt = time.time() - t0
    s = rx.stats
    print(f"\n  {nframes} frames in {dt:.0f} s")
    print(f"    success            : {100*okc/nframes:.1f} %")
    print(f"    mean EVM           : {np.mean(evms):.2f} %")
    print(f"    buffer first/last  : {bufs[0]} / {bufs[-1]} samples "
          f"(max {max(bufs)})")
    print(f"    buffer_aborts {s.buffer_aborts}  stalls {s.stalls}  "
          f"early_rejects {s.early_rejects}  false_acq {s.false_acquisitions}")
    ok = verdict("no state leak: buffer bounded across the whole soak",
                 max(bufs) <= cfg.RX_BUFFER_SAMPLES * cfg.RX_BUFFER_MARGIN,
                 f"max {max(bufs)} vs cap {cfg.RX_BUFFER_SAMPLES*cfg.RX_BUFFER_MARGIN}")
    ok &= verdict("no buffer aborts or stalls over the soak",
                  s.buffer_aborts == 0 and s.stalls == 0)
    ok &= verdict("success rate holds up across the soak", 100 * okc / nframes >= 90,
                  f"{100*okc/nframes:.1f} %")
    RESULTS["soak"] = {"frames": nframes, "success_pct": 100 * okc / nframes,
                       "max_buffer": max(bufs), "evm_mean": float(np.mean(evms))}
    return ok


# ====================================================================== main
SECTIONS = {
    1: ("below the noise floor", sec_below_noise),
    2: ("processing gain", sec_processing_gain),
    3: ("sensitivity", sec_sensitivity),
    4: ("constellation quality", sec_constellation),
    5: ("impairments", sec_impairments),
    6: ("interference", sec_interference),
    7: ("payload integrity", sec_payload),
    8: ("false alarm", sec_false_alarm),
    9: ("spreading factor", sec_spreading),
    10: ("two nodes", sec_two_nodes),
    11: ("soak", sec_soak),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--only", type=str, default=None)
    ap.add_argument("--json", type=str, default=None)
    ap.add_argument("--procs", type=int, default=2)
    a = ap.parse_args()

    N = 12 if a.quick else 40
    noise_s = 10 if a.quick else 60
    soak_n = 20 if a.quick else 60
    want = ([int(x) for x in a.only.split(",")] if a.only else list(SECTIONS))

    print(cfg.summary())
    print(f"\n  validation: {'QUICK' if a.quick else 'FULL'}   "
          f"{N} trials per point   {a.procs} processes")

    t0 = time.time()
    results = {}
    with ProcessPoolExecutor(max_workers=a.procs) as pool:
        for k in want:
            name, fn = SECTIONS[k]
            if k == 8:
                results[k] = fn(pool, N, noise_s)
            elif k == 11:
                results[k] = fn(pool, N, soak_n)
            else:
                results[k] = fn(pool, N)

    dt = time.time() - t0
    print()
    print("=" * 78)
    print("  VALIDATION SUMMARY")
    print("=" * 78)
    for k in want:
        print(f"   {k:2d}. {SECTIONS[k][0]:26s} {'PASS' if results[k] else 'FAIL'}")
    print("-" * 78)
    if FAILURES:
        print(f"  {len(FAILURES)} CHECK(S) FAILED:")
        for f in FAILURES:
            print(f"    - {f}")
    else:
        print("  ALL CHECKS PASSED")
    print(f"  ({dt/60:.1f} minutes)")
    print("=" * 78)

    if a.json:
        with open(a.json, "w") as fh:
            json.dump({"results": {str(k): v for k, v in results.items()},
                       "failures": FAILURES, "detail": RESULTS}, fh,
                      indent=2, default=str)
        print(f"  wrote {a.json}")
    return 0 if not FAILURES else 1


if __name__ == "__main__":
    sys.exit(main())
