#!/usr/bin/env python3
"""
run_link.py -- start the DSSS/QPSK link and its terminal console.

    python run_link.py --sim              no radio at all: simulated channel
    python run_link.py --sim --snr -12    simulate a signal 12 dB below the noise
    python run_link.py --grsim            GNU Radio flowgraph, no hardware
    python run_link.py                    real B206mini-i (see config.py)
    python run_link.py --simple           plain line-mode console

SINGLE RADIO LOOPBACK (the default hardware setup)
    Connect  TX/RX  --[30-40 dB attenuator]--  RX2  on the B206mini-i.
    Leave LOOPBACK_ACCEPT_OWN = True and HALF_DUPLEX_MUTE_RX = False so the node
    hears its own bursts come back; every message you type will round-trip
    through the whole modem and get ACKed.

TWO RADIOS
    On each node set a different NODE_ID, point PEER_NODE_ID at the other,
    set LOOPBACK_ACCEPT_OWN = False and HALF_DUPLEX_MUTE_RX = True, and give
    each DEVICE_ARGS the right serial.  Everything else stays identical -- the
    waveform knobs MUST match on both ends.
"""

import argparse
import sys
import time

from dsss_qpsk import config as cfg
from dsss_qpsk.app.terminal import TerminalApp
from dsss_qpsk.link import LinkManager


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--sim", action="store_true",
                   help="simulated channel, no GNU Radio and no radio")
    p.add_argument("--grsim", action="store_true",
                   help="GNU Radio flowgraph with a simulated channel (no radio)")
    p.add_argument("--snr", type=float, default=None,
                   help="simulated chip-band SNR in dB (negative = below the noise floor)")
    p.add_argument("--cfo", type=float, default=None, help="simulated carrier offset, Hz")
    p.add_argument("--node", type=int, default=None, help="override NODE_ID")
    p.add_argument("--peer", type=int, default=None, help="override PEER_NODE_ID")
    p.add_argument("--device", type=str, default=None, help="override DEVICE_ARGS")
    p.add_argument("--freq", type=float, default=None, help="override CENTER_FREQ_HZ")
    p.add_argument("--sf", type=int, default=None, help="override SPREADING_FACTOR")
    p.add_argument("--simple", action="store_true", help="plain line-mode console")
    p.add_argument("--web", action="store_true",
                   help="serve the live browser dashboard (constellation, "
                        "spectrum, waterfall, acquisition cuts, trends)")
    p.add_argument("--web-port", type=int, default=None)
    p.add_argument("--no-terminal", action="store_true",
                   help="dashboard only; do not take over the terminal")
    a = p.parse_args()

    if a.node is not None:
        cfg.NODE_ID = a.node
    if a.peer is not None:
        cfg.PEER_NODE_ID = a.peer
    if a.device is not None:
        cfg.DEVICE_ARGS = a.device
    if a.freq is not None:
        cfg.CENTER_FREQ_HZ = a.freq
    if a.sf is not None:
        cfg.SPREADING_FACTOR = a.sf
    cfg.recompute()

    print(cfg.summary())

    from dsss_qpsk import transports
    if a.sim:
        transport = transports.SimTransport(cfg, snr_db=a.snr, cfo_hz=a.cfo)
        mode = f"SIMULATION  chip SNR {transport.snr_db:+.1f} dB"
    elif a.grsim:
        transport = transports.GrLoopbackTransport(cfg, snr_db=a.snr, cfo_hz=a.cfo)
        mode = "GNU RADIO LOOPBACK (no hardware)"
    else:
        transport = transports.UsrpTransport(cfg)
        mode = f"HARDWARE: {transport.describe()}"
    print(f"\nmode: {mode}\nstarting...\n")

    link = LinkManager(cfg, transport)
    transport.start()
    link.start()

    dash = None
    if a.web:
        from dsss_qpsk.webui import Dashboard
        dash = Dashboard(cfg, link, port=a.web_port or cfg.WEB_PORT,
                         host=cfg.WEB_HOST)
        url = dash.start()
        print(f"  dashboard: {url}")
        print("  (constellation, live spectrum, waterfall, acquisition cuts,")
        print("   trends, and a send box -- open it in a browser)\n")

    try:
        if a.no_terminal:
            if dash is None:
                print("--no-terminal without --web would leave nothing to look at")
                return 2
            print("  running; Ctrl-C to stop.")
            while True:
                time.sleep(0.5)
        else:
            app = TerminalApp(cfg, link, transport, simple=a.simple)
            app.say(f"mode: {mode}")
            if dash is not None:
                app.say(f"dashboard: {dash.url}")
            app.run()
    except KeyboardInterrupt:
        pass
    finally:
        if dash is not None:
            dash.stop()
        link.stop()
        transport.stop()
        print("stopped.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
