#!/usr/bin/env python3
"""
run_filetest.py -- end-to-end file transfer over the simulated channel.

    python run_filetest.py                      8 kB at -13 dB
    python run_filetest.py -s -13 -b 65536      64 kB below the noise floor
    python run_filetest.py --drop 0.15          throw away 15% of the bursts
    python run_filetest.py --nostream           per-segment ARQ instead

This is the test that matters for the file feature: it runs the real link
manager, the real modulator and receiver, over the real channel model, and
checks that the bytes that come out of the inbox are the bytes that went in.

--drop is the important one.  It deletes whole bursts at random on the way in,
which is what a fade or a collision looks like, and proves the repair path
actually converges instead of just existing.
"""
from __future__ import annotations

import argparse
import hashlib
import shutil
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from dsss_qpsk import config as cfg            # noqa: E402
from dsss_qpsk import transports               # noqa: E402
from dsss_qpsk.filexfer import human           # noqa: E402
from dsss_qpsk.link import LinkManager         # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-s", "--snr", type=float, default=-13.0)
    ap.add_argument("-b", "--bytes", type=int, default=8192)
    ap.add_argument("--drop", type=float, default=0.0,
                    help="probability of losing each received burst")
    ap.add_argument("--nostream", action="store_true",
                    help="use per-segment stop-and-wait ARQ")
    ap.add_argument("--timeout", type=float, default=300.0)
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()

    if a.nostream:
        cfg.FILE_STREAM_MODE = False
    inbox = HERE / "inbox_test"
    shutil.rmtree(inbox, ignore_errors=True)
    cfg.FILE_INBOX = str(inbox)
    cfg.recompute()

    rng = np.random.default_rng(7)
    # Compressible-ish content, so a bad byte is obvious and the CRC is real.
    payload = bytes(rng.integers(32, 127, a.bytes, dtype=np.uint8))
    src = HERE / "testfile.bin"
    src.write_bytes(payload)
    want = hashlib.sha256(payload).hexdigest()

    transport = transports.SimTransport(cfg, snr_db=a.snr)
    link = LinkManager(cfg, transport)

    state = {"dropped": 0, "sent": 0}
    if a.drop > 0:
        # Kill whole bursts on the way OUT.  Doing it here rather than on the
        # received samples is exact: the burst simply never happened, which is
        # what a deep fade or a collision actually looks like to the receiver.
        real_tx = transport.transmit
        drop_rng = np.random.default_rng(11)

        def lossy_tx(samples):
            state["sent"] += 1
            if drop_rng.random() < a.drop:
                state["dropped"] += 1
                return                      # into the void
            real_tx(samples)
        transport.transmit = lossy_tx

    transport.start()
    link.start()

    print(f"file transfer test: {human(len(payload))} at chip SNR "
          f"{transport.snr_db:+.1f} dB, "
          f"{'STREAM' if cfg.FILE_STREAM_MODE else 'per-segment ARQ'}"
          + (f", dropping {a.drop*100:.0f}% of bursts" if a.drop else ""))
    t0 = time.time()
    link.send_file(src)

    got = None
    last = ""
    try:
        while time.time() - t0 < a.timeout:
            time.sleep(0.4)
            snap = link.files.snapshot()
            rxs = [t for t in snap["active"] + snap["history"] if t["dir"] == "rx"]
            if not a.quiet and rxs:
                r = rxs[0]
                line = (f"  rx {r['seg_done']}/{r['nseg']} segments "
                        f"{r['pct']:5.1f}%  {human(r['rate'])}/s  {r['state']}")
                if line != last:
                    print(line, flush=True)
                    last = line
            done = [r for r in rxs if r["state"] in ("complete", "failed")]
            if done:
                got = done[0]
                break
    finally:
        link.stop()
        transport.stop()

    el = time.time() - t0
    print()
    if got is None:
        print(f"FAIL: transfer never finished in {el:.0f} s")
        return 1
    if got["state"] != "complete":
        print(f"FAIL: receiver reported {got['state']}")
        return 1
    blob = Path(got["path"]).read_bytes()
    same = hashlib.sha256(blob).hexdigest() == want
    m = link.metrics()
    print(f"  bytes            : {len(blob)} / {len(payload)}")
    print(f"  sha256 match     : {same}")
    print(f"  wall time        : {el:.1f} s   ({human(len(payload)/el)}/s)")
    print(f"  segments         : {got['nseg']}   repairs asked: {got['repairs']}")
    print(f"  bursts dropped   : {state['dropped']}")
    print(f"  link retries     : {m['retries']}   lost messages: {m['lost']}")
    print(f"  stream frames    : tx {m['stream_tx']}  rx {m['stream_rx']}")
    print(f"  last frame EVM   : {m.get('evm_pct', float('nan')):.2f} %   "
          f"chip SNR {m.get('snr_chip_db', float('nan')):.1f} dB")
    print()
    print("PASS" if same else "FAIL: contents differ")
    return 0 if same else 1


if __name__ == "__main__":
    sys.exit(main())
