"""
DSSS Despreader (GPS-style, acquisition + tracking, per-node code) - THE
PROCESSING-GAIN STEP
--------------------------------------------------------------------------------
This is the very first thing done to the received signal (before AGC,
before carrier recovery, before anything else) - despreading is what
actually pulls a signal buried below the noise floor back out, and doing
it first means every downstream stage (Costas loop, slicer, ...) gets to
work on a signal that has already had ~10*log10(code_len) dB of
processing gain applied to it, instead of trying to lock onto raw noise.

Algorithm (validated against a standalone numpy simulation before being
wired in here - see the project's test scripts):

  1. ACQUISITION (one-time, on first lock / after a lock loss): take one
     code-period's worth of samples and cross-correlate it against every
     possible rotation of the local code replica *at once*, via FFT
     (this is exactly GPS's own "parallel code-phase search" acquisition
     technique - O(N log N) instead of a naive O(N^2) serial search over
     1023 phases). If the strongest rotation's correlation magnitude
     clearly stands out above the noise floor (the other 1022 rotations),
     that rotation is the code phase - lock is declared there.

  2. TRACKING (every symbol once acquired): naive advancement by exactly
     one code period per symbol turns out to be *fragile*, not
     approximately-fine-that-degrades-gracefully - a DSSS code's
     autocorrelation is famously razor-thin (this project's own testing
     found being off by a single chip collapses the correlation gain
     from ~1023 to the noise-floor-level Gold-code sidelobe, ~63 at
     best - there is no "mostly aligned"). So instead of a classic
     single-step early/late discriminator (which necessarily spends time
     sitting at a wrong alignment while converging), every symbol re-runs
     a small *bounded* local search (+/- `search_margin` chips around
     where the previous symbol predicts the next one should start) and
     always uses whichever offset in that small window correlates best -
     this snaps to perfect alignment fresh every single symbol, so it
     tracks any realistic TX/RX clock drift with zero symbols lost to
     misalignment, at the cost of only `2*search_margin+1` correlations
     per symbol.

  3. RE-ACQUISITION: if the best local-search correlation stops standing
     out above that window's own noise floor for `lock_loss_symbols` in a
     row (default 500 - a last-resort safety net for a real loss of lock,
     not a normal-operation trigger), lock is dropped and a fresh full
     acquisition search is triggered. The same thing happens IMMEDIATELY,
     on purpose, whenever `prn_taps` changes (see below) - a code change
     means "I am now listening for a different node", so whatever the old
     code was tracking is meaningless and must not be trusted for even one
     more symbol.

MULTIPLE ACCESS (CDMA): `prn_taps` selects WHICH node's Gold code this
receiver despreads against - i.e. who you're listening to (see the
flowgraph's `dest_node_id` variable and `node_prn_table`). Two nodes each
transmitting on their OWN code and despreading against their PEER's code
is what makes full-duplex, multi-node operation on one shared frequency
possible without one node's transmit chain interfering with its own
receive chain, or with a third node's link.

Each despread output symbol is tagged with its correlation magnitude
('corr_mag') so a QT GUI Number Sink or similar can show the live
processing-gain readout.

DIAGNOSTICS (purely additive - does not change acquisition/tracking
control flow, timing, or the stream output at all): every
`stats_period_symbols` tracked symbols, this block publishes a 'stats'
message reporting the MEASURED processing gain (`10*log10(best_mag/floor)`
- how far the correlation peak stands above the surrounding noise floor,
right now, on real samples) alongside the THEORETICAL ideal
(`10*log10(code_len)`, a constant - what you'd get with a perfect
correlator and no implementation loss). Watching the gap between those two
numbers is a direct, honest measure of how much margin the link actually
has versus how much the code length nominally promises. It also publishes
an immediate 'stats' message the instant lock is gained or lost (not
waiting for the next periodic tick), since that transition matters more
than any single periodic sample.

Input : stream of complex64 chip-rate samples (buried in noise - this is
        the very first block downstream of the channel/USRP source)
Output: stream of complex64 QPSK symbols, one per code period, at
        (input_rate / code_len) - a genuinely variable-rate block
        (gr.basic_block + general_work), not a fixed decimator, since the
        exact number of input chips consumed per output symbol tracks
        real (if tiny) sample-clock drift between TX and RX.
"""

import numpy as np
import pmt
from gnuradio import gr


def g1_sequence(n_chips):
    reg = [1] * 10
    out = np.empty(n_chips, dtype=np.uint8)
    for i in range(n_chips):
        out[i] = reg[9]
        fb = reg[2] ^ reg[9]
        reg = [fb] + reg[:-1]
    return out


def g2_sequence(taps, n_chips):
    reg = [1] * 10
    t0, t1 = taps[0] - 1, taps[1] - 1
    out = np.empty(n_chips, dtype=np.uint8)
    for i in range(n_chips):
        out[i] = reg[t0] ^ reg[t1]
        fb = reg[1] ^ reg[2] ^ reg[5] ^ reg[7] ^ reg[8] ^ reg[9]
        reg = [fb] + reg[:-1]
    return out


def gps_style_gold_code(code_len=1023, prn_taps=(2, 6)):
    """MUST match dsss_spreader.py's code generation exactly."""
    bits = g1_sequence(code_len) ^ g2_sequence(prn_taps, code_len)
    return 1.0 - 2.0 * bits.astype(np.float32)


class blk(gr.basic_block):
    """DSSS Despreader (GPS-style acquisition + tracking, per-node PRN)"""

    def __init__(self, code_len=1023, prn_taps=(2, 6), search_margin=4,
                 acq_threshold=3.0, lock_loss_symbols=500,
                 stats_period_symbols=50):
        gr.basic_block.__init__(
            self, name='DSSS Despreader',
            in_sig=[np.complex64], out_sig=[np.complex64])
        self.code_len = int(code_len)
        self.margin = int(search_margin)
        self.acq_threshold = float(acq_threshold)
        self.lock_loss_symbols = int(lock_loss_symbols)
        self.stats_period_symbols = max(1, int(stats_period_symbols))
        self.ideal_gain_db = 10.0 * np.log10(self.code_len)

        self.acquired = False
        self.center = 0       # absolute sample index of next expected symbol start
        self.weak_count = 0
        self._sym_count = 0
        self.set_tag_propagation_policy(gr.TPP_DONT)

        self.message_port_register_out(pmt.intern('stats'))

        self._prn_taps = (2, 6)
        self.code = gps_style_gold_code(self.code_len, self._prn_taps)
        self.prn_taps = prn_taps

    def _publish_stats(self, best_mag, floor, locked):
        if floor > 0 and best_mag > 0:
            actual_db = 10.0 * np.log10(best_mag / floor)
        else:
            actual_db = float('-inf')
        text = ("PROCGAIN actual=%.1f ideal=%.1f locked=%d" %
                (actual_db, self.ideal_gain_db, int(locked)))
        try:
            self.message_port_pub(
                pmt.intern('stats'),
                pmt.cons(pmt.PMT_NIL,
                         pmt.init_u8vector(len(text), list(text.encode('utf-8')))))
        except Exception:
            pass

    # See dsss_spreader.py for why this is a property rather than a plain
    # attribute: GRC's generated variable-setter code for an embedded
    # Python block's parameter is a direct attribute assignment
    # (`self.dsss_despreader.prn_taps = node_prn_table[self.dest_node_id]`),
    # not a method call - a property is what turns that into "rebuild the
    # code replica and force an immediate re-acquisition".
    @property
    def prn_taps(self):
        return self._prn_taps

    @prn_taps.setter
    def prn_taps(self, value):
        taps = (int(value[0]), int(value[1]))
        if taps == self._prn_taps and self.code is not None:
            return
        self._prn_taps = taps
        self.code = gps_style_gold_code(self.code_len, taps)
        # Switching who we're listening to invalidates any existing lock
        # immediately - do NOT let the old code's tracking loop keep
        # "successfully" correlating against the new sample stream with
        # stale state; drop lock now so the next work() call restarts a
        # full FFT acquisition search on the new code.
        was_acquired = self.acquired
        self.acquired = False
        self.weak_count = 0
        if was_acquired:
            self._publish_stats(0.0, 0.0, locked=False)

    def forecast(self, noutput_items, ninputs):
        need = (noutput_items + 2) * self.code_len + 4 * self.margin
        return [need] * ninputs

    def general_work(self, input_items, output_items):
        in0 = input_items[0]
        out = output_items[0]
        n_avail = len(in0)
        base = self.nitems_read(0)

        if not self.acquired:
            if n_avail < self.code_len:
                self.consume(0, 0)
                return 0
            window = in0[0:self.code_len]
            corr = np.fft.ifft(np.fft.fft(window) * np.conj(np.fft.fft(self.code)))
            mags = np.abs(corr)
            best = int(np.argmax(mags))
            peak = mags[best]
            floor = np.median(mags)
            if floor > 0 and peak > self.acq_threshold * floor:
                # `best` locates *this* symbol's start; the next symbol
                # (the one the tracking loop below should center its
                # search on) starts one code period later. The samples
                # for this first-acquired symbol are simply not despread
                # (a one-symbol cost at acquisition time, same as any
                # real receiver spends a little settling time locking on).
                self.center = base + best + self.code_len
                self.acquired = True
                self.weak_count = 0
                self._publish_stats(peak, floor, locked=True)
                # only discard the stale prefix before the found symbol -
                # the tracking loop's very first search needs samples
                # starting at (center - margin), which is inside this
                # symbol's own span, so keep from `best` onward rather
                # than consuming the whole code_len (which would throw
                # away exactly the margin the next call needs).
                self.consume(0, best)
            else:
                self.consume(0, self.code_len)
            return 0

        produced = 0
        max_out = len(out)
        while produced < max_out:
            lo = self.center - self.margin
            hi = self.center + self.margin
            need_end = hi + self.code_len
            if lo - base < 0 or (need_end - base) > n_avail:
                break

            best_off, best_mag, best_val = self.center, -1.0, 0j
            mags = []
            for off in range(lo, hi + 1):
                rel = off - base
                val = np.dot(in0[rel:rel + self.code_len], self.code)
                mag = abs(val)
                mags.append(mag)
                if mag > best_mag:
                    best_mag, best_off, best_val = mag, off, val

            floor = float(np.median(mags))
            if floor <= 0 or best_mag <= self.acq_threshold * floor:
                self.weak_count += 1
            else:
                self.weak_count = 0

            out[produced] = best_val
            self.add_item_tag(0, self.nitems_written(0) + produced,
                               pmt.intern('corr_mag'), pmt.from_double(best_mag))
            produced += 1
            self.center = best_off + self.code_len

            self._sym_count += 1
            if self._sym_count >= self.stats_period_symbols:
                self._sym_count = 0
                self._publish_stats(best_mag, floor, locked=True)

            if self.weak_count >= self.lock_loss_symbols:
                self.acquired = False
                self._publish_stats(best_mag, floor, locked=False)
                break

        consume_upto_abs = self.center - self.margin
        consume_amt = max(0, min(n_avail, consume_upto_abs - base))
        self.consume(0, consume_amt)
        return produced
