#!/usr/bin/env python3
"""
jammer.py -- drive a third USRP as an interference source for the link
======================================================================

REQUIREMENT 8 (stretch): add a third B206mini and use it to test the link
against a co-channel interferer.

Interference rejection is the defining property of a direct-sequence
spread-spectrum system -- it is the reason GPS works under strong local
signals and the reason this project spends 1023 chips per symbol in the first
place. So the honest way to demonstrate the spreading gain is to put a
controlled interferer on the link's own frequency, on the bench, behind
attenuators, and measure how strong it has to be before the link degrades.
That measurement is the "jamming margin", and `demo.py 8` sweeps it.

This is a small hand-written GNU Radio application rather than a GRC flowgraph:
the graph is a waveform source and a USRP sink, and the useful thing is a
scriptable sweep of interferer-to-signal ratio rather than one fixed setting.
It exposes a UDP control port so the demo can step the level automatically and
lay the measured curve over the simulated one.

WAVEFORMS
---------
Five, chosen because a DSSS receiver suppresses each by a different amount, and
comparing them is the actual result:

  cw         a single tone. The despreader spreads it across the full code
             bandwidth while collapsing the wanted signal, so only ~1/1023 of
             its power reaches the symbol bandwidth -- the easiest case, and
             the one the spreading gain handles almost completely.
  swept      a tone sweeping the band; in the correlator's way for part of
             every symbol rather than parked at one frequency.
  pulsed     CW gated on and off at a duty cycle -- energy in bursts.
  partial    band-limited noise filling a fraction of the band; worse per watt
             than full-band noise, because concentrating the power raises the
             fraction that survives despreading.
  broadband  white noise across the whole band -- the worst case, suppressed
             only by the processing gain because it is already spread.

SAFETY AND LEGALITY
-------------------
This transmits deliberate co-channel interference, so it stays on the bench:
low TX gain, a cabled/attenuated path or well-isolated antennas, into a dummy
load where possible, and inside whatever your local spectrum rules allow. The
default TX gain here is 0, on purpose -- you raise it knowingly. Radiating an
interferer over the air is very likely illegal; keep it conducted.
"""

from __future__ import annotations

import argparse
import signal
import socket
import sys
import threading
import time

import numpy as np


# ---------------------------------------------------------------------------
# Waveform generation -- pure NumPy, so the file imports and self-tests with no
# GNU Radio present. The GNU Radio layer below only pushes these samples out.
# ---------------------------------------------------------------------------

def make_waveform(kind, n, samp_rate, sweep_hz=None, tone_hz=None,
                  duty=0.5, pulse_hz=1000.0, partial_frac=0.1, seed=0):
    """One block of `n` complex samples of the chosen waveform, unit power."""
    rng = np.random.default_rng(seed)
    t = np.arange(n) / samp_rate
    if tone_hz is None:
        tone_hz = samp_rate * 0.13
    if sweep_hz is None:
        sweep_hz = samp_rate * 0.4

    if kind == "cw":
        w = np.exp(2j * np.pi * tone_hz * t)
    elif kind == "swept":
        period = n / samp_rate
        f = sweep_hz * (2.0 * ((t / period) % 1.0) - 1.0)
        w = np.exp(2j * np.pi * np.cumsum(f) / samp_rate)
    elif kind == "pulsed":
        w = np.exp(2j * np.pi * tone_hz * t)
        gate = ((t * pulse_hz) % 1.0) < duty
        w = w * gate
    elif kind == "partial":
        noise = (rng.standard_normal(n) + 1j * rng.standard_normal(n)) / np.sqrt(2)
        spec = np.fft.fft(noise)
        keep = max(1, int(len(spec) * partial_frac / 2))
        mask = np.zeros(len(spec), dtype=bool)
        mask[:keep] = True
        mask[-keep:] = True
        spec[~mask] = 0
        w = np.fft.ifft(spec)
    elif kind == "broadband":
        w = (rng.standard_normal(n) + 1j * rng.standard_normal(n)) / np.sqrt(2)
    else:
        raise ValueError(f"unknown waveform {kind!r}")

    w = np.asarray(w, dtype=np.complex64)
    p = float(np.mean(np.abs(w) ** 2))
    if p > 0:
        w = (w / np.sqrt(p)).astype(np.complex64)
    return w


WAVEFORMS = ("cw", "swept", "pulsed", "partial", "broadband")


# ---------------------------------------------------------------------------
# GNU Radio source block, only imported when actually transmitting.
# ---------------------------------------------------------------------------

def _build_source_class():
    from gnuradio import gr

    class InterferenceSource(gr.sync_block):
        """Emits the selected waveform continuously at a settable amplitude.

        Amplitude, waveform and centre offset are all runtime-settable so the
        control thread can sweep the interferer-to-signal ratio without
        restarting the graph.
        """

        def __init__(self, kind="cw", samp_rate=2.046e6, amplitude=0.0,
                     block=8192):
            gr.sync_block.__init__(self, name="Interference Source",
                                   in_sig=[], out_sig=[np.complex64])
            self.samp_rate = float(samp_rate)
            self.block = int(block)
            self._kind = kind
            self._amp = float(amplitude)
            self._lock = threading.Lock()
            self._buf = make_waveform(kind, self.block, self.samp_rate)
            self._pos = 0

        def set_amplitude(self, a):
            with self._lock:
                self._amp = max(0.0, float(a))

        def set_waveform(self, kind):
            with self._lock:
                self._kind = kind
                self._buf = make_waveform(kind, self.block, self.samp_rate)
                self._pos = 0

        def work(self, input_items, output_items):
            out = output_items[0]
            n = len(out)
            with self._lock:
                amp = self._amp
                buf = self._buf
                pos = self._pos
                produced = 0
                while produced < n:
                    take = min(n - produced, len(buf) - pos)
                    out[produced:produced + take] = buf[pos:pos + take] * amp
                    produced += take
                    pos = (pos + take) % len(buf)
                self._pos = pos
            return n

    return InterferenceSource


# ---------------------------------------------------------------------------
# The application
# ---------------------------------------------------------------------------

class JammerApp:
    def __init__(self, args):
        self.args = args
        from gnuradio import gr, uhd
        Source = _build_source_class()

        self.tb = gr.top_block("Interference source")
        self.src = Source(kind=args.waveform, samp_rate=args.samp_rate,
                          amplitude=args.amplitude)
        self.sink = uhd.usrp_sink(
            ",".join((args.dev_addr, "")),
            uhd.stream_args(cpu_format="fc32", channels=[0]))
        self.sink.set_samp_rate(args.samp_rate)
        self.sink.set_center_freq(args.freq, 0)
        self.sink.set_gain(args.tx_gain, 0)
        self.sink.set_antenna(args.antenna, 0)
        self.tb.connect(self.src, self.sink)

        # J/S is relative to a reference signal amplitude the operator sets to
        # match the actual link signal level at the receiver. Amplitude is
        # ref * 10^(JSR/20).
        self.ref_amp = args.ref_amplitude
        self._apply_jsr(args.jsr)

    def _apply_jsr(self, jsr_db):
        amp = self.ref_amp * (10 ** (jsr_db / 20.0)) if self.ref_amp else 0.0
        self.src.set_amplitude(amp)
        self.jsr = jsr_db

    # -- control port ---------------------------------------------------
    def serve(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((self.args.bind_host, self.args.ctrl_port))
        s.settimeout(0.5)
        print(f"  control on {self.args.bind_host}:{self.args.ctrl_port} "
              f"(JSR=<dB>, WAVEFORM=<name>, AMP=<0..1>, OFF)")
        while True:
            try:
                data, _addr = s.recvfrom(1500)
            except socket.timeout:
                continue
            except OSError:
                return
            cmd = data.decode("utf-8", "replace").strip()
            key, _, val = cmd.partition("=")
            key = key.strip().upper()
            try:
                if key == "JSR":
                    self._apply_jsr(float(val))
                    print(f"  J/S -> {self.jsr:+.1f} dB")
                elif key == "WAVEFORM" and val.strip() in WAVEFORMS:
                    self.src.set_waveform(val.strip())
                    print(f"  waveform -> {val.strip()}")
                elif key == "AMP":
                    self.src.set_amplitude(float(val))
                    print(f"  amplitude -> {float(val):.3f}")
                elif key == "OFF":
                    self.src.set_amplitude(0.0)
                    print("  interferer off")
            except ValueError:
                print(f"  bad command: {cmd!r}")

    def run(self):
        print(f"Interference source: {self.args.waveform} at "
              f"{self.args.freq / 1e6:.3f} MHz, {self.args.samp_rate / 1e6:.3f} "
              f"Msps, TX gain {self.args.tx_gain} dB")
        if self.args.tx_gain == 0 and self.args.amplitude == 0:
            print("  NOTE: TX gain and amplitude are both 0 -- nothing is "
                  "radiating yet. Raise --tx-gain and set a J/S to transmit.")
        print("  keep this conducted and attenuated -- see the file header.")
        self.tb.start()
        threading.Thread(target=self.serve, daemon=True).start()

        def stop(*_):
            self.tb.stop()
            self.tb.wait()
            sys.exit(0)
        signal.signal(signal.SIGINT, stop)
        signal.signal(signal.SIGTERM, stop)
        try:
            while True:
                time.sleep(1.0)
        except KeyboardInterrupt:
            stop()


def selftest():
    """Verify the waveforms without a radio: unit power and the expected
    spectral shape. Run with --selftest, and by tests/test_jammer.py."""
    ok = True
    for kind in WAVEFORMS:
        w = make_waveform(kind, 8192, 2.046e6, seed=1)
        p = float(np.mean(np.abs(w) ** 2))
        spec = np.abs(np.fft.fftshift(np.fft.fft(w))) ** 2
        occ = float(np.sum(spec > spec.max() * 0.1)) / len(spec)
        print(f"  {kind:10} power={p:.3f}  occupied~{occ * 100:4.0f}% of band")
        if abs(p - 1.0) > 0.05:
            print(f"    FAIL: power should be 1.0")
            ok = False
    # CW should occupy far less band than broadband.
    cw = np.abs(np.fft.fft(make_waveform("cw", 8192, 2.046e6))) ** 2
    bb = np.abs(np.fft.fft(make_waveform("broadband", 8192, 2.046e6))) ** 2
    cw_occ = np.sum(cw > cw.max() * 0.1) / len(cw)
    bb_occ = np.sum(bb > bb.max() * 0.1) / len(bb)
    if not (cw_occ < 0.05 < bb_occ):
        print(f"    FAIL: CW ({cw_occ:.2f}) should be far narrower than "
              f"broadband ({bb_occ:.2f})")
        ok = False
    print("  selftest", "PASSED" if ok else "FAILED")
    return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--waveform", default="broadband", choices=WAVEFORMS,
                    help="interference waveform (default: broadband, the "
                         "worst case for a DSSS link)")
    ap.add_argument("--freq", type=float, default=915e6,
                    help="centre frequency, matching the link (default 915 MHz)")
    ap.add_argument("--samp-rate", type=float, default=2.046e6,
                    help="sample rate; cover the link's occupied bandwidth")
    ap.add_argument("--tx-gain", type=float, default=0.0,
                    help="USRP TX gain in dB (default 0 -- raise knowingly)")
    ap.add_argument("--jsr", type=float, default=0.0,
                    help="interferer-to-signal ratio in dB, relative to "
                         "--ref-amplitude")
    ap.add_argument("--ref-amplitude", type=float, default=0.0,
                    help="digital amplitude that matches the link signal at "
                         "the receiver; J/S is applied relative to it")
    ap.add_argument("--amplitude", type=float, default=0.0,
                    help="set the digital amplitude directly instead of J/S")
    ap.add_argument("--antenna", default="TX/RX")
    ap.add_argument("--dev-addr", default="",
                    help="UHD device address, e.g. 'serial=...'; blank "
                         "auto-selects, but with three radios attached you "
                         "should pin each one")
    ap.add_argument("--ctrl-port", type=int, default=52010,
                    help="UDP control port for scripted sweeps (demo 8)")
    ap.add_argument("--bind-host", default="127.0.0.1")
    ap.add_argument("--selftest", action="store_true",
                    help="verify the waveforms with no radio and exit")
    args = ap.parse_args()

    if args.selftest:
        return selftest()

    try:
        app = JammerApp(args)
    except Exception as exc:
        print(f"could not start (is UHD installed and a USRP attached?): {exc}")
        print("run with --selftest to verify the waveforms without hardware.")
        return 1
    app.run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
