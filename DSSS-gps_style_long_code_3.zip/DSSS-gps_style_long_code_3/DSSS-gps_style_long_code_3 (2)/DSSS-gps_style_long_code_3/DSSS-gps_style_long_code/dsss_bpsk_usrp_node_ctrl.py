"""
Node Control - GUI-driven node id / destination switching
--------------------------------------------------------------
Parses tiny plain-text UDP commands from the ground station GUI (or
terminal.py) and turns them into GRC variable-set messages, using the
standard "message pair -> Message Pair to Var block -> variable setter"
idiom (see node_prn_table / my_node_id / dest_node_id in the flowgraph)
rather than reaching into any other block directly.

Commands (one per UDP datagram, case-insensitive, whitespace-tolerant):
    NODE=<n>     set my_node_id  = n   (which PRN this radio TRANSMITS on)
    DEST=<n>     set dest_node_id = n  (which peer's PRN this radio
                                        DESPREADS against - i.e. who it's
                                        currently listening to)

`n` is validated against `table_size` (must match the flowgraph's
`node_prn_table` size) before being forwarded - an out-of-range id would
otherwise crash the flowgraph the instant `node_prn_table[n]` is evaluated
as a KeyError, so it's rejected here instead, with a printed warning, and
the previous value is left untouched.

Ports
  message in  'in'        : a raw command PDU (UTF-8 text) from a
                             network_socket_pdu UDP_SERVER block
  message out 'node_msg'   : (symbol . long) pair, feed to a
                             blocks_msgpair_to_var targeting my_node_id
  message out 'dest_msg'   : (symbol . long) pair, feed to a
                             blocks_msgpair_to_var targeting dest_node_id
"""

import pmt
from gnuradio import gr


def pdu_data(msg):
    vec = pmt.cdr(msg) if pmt.is_pair(msg) else msg
    return bytes(bytearray(pmt.u8vector_elements(vec)))


class blk(gr.basic_block):
    """Node Control"""

    def __init__(self, table_size=16):
        gr.basic_block.__init__(self, name='Node Control', in_sig=[], out_sig=[])
        self.table_size = int(table_size)
        self.message_port_register_in(pmt.intern('in'))
        self.message_port_register_out(pmt.intern('node_msg'))
        self.message_port_register_out(pmt.intern('dest_msg'))
        self.set_msg_handler(pmt.intern('in'), self.handle_msg)

    def handle_msg(self, msg):
        try:
            text = pdu_data(msg).decode('utf-8', 'replace').strip()
        except Exception:
            return
        if not text or '=' not in text:
            return
        key, _, val = text.partition('=')
        key = key.strip().upper()
        try:
            n = int(val.strip())
        except ValueError:
            print("[Node Control] bad value in %r - ignored" % text)
            return
        if not (0 <= n < self.table_size):
            print("[Node Control] node id %d out of range [0, %d) - ignored" %
                  (n, self.table_size))
            return

        if key == 'NODE':
            self.message_port_pub(
                pmt.intern('node_msg'),
                pmt.cons(pmt.intern('my_node_id'), pmt.from_long(n)))
            print("[Node Control] my_node_id -> %d" % n)
        elif key == 'DEST':
            self.message_port_pub(
                pmt.intern('dest_msg'),
                pmt.cons(pmt.intern('dest_node_id'), pmt.from_long(n)))
            print("[Node Control] dest_node_id -> %d" % n)
        else:
            print("[Node Control] unknown command %r - ignored" % text)
