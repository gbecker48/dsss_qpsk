#!/usr/bin/env python3
"""
ground_station.py -- PyQt5 console for the DSSS + QPSK link
============================================================

A pure UDP front-end for the GNU Radio flowgraph. There is no `import
gnuradio` anywhere in this file and it never assumes the flowgraph is running:
sends are fire-and-forget datagrams, and with nothing on the other end the UI
sits in a clean NO LINK state and waits.

WHAT IT DOES
------------
  * Send text messages, as before.
  * Send FILES, with Reed-Solomon erasure coding so a transfer survives lost
    fragments without any retransmission, live per-fragment progress, and an
    end-to-end SHA-256 check on arrival.
  * Receive files, verify them, and write them to disk -- only if the hash
    matches.
  * Show real link metrics: post-despread symbol SNR, EVM, processing gain,
    carrier offset, code-phase drift, packet error rate, and a continuous
    PRBS bit error rate test.
  * Launch any of the eight requirement demos and show its report.

=== UDP protocol (frozen contract with the flowgraph) ===

  TX      this app -> flowgraph, 127.0.0.1:52001
          One whole message per datagram. The flowgraph fragments it; this
          app never fragments. Ceiling is 65535 fragments x 244 bytes.

  RX DATA flowgraph -> this app, :52002
          One complete, CRC-validated, erasure-decoded message per datagram.

  RX STATUS flowgraph -> this app, :52003   (text, one event per datagram)
          FRAG msg= idx= type= data= parity= have= seq= len= src= dst=
          IDLE seq= src= dst=
          DONE msg= fragments= bytes= src= recovered=
          INCOMPLETE msg= missing= blocks_lost=
          FOREIGN / WARN / HEALTH / TXQUEUE / TXCTRL / CTRL / BERT

  CONTROL this app -> flowgraph, 127.0.0.1:52004
          NODE=<n> DEST=<n> TXGAIN=<0..1> BERT=<0|1> PARITY=<percent>

  DIAG    flowgraph -> this app, :52005     (text, telemetry)
          LOCK state= cfo_hz= code_phase=
          SNR symbol_db= psr_db= cfo_hz= drift= slips= locked=
          QUALITY evm_pct= snr_evm_db= snr_m2m4_db= n=
          RXPOWER dbfs=
          FEC corrected= pct=
          PSD n= frames= bw= total_dbfs= bins=

  Parsed leniently everywhere: split on whitespace, then on the first '='.
  An unrecognised line is logged raw and never crashes the app.

=== Design assumptions (unchanged from the original, still true) ===

  1. Sent-message to wire msg-id correlation is an ASSUMPTION, not something
     the protocol guarantees. This app assumes one client per flowgraph and
     that the flowgraph assigns ids in the order it receives sends, so ids
     are assigned 0,1,2,... locally and matched against FRAG/DONE lines. That
     breaks with multiple clients sharing one flowgraph.
  2. IDLE lines are omitted from the Link Log -- they are a once-a-second
     heartbeat and would drown out real events. They still drive the
     link-alive indicator.
  3. Only the receive sockets get worker threads. A single sendto() of a
     small datagram on loopback is treated as non-blocking and issued from
     the GUI thread.
"""

import os
import sys

# ----------------------------------------------------------------------------
# Work around a real, confirmed Ubuntu/Snap crash, BEFORE anything else in
# this file runs - in particular before PyQt5/Qt ever get imported. This
# isn't a generic "just in case" guard: the exact failure below was
# reproduced and root-caused directly (see the project history) while fixing
# a real user report, and the fix here is the specific, verified fix for it,
# not a guess.
#
# THE SYMPTOM:
#   QSocketNotifier: Can only be used with threads started with QThread
#   python3: symbol lookup error: .../snap/core20/current/lib/.../libpthread.so.0:
#   undefined symbol: __libc_pthread_init, version GLIBC_PRIVATE
#
# THE ACTUAL CAUSE (confirmed by reproducing it directly): on a GNOME-based
# Ubuntu desktop, Qt auto-detects the desktop environment and tries to load
# its "gtk3" platform theme integration plugin for native-looking widgets -
# either automatically, or because something in the session (a Snap app's
# own launch environment, e.g. VS Code's, which can leak GTK_PATH/
# QT_QPA_PLATFORMTHEME into a terminal spawned from it) points Qt at that
# plugin. Loading it pulls in a GTK module from a Snap's bundled library
# directory (GTK_PATH pointing into e.g. .../snap/<app>/current/usr/lib/.../
# gtk-3.0), and that module was built against its Snap's own base (commonly
# core20) - whose bundled, standalone libpthread.so.0 predates glibc 2.34
# merging pthread into libc.so.6, and is binary-incompatible with the host
# system's actual glibc. The crash fires from that mismatch, at plugin-load
# time - it has NOTHING to do with sockets, this app's own UDP listener
# threads, or anything else in this file (this was verified directly:
# setting QT_QPA_PLATFORMTHEME=gtk3 alone reproduces the exact crash with no
# other code involved at all; clearing it, or clearing a Snap-polluted
# GTK_PATH, independently prevents it).
#
# THE FIX: this app draws its own dark theme via an explicit stylesheet
# anyway (see build_stylesheet() below) - it has no use for native GTK theme
# integration in the first place, so the simplest fix is to unconditionally
# disable it, and strip Snap paths from a few related GTK/GIO module-lookup
# variables as a second, independent layer of defense in case some other
# Qt subsystem (e.g. a native file dialog) would otherwise also try to load
# a module from one of them later in the app's life. Both changes take
# effect via plain os.environ writes made before PyQt5 is ever imported -
# no process re-exec is needed for these (they're read lazily, at the point
# Qt actually loads a plugin, not baked in at process start the way the
# dynamic linker's own LD_LIBRARY_PATH search is).
# ----------------------------------------------------------------------------
os.environ["QT_QPA_PLATFORMTHEME"] = ""
for _var in ("GTK_PATH", "GIO_MODULE_DIR", "GIO_EXTRA_MODULES",
             "GDK_PIXBUF_MODULEDIR", "GDK_PIXBUF_MODULE_FILE",
             "GTK_IM_MODULE_FILE", "XDG_DATA_DIRS"):
    _val = os.environ.get(_var, "")
    if "/snap/" in _val:
        _kept = os.pathsep.join(p for p in _val.split(os.pathsep) if "/snap/" not in p)
        if _kept:
            os.environ[_var] = _kept
        else:
            os.environ.pop(_var, None)
del _var, _val


def _sanitize_snap_polluted_ld_library_path():
    """A separate, independent layer of defense against the same class of
    problem via a different vector: if LD_LIBRARY_PATH itself (not just the
    GTK-specific variables above) contains a Snap path - e.g. from a shell
    that was launched from, or ever sourced environment from, a Snap
    application - the dynamic linker can resolve libpthread.so.0 (or other
    libraries) against it directly, independent of anything Qt/GTK-related.
    That has to be fixed by re-executing this process with a cleaned
    environment, since LD_LIBRARY_PATH is consulted by the dynamic linker
    at process/library-load time, not lazily re-read the way the GTK
    variables above are. A guard env var prevents looping.
    """
    if os.environ.get("_GS_ENV_SANITIZED"):
        return
    ld_path = os.environ.get("LD_LIBRARY_PATH", "")
    if not ld_path:
        return
    parts = ld_path.split(os.pathsep)
    kept = [p for p in parts if "/snap/" not in p]
    if len(kept) == len(parts):
        return  # nothing Snap-related to strip
    os.environ["_GS_ENV_SANITIZED"] = "1"
    if kept:
        os.environ["LD_LIBRARY_PATH"] = os.pathsep.join(kept)
    else:
        os.environ.pop("LD_LIBRARY_PATH", None)
    try:
        os.execve(sys.executable, [sys.executable] + sys.argv, os.environ)
    except OSError:
        pass  # if re-exec itself fails for some reason, just carry on as-is


_sanitize_snap_polluted_ld_library_path()


import argparse
import math
import os
import shutil
import socket
import subprocess
import sys
import threading
import time
import traceback
from datetime import datetime

from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QObject
from PyQt5.QtGui import QFont, QTextCursor, QColor, QKeySequence
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QPushButton, QTableWidget,
    QTableWidgetItem, QHeaderView, QAbstractItemView, QPlainTextEdit,
    QTextEdit, QSplitter, QVBoxLayout, QHBoxLayout, QDialog, QDialogButtonBox,
    QMessageBox, QFrame, QStatusBar, QShortcut, QSizePolicy, QSpinBox,
    QFileDialog, QProgressBar, QDoubleSpinBox, QCheckBox, QComboBox,
    QTabWidget, QGridLayout,
)

# The link's own modules. Imported for the wire format and the profile table
# so the GUI cannot disagree with the flowgraph about either -- this app used
# to carry its own copies of FRAGMENT_PAYLOAD_BYTES and friends, which is
# exactly the kind of duplication that goes stale silently.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from dsss_link import protocol, filexfer, link_profiles, metrics  # noqa: E402

FRAGMENT_PAYLOAD_BYTES = protocol.chunk_bytes(256)
MAX_FRAGMENTS = protocol.MAX_FRAGMENTS
MAX_MESSAGE_BYTES = protocol.max_message_bytes(256)
MSG_ID_WRAP = 256

HEARTBEAT_STALE_SEC = 5.0
HEARTBEAT_POLL_MS = 1000
LOG_MAX_LINES = 4000
RECV_SOCK_TIMEOUT_S = 0.5
PREVIEW_LEN = 60
NODE_TABLE_SIZE = 16
DEFAULT_DOWNLOAD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    "received_files")


def now_hms() -> str:
    return datetime.now().strftime('%H:%M:%S')


def make_preview(text: str, length: int = PREVIEW_LEN) -> str:
    flat = text.replace('\r\n', ' / ').replace('\n', ' / ').replace('\r', ' / ')
    return flat[:length] + '…' if len(flat) > length else flat


def parse_status_line(line: str):
    """Lenient 'KEYWORD k=v k=v' parser. Never raises."""
    parts = line.strip().split()
    if not parts:
        return None
    kv = {}
    for tok in parts[1:]:
        if '=' in tok:
            k, _, v = tok.partition('=')
            if k:
                kv[k] = v
    return parts[0], kv


def _html_escape(s: str) -> str:
    return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


# --------------------------------------------------------------------------
# Background UDP receive workers
#
# One blocking socket per port on a plain daemon thread. Emitting a Qt signal
# from a foreign thread is well-defined in PyQt5 -- Qt queues it onto the
# receiving object's thread -- so widgets are only ever touched from GUI-thread
# slots. The short socket timeout lets the loop notice stop() without relying
# on close() interrupting recvfrom() on every platform.
# --------------------------------------------------------------------------

class UdpListener(QObject):
    datagram_received = pyqtSignal(bytes)
    bind_failed = pyqtSignal(str)

    def __init__(self, label: str, host: str, port: int, parent=None):
        super().__init__(parent)
        self.label, self.host, self.port = label, host, port
        self._sock = None
        self._stop_event = threading.Event()
        self._thread = None

    def start(self) -> bool:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind((self.host, self.port))
            sock.settimeout(RECV_SOCK_TIMEOUT_S)
        except OSError as exc:
            self.bind_failed.emit(
                f"{self.label}: could not bind {self.host}:{self.port} ({exc})")
            return False
        self._sock = sock
        self._thread = threading.Thread(target=self._run,
                                        name=f"udp-{self.label}", daemon=True)
        self._thread.start()
        return True

    def _run(self):
        while not self._stop_event.is_set():
            try:
                data, _addr = self._sock.recvfrom(65535)
            except socket.timeout:
                continue
            except OSError:
                return
            try:
                self.datagram_received.emit(bytes(data))
            except RuntimeError:
                return

    def stop(self):
        self._stop_event.set()
        if self._sock is not None:
            try:
                self._sock.close()
            except OSError:
                pass


class ComposeEdit(QPlainTextEdit):
    send_requested = pyqtSignal()

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key_Return, Qt.Key_Enter) and (
                event.modifiers() & (Qt.ControlModifier | Qt.MetaModifier)):
            self.send_requested.emit()
            return
        super().keyPressEvent(event)


class FullTextDialog(QDialog):
    def __init__(self, title: str, text: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(720, 480)
        layout = QVBoxLayout(self)
        viewer = QPlainTextEdit(self)
        viewer.setReadOnly(True)
        viewer.setPlainText(text)
        mono = QFont("DejaVu Sans Mono", 10)
        mono.setStyleHint(QFont.Monospace)
        viewer.setFont(mono)
        layout.addWidget(viewer)
        buttons = QDialogButtonBox(QDialogButtonBox.Close, self)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)


# --------------------------------------------------------------------------
# Diagnostics window
# --------------------------------------------------------------------------

class DiagnosticsWindow(QDialog):
    """Live link metrics.

    The processing-gain rows deserve a note. An earlier version of this window
    showed "processing gain, actual" as the correlation peak over its
    neighbours, next to "ideal" of 10*log10(1023) = 30.1 dB. Those are
    different quantities: peak-over-neighbours is the code's peak-to-sidelobe
    ratio, which is pinned by the code's own sidelobes and cannot reach 30 dB
    however good the link is. It now appears under its real name as a lock
    quality indicator, and processing gain is derived properly from the SNR
    before and after despreading.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Link diagnostics")
        self.setModal(False)
        self.resize(500, 720)
        self.setStyleSheet(_QSS)
        layout = QVBoxLayout(self)
        layout.setSpacing(4)
        self.labels = {}

        def section(title, hint=""):
            lbl = QLabel(title, self)
            lbl.setObjectName("panelTitle")
            layout.addSpacing(10)
            layout.addWidget(lbl)
            if hint:
                h = QLabel(hint, self)
                h.setObjectName("cfgLabel")
                h.setWordWrap(True)
                layout.addWidget(h)

        def row(key, title, initial="--"):
            box = QHBoxLayout()
            name = QLabel(title, self)
            name.setMinimumWidth(215)
            val = QLabel(initial, self)
            val.setObjectName("diagValue")
            mono = QFont("DejaVu Sans Mono", 10)
            mono.setStyleHint(QFont.Monospace)
            val.setFont(mono)
            box.addWidget(name)
            box.addWidget(val, stretch=1)
            layout.addLayout(box)
            self.labels[key] = val

        section("CODE LOCK", "Requirement 1: acquisition and code tracking.")
        row('lock', 'Despreader lock', 'UNKNOWN')
        row('code_phase', 'Tracked code phase')
        row('drift', 'Code phase drift', )
        row('slips', 'Tracking slips')
        row('cfo', 'Carrier offset found')

        section("PROCESSING GAIN",
                "Gain is the difference between the SNR before and after "
                "despreading, so it needs both. Peak-to-sidelobe is a lock "
                "quality indicator, not the gain -- see demo 7.")
        row('pg_ideal', 'Ideal, 10*log10(code_len)')
        row('snr_symbol', 'Symbol SNR after despread')
        row('snr_chip', 'Implied SNR before despread')
        row('psr', 'Peak-to-sidelobe (lock quality)')

        section("SIGNAL QUALITY")
        row('evm_last', 'EVM')
        row('snr_evm', 'SNR implied by EVM')
        row('snr_m2m4', 'SNR, moment estimator')
        row('power', 'RX power (dBFS)')

        section("ERRORS", "Requirement 7: bit error rate.")
        row('bert', 'BER (PRBS-15 test)')
        row('bert_bits', 'BER bits measured')
        row('pkt_err', 'Packet error rate (CRC)')
        row('recovered', 'Fragments recovered by parity')
        row('fec', 'Repetition-FEC corrections')

        section("USRP HEALTH", "Real hardware only.")
        row('underflow', 'TX underflow events')
        row('overflow', 'RX overflow events')
        row('other_health', 'Other UHD async events')

        section("SESSION")
        row('profile', 'Link profile')
        row('uptime', 'Uptime')
        row('counts', 'Messages sent / received')
        row('files', 'Files sent / received')

        layout.addStretch(1)
        note = QLabel(
            "Lock, SNR, EVM and spectrum readings come from the flowgraph's "
            "diagnostics port and only update while it is running. UHD health "
            "events only ever appear on real hardware.", self)
        note.setWordWrap(True)
        note.setObjectName("cfgLabel")
        layout.addWidget(note)

    def set_value(self, key, text):
        lbl = self.labels.get(key)
        if lbl is not None:
            lbl.setText(text)


# --------------------------------------------------------------------------
# Demo launcher
# --------------------------------------------------------------------------

DEMO_TITLES = [
    (1, "PN code alignment and code tracking"),
    (2, "High spreading factor"),
    (3, "Chip rate versus bit rate"),
    (4, "Carrier offset / timing drift decision"),
    (5, "Full duplex"),
    (6, "Spectrum: signal below the noise floor"),
    (7, "Processing gain and bit error rate"),
    (8, "Stretch: third-radio jammer"),
]


class DemoWindow(QDialog):
    """Runs demo.py and shows its output.

    Each requirement gets one button. The run happens in a worker thread with
    its output streamed into the pane, because several of these take a couple
    of minutes and a frozen window during a live demonstration is its own kind
    of failure.
    """

    output_line = pyqtSignal(str)
    finished_run = pyqtSignal(int, str)

    def __init__(self, parent=None, live=False):
        super().__init__(parent)
        self.setWindowTitle("Requirement demos")
        self.setModal(False)
        self.resize(980, 720)
        self.setStyleSheet(_QSS)
        self._proc = None
        self._live = live

        layout = QVBoxLayout(self)
        title = QLabel("EACH REQUIREMENT, ONE RUN", self)
        title.setObjectName("panelTitle")
        layout.addWidget(title)
        blurb = QLabel(
            "Every run writes a folder under demo_results/ with a report, the "
            "figures, and the raw data. Tick 'measure the live flowgraph' to "
            "have the runs that can talk to the radio do so as well as "
            "simulating.", self)
        blurb.setWordWrap(True)
        blurb.setObjectName("cfgLabel")
        layout.addWidget(blurb)

        grid = QGridLayout()
        self.buttons = []
        for i, (n, t) in enumerate(DEMO_TITLES):
            b = QPushButton(f"{n}.  {t}", self)
            b.setObjectName("demoButton")
            b.clicked.connect(lambda _c, num=n: self.run_demo(num))
            grid.addWidget(b, i // 2, i % 2)
            self.buttons.append(b)
        layout.addLayout(grid)

        opts = QHBoxLayout()
        self.live_check = QCheckBox("measure the live flowgraph", self)
        self.live_check.setChecked(live)
        self.quick_check = QCheckBox("quick (shorter sweeps)", self)
        opts.addWidget(self.live_check)
        opts.addWidget(self.quick_check)
        opts.addStretch(1)
        self.all_button = QPushButton("Run all eight", self)
        self.all_button.setObjectName("sendButton")
        self.all_button.clicked.connect(lambda: self.run_demo("all"))
        opts.addWidget(self.all_button)
        self.open_button = QPushButton("Open results folder", self)
        self.open_button.setObjectName("clearLogBtn")
        self.open_button.clicked.connect(self._open_results)
        opts.addWidget(self.open_button)
        layout.addLayout(opts)

        self.out = QTextEdit(self)
        self.out.setReadOnly(True)
        self.out.setLineWrapMode(QTextEdit.NoWrap)
        mono = QFont("DejaVu Sans Mono", 9)
        mono.setStyleHint(QFont.Monospace)
        self.out.setFont(mono)
        layout.addWidget(self.out, stretch=1)

        self.output_line.connect(self._append)
        self.finished_run.connect(self._done)

    def _append(self, text):
        self.out.moveCursor(QTextCursor.End)
        self.out.insertPlainText(text)
        self.out.moveCursor(QTextCursor.End)

    def _set_enabled(self, on):
        for b in self.buttons:
            b.setEnabled(on)
        self.all_button.setEnabled(on)

    def run_demo(self, which):
        if self._proc is not None:
            QMessageBox.information(self, "Already running",
                                    "A demo is already running. Wait for it "
                                    "to finish.")
            return
        here = os.path.dirname(os.path.abspath(__file__))
        cmd = [sys.executable, os.path.join(here, "demo.py"), str(which)]
        if self.live_check.isChecked():
            cmd.append("--live")
        if self.quick_check.isChecked():
            cmd.append("--quick")
        self.out.clear()
        self._append(" ".join(cmd) + "\n\n")
        self._set_enabled(False)

        def worker():
            try:
                p = subprocess.Popen(cmd, cwd=here, stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT, text=True,
                                     bufsize=1)
                self._proc = p
                for line in p.stdout:
                    self.output_line.emit(line)
                p.wait()
                self.finished_run.emit(p.returncode, str(which))
            except Exception as exc:
                self.output_line.emit(f"\nfailed to start demo.py: {exc}\n")
                self.finished_run.emit(-1, str(which))

        threading.Thread(target=worker, daemon=True).start()

    def _done(self, code, which):
        self._proc = None
        self._set_enabled(True)
        self._append(f"\n--- finished (exit {code}) ---\n")

    def _open_results(self):
        here = os.path.dirname(os.path.abspath(__file__))
        d = os.path.join(here, "demo_results")
        os.makedirs(d, exist_ok=True)
        for opener in ("xdg-open", "open", "explorer"):
            if shutil.which(opener):
                subprocess.Popen([opener, d])
                return
        QMessageBox.information(self, "Results", d)


# --------------------------------------------------------------------------
# Main window
# --------------------------------------------------------------------------

class GroundStationWindow(QMainWindow):
    def __init__(self, host, tx_port, rx_data_port, rx_status_port, bind_host,
                 ctrl_port, diag_port, download_dir, profile_name):
        super().__init__()
        self.host = host
        self.tx_port = tx_port
        self.rx_data_port = rx_data_port
        self.rx_status_port = rx_status_port
        self.bind_host = bind_host
        self.ctrl_port = ctrl_port
        self.diag_port = diag_port
        self.profile = link_profiles.get(profile_name)

        self.diag_window = None
        self.demo_window = None
        self._start_monotonic = time.monotonic()
        self._crc_ok_count = 0
        self._crc_fail_count = 0
        self._underflow_count = 0
        self._overflow_count = 0
        self._other_health_count = 0
        self._msgs_received = 0
        self._files_sent = 0
        self._recovered_total = 0
        self._last_snr = {}

        self._next_tx_msg_id = 0
        self.pending_sends = {}          # msg_id -> dict
        self.transfers = {}              # msg_id -> TransferProgress
        self._last_status_rx_monotonic = None

        self.incoming = filexfer.IncomingFiles(download_dir)

        self.setWindowTitle("GROUND STATION — DSSS/QPSK LINK")
        self.resize(1320, 880)

        self._build_ui()
        self.setStyleSheet(_QSS)

        self.tx_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.ctrl_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        self.data_listener = UdpListener("RX-DATA", bind_host, rx_data_port)
        self.data_listener.datagram_received.connect(self._on_data_datagram)
        self.data_listener.bind_failed.connect(self._on_bind_failed)
        self.status_listener = UdpListener("RX-STATUS", bind_host,
                                           rx_status_port)
        self.status_listener.datagram_received.connect(self._on_status_datagram)
        self.status_listener.bind_failed.connect(self._on_bind_failed)
        self.diag_listener = UdpListener("DIAG", bind_host, diag_port)
        self.diag_listener.datagram_received.connect(self._on_diag_datagram)
        self.diag_listener.bind_failed.connect(self._on_bind_failed)

        ok_data = self.data_listener.start()
        ok_status = self.status_listener.start()
        self.diag_listener.start()
        if ok_data and ok_status:
            self._log_plain("link log ready; waiting for flowgraph traffic...",
                            "#8b949e")
            self._log_plain(
                f"profile '{self.profile.name}': {self.profile.code_len}-chip "
                f"code, {self.profile.chip_rate / 1e6:.3f} Mcps, "
                f"{self.profile.processing_gain_db:.1f} dB gain, "
                f"~{self.profile.payload_rate_bytes_per_s():.0f} bytes/s",
                "#58a6ff")

        self.heartbeat_timer = QTimer(self)
        self.heartbeat_timer.timeout.connect(self._update_heartbeat_display)
        self.heartbeat_timer.start(HEARTBEAT_POLL_MS)
        self._update_heartbeat_display()

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------
    def _build_ui(self):
        central = QWidget(self)
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(8)
        root.addWidget(self._build_header())
        root.addWidget(self._build_bind_error_banner())

        splitter = QSplitter(Qt.Vertical, self)
        splitter.addWidget(self._build_tables())
        splitter.addWidget(self._build_log_panel())
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 2)
        root.addWidget(splitter, stretch=1)
        root.addWidget(self._build_send_panel())

        self.setStatusBar(QStatusBar(self))
        self.statusBar().showMessage("ready")

    def _build_header(self):
        bar = QFrame(self)
        bar.setObjectName("headerBar")
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(12, 8, 12, 8)

        title = QLabel("GROUND STATION", bar)
        title.setObjectName("titleLabel")
        cfg = QLabel(f"TX→{self.host}:{self.tx_port}   "
                     f"RX←{self.bind_host}:{self.rx_data_port}/"
                     f"{self.rx_status_port}/{self.diag_port}", bar)
        cfg.setObjectName("cfgLabel")
        mono = QFont("DejaVu Sans Mono", 9)
        mono.setStyleHint(QFont.Monospace)
        cfg.setFont(mono)
        layout.addWidget(title)
        layout.addSpacing(16)
        layout.addWidget(cfg)
        layout.addStretch(1)

        node_box = QFrame(bar)
        node_box.setObjectName("nodeBox")
        nl = QHBoxLayout(node_box)
        nl.setContentsMargins(8, 2, 8, 2)
        nl.setSpacing(4)
        nl.addWidget(QLabel("MY NODE", node_box))
        self.my_node_spin = QSpinBox(node_box)
        self.my_node_spin.setRange(0, NODE_TABLE_SIZE - 1)
        self.my_node_spin.valueChanged.connect(self._on_my_node_changed)
        nl.addWidget(self.my_node_spin)
        nl.addSpacing(10)
        nl.addWidget(QLabel("TALKING TO", node_box))
        self.dest_node_spin = QSpinBox(node_box)
        self.dest_node_spin.setRange(0, NODE_TABLE_SIZE - 1)
        self.dest_node_spin.setValue(1)
        self.dest_node_spin.valueChanged.connect(self._on_dest_node_changed)
        nl.addWidget(self.dest_node_spin)
        layout.addWidget(node_box)
        layout.addSpacing(10)

        self.bert_button = QPushButton("BER test", bar)
        self.bert_button.setObjectName("debugButton")
        self.bert_button.setCheckable(True)
        self.bert_button.setToolTip(
            "Fill idle slots with a PRBS-15 pattern so the receiver can count "
            "real channel bit errors continuously. Requirement 7.")
        self.bert_button.clicked.connect(self._on_bert_toggled)
        layout.addWidget(self.bert_button)

        self.demo_button = QPushButton("Demos ▸", bar)
        self.demo_button.setObjectName("debugButton")
        self.demo_button.clicked.connect(self._open_demos)
        layout.addWidget(self.demo_button)

        self.debug_button = QPushButton("Diagnostics ▸", bar)
        self.debug_button.setObjectName("debugButton")
        self.debug_button.setCheckable(True)
        self.debug_button.clicked.connect(self._toggle_debug_window)
        layout.addWidget(self.debug_button)
        layout.addSpacing(12)

        self.link_dot = QLabel(bar)
        self.link_dot.setFixedSize(14, 14)
        self.link_heartbeat_label = QLabel("NO LINK", bar)
        self.link_heartbeat_label.setObjectName("heartbeatLabel")
        layout.addWidget(self.link_dot)
        layout.addWidget(self.link_heartbeat_label)
        return bar

    def _build_bind_error_banner(self):
        self.bind_error_banner = QLabel("", self)
        self.bind_error_banner.setObjectName("bindErrorBanner")
        self.bind_error_banner.setWordWrap(True)
        self.bind_error_banner.hide()
        return self.bind_error_banner

    def _make_table(self, headers):
        t = QTableWidget(0, len(headers), self)
        t.setHorizontalHeaderLabels(headers)
        t.verticalHeader().setVisible(False)
        t.setEditTriggers(QAbstractItemView.NoEditTriggers)
        t.setSelectionBehavior(QAbstractItemView.SelectRows)
        t.setSelectionMode(QAbstractItemView.SingleSelection)
        t.setAlternatingRowColors(True)
        t.setWordWrap(False)
        t.horizontalHeader().setStretchLastSection(True)
        mono = QFont("DejaVu Sans Mono", 9)
        mono.setStyleHint(QFont.Monospace)
        t.setFont(mono)
        return t

    def _build_tables(self):
        container = QSplitter(Qt.Horizontal, self)

        sent_box = QWidget(self)
        sl = QVBoxLayout(sent_box)
        sl.setContentsMargins(0, 0, 0, 0)
        lbl = QLabel("SENT", sent_box)
        lbl.setObjectName("panelTitle")
        self.sent_table = self._make_table(
            ["Time", "Kind", "Size", "Preview", "Progress", "Status"])
        h = self.sent_table.horizontalHeader()
        for c in (0, 1, 2, 4):
            h.setSectionResizeMode(c, QHeaderView.ResizeToContents)
        h.setSectionResizeMode(3, QHeaderView.Stretch)
        self.sent_table.itemDoubleClicked.connect(self._on_sent_double)
        sl.addWidget(lbl)
        sl.addWidget(self.sent_table)

        recv_box = QWidget(self)
        rl = QVBoxLayout(recv_box)
        rl.setContentsMargins(0, 0, 0, 0)
        rlbl = QLabel("RECEIVED", recv_box)
        rlbl.setObjectName("panelTitle")
        self.recv_table = self._make_table(
            ["Time", "Kind", "Size", "Detail", "Integrity"])
        rh = self.recv_table.horizontalHeader()
        for c in (0, 1, 2, 4):
            rh.setSectionResizeMode(c, QHeaderView.ResizeToContents)
        rh.setSectionResizeMode(3, QHeaderView.Stretch)
        self.recv_table.itemDoubleClicked.connect(self._on_recv_double)
        rl.addWidget(rlbl)
        rl.addWidget(self.recv_table)

        container.addWidget(sent_box)
        container.addWidget(recv_box)
        container.setStretchFactor(0, 1)
        container.setStretchFactor(1, 1)
        return container

    def _build_log_panel(self):
        box = QWidget(self)
        layout = QVBoxLayout(box)
        layout.setContentsMargins(0, 0, 0, 0)
        row = QHBoxLayout()
        t = QLabel("LINK LOG", box)
        t.setObjectName("panelTitle")
        row.addWidget(t)
        row.addStretch(1)
        self.show_frags = QCheckBox("show every fragment", box)
        self.show_frags.setToolTip(
            "Off by default: a one-megabyte file is several thousand "
            "fragments and logging each one buries everything else.")
        row.addWidget(self.show_frags)
        clear = QPushButton("Clear", box)
        clear.setObjectName("clearLogBtn")
        clear.clicked.connect(self._clear_log)
        row.addWidget(clear)
        layout.addLayout(row)
        self.log_edit = QTextEdit(box)
        self.log_edit.setReadOnly(True)
        self.log_edit.setLineWrapMode(QTextEdit.NoWrap)
        mono = QFont("DejaVu Sans Mono", 9)
        mono.setStyleHint(QFont.Monospace)
        self.log_edit.setFont(mono)
        layout.addWidget(self.log_edit)
        return box

    def _build_send_panel(self):
        box = QFrame(self)
        box.setObjectName("composePanel")
        outer = QVBoxLayout(box)
        tabs = QTabWidget(box)
        tabs.setObjectName("sendTabs")

        # ---- message tab ----
        msg = QWidget(box)
        ml = QVBoxLayout(msg)
        self.compose_edit = ComposeEdit(msg)
        self.compose_edit.setPlaceholderText(
            "Type a message to transmit over the link... "
            "(Ctrl+Enter sends)")
        self.compose_edit.setMinimumHeight(70)
        mono = QFont("DejaVu Sans Mono", 10)
        mono.setStyleHint(QFont.Monospace)
        self.compose_edit.setFont(mono)
        self.compose_edit.textChanged.connect(self._update_compose_stats)
        self.compose_edit.send_requested.connect(self._on_send_clicked)
        ml.addWidget(self.compose_edit)
        stats = QHBoxLayout()
        self.byte_counter_label = QLabel("0 bytes", msg)
        self.byte_counter_label.setObjectName("byteCounterLabel")
        self.estimate_label = QLabel("", msg)
        self.estimate_label.setObjectName("estimateLabel")
        stats.addWidget(self.byte_counter_label)
        stats.addSpacing(16)
        stats.addWidget(self.estimate_label)
        stats.addStretch(1)
        self.send_button = QPushButton("SEND ▶", msg)
        self.send_button.setObjectName("sendButton")
        self.send_button.clicked.connect(self._on_send_clicked)
        stats.addWidget(self.send_button)
        ml.addLayout(stats)
        tabs.addTab(msg, "Message")

        # ---- file tab ----
        fil = QWidget(box)
        fl = QVBoxLayout(fil)
        pick = QHBoxLayout()
        self.file_label = QLabel("no file chosen — or drop one here", fil)
        self.file_label.setObjectName("estimateLabel")
        browse = QPushButton("Choose file…", fil)
        browse.setObjectName("clearLogBtn")
        browse.clicked.connect(self._choose_file)
        pick.addWidget(browse)
        pick.addSpacing(10)
        pick.addWidget(self.file_label, stretch=1)
        fl.addLayout(pick)

        opts = QHBoxLayout()
        opts.addWidget(QLabel("parity overhead", fil))
        self.parity_spin = QDoubleSpinBox(fil)
        self.parity_spin.setRange(0.0, 50.0)
        self.parity_spin.setSingleStep(5.0)
        self.parity_spin.setValue(self.profile.parity_fraction * 100)
        self.parity_spin.setSuffix(" %")
        self.parity_spin.setToolTip(
            "Extra Reed-Solomon fragments. There is no retransmission on this "
            "link, so without parity a single lost fragment loses the whole "
            "file. 20% survives roughly 15% fragment loss.")
        self.parity_spin.valueChanged.connect(self._on_parity_changed)
        opts.addWidget(self.parity_spin)
        opts.addSpacing(20)
        self.file_estimate = QLabel("", fil)
        self.file_estimate.setObjectName("estimateLabel")
        opts.addWidget(self.file_estimate, stretch=1)
        self.send_file_button = QPushButton("SEND FILE ▶", fil)
        self.send_file_button.setObjectName("sendButton")
        self.send_file_button.setEnabled(False)
        self.send_file_button.clicked.connect(self._on_send_file)
        opts.addWidget(self.send_file_button)
        fl.addLayout(opts)

        self.file_progress = QProgressBar(fil)
        self.file_progress.setRange(0, 1000)
        self.file_progress.setValue(0)
        self.file_progress.setFormat("")
        fl.addWidget(self.file_progress)
        self.file_status = QLabel(
            f"received files are written to {self.incoming.save_dir}", fil)
        self.file_status.setObjectName("cfgLabel")
        fl.addWidget(self.file_status)
        tabs.addTab(fil, "File")

        outer.addWidget(tabs)
        self.setAcceptDrops(True)
        self._pending_file = None

        self._send_shortcut = QShortcut(QKeySequence("Ctrl+Return"), self)
        self._send_shortcut.activated.connect(self._on_send_clicked)
        self._update_compose_stats()
        return box

    # ------------------------------------------------------------------
    # Drag and drop
    # ------------------------------------------------------------------
    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event):
        urls = event.mimeData().urls()
        if urls:
            path = urls[0].toLocalFile()
            if path and os.path.isfile(path):
                self._set_file(path)
                event.acceptProposedAction()

    # ------------------------------------------------------------------
    # Control commands
    # ------------------------------------------------------------------
    def _send_ctrl(self, text: str):
        try:
            self.ctrl_sock.sendto(text.encode('ascii'),
                                  (self.host, self.ctrl_port))
        except OSError as exc:
            self._log_html(f"<span style='color:#f85149'><b>CONTROL SEND "
                           f"FAILED:</b> {_html_escape(str(exc))}</span>")

    def _on_my_node_changed(self, v):
        self._send_ctrl(f"NODE={v}")
        self._log_plain(f"transmitting as node {v}", "#58a6ff")

    def _on_dest_node_changed(self, v):
        self._send_ctrl(f"DEST={v}")
        self._log_plain(f"now despreading node {v}'s code", "#58a6ff")

    def _on_parity_changed(self, v):
        self._send_ctrl(f"PARITY={v:.0f}")
        self._refresh_file_estimate()

    def _on_bert_toggled(self, checked):
        self._send_ctrl(f"BERT={1 if checked else 0}")
        self._log_plain(
            "BER test ON -- idle slots now carry PRBS-15; the receiver is "
            "counting real channel bit errors" if checked
            else "BER test off", "#58a6ff")

    def _open_demos(self):
        if self.demo_window is None:
            self.demo_window = DemoWindow(self, live=True)
        self.demo_window.show()
        self.demo_window.raise_()
        self.demo_window.activateWindow()

    def _toggle_debug_window(self, checked):
        if self.diag_window is None:
            self.diag_window = DiagnosticsWindow(self)
            self.diag_window.finished.connect(
                lambda _: self.debug_button.setChecked(False))
            self.diag_window.set_value(
                'pg_ideal',
                f"{metrics.ideal_processing_gain_db(self.profile.code_len):.1f} dB")
            self.diag_window.set_value(
                'profile',
                f"{self.profile.name} ({self.profile.code_len} chips, "
                f"{self.profile.chip_rate / 1e6:.3f} Mcps)")
        if checked:
            self._refresh_debug_window()
            self.diag_window.show()
            self.diag_window.raise_()
        else:
            self.diag_window.hide()

    def _refresh_debug_window(self):
        w = self.diag_window
        if w is None:
            return
        up = time.monotonic() - self._start_monotonic
        h, rem = divmod(int(up), 3600)
        m, s = divmod(rem, 60)
        w.set_value('uptime', f"{h:02d}:{m:02d}:{s:02d}")
        w.set_value('counts', f"sent={self._next_tx_msg_id}  "
                              f"received={self._msgs_received}")
        w.set_value('files', f"sent={self._files_sent}  "
                             f"received={len(self.incoming.received)}")
        w.set_value('underflow', str(self._underflow_count))
        w.set_value('overflow', str(self._overflow_count))
        w.set_value('other_health', str(self._other_health_count))
        w.set_value('recovered', str(self._recovered_total))
        total = self._crc_ok_count + self._crc_fail_count
        if total:
            pct = 100.0 * self._crc_fail_count / total
            w.set_value('pkt_err',
                        f"{pct:.2f}%  ({self._crc_fail_count}/{total})")

    # ------------------------------------------------------------------
    # Diagnostics telemetry
    # ------------------------------------------------------------------
    def _on_diag_datagram(self, data: bytes):
        line = data.decode('utf-8', errors='replace').strip()
        if not line:
            return
        try:
            self._handle_diag_line(line)
        except Exception:
            traceback.print_exc()

    def _handle_diag_line(self, line):
        parsed = parse_status_line(line)
        if parsed is None:
            return
        kw, kv = parsed
        w = self.diag_window

        def setv(key, text):
            if w is not None:
                w.set_value(key, text)

        if kw == "LOCK":
            state = kv.get('state', '?')
            setv('lock', "ACQUIRED (tracking)" if state == 'acquired'
                 else f"SEARCHING ({kv.get('reason', 'no lock')})")
            if 'cfo_hz' in kv:
                setv('cfo', f"{float(kv['cfo_hz']):+.1f} Hz")
            if 'code_phase' in kv:
                setv('code_phase', f"{kv['code_phase']} samples")
            self._log_plain(
                f"despreader {'acquired' if state == 'acquired' else 'lost'} "
                f"lock" + (f" (carrier offset {float(kv['cfo_hz']):+.0f} Hz)"
                           if kv.get('cfo_hz') else ""),
                "#3fb950" if state == 'acquired' else "#d29922")

        elif kw == "SNR":
            if 'symbol_db' in kv:
                v = float(kv['symbol_db'])
                setv('snr_symbol', f"{v:.1f} dB")
                # Implied pre-despread SNR: the same signal measured in the
                # spread bandwidth. This is the number a spectrum analyser
                # would show, and the reason it is negative is the point.
                setv('snr_chip',
                     f"{metrics.symbol_snr_to_chip_snr_db(v, self.profile.code_len):.1f} dB")
            if 'psr_db' in kv:
                setv('psr', f"{float(kv['psr_db']):.1f} dB")
            if 'drift' in kv:
                setv('drift', f"{float(kv['drift']):+.3f} chips / 1000 symbols")
            if 'slips' in kv:
                setv('slips', kv['slips'])
            if 'cfo_hz' in kv:
                setv('cfo', f"{float(kv['cfo_hz']):+.1f} Hz")

        elif kw == "QUALITY":
            if 'evm_pct' in kv:
                setv('evm_last', f"{float(kv['evm_pct']):.1f} %")
            if 'snr_evm_db' in kv:
                setv('snr_evm', f"{float(kv['snr_evm_db']):.1f} dB")
            if 'snr_m2m4_db' in kv:
                setv('snr_m2m4', f"{float(kv['snr_m2m4_db']):.1f} dB")

        elif kw == "RXPOWER":
            if 'dbfs' in kv:
                setv('power', f"{kv['dbfs']} dBFS")

        elif kw == "FEC":
            setv('fec', f"{kv.get('corrected', '--')} ({kv.get('pct', '?')}%)")

        # PSD lines are consumed by demo 6 rather than displayed here; a
        # spectrum does not belong in a field-value list.

    # ------------------------------------------------------------------
    # Sending
    # ------------------------------------------------------------------
    def _update_compose_stats(self):
        text = self.compose_edit.toPlainText()
        n = len(text.encode('utf-8'))
        over = n > MAX_MESSAGE_BYTES
        frags = math.ceil(n / FRAGMENT_PAYLOAD_BYTES) if n else 0
        secs = filexfer.estimate_seconds(frags, self.profile)
        self.byte_counter_label.setText(f"{n:,} bytes")
        self.byte_counter_label.setProperty("overLimit", over)
        self.byte_counter_label.style().unpolish(self.byte_counter_label)
        self.byte_counter_label.style().polish(self.byte_counter_label)
        if over:
            self.estimate_label.setText(
                f"exceeds the {MAX_MESSAGE_BYTES:,}-byte ceiling")
        else:
            self.estimate_label.setText(
                f"{frags} fragment{'s' if frags != 1 else ''} · "
                f"~{filexfer.human_duration(secs)} on air")
        self.send_button.setEnabled(not over)

    def _choose_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Send a file over the link")
        if path:
            self._set_file(path)

    def _set_file(self, path):
        self._pending_file = path
        self.file_label.setText(path)
        self._refresh_file_estimate()

    def _refresh_file_estimate(self):
        if not self._pending_file or not os.path.isfile(self._pending_file):
            self.send_file_button.setEnabled(False)
            self.file_estimate.setText("")
            return
        try:
            size = os.path.getsize(self._pending_file)
        except OSError as exc:
            self.file_estimate.setText(f"cannot read: {exc}")
            self.send_file_button.setEnabled(False)
            return

        pf = self.parity_spin.value() / 100.0
        overhead = 64 + 12
        n_data = max(1, -(-(size + overhead) // FRAGMENT_PAYLOAD_BYTES))
        n_par = protocol.parity_count_for(n_data, pf)
        total = n_data + n_par
        secs = filexfer.estimate_seconds(total, self.profile)
        too_big = n_data > MAX_FRAGMENTS

        self.file_estimate.setText(
            f"{filexfer.human_bytes(size)} → {n_data:,} data + "
            f"{n_par:,} parity fragments · "
            f"~{filexfer.human_duration(secs)} on air at "
            f"{self.profile.payload_rate_bytes_per_s():.0f} B/s"
            + ("  — TOO LARGE" if too_big else ""))
        self.send_file_button.setEnabled(not too_big)

    def _on_send_file(self):
        path = self._pending_file
        if not path:
            return
        pf = self.parity_spin.value() / 100.0
        try:
            prep = filexfer.prepare_file(path, pf)
        except OSError as exc:
            QMessageBox.critical(self, "Cannot read file", str(exc))
            return
        if prep["too_large"]:
            QMessageBox.warning(
                self, "File too large",
                f"This file needs {prep['n_data']:,} fragments; the wire "
                f"format allows {MAX_FRAGMENTS:,} "
                f"({filexfer.human_bytes(prep['max_bytes'])}).")
            return

        secs = filexfer.estimate_seconds(prep["n_total"], self.profile)
        if secs > 600:
            ok = QMessageBox.question(
                self, "This will take a while",
                f"{prep['filename']} is {filexfer.human_bytes(prep['file_bytes'])}.\n\n"
                f"At the '{self.profile.name}' profile's "
                f"{self.profile.payload_rate_bytes_per_s():.0f} bytes/second "
                f"that is about {filexfer.human_duration(secs)} on air.\n\n"
                f"A faster profile would cut that "
                f"(see demo 3). Send anyway?")
            if ok != QMessageBox.Yes:
                return

        self._transmit(prep["message"], kind="file", label=prep["filename"],
                       file_bytes=prep["file_bytes"],
                       n_data=prep["n_data"], n_parity=prep["n_parity"])
        self._files_sent += 1

    def _on_send_clicked(self):
        text = self.compose_edit.toPlainText()
        if not text:
            return
        encoded = text.encode('utf-8')
        if len(encoded) > MAX_MESSAGE_BYTES:
            QMessageBox.warning(self, "Message too large",
                                f"{len(encoded):,} bytes exceeds the "
                                f"{MAX_MESSAGE_BYTES:,}-byte ceiling.")
            return
        self._transmit(encoded, kind="text", label=make_preview(text),
                       file_bytes=len(encoded),
                       n_data=max(1, math.ceil(len(encoded)
                                               / FRAGMENT_PAYLOAD_BYTES)),
                       n_parity=0, full_text=text)
        self.compose_edit.clear()

    def _transmit(self, payload, kind, label, file_bytes, n_data, n_parity,
                  full_text=None):
        try:
            self.tx_sock.sendto(payload, (self.host, self.tx_port))
        except OSError as exc:
            QMessageBox.critical(self, "Send failed", f"sendto() failed: {exc}")
            return

        msg_id = self._next_tx_msg_id
        self._next_tx_msg_id = (self._next_tx_msg_id + 1) % MSG_ID_WRAP

        prog = filexfer.TransferProgress(
            msg_id=msg_id, filename=label, file_bytes=file_bytes,
            n_data=n_data, n_parity=n_parity)
        self.transfers[msg_id] = prog

        self.sent_table.insertRow(0)
        items = [QTableWidgetItem(now_hms()),
                 QTableWidgetItem("FILE" if kind == "file" else "text"),
                 QTableWidgetItem(filexfer.human_bytes(file_bytes)),
                 QTableWidgetItem(label),
                 QTableWidgetItem("0%"),
                 QTableWidgetItem("sending…")]
        items[3].setData(Qt.UserRole, full_text if full_text is not None
                         else f"[file] {label}")
        for c, it in enumerate(items):
            it.setFlags(it.flags() & ~Qt.ItemIsEditable)
            self.sent_table.setItem(0, c, it)
        self.pending_sends[msg_id] = {"progress_item": items[4],
                                      "status_item": items[5],
                                      "kind": kind}
        self.statusBar().showMessage(
            f"sent msg {msg_id}: {label} "
            f"({n_data} data + {n_parity} parity fragments)", 6000)
        self._log_plain(
            f"queued {kind} '{label}' as msg {msg_id}: {n_data} data + "
            f"{n_parity} parity fragments", "#58a6ff")

    # ------------------------------------------------------------------
    # Receiving
    # ------------------------------------------------------------------
    def _on_data_datagram(self, data: bytes):
        self._msgs_received += 1
        rec = None
        try:
            rec = self.incoming.handle(data)
        except Exception:
            traceback.print_exc()

        self.recv_table.insertRow(0)
        if rec is not None:
            ok = rec["sha_ok"]
            items = [QTableWidgetItem(now_hms()),
                     QTableWidgetItem("FILE"),
                     QTableWidgetItem(filexfer.human_bytes(rec["bytes"])),
                     QTableWidgetItem(rec["filename"]
                                      + (f"  → {rec['path']}" if ok else "")),
                     QTableWidgetItem("SHA-256 OK" if ok else "HASH MISMATCH")]
            items[4].setForeground(QColor("#3fb950" if ok else "#f85149"))
            items[3].setData(Qt.UserRole,
                             f"{rec['filename']}\n"
                             f"{rec['bytes']:,} bytes\n"
                             f"sha256 {rec['sha256']}\n"
                             f"{'saved to ' + rec['path'] if ok else 'NOT saved -- hash mismatch'}")
            self._log_html(
                f"<span style='color:{'#3fb950' if ok else '#f85149'}; "
                f"font-weight:bold'>FILE {'RECEIVED' if ok else 'CORRUPT'}: "
                f"{_html_escape(rec['filename'])} "
                f"({filexfer.human_bytes(rec['bytes'])})"
                f"{' saved to ' + _html_escape(rec['path']) if ok else ''}"
                f"</span>")
            self.file_status.setText(
                f"last file: {rec['filename']} — "
                + ("verified and saved" if ok else "HASH MISMATCH, not saved"))
        else:
            text = data.decode('utf-8', errors='replace')
            items = [QTableWidgetItem(now_hms()),
                     QTableWidgetItem("text"),
                     QTableWidgetItem(filexfer.human_bytes(len(data))),
                     QTableWidgetItem(make_preview(text)),
                     QTableWidgetItem("CRC OK")]
            items[3].setData(Qt.UserRole, text)
        for c, it in enumerate(items):
            it.setFlags(it.flags() & ~Qt.ItemIsEditable)
            self.recv_table.setItem(0, c, it)
        self.recv_table.scrollToTop()
        self.statusBar().showMessage(
            f"received {filexfer.human_bytes(len(data))}", 5000)
        self._refresh_debug_window()

    # ------------------------------------------------------------------
    # Status stream
    # ------------------------------------------------------------------
    def _on_status_datagram(self, data: bytes):
        self._last_status_rx_monotonic = time.monotonic()
        line = data.decode('utf-8', errors='replace').strip()
        if not line:
            return
        try:
            self._handle_status_line(line)
        except Exception:
            traceback.print_exc()
            self._log_html(f"<span style='color:#8b949e'>[unparsed] "
                           f"{_html_escape(line)}</span>")

    def _handle_status_line(self, line):
        parsed = parse_status_line(line)
        if parsed is None:
            return
        kw, kv = parsed

        if kw == "FRAG":
            self._handle_frag(kv, line)
        elif kw == "IDLE":
            pass
        elif kw == "DONE":
            self._handle_done(kv, line)
        elif kw == "INCOMPLETE":
            self._handle_incomplete(kv, line)
        elif kw == "BERT":
            self._handle_bert(kv, line)
        elif kw == "HEALTH":
            self._count_health_event(line)
            self._log_html(f"<span style='color:#d29922; font-weight:bold'>"
                           f"{_html_escape(line)}</span>")
        elif kw in ("WARN", "FOREIGN"):
            self._log_html(f"<span style='color:#d29922'>"
                           f"{_html_escape(line)}</span>")
        elif kw in ("TXQUEUE", "TXCTRL", "CTRL", "TXERR"):
            self._log_html(f"<span style='color:#58a6ff'>"
                           f"{_html_escape(line)}</span>")
        else:
            if "CRC FAIL" in line:
                self._crc_fail_count += 1
                self._refresh_debug_window()
            self._log_html(f"<span style='color:#8b949e'>"
                           f"{_html_escape(line)}</span>")

    def _safe_int(self, kv, key):
        try:
            return int(kv[key])
        except (KeyError, ValueError, TypeError):
            return None

    def _handle_frag(self, kv, raw):
        self._crc_ok_count += 1
        if self.show_frags.isChecked():
            self._log_html(f"<span style='color:#3fb950'>"
                           f"{_html_escape(raw)}</span>")

        msg_id = self._safe_int(kv, 'msg')
        if msg_id is None:
            return
        prog = self.transfers.get(msg_id)
        if prog is None:
            return
        idx = self._safe_int(kv, 'idx')
        if idx is not None:
            prog.note_fragment(kv.get('type', 'DATA'), idx)
        n_data = self._safe_int(kv, 'data')
        n_par = self._safe_int(kv, 'parity')
        if n_data:
            prog.n_data = n_data
        if n_par is not None:
            prog.n_parity = n_par

        entry = self.pending_sends.get(msg_id)
        if entry:
            try:
                entry["progress_item"].setText(f"{prog.fraction * 100:.0f}%")
                entry["status_item"].setText(prog.summary())
            except RuntimeError:
                self.pending_sends.pop(msg_id, None)
        if entry and entry["kind"] == "file":
            self.file_progress.setValue(int(prog.fraction * 1000))
            self.file_progress.setFormat(
                f"{prog.filename}  —  {prog.summary()}")

    def _handle_done(self, kv, raw):
        self._log_html(f"<span style='color:#3fb950; font-weight:bold'>"
                       f"{_html_escape(raw)}</span>")
        rec = self._safe_int(kv, 'recovered') or 0
        if rec:
            self._recovered_total += rec
            self._log_html(
                f"<span style='color:#58a6ff'>erasure coding reconstructed "
                f"{rec} lost fragment{'s' if rec != 1 else ''} — the "
                f"message completed anyway</span>")
        msg_id = self._safe_int(kv, 'msg')
        prog = self.transfers.get(msg_id)
        entry = self.pending_sends.pop(msg_id, None)
        if prog:
            prog.done = True
        if entry:
            try:
                entry["progress_item"].setText("100%")
                entry["status_item"].setText(
                    prog.summary() if prog else "delivered")
                entry["status_item"].setForeground(QColor("#3fb950"))
            except RuntimeError:
                pass
            if entry["kind"] == "file":
                self.file_progress.setValue(1000)
                self.file_progress.setFormat(
                    f"{prog.filename if prog else ''} — delivered")
        self._refresh_debug_window()

    def _handle_incomplete(self, kv, raw):
        self._log_html(f"<span style='color:#f85149; font-weight:bold'>"
                       f"{_html_escape(raw)}</span>")
        lost = self._safe_int(kv, 'blocks_lost')
        if lost:
            self._log_html(
                f"<span style='color:#d29922'>{lost} erasure-coding block"
                f"{'s' if lost != 1 else ''} lost more fragments than the "
                f"parity could cover — raise the parity overhead or "
                f"improve the link, then resend</span>")
        msg_id = self._safe_int(kv, 'msg')
        prog = self.transfers.get(msg_id)
        if prog:
            prog.failed = True
            prog.note = f"{lost or '?'} block(s) unrecoverable"
        entry = self.pending_sends.pop(msg_id, None)
        if entry:
            try:
                entry["status_item"].setText(
                    f"incomplete (missing {kv.get('missing', '?')})")
                entry["status_item"].setForeground(QColor("#f85149"))
            except RuntimeError:
                pass

    def _handle_bert(self, kv, raw):
        w = self.diag_window
        try:
            errors = int(kv.get('errors', 0))
            bits = int(kv.get('bits', 0))
        except ValueError:
            return
        synced = kv.get('synced') == '1'
        if bits and w is not None:
            ber = errors / bits
            lo, hi = metrics.ber_confidence_interval(errors, bits)
            w.set_value('bert', f"{ber:.2e}   [{lo:.1e}, {hi:.1e}]"
                                if synced else "SYNC LOST")
            w.set_value('bert_bits', f"{bits:,} bits, {errors:,} errors")
        if not synced:
            self._log_html("<span style='color:#d29922'>BER test lost sync "
                           "— the link dropped; counting restarts"
                           "</span>")

    def _count_health_event(self, line):
        parts = line.split()
        side = parts[1] if len(parts) > 1 else ""
        event = parts[2] if len(parts) > 2 else ""
        if side == "RX":
            self._overflow_count += 1
        elif event in ("UNDERFLOW", "UNDERFLOW_IN_PACKET"):
            self._underflow_count += 1
        else:
            self._other_health_count += 1
        self._refresh_debug_window()

    # ------------------------------------------------------------------
    # Link indicator, log, dialogs, shutdown
    # ------------------------------------------------------------------
    def _update_heartbeat_display(self):
        self._refresh_debug_window()
        if self._last_status_rx_monotonic is None:
            self._set_link_dot(False)
            self.link_heartbeat_label.setText("NO LINK")
            return
        elapsed = time.monotonic() - self._last_status_rx_monotonic
        if elapsed <= HEARTBEAT_STALE_SEC:
            self._set_link_dot(True)
            self.link_heartbeat_label.setText(f"last heartbeat {elapsed:.0f}s ago")
        else:
            self._set_link_dot(False)
            self.link_heartbeat_label.setText(f"NO LINK ({elapsed:.0f}s)")

    def _set_link_dot(self, alive):
        c = "#3fb950" if alive else "#6e7681"
        self.link_dot.setStyleSheet(
            f"background-color:{c}; border-radius:7px; border:1px solid #010409;")

    def _on_bind_failed(self, message):
        cur = self.bind_error_banner.text()
        self.bind_error_banner.setText((cur + "\n" if cur else "")
                                       + "⚠ " + message)
        self.bind_error_banner.show()
        self._log_html(f"<span style='color:#f85149; font-weight:bold'>"
                       f"{_html_escape(message)}</span>")

    def _log_html(self, html):
        self.log_edit.append(
            f"<span style='color:#8b949e'>[{now_hms()}]</span> {html}")
        self._trim_log()

    def _log_plain(self, text, color="#c9d1d9"):
        self._log_html(f"<span style='color:{color}'>"
                       f"{_html_escape(text)}</span>")

    def _trim_log(self):
        doc = self.log_edit.document()
        while doc.blockCount() > LOG_MAX_LINES:
            cur = QTextCursor(doc.findBlockByNumber(0))
            cur.select(QTextCursor.BlockUnderCursor)
            cur.removeSelectedText()
            cur.deleteChar()

    def _clear_log(self):
        self.log_edit.clear()

    def _on_sent_double(self, item):
        it = self.sent_table.item(item.row(), 3)
        FullTextDialog("Sent", (it.data(Qt.UserRole) if it else "") or "",
                       self).exec_()

    def _on_recv_double(self, item):
        it = self.recv_table.item(item.row(), 3)
        FullTextDialog("Received", (it.data(Qt.UserRole) if it else "") or "",
                       self).exec_()

    def closeEvent(self, event):
        try:
            self.data_listener.stop()
            self.status_listener.stop()
            self.diag_listener.stop()
            self.tx_sock.close()
            self.ctrl_sock.close()
            for w in (self.diag_window, self.demo_window):
                if w is not None:
                    w.close()
        except Exception:
            pass
        super().closeEvent(event)


_QSS = """
QWidget {
    background-color: #0d1117;
    color: #c9d1d9;
    font-family: "DejaVu Sans", "Segoe UI", sans-serif;
    font-size: 12px;
}
#headerBar {
    background-color: #161b22;
    border: 1px solid #30363d;
    border-radius: 4px;
}
#titleLabel {
    color: #58a6ff;
    font-size: 15px;
    font-weight: bold;
    letter-spacing: 1px;
}
#cfgLabel {
    color: #8b949e;
}
#heartbeatLabel {
    color: #c9d1d9;
    font-weight: bold;
    padding-left: 4px;
}
#nodeBox {
    background-color: #0d1117;
    border: 1px solid #30363d;
    border-radius: 4px;
}
#nodeBox QLabel {
    color: #8b949e;
    font-weight: bold;
    font-size: 10px;
}
#nodeBox QSpinBox {
    background-color: #161b22;
    color: #58a6ff;
    border: 1px solid #30363d;
    border-radius: 3px;
    padding: 1px 4px;
    font-weight: bold;
    min-width: 32px;
}
#diagValue {
    color: #3fb950;
    font-weight: bold;
}
#debugButton {
    background-color: #21262d;
    color: #c9d1d9;
    border: 1px solid #30363d;
    border-radius: 3px;
    padding: 3px 12px;
}
#debugButton:hover {
    background-color: #30363d;
}
#bindErrorBanner {
    background-color: #3d1c1c;
    color: #ffb3ab;
    border: 1px solid #f85149;
    border-radius: 4px;
    padding: 6px 10px;
    font-weight: bold;
}
#panelTitle {
    color: #58a6ff;
    font-weight: bold;
    letter-spacing: 1px;
    padding: 2px 0px;
}
QTableWidget {
    background-color: #0d1117;
    alternate-background-color: #12181f;
    gridline-color: #21262d;
    border: 1px solid #30363d;
    selection-background-color: #1f6feb;
    selection-color: #ffffff;
}
QHeaderView::section {
    background-color: #161b22;
    color: #8b949e;
    border: 1px solid #30363d;
    padding: 4px;
    font-weight: bold;
}
QTextEdit, QPlainTextEdit {
    background-color: #010409;
    color: #c9d1d9;
    border: 1px solid #30363d;
    border-radius: 4px;
    selection-background-color: #1f6feb;
}
#composePanel {
    background-color: #161b22;
    border: 1px solid #30363d;
    border-radius: 4px;
}
#byteCounterLabel {
    color: #8b949e;
    font-family: "DejaVu Sans Mono", monospace;
}
#byteCounterLabel[overLimit="true"] {
    color: #f85149;
    font-weight: bold;
}
#estimateLabel {
    color: #8b949e;
    font-family: "DejaVu Sans Mono", monospace;
}
#sendButton {
    background-color: #238636;
    color: #ffffff;
    border: 1px solid #2ea043;
    border-radius: 4px;
    padding: 6px 18px;
    font-weight: bold;
}
#sendButton:hover {
    background-color: #2ea043;
}
#sendButton:disabled {
    background-color: #30363d;
    color: #6e7681;
    border: 1px solid #30363d;
}
#clearLogBtn {
    background-color: #21262d;
    color: #c9d1d9;
    border: 1px solid #30363d;
    border-radius: 3px;
    padding: 2px 10px;
}
#clearLogBtn:hover {
    background-color: #30363d;
}
QSplitter::handle {
    background-color: #30363d;
}
QStatusBar {
    background-color: #161b22;
    color: #8b949e;
    border-top: 1px solid #30363d;
}
QScrollBar:vertical {
    background: #0d1117;
    width: 12px;
}
QScrollBar::handle:vertical {
    background: #30363d;
    border-radius: 4px;
    min-height: 20px;
}
QScrollBar:horizontal {
    background: #0d1117;
    height: 12px;
}
QScrollBar::handle:horizontal {
    background: #30363d;
    border-radius: 4px;
    min-width: 20px;
}

#sendTabs::pane {
    border: 1px solid #30363d;
    border-radius: 4px;
}
#sendTabs QTabBar::tab {
    background: #21262d;
    color: #8b949e;
    padding: 5px 16px;
    border: 1px solid #30363d;
    border-bottom: none;
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
}
#sendTabs QTabBar::tab:selected {
    background: #0d1117;
    color: #58a6ff;
    font-weight: bold;
}
#demoButton {
    background-color: #21262d;
    color: #c9d1d9;
    border: 1px solid #30363d;
    border-radius: 3px;
    padding: 8px 12px;
    text-align: left;
}
#demoButton:hover { background-color: #30363d; }
#demoButton:disabled { color: #6e7681; }
QProgressBar {
    background-color: #0d1117;
    border: 1px solid #30363d;
    border-radius: 4px;
    text-align: center;
    color: #c9d1d9;
    height: 18px;
}
QProgressBar::chunk {
    background-color: #238636;
    border-radius: 3px;
}
QDoubleSpinBox, QComboBox {
    background-color: #161b22;
    color: #58a6ff;
    border: 1px solid #30363d;
    border-radius: 3px;
    padding: 2px 6px;
    font-weight: bold;
}
QCheckBox { color: #8b949e; }
"""

def _install_crash_guard():
    """PyQt5 aborts the process if an exception escapes a slot, unless
    sys.excepthook is overridden -- so override it. Defence in depth on top of
    the try/except blocks in the status handling: an unanticipated bug logs a
    traceback instead of taking the console down mid-demonstration."""
    def _hook(exc_type, exc_value, exc_tb):
        traceback.print_exception(exc_type, exc_value, exc_tb)
    sys.excepthook = _hook


def parse_args(argv=None):
    ap = argparse.ArgumentParser(
        description="Ground station for the DSSS/QPSK link (UDP only; no "
                    "gnuradio import).")
    ap.add_argument('--host', default='127.0.0.1',
                    help='host the flowgraph is running on')
    ap.add_argument('--tx-port', type=int, default=52001)
    ap.add_argument('--rx-data-port', type=int, default=52002)
    ap.add_argument('--rx-status-port', type=int, default=52003)
    ap.add_argument('--ctrl-port', type=int, default=52004)
    ap.add_argument('--diag-port', type=int, default=52005)
    ap.add_argument('--bind-host', default='127.0.0.1')
    ap.add_argument('--download-dir', default=DEFAULT_DOWNLOAD_DIR,
                    help='where received files are written')
    ap.add_argument('--profile', default=os.environ.get('LINK_PROFILE',
                                                        'stealth'),
                    help='which link profile the flowgraph is running, so '
                         'airtime estimates are right (default: stealth)')
    return ap.parse_args(argv)


def main():
    _install_crash_guard()
    args = parse_args()
    app = QApplication(sys.argv)
    app.setApplicationName("Ground Station")
    win = GroundStationWindow(
        host=args.host, tx_port=args.tx_port,
        rx_data_port=args.rx_data_port, rx_status_port=args.rx_status_port,
        bind_host=args.bind_host, ctrl_port=args.ctrl_port,
        diag_port=args.diag_port, download_dir=args.download_dir,
        profile_name=args.profile)
    win.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
