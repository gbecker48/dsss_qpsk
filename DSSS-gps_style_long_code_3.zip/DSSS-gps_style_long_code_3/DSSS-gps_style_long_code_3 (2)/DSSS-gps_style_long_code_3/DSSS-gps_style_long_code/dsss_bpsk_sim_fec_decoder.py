"""
FEC Decoder - Majority Vote (streaming, tag-aware)
------------------------------------------------------
Inverse of fec_repeat.py: groups every `repeat` incoming bits and takes a
majority vote, correcting any single-bit (and some multi-bit) errors per
group. A real continuous streaming block with correct `packet_len` tag
rescaling (offset and value both divided by `repeat`), matching
fec_repeat.py on the transmit side.

Input : stream of bytes (0/1), `repeat` per decoded bit
Output: stream of bytes (0/1), decoded
"""

import numpy as np
import pmt
from gnuradio import gr


class blk(gr.decim_block):
    """FEC Decoder - Majority Vote"""

    def __init__(self, repeat=1):
        gr.decim_block.__init__(self, name='FEC Decoder (Majority Vote)',
                                 in_sig=[np.uint8], out_sig=[np.uint8],
                                 decim=int(repeat))
        self.repeat = int(repeat)
        self.set_tag_propagation_policy(gr.TPP_DONT)

    def work(self, input_items, output_items):
        in0 = input_items[0]
        out = output_items[0]
        n_groups = len(in0) // self.repeat
        n_groups = min(n_groups, len(out))
        if n_groups == 0:
            return 0
        groups = in0[:n_groups * self.repeat].reshape(n_groups, self.repeat)
        out[:n_groups] = (groups.sum(axis=1) * 2 >= self.repeat).astype(np.uint8)

        for t in self.get_tags_in_window(0, 0, n_groups * self.repeat):
            rel = t.offset - self.nitems_read(0)
            new_offset = self.nitems_written(0) + rel // self.repeat
            key = pmt.symbol_to_string(t.key)
            val = t.value
            if key == 'packet_len' and pmt.is_integer(val):
                val = pmt.from_long(pmt.to_long(val) // self.repeat)
            self.add_item_tag(0, new_offset, t.key, val)

        return n_groups
