"""
TX Scheduler (node-addressed, strobe-paced)
----------------------------------------------
This restores the original strobe-driven pacing after a "never-starving
continuous source" replacement (`tx_frame_source.py`, now removed) turned
out to cause MORE underflow/overflow on real hardware, not less. The
regression's real cause was almost certainly the aggressively small
per-block buffer caps that redesign added to keep message latency down -
that cut directly into the buffering margin real hardware needs to absorb
normal OS/USB scheduling jitter, something a pure software/sim run never
stresses. This version keeps everything the networking work added (SRC/DST
addressing, per-node ids) but goes back to letting GNU Radio use its own
generous default buffer sizing throughout the TX chain, paced by a
`blocks.message_strobe` tick instead. See dsss_bpsk_usrp.grc's
`tx_pace_margin_pct` variable (a live GUI slider) for the tunable "packet
sending downtime" knob this replaces - it no longer requires reopening GRC
to retune for a specific PC.

Two message inputs:
  'queue_in' - a raw user message PDU (any length, up to MAX_MESSAGE_BYTES)
               arriving from the UDP terminal. It gets split into
               fixed-size fragments (CHUNK_BYTES of real data each) and
               all of them are pushed onto an internal FIFO queue - not
               sent immediately. A message longer than one fragment holds
               no special priority over ones already queued; fragments
               are sent strictly in the order they were queued.
  'strobe'   - a timing tick (from a message_strobe running at
               `strobe_period_ms`) that means "produce the next thing to
               transmit right now". If the queue has a pending fragment,
               that's popped and sent; if the queue is empty, an IDLE
               filler fragment (frag_total=0) is sent instead. This is
               what keeps the physical layer always-on: there is never a
               moment with nothing being spread and transmitted, exactly
               like GPS satellites.

Each fragment payload (always exactly PAYLOAD_BYTES, zero-padded) is:
    [SRC 1B][DST 1B][MSG_ID 1B][FRAG_IDX 1B][FRAG_TOTAL 1B][CHUNK_LEN 1B][DATA]
FRAG_TOTAL == 0 is the reserved idle/no-data marker (still stamped with the
current SRC/DST so idle heartbeats show who's currently paired with whom).

Output: PDU (payload bytes, always length PAYLOAD_BYTES) on port 'out',
        handed to the Packet Framer next.
"""

import numpy as np
import pmt
from gnuradio import gr
from collections import deque


def pdu_data(msg):
    vec = pmt.cdr(msg) if pmt.is_pair(msg) else msg
    return np.array(pmt.u8vector_elements(vec), dtype=np.uint8)


def make_pdu(values):
    arr = np.asarray(values, dtype=np.uint8)
    return pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(arr), arr.tolist()))


class blk(gr.basic_block):
    """TX Scheduler: fragmentation + node addressing + strobe pacing"""

    def __init__(self, payload_bytes=256, header_bytes=6, my_node_id=0,
                 dest_node_id=1):
        gr.basic_block.__init__(self, name='TX Scheduler', in_sig=[], out_sig=[])
        self.payload_bytes = int(payload_bytes)
        self.header_bytes = int(header_bytes)
        self.chunk_bytes = self.payload_bytes - self.header_bytes
        self.max_message_bytes = self.chunk_bytes * 256  # FRAG_IDX is 1 byte
        self.my_node_id = int(my_node_id)
        self.dest_node_id = int(dest_node_id)

        self.queue = deque()
        self.msg_id = 0

        self.message_port_register_in(pmt.intern('queue_in'))
        self.message_port_register_in(pmt.intern('strobe'))
        self.message_port_register_out(pmt.intern('out'))
        self.set_msg_handler(pmt.intern('queue_in'), self.handle_queue_in)
        self.set_msg_handler(pmt.intern('strobe'), self.handle_strobe)

    def handle_queue_in(self, msg):
        data = pdu_data(msg).tobytes()
        if len(data) > self.max_message_bytes:
            print("[TX Scheduler] message too long (%d bytes, max %d) - truncating" %
                  (len(data), self.max_message_bytes))
            data = data[:self.max_message_bytes]
        if len(data) == 0:
            return

        n_frags = (len(data) + self.chunk_bytes - 1) // self.chunk_bytes
        mid = self.msg_id
        self.msg_id = (self.msg_id + 1) & 0xFF
        print("[TX Scheduler] queued msg id=%d, %d bytes -> %d fragment(s) "
              "(node %d -> node %d)" %
              (mid, len(data), n_frags, self.my_node_id, self.dest_node_id))
        for idx in range(n_frags):
            chunk = data[idx * self.chunk_bytes:(idx + 1) * self.chunk_bytes]
            header = bytes([self.my_node_id & 0xFF, self.dest_node_id & 0xFF,
                             mid, idx, n_frags, len(chunk)])
            payload = header + chunk + bytes(self.chunk_bytes - len(chunk))
            assert len(payload) == self.payload_bytes
            self.queue.append(payload)

    def handle_strobe(self, msg):
        if self.queue:
            payload = self.queue.popleft()
        else:
            header = bytes([self.my_node_id & 0xFF, self.dest_node_id & 0xFF,
                             0, 0, 0, 0])
            payload = header + bytes(self.chunk_bytes)  # frag_total=0 -> idle
        self.message_port_pub(pmt.intern('out'), make_pdu(list(payload)))
