"""
DSSS Spreader (GPS-style, symbol-domain, per-node code)
------------------------------------------------------------
Spreads the actual QPSK WAVEFORM, not just the underlying bits: every
incoming complex QPSK symbol is held for one full period of a long
pseudo-noise "chip" code and multiplied, chip by chip, by that code
(+1/-1) - exactly how GPS spreads its 50 bps navigation data with a
1023-chip Gold code repeated once per data bit (well, once per 20
repetitions in real GPS; here once per symbol - see the flowgraph README
for the exact timing this maps to). This is a real interpolating stream
block (not a one-shot message-domain array build like earlier revisions of
this project used) so there is no upper limit on how long a transmission
can run.

MULTIPLE ACCESS (CDMA): `prn_taps` selects WHICH Gold code this node
spreads with, exactly the way each GPS satellite gets its own PRN. Every
node on the link should use a distinct `prn_taps` pair (see the flowgraph's
`node_prn_table` variable, which maps a small integer node id to a taps
pair) so that two nodes transmitting at the same time, on the same
frequency, don't collide: Gold codes are only ~-24 dB cross-correlated
(63/1023) rather than perfectly orthogonal, but combined with despreading
gain on the receive side that is enough separation for one node's spread
signal to look like harmless noise to a receiver locked onto a different
node's code. `prn_taps` is a normal (settable-at-runtime) GRC parameter -
change the flowgraph's `my_node_id` variable (e.g. from the ground station
GUI's node switcher) and this block's code is regenerated on the fly, no
restart required.

Input : stream of complex64 QPSK symbols, 1 per item
Output: stream of complex64 chips, `code_len` per input symbol
"""

import numpy as np
import pmt
from gnuradio import gr


def g1_sequence(n_chips):
    reg = [1] * 10
    out = np.empty(n_chips, dtype=np.uint8)
    for i in range(n_chips):
        out[i] = reg[9]
        fb = reg[2] ^ reg[9]
        reg = [fb] + reg[:-1]
    return out


def g2_sequence(taps, n_chips):
    reg = [1] * 10
    t0, t1 = taps[0] - 1, taps[1] - 1
    out = np.empty(n_chips, dtype=np.uint8)
    for i in range(n_chips):
        out[i] = reg[t0] ^ reg[t1]
        fb = reg[1] ^ reg[2] ^ reg[5] ^ reg[7] ^ reg[8] ^ reg[9]
        reg = [fb] + reg[:-1]
    return out


def gps_style_gold_code(code_len=1023, prn_taps=(2, 6)):
    """MUST match dsss_despreader.py's code generation exactly."""
    bits = g1_sequence(code_len) ^ g2_sequence(prn_taps, code_len)
    return 1.0 - 2.0 * bits.astype(np.float32)  # bipolar +-1


class blk(gr.interp_block):
    """DSSS Spreader (GPS-style Gold code, per-node PRN)"""

    def __init__(self, code_len=1023, prn_taps=(2, 6)):
        gr.interp_block.__init__(
            self, name='DSSS Spreader',
            in_sig=[np.complex64], out_sig=[np.complex64],
            interp=int(code_len))
        self.code_len = int(code_len)
        self._prn_taps = (2, 6)
        self.code = gps_style_gold_code(self.code_len, self._prn_taps)
        # now route through the property setter so it's the single place
        # the code array is (re)built, including for this initial value
        self.prn_taps = prn_taps
        self.set_tag_propagation_policy(gr.TPP_DONT)

    # `prn_taps` is exposed as a GRC parameter so it can be tied to the
    # `my_node_id` variable. GRC's generated variable-setter code pokes
    # this attribute directly (`self.dsss_spreader.prn_taps = ...`) rather
    # than calling a method - a Python property is what turns that plain
    # assignment into "regenerate the code array", with no GRC-side
    # special-casing needed.
    @property
    def prn_taps(self):
        return self._prn_taps

    @prn_taps.setter
    def prn_taps(self, value):
        taps = (int(value[0]), int(value[1]))
        if taps == self._prn_taps:
            return
        self._prn_taps = taps
        self.code = gps_style_gold_code(self.code_len, taps)

    def work(self, input_items, output_items):
        in0 = input_items[0]
        out = output_items[0]
        n = len(in0)
        # out[k*code_len : (k+1)*code_len] = in0[k] * code[:]
        out[:n * self.code_len] = (
            np.repeat(in0, self.code_len) * np.tile(self.code, n)
        )

        # manually propagate + rescale any tags (e.g. packet_len) since we
        # disabled automatic propagation above (TPP_DONT) to avoid GRC's
        # default policy mis-scaling tag VALUES, only offsets
        for t in self.get_tags_in_window(0, 0, n):
            rel = t.offset - self.nitems_read(0)
            new_offset = self.nitems_written(0) + rel * self.code_len
            key = pmt.symbol_to_string(t.key)
            val = t.value
            if key == 'packet_len' and pmt.is_integer(val):
                val = pmt.from_long(pmt.to_long(val) * self.code_len)
            self.add_item_tag(0, new_offset, t.key, val)

        return n * self.code_len
