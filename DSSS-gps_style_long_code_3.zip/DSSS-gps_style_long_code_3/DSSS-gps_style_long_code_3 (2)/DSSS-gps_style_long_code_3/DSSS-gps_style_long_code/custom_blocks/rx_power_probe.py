"""
RX Power Probe
----------------
Taps the raw received samples (right off the USRP source / channel model,
before anything else touches them) via a second, purely additive
connection - same non-inline, cannot-disrupt-the-decode-chain design as
EVM Probe (see its docstring): no stream output, so it cannot alter the
existing signal path's timing or buffering.

Reports average received power in dBFS (0 dB = a complex sample magnitude
of 1.0, i.e. USRP full scale) every `period_samples` samples - a directly
useful "is my signal even audible" number, watchable next to the
despreader's own actual-vs-ideal processing gain reading (see
dsss_despreader.py) to see the whole story: how strong the raw RF is
before anything is done to it, and how much of the buried signal
despreading claws back out afterwards.
"""

import numpy as np
import pmt
from gnuradio import gr


class blk(gr.sync_block):
    """RX Power Probe"""

    def __init__(self, period_samples=200000):
        gr.sync_block.__init__(self, name='RX Power Probe',
                               in_sig=[np.complex64], out_sig=[])
        self.period_samples = max(1, int(period_samples))
        self._count = 0
        self._sum_sq = 0.0
        self.message_port_register_out(pmt.intern('power'))

    def work(self, input_items, output_items):
        in0 = input_items[0]
        n = len(in0)
        if n == 0:
            return 0
        self._sum_sq += float(np.sum(np.abs(in0.astype(np.complex128)) ** 2))
        self._count += n
        if self._count >= self.period_samples:
            mean_sq = self._sum_sq / self._count
            dbfs = 10.0 * np.log10(mean_sq) if mean_sq > 0 else float('-inf')
            text = "RXPOWER dbfs=%.1f" % dbfs
            try:
                self.message_port_pub(
                    pmt.intern('power'),
                    pmt.cons(pmt.PMT_NIL,
                             pmt.init_u8vector(len(text), list(text.encode('utf-8')))))
            except Exception:
                pass
            self._count = 0
            self._sum_sq = 0.0
        return n
