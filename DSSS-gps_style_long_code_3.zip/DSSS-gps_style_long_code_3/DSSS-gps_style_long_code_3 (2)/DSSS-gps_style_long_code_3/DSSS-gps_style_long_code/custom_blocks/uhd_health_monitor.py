"""
UHD Health Monitor - underflow/overflow visibility
------------------------------------------------------
Subscribes to a uhd_usrp_sink's and/or uhd_usrp_source's 'async_msgs'
message port (a real, standard gr-uhd output - see
/usr/share/gnuradio/grc/blocks/uhd_usrp_{sink,source}.block.yml) and turns
UHD's low-level TX underflow / RX overflow / sequence-error / time-error
events into readable status lines, counted and rate-limited so a real
problem is loud without flooding the log.

This is deliberately DEFENSE IN DEPTH, not the primary underflow fix - the
primary fix is that TX Frame Source physically cannot starve the sink (see
that file's docstring for the root-cause bug this project used to have).
This block exists so that if an underflow/overflow ever does happen again
(a USB hiccup, another process stealing the CPU, an over-ambitious sample
rate for this particular PC, ...) it shows up immediately in the ground
station's Link Log instead of being a silent, confusing "no data getting
through" mystery - the exact failure mode originally reported.

UHD's async metadata is delivered as a PMT dictionary with (at minimum) an
'event_code' entry; the exact key set has varied a little across
GNU Radio/UHD versions, so decoding here is deliberately defensive: known
keys are decoded into a human label, and anything unrecognized still
increments a generic counter and prints its raw PMT form rather than being
silently dropped - "never silently lose an event" matters more here than
a perfectly-typed decode.

Known UHD event codes (uhd::async_metadata_t::event_code_t):
    0x1  BURST_ACK            (informational, not logged as a problem)
    0x2  UNDERFLOW            <-- the one this project cares about most
    0x4  SEQ_ERROR
    0x8  TIME_ERROR
    0x10 UNDERFLOW_IN_PACKET
    0x20 SEQ_ERROR_IN_BURST
    0x40 USER_PAYLOAD

Ports
  message in  'async_in' : connect from usrp_sink/usrp_source's 'async_msgs'
  message out 'status'   : human-readable text PDUs, same shape the rest
                            of the RX status chain already emits, so this
                            can fan into the same UDP status port the
                            ground station already listens on.
"""

import pmt
from gnuradio import gr

EVENT_NAMES = {
    0x1: ("BURST_ACK", False),
    0x2: ("UNDERFLOW", True),
    0x4: ("SEQ_ERROR", True),
    0x8: ("TIME_ERROR", True),
    0x10: ("UNDERFLOW_IN_PACKET", True),
    0x20: ("SEQ_ERROR_IN_BURST", True),
    0x40: ("USER_PAYLOAD", False),
}


def _extract_event_code(msg):
    """Best-effort decode of a UHD async-message PMT. Returns
    (event_code_int_or_None, raw_repr_str)."""
    raw_repr = None
    try:
        raw_repr = pmt.write_string(msg)
    except Exception:
        raw_repr = repr(msg)

    try:
        # The metadata dict can arrive bare, or wrapped as a (car . cdr)
        # pair with the dict on either side - check all the plausible
        # spots rather than assuming one exact shape.
        candidates = [msg]
        if pmt.is_pair(msg):
            candidates = [pmt.car(msg), pmt.cdr(msg), msg]

        for cand in candidates:
            if pmt.is_dict(cand):
                for key in ('event_code', 'code', 'async_event_code'):
                    v = pmt.dict_ref(cand, pmt.intern(key), pmt.PMT_NIL)
                    if not pmt.eq(v, pmt.PMT_NIL) and (pmt.is_integer(v) or pmt.is_uinteger(v)):
                        return int(pmt.to_long(v)), raw_repr

        for cand in candidates:
            if pmt.is_integer(cand) or pmt.is_uinteger(cand):
                return int(pmt.to_long(cand)), raw_repr
    except Exception:
        pass
    return None, raw_repr


class blk(gr.basic_block):
    """UHD Health Monitor"""

    def __init__(self, label='TX', log_every=1):
        gr.basic_block.__init__(self, name='UHD Health Monitor', in_sig=[], out_sig=[])
        self.label = str(label)
        self.log_every = max(1, int(log_every))
        self.counts = {}       # event name -> count
        self.total_events = 0
        self.unrecognized = 0

        self.message_port_register_in(pmt.intern('async_in'))
        self.message_port_register_out(pmt.intern('status'))
        self.set_msg_handler(pmt.intern('async_in'), self._on_async_msg)

    def _on_async_msg(self, msg):
        code, raw_repr = _extract_event_code(msg)
        self.total_events += 1

        if code is None:
            self.unrecognized += 1
            self._emit("%s async event (undecoded, #%d): %s" %
                       (self.label, self.unrecognized, raw_repr))
            return

        name, is_problem = EVENT_NAMES.get(code, ("UNKNOWN_0x%x" % code, True))
        self.counts[name] = self.counts.get(name, 0) + 1
        n = self.counts[name]

        if not is_problem:
            return  # BURST_ACK / USER_PAYLOAD are routine, don't spam the log

        if n % self.log_every == 0:
            self._emit("HEALTH %s %s #%d (total async events=%d)" %
                       (self.label, name, n, self.total_events))

    def _emit(self, text):
        print("[UHD Health] " + text)
        self.message_port_pub(
            pmt.intern('status'),
            pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(text.encode('utf-8')),
                                                      list(text.encode('utf-8')))))
