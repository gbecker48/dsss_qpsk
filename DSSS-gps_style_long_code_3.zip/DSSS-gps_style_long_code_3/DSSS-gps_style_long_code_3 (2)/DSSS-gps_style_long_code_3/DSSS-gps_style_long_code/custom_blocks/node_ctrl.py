"""
Node Control -- runtime commands from the ground station
========================================================

Parses small plain-text UDP commands and turns them into either GRC variable
sets (via the standard message-pair -> Message Pair to Var idiom) or control
messages forwarded to the blocks that own the setting. Nothing here reaches
into another block's internals directly.

Commands (one per datagram, case-insensitive, whitespace-tolerant)
------------------------------------------------------------------
    NODE=<n>       which PRN this radio TRANSMITS on
    DEST=<n>       which peer's PRN this radio DESPREADS against
    TXGAIN=<x>     normalised TX gain, 0.0 to 1.0

                   0 is how `demo.py 6` takes its transmitter-off reference
                   capture for the below-the-noise-floor measurement, and how
                   `demo.py 8` sets jammer-to-signal ratios. It is a real
                   operational control, not a test hook.

    BERT=<0|1>     fill idle slots with PRBS-15 so the receiver can count true
                   channel bit errors continuously (requirement 7)
    PARITY=<pct>   erasure-coding overhead for subsequent file transfers

Validation happens here rather than downstream. An out-of-range node id would
otherwise reach `node_prn_table[n]` and take the whole flowgraph down with a
KeyError the instant it is evaluated -- so a bad id is rejected, logged, and
the previous value left alone.

Ports
  in  'in'         raw command PDU from a network_socket_pdu UDP_SERVER
  out 'node_msg'   (symbol . long) -> blocks_msgpair_to_var for my_node_id
  out 'dest_msg'   (symbol . long) -> blocks_msgpair_to_var for dest_node_id
  out 'gain_msg'   (symbol . double) -> blocks_msgpair_to_var for tx_gain
  out 'tx_ctrl'    text -> TX Scheduler's 'ctrl' port (BERT/PARITY)
  out 'status'     text echo of what was applied, for the GUI log
"""

import numpy as np
import pmt
from gnuradio import gr


def pdu_data(msg):
    vec = pmt.cdr(msg) if pmt.is_pair(msg) else msg
    return bytes(bytearray(pmt.u8vector_elements(vec)))


def make_pdu(values):
    arr = np.asarray(values, dtype=np.uint8)
    return pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(arr), arr.tolist()))


class blk(gr.basic_block):
    """Node Control"""

    def __init__(self, table_size=16):
        gr.basic_block.__init__(self, name='Node Control',
                                in_sig=[], out_sig=[])
        self.table_size = int(table_size)
        self.message_port_register_in(pmt.intern('in'))
        for p in ('node_msg', 'dest_msg', 'gain_msg', 'tx_ctrl', 'status'):
            self.message_port_register_out(pmt.intern(p))
        self.set_msg_handler(pmt.intern('in'), self.handle_msg)

    def handle_msg(self, msg):
        try:
            text = pdu_data(msg).decode('utf-8', 'replace').strip()
        except Exception:
            return
        if not text or '=' not in text:
            return
        key, _, val = text.partition('=')
        key = key.strip().upper()
        val = val.strip()

        if key in ('NODE', 'DEST'):
            try:
                n = int(val)
            except ValueError:
                self._status('CTRL bad value in %r - ignored' % text)
                return
            if not (0 <= n < self.table_size):
                self._status('CTRL node id %d out of range [0,%d) - ignored'
                             % (n, self.table_size))
                return
            if key == 'NODE':
                self.message_port_pub(pmt.intern('node_msg'),
                                      pmt.cons(pmt.intern('my_node_id'),
                                               pmt.from_long(n)))
                self._status('CTRL my_node_id=%d' % n)
            else:
                self.message_port_pub(pmt.intern('dest_msg'),
                                      pmt.cons(pmt.intern('dest_node_id'),
                                               pmt.from_long(n)))
                self._status('CTRL dest_node_id=%d' % n)

        elif key == 'TXGAIN':
            try:
                g = float(val)
            except ValueError:
                self._status('CTRL bad gain in %r - ignored' % text)
                return
            g = max(0.0, min(1.0, g))
            self.message_port_pub(pmt.intern('gain_msg'),
                                  pmt.cons(pmt.intern('tx_gain'),
                                           pmt.from_double(g)))
            self._status('CTRL tx_gain=%.3f' % g)

        elif key in ('BERT', 'PARITY'):
            fwd = ('%s=%s' % (key, val)).encode('utf-8')
            self.message_port_pub(pmt.intern('tx_ctrl'), make_pdu(list(fwd)))
            self._status('CTRL %s=%s' % (key, val))

        else:
            self._status('CTRL unknown command %r - ignored' % text)

    def _status(self, text):
        print('[Node Control] ' + text)
        data = text.encode('utf-8')
        self.message_port_pub(pmt.intern('status'), make_pdu(list(data)))
