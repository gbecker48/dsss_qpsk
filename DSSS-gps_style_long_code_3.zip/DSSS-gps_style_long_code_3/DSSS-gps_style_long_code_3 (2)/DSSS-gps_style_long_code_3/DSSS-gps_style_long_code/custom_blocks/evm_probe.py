"""
EVM Probe
-----------
Taps the carrier-recovered, pre-slicer QPSK symbol stream via a second,
purely additive connection - it does not sit inline in the signal path and
produces no stream output of its own, so it cannot alter the existing
Costas-loop -> slicer connection's timing or buffering in any way. Its own
per-call work is a couple of fully-vectorized numpy reductions, cheap even
if called very frequently.

Measures Error Vector Magnitude: the nearest ideal QPSK point for each
symbol is identified purely by quadrant (sign of the real and imaginary
parts) - scale-invariant, so no assumption about the despread
correlation's absolute amplitude is needed. A single real least-squares
scale factor is then fit against those nearest points, and EVM is reported
as the RMS residual, as a percentage of the ideal constellation's own RMS
magnitude - the standard definition.

Publishes an 'evm' status message every `period_symbols` symbols.
"""

import numpy as np
import pmt
from gnuradio import gr


class blk(gr.sync_block):
    """EVM Probe"""

    def __init__(self, period_symbols=200):
        gr.sync_block.__init__(self, name='EVM Probe',
                               in_sig=[np.complex64], out_sig=[])
        self.period_symbols = max(1, int(period_symbols))
        self._buf = np.empty(0, dtype=np.complex64)
        self.message_port_register_out(pmt.intern('evm'))

    def work(self, input_items, output_items):
        in0 = input_items[0]
        n = len(in0)
        if n == 0:
            return 0
        self._buf = np.concatenate([self._buf, in0])
        if len(self._buf) >= self.period_symbols:
            self._measure(self._buf[:self.period_symbols])
            self._buf = self._buf[self.period_symbols:]
        return n

    def _measure(self, s):
        re_sign = np.where(np.real(s) >= 0, 1.0, -1.0)
        im_sign = np.where(np.imag(s) >= 0, 1.0, -1.0)
        nearest = (re_sign + 1j * im_sign).astype(np.complex128) / np.sqrt(2)
        denom = float(np.sum(np.abs(nearest) ** 2))
        if denom <= 0:
            return
        alpha = float(np.sum(np.real(s.astype(np.complex128) * np.conj(nearest)))) / denom
        if alpha == 0:
            return
        error = s.astype(np.complex128) - alpha * nearest
        evm_rms = float(np.sqrt(np.mean(np.abs(error) ** 2)))
        ref_rms = float(np.sqrt(np.mean(np.abs(alpha * nearest) ** 2)))
        evm_pct = 100.0 * evm_rms / ref_rms if ref_rms > 0 else float('nan')
        text = "EVM pct=%.2f" % evm_pct
        try:
            self.message_port_pub(
                pmt.intern('evm'),
                pmt.cons(pmt.PMT_NIL,
                         pmt.init_u8vector(len(text), list(text.encode('utf-8')))))
        except Exception:
            pass
