"""
FEC Encoder - Repetition (streaming, tag-aware)
--------------------------------------------------
Repeats every incoming bit `repeat` times in a row. This is a real
continuous streaming block (not a one-shot PDU/message transform like
earlier revisions of this project used) since the link is now
continuous, not burst-based - so it must correctly rescale the
`packet_len` tag (both its offset AND its value) by the repeat factor,
same as any other tagged-stream block in this chain.

With the ~30 dB of processing gain the DSSS spreading now provides, this
stage is far less load-bearing than it was for the original (unspread)
version of this link - `repeat=1` (the default) is a clean no-op, kept
around mainly so the architecture still has an FEC stage to turn up if
you want extra margin on top of the spreading gain.

Input : stream of bytes (0/1 per byte)
Output: stream of bytes (0/1), `repeat` per input bit
"""

import numpy as np
import pmt
from gnuradio import gr


class blk(gr.interp_block):
    """FEC Encoder - Repetition"""

    def __init__(self, repeat=1):
        gr.interp_block.__init__(self, name='FEC Encoder (Repetition)',
                                  in_sig=[np.uint8], out_sig=[np.uint8],
                                  interp=int(repeat))
        self.repeat = int(repeat)
        self.set_tag_propagation_policy(gr.TPP_DONT)

    def work(self, input_items, output_items):
        in0 = input_items[0]
        out = output_items[0]
        n = len(in0)
        out[:n * self.repeat] = np.repeat(in0, self.repeat)

        for t in self.get_tags_in_window(0, 0, n):
            rel = t.offset - self.nitems_read(0)
            new_offset = self.nitems_written(0) + rel * self.repeat
            key = pmt.symbol_to_string(t.key)
            val = t.value
            if key == 'packet_len' and pmt.is_integer(val):
                val = pmt.from_long(pmt.to_long(val) * self.repeat)
            self.add_item_tag(0, new_offset, t.key, val)

        return n * self.repeat
