"""
Packet Framer
-------------
Wraps one fixed-size (payload_bytes) fragment from the TX Scheduler into
the actual over-the-air frame:

    [ SYNC 8B (fixed, never scrambled) ][ SEQ 1B ][ PAYLOAD ][ CRC32 4B ]
                                        \\____________ scrambled ____________/

SEQ is just a rolling low-level packet counter (for diagnostics/logging -
the real message identity lives in the payload's own SRC/DST/MSG_ID/
FRAG_IDX fields, set by the TX Scheduler - this block doesn't interpret
the payload at all). CRC32 is computed over SEQ+PAYLOAD before scrambling.
Scrambling XORs a per-frame LFSR keystream over SEQ+PAYLOAD+CRC32
(restarted fresh every frame, since every frame here is independent and
the same fixed size - no cross-frame state needed); the sync word is
deliberately left unscrambled and fixed, since it needs to be a byte
pattern the receiver can literally search for.

Note: with DSSS spreading applied afterwards, the transmitted RF spectrum
is shaped entirely by the spreading code, not by the data - so unlike a
directly-modulated link, scrambling here is *not* load-bearing for
spectral flatness. It's kept anyway for good practice (avoiding any
pathological data/code correlation) and because forward error
correction/whitening was part of this project's original spec.

Input : PDU - exactly `payload_bytes` bytes (from the TX Scheduler)
Output: PDU - the complete framed byte sequence, ready for
        pdu_to_tagged_stream(byte, "packet_len")
"""

import numpy as np
import zlib
import pmt
from gnuradio import gr

SYNC_WORD = bytes([171, 55, 105, 56, 188, 163, 8, 63])  # 64-bit fixed sync pattern


def pdu_data(msg):
    vec = pmt.cdr(msg) if pmt.is_pair(msg) else msg
    return np.array(pmt.u8vector_elements(vec), dtype=np.uint8)


def make_pdu(values):
    arr = np.asarray(values, dtype=np.uint8)
    return pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(arr), arr.tolist()))


def lfsr_sequence(n_bits, taps, seed, length):
    state = seed & ((1 << n_bits) - 1)
    if state == 0:
        state = 1
    out = np.empty(length, dtype=np.uint8)
    for i in range(length):
        out[i] = state & 1
        fb = bin(state & taps).count('1') & 1
        state = (state >> 1) | (fb << (n_bits - 1))
    return out


# 9-bit maximal-length (period 511) scrambler polynomial + seed. Must
# match pkt_deframer.py exactly.
SCRAMBLER_NBITS, SCRAMBLER_TAPS, SCRAMBLER_SEED = 9, 0b110011, 0b011010110


def scramble_bytes(data):
    bits = np.unpackbits(np.frombuffer(data, dtype=np.uint8))
    ks = lfsr_sequence(SCRAMBLER_NBITS, SCRAMBLER_TAPS, SCRAMBLER_SEED, len(bits))
    return np.packbits(bits ^ ks).tobytes()


class blk(gr.basic_block):
    """Packet Framer"""

    def __init__(self):
        gr.basic_block.__init__(self, name='Packet Framer', in_sig=[], out_sig=[])
        self._seq = 0
        self.message_port_register_in(pmt.intern('in'))
        self.message_port_register_out(pmt.intern('out'))
        self.set_msg_handler(pmt.intern('in'), self.handle_msg)

    def handle_msg(self, msg):
        payload = pdu_data(msg).tobytes()
        header = bytes([self._seq & 0xFF])
        crc = zlib.crc32(header + payload) & 0xFFFFFFFF
        body = header + payload + crc.to_bytes(4, 'big')
        self._seq = (self._seq + 1) & 0xFF
        frame = SYNC_WORD + scramble_bytes(body)
        self.message_port_pub(pmt.intern('out'), make_pdu(list(frame)))
