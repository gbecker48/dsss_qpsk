"""
FEC Decoder - Majority Vote (streaming, tag-aware)
------------------------------------------------------
Inverse of fec_repeat.py: groups every `repeat` incoming bits and takes a
majority vote, correcting any single-bit (and some multi-bit) errors per
group. A real continuous streaming block with correct `packet_len` tag
rescaling (offset and value both divided by `repeat`), matching
fec_repeat.py on the transmit side.

DIAGNOSTICS (purely additive - does not change the decode output or tag
handling above at all): whenever `repeat` > 1, a group that isn't
unanimous is direct evidence of at least one bit error the repetition code
just corrected. Every `stats_period_groups` groups, this block publishes a
'stats' message reporting how many of them needed correction - a real,
measurable channel bit-error indicator (not available at all when
`repeat` == 1, the default, since there's no redundancy to compare against
- reported as `n/a` in that case rather than a misleading zero).

Input : stream of bytes (0/1), `repeat` per decoded bit
Output: stream of bytes (0/1), decoded
"""

import numpy as np
import pmt
from gnuradio import gr


class blk(gr.decim_block):
    """FEC Decoder - Majority Vote"""

    def __init__(self, repeat=1, stats_period_groups=2000):
        gr.decim_block.__init__(self, name='FEC Decoder (Majority Vote)',
                                 in_sig=[np.uint8], out_sig=[np.uint8],
                                 decim=int(repeat))
        self.repeat = int(repeat)
        self.stats_period_groups = max(1, int(stats_period_groups))
        self._group_count = 0
        self._corrected_count = 0
        self.set_tag_propagation_policy(gr.TPP_DONT)
        self.message_port_register_out(pmt.intern('stats'))

    def work(self, input_items, output_items):
        in0 = input_items[0]
        out = output_items[0]
        n_groups = len(in0) // self.repeat
        n_groups = min(n_groups, len(out))
        if n_groups == 0:
            return 0
        groups = in0[:n_groups * self.repeat].reshape(n_groups, self.repeat)
        sums = groups.sum(axis=1)
        out[:n_groups] = (sums * 2 >= self.repeat).astype(np.uint8)

        if self.repeat > 1:
            disagreements = int(np.sum((sums != 0) & (sums != self.repeat)))
            self._corrected_count += disagreements
            self._group_count += n_groups
            if self._group_count >= self.stats_period_groups:
                self._publish_stats()

        for t in self.get_tags_in_window(0, 0, n_groups * self.repeat):
            rel = t.offset - self.nitems_read(0)
            new_offset = self.nitems_written(0) + rel // self.repeat
            key = pmt.symbol_to_string(t.key)
            val = t.value
            if key == 'packet_len' and pmt.is_integer(val):
                val = pmt.from_long(pmt.to_long(val) // self.repeat)
            self.add_item_tag(0, new_offset, t.key, val)

        return n_groups

    def _publish_stats(self):
        pct = 100.0 * self._corrected_count / self._group_count if self._group_count else 0.0
        text = "FEC corrected=%d/%d pct=%.3f" % (
            self._corrected_count, self._group_count, pct)
        self._group_count = 0
        self._corrected_count = 0
        try:
            self.message_port_pub(
                pmt.intern('stats'),
                pmt.cons(pmt.PMT_NIL,
                         pmt.init_u8vector(len(text), list(text.encode('utf-8')))))
        except Exception:
            pass
