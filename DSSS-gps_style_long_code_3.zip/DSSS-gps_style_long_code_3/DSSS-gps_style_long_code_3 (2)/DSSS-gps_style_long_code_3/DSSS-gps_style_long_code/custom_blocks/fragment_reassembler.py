"""
Fragment Reassembler -- reassembly, erasure decoding, addressing, BER counting
==============================================================================

The receive-side mirror of tx_scheduler.py. Parses each CRC-validated
fragment's v2 header, accumulates fragments by message id, reconstructs
anything missing from the Reed-Solomon parity, and publishes the complete
message.

WHY THIS CAN RECOVER LOST FRAGMENTS
------------------------------------
Because the frame CRC32 upstream has already done the hard part. A corrupted
fragment is *discarded*, not passed up half-broken, so this block always knows
exactly WHICH fragments are missing -- their positions are known and only their
values are unknown. That is the erasure case, and erasure coding is twice as
efficient as error correction: m parity fragments recover m erasures but only
m/2 errors.

So a message completes as soon as any k of the k+m fragments in each RS block
have arrived. With the default 20% parity that means a file survives roughly
15% fragment loss and still verifies bit-exact against its SHA-256. Without it,
a single lost fragment anywhere in a 4300-fragment file loses the whole
transfer -- which is the difference between file transfer working and not.

The RS block layout is derived from N_DATA and N_PARITY, which are in every
fragment header, so a receiver that joins mid-transfer or misses the beginning
still knows exactly what it is looking at. There is no setup handshake to miss.

WHEN TO GIVE UP
---------------
A message is decoded the moment enough fragments are in hand. If the sender
stops and a message is still short, it is held for `stale_after` further
fragments and then reported INCOMPLETE with exactly which indices never
arrived, rather than held forever. Partial recovery is reported honestly:
blocks are independent, so "one RS block short" is a very different situation
from "the link is down", and the status line says which.

BER COUNTING
------------
TYPE_BERT fragments carry PRBS-15. This block synchronises its own generator
to the received bits and counts every mismatch, giving a true channel bit error
rate over an unbounded run with nothing stored on either side. Reported with a
bit count and a confidence interval, because a BER quoted without a bit count
is not a measurement -- three errors in ten thousand bits and three thousand in
ten million are the same ratio and very different levels of confidence.

STATUS LINE GRAMMAR
-------------------
A frozen contract with ground_station.py and terminal.py. Adding keys is safe
(both parse leniently); renaming or reordering is not.

    "FRAG msg=<id> idx=<i> type=<DATA|PARITY> data=<k> parity=<m> have=<n>
          seq=<s> len=<bytes> src=<s> dst=<d>"
    "IDLE seq=<seq> src=<s> dst=<d>"
    "DONE msg=<id> fragments=<n> bytes=<total> src=<s> recovered=<r>"
    "INCOMPLETE msg=<id> missing=<comma,separated> blocks_lost=<n>"
    "FOREIGN src=<s> dst=<d> msg=<id> (not addressed to node <my_node_id>)"
    "WARN unexpected src=<s> while listening on node <dest_node_id>'s code"
    "BERT errors=<e> bits=<n> ber=<x> synced=<0|1>"

Input : PDU - [SEQ 1B][payload_bytes], CRC-validated by the Packet Deframer
Outputs: 'msg'    - a complete reassembled message
         'status' - one of the lines above
"""

import numpy as np
import pmt
import struct
from gnuradio import gr

HEADER_BYTES = 12
_HDR = struct.Struct(">BBBBHHHH")

TYPE_IDLE = 0
TYPE_DATA = 1
TYPE_PARITY = 2
TYPE_BERT = 3
TYPE_NAMES = {0: 'IDLE', 1: 'DATA', 2: 'PARITY', 3: 'BERT'}

BROADCAST_NODE = 0xFF

# --- GF(256) Reed-Solomon, decode side ---------------------------------------
_PRIM = 0x11D


def _gf_tables():
    exp = np.zeros(512, dtype=np.uint8)
    log = np.zeros(256, dtype=np.uint8)
    x = 1
    for i in range(255):
        exp[i] = x
        log[x] = i
        x <<= 1
        if x & 0x100:
            x ^= _PRIM
    exp[255:] = exp[:257]
    return exp, log


_EXP, _LOG = _gf_tables()
MAX_BLOCK = 255
BLOCK_K = 200


def _gf_mul(a, b):
    a = np.asarray(a, dtype=np.uint8)
    b = np.asarray(b, dtype=np.uint8)
    out = _EXP[(_LOG[a].astype(np.int16) + _LOG[b].astype(np.int16))]
    return np.where((a == 0) | (b == 0), np.uint8(0), out).astype(np.uint8)


def _gf_inv(a):
    return int(_EXP[(255 - int(_LOG[a])) % 255])


def _gf_matmul(A, B):
    out = np.zeros((A.shape[0], B.shape[1]), dtype=np.uint8)
    for i in range(A.shape[1]):
        col = A[:, i][:, None]
        row = B[i][None, :]
        nz = (col != 0) & (row != 0)
        prod = _EXP[(_LOG[col].astype(np.int16) + _LOG[row].astype(np.int16))]
        out ^= np.where(nz, prod, np.uint8(0)).astype(np.uint8)
    return out


def _vandermonde(k, m):
    V = np.zeros((m, k), dtype=np.uint8)
    for i in range(m):
        a = int(_EXP[1 + i])
        val = 1
        for j in range(k):
            V[i, j] = val
            val = 0 if (val == 0 or a == 0) else int(
                _EXP[(int(_LOG[val]) + int(_LOG[a])) % 255])
    return V


def _gf_inverse(A):
    n = A.shape[0]
    M = np.concatenate([A.copy(), np.eye(n, dtype=np.uint8)], axis=1)
    for col in range(n):
        piv = -1
        for r in range(col, n):
            if M[r, col] != 0:
                piv = r
                break
        if piv < 0:
            raise ValueError('singular RS matrix')
        if piv != col:
            M[[col, piv]] = M[[piv, col]]
        M[col] = _gf_mul(M[col], np.uint8(_gf_inv(int(M[col, col]))))
        f = M[:, col].copy()
        f[col] = 0
        nz = f != 0
        if np.any(nz):
            M[nz] ^= _gf_mul(f[nz][:, None],
                             np.broadcast_to(M[col], (int(nz.sum()), M.shape[1])))
    return M[:, n:]


def rs_plan(n_data, n_parity):
    """MUST match tx_scheduler.rs_plan and dsss_link/erasure_fec.plan."""
    if n_data <= 0:
        return []
    n_blocks = max(1, -(-n_data // BLOCK_K))
    base, extra = divmod(n_data, n_blocks)
    ks = [base + (1 if b < extra else 0) for b in range(n_blocks)]
    ks = [k for k in ks if k > 0]
    n_blocks = len(ks)
    if n_parity <= 0:
        return [(k, 0) for k in ks]
    total_k = sum(ks)
    exact = [n_parity * k / total_k for k in ks]
    ms = [int(np.floor(e)) for e in exact]
    leftover = n_parity - sum(ms)
    order = sorted(range(n_blocks), key=lambda b: (-(exact[b] - ms[b]), b))
    for i in range(leftover):
        ms[order[i % n_blocks]] += 1
    return [(k, min(m, MAX_BLOCK - k)) for k, m in zip(ks, ms)]


def pdu_data(msg):
    vec = pmt.cdr(msg) if pmt.is_pair(msg) else msg
    return np.array(pmt.u8vector_elements(vec), dtype=np.uint8)


def make_pdu(values):
    arr = np.asarray(values, dtype=np.uint8)
    return pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(arr), arr.tolist()))


class blk(gr.basic_block):
    """Fragment Reassembler (erasure-decoding, node-addressed)"""

    def __init__(self, payload_bytes=256, stale_after=256, my_node_id=0,
                 dest_node_id=1, bert_report_bits=100000):
        gr.basic_block.__init__(self, name='Fragment Reassembler',
                                in_sig=[], out_sig=[])
        self.payload_bytes = int(payload_bytes)
        self.chunk_bytes = self.payload_bytes - HEADER_BYTES
        self.stale_after = int(stale_after)
        self.my_node_id = int(my_node_id)
        self.dest_node_id = int(dest_node_id)
        self.bert_report_bits = int(bert_report_bits)

        self.pending = {}
        self._bert_state = None
        self._bert_errors = 0
        self._bert_bits = 0
        # Per-fragment status is published to the GUI every time, but only
        # printed to the console occasionally. A megabyte file is four
        # thousand fragments; printing each one turns the terminal the
        # flowgraph is running in into the bottleneck.
        self._print_every = 50
        self._status_count = 0

        self.message_port_register_in(pmt.intern('in'))
        for p in ('msg', 'status'):
            self.message_port_register_out(pmt.intern(p))
        self.set_msg_handler(pmt.intern('in'), self.handle_msg)

    # -- main path ----------------------------------------------------------
    def handle_msg(self, msg):
        raw = pdu_data(msg).tobytes()
        if len(raw) < 1 + HEADER_BYTES:
            return
        seq = raw[0]
        payload = raw[1:]
        src, dst, mtype, mid, idx, n_data, n_par, clen = _HDR.unpack(
            payload[:HEADER_BYTES])
        clen = min(clen, len(payload) - HEADER_BYTES)
        chunk = payload[HEADER_BYTES:HEADER_BYTES + self.chunk_bytes]

        addressed = (dst == self.my_node_id) or (dst == BROADCAST_NODE)

        if mtype == TYPE_BERT:
            if addressed:
                self._bert_update(chunk)
            return

        if mtype == TYPE_IDLE or n_data == 0:
            if addressed:
                self._status('IDLE seq=%d src=%d dst=%d' % (seq, src, dst))
            self._age_pending()
            self._check_src(src)
            return

        if not addressed:
            self._status('FOREIGN src=%d dst=%d msg=%d '
                         '(not addressed to node %d)'
                         % (src, dst, mid, self.my_node_id))
            return

        self._check_src(src)

        e = self.pending.get(mid)
        if e is None or e['n_data'] != n_data or e['n_parity'] != n_par:
            # A changed shape means this is a different message that reused the
            # id, not a continuation -- start fresh rather than mixing two
            # files together, which would decode to plausible-looking garbage.
            e = {'n_data': n_data, 'n_parity': n_par, 'data': {}, 'parity': {},
                 'age': 0, 'src': src, 'total_bytes': 0}
            self.pending[mid] = e

        if mtype == TYPE_DATA and idx < n_data:
            e['data'][idx] = np.frombuffer(chunk, dtype=np.uint8)
            e['total_bytes'] = max(e['total_bytes'], idx * self.chunk_bytes + clen)
        elif mtype == TYPE_PARITY and idx < n_par:
            e['parity'][idx] = np.frombuffer(chunk, dtype=np.uint8)
        e['age'] = 0

        have = len(e['data']) + len(e['parity'])
        self._status('FRAG msg=%d idx=%d type=%s data=%d parity=%d have=%d '
                     'seq=%d len=%d src=%d dst=%d'
                     % (mid, idx, TYPE_NAMES.get(mtype, '?'), n_data, n_par,
                        have, seq, clen, src, dst))

        if self._try_complete(mid, e):
            return
        self._age_pending(exclude=mid)

    # -- completion ---------------------------------------------------------
    def _try_complete(self, mid, e):
        """Decode as soon as every RS block has enough fragments."""
        plan = rs_plan(e['n_data'], e['n_parity'])
        d_pos = p_pos = 0
        for (k, m) in plan:
            have = sum(1 for i in range(k) if (d_pos + i) in e['data'])
            have += sum(1 for i in range(m) if (p_pos + i) in e['parity'])
            if have < k:
                return False
            d_pos += k
            p_pos += m

        out = []
        recovered = 0
        d_pos = p_pos = 0
        try:
            for (k, m) in plan:
                block = {}
                for i in range(k):
                    f = e['data'].get(d_pos + i)
                    if f is not None:
                        block[i] = f
                for i in range(m):
                    f = e['parity'].get(p_pos + i)
                    if f is not None:
                        block[k + i] = f
                missing = k - sum(1 for i in range(k) if i in block)
                if missing == 0:
                    out.extend(block[i] for i in range(k))
                else:
                    recovered += missing
                    idxs = sorted(block.keys())[:k]
                    V = _vandermonde(k, m) if m else np.zeros((0, k), np.uint8)
                    rows = np.zeros((k, k), dtype=np.uint8)
                    rhs = np.zeros((k, self.chunk_bytes), dtype=np.uint8)
                    for r, i in enumerate(idxs):
                        if i < k:
                            rows[r, i] = 1
                        else:
                            rows[r] = V[i - k]
                        rhs[r] = block[i]
                    out.extend(list(_gf_matmul(_gf_inverse(rows), rhs)))
                d_pos += k
                p_pos += m
        except Exception as exc:
            self._status('INCOMPLETE msg=%d missing=rs_decode_failed:%s '
                         'blocks_lost=1' % (mid, exc))
            self.pending.pop(mid, None)
            return True

        blob = b''.join(x.tobytes() for x in out)[:e['total_bytes']]
        del self.pending[mid]
        self.message_port_pub(pmt.intern('msg'), make_pdu(list(blob)))
        self._status('DONE msg=%d fragments=%d bytes=%d src=%d recovered=%d'
                     % (mid, e['n_data'], len(blob), e['src'], recovered))
        return True

    def _check_src(self, src):
        # A fresh acquisition can land on a foreign code's sidelobe for a
        # single symbol, so this is not fatal; a persistent mismatch usually
        # means two nodes picked the same PRN, which is worth saying out loud.
        if src != self.dest_node_id:
            self._status("WARN unexpected src=%d while listening on node %d's "
                         "code" % (src, self.dest_node_id))

    def _age_pending(self, exclude=None):
        stale = []
        for mid, e in self.pending.items():
            if mid == exclude:
                continue
            e['age'] += 1
            if e['age'] >= self.stale_after:
                stale.append(mid)
        for mid in stale:
            e = self.pending.pop(mid)
            missing = [i for i in range(e['n_data']) if i not in e['data']]
            plan = rs_plan(e['n_data'], e['n_parity'])
            lost_blocks = 0
            d_pos = p_pos = 0
            for (k, m) in plan:
                have = sum(1 for i in range(k) if (d_pos + i) in e['data'])
                have += sum(1 for i in range(m) if (p_pos + i) in e['parity'])
                if have < k:
                    lost_blocks += 1
                d_pos += k
                p_pos += m
            shown = ','.join(str(i) for i in missing[:32])
            if len(missing) > 32:
                shown += ',...+%d' % (len(missing) - 32)
            self._status('INCOMPLETE msg=%d missing=%s blocks_lost=%d'
                         % (mid, shown, lost_blocks))

    # -- BERT ---------------------------------------------------------------
    def _bert_update(self, chunk):
        """Count bit errors against a locally regenerated PRBS-15 sequence.

        Sync is re-established from the received bits whenever it is lost, so a
        dropout costs the bits during the dropout and not the whole run. Errors
        are only counted while the predictor agrees with the stream well enough
        to be tracking it -- a run of bits counted while out of sync would
        report a BER of 0.5 and mean nothing.
        """
        bits = np.unpackbits(np.frombuffer(chunk, dtype=np.uint8))
        if len(bits) < 16:
            return

        if self._bert_state is None:
            s = 0
            for b in bits[:15]:
                s = ((s << 1) | int(b)) & 0x7FFF
            self._bert_state = s or 0x7FFF
            bits = bits[15:]
            if len(bits) == 0:
                return

        s = self._bert_state
        pred = np.empty(len(bits), dtype=np.uint8)
        for i in range(len(bits)):
            fb = ((s >> 14) ^ (s >> 13)) & 1
            s = ((s << 1) | fb) & 0x7FFF
            pred[i] = fb
        errs = int(np.count_nonzero(pred ^ bits))

        if errs > len(bits) * 0.3:
            # Not tracking. Re-seed from the stream rather than accumulating
            # meaningless errors.
            self._bert_state = None
            self._status('BERT errors=%d bits=%d ber=%.3e synced=0'
                         % (self._bert_errors, self._bert_bits,
                            self._bert_errors / max(1, self._bert_bits)))
            return

        self._bert_state = s
        self._bert_errors += errs
        self._bert_bits += len(bits)

        if self._bert_bits >= self.bert_report_bits:
            ber = self._bert_errors / self._bert_bits
            self._status('BERT errors=%d bits=%d ber=%.3e synced=1'
                         % (self._bert_errors, self._bert_bits, ber))
            self._bert_errors = 0
            self._bert_bits = 0

    def _status(self, text):
        self._status_count += 1
        if not text.startswith(('FRAG', 'IDLE')) or \
                self._status_count % self._print_every == 0:
            print('[RX] ' + text)
        data = text.encode('utf-8')
        self.message_port_pub(pmt.intern('status'), make_pdu(list(data)))
