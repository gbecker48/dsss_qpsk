"""
Packet Capture
---------------
Watches the recovered, already FEC-decoded bit stream for the 'sync' tag
emitted by the Correlate Access Code block (which is searching for the
Packet Framer's fixed 64-bit sync word). The instant a frame's sync word
is found, this block starts collecting exactly `total_bits` further bits
(SEQ + PAYLOAD + CRC32) into a buffer, packs them into bytes once full,
and publishes the whole frame body as a single PDU - the bridge from the
continuous, always-running receive bit stream back into the per-frame
message/PDU domain used by the Packet Deframer.

Input : stream of bytes (0/1), tagged with a 'sync' tag at frame start
Output: message PDU - the frame body, packed to bytes (total_bits/8 of them)
"""

import numpy as np
import pmt
from gnuradio import gr


def make_pdu(values):
    arr = np.asarray(values, dtype=np.uint8)
    return pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(arr), arr.tolist()))


class blk(gr.sync_block):
    """Packet Capture"""

    def __init__(self, total_bits=2088, tagname='sync'):
        gr.sync_block.__init__(self, name='Packet Capture', in_sig=[np.uint8], out_sig=[])
        self.tagname = tagname
        self.need = int(total_bits)
        self.capturing = False
        self.buf = np.empty(0, dtype=np.uint8)
        self.message_port_register_out(pmt.intern('out'))

    def work(self, input_items, output_items):
        in0 = input_items[0]
        n = len(in0)

        tags = self.get_tags_in_window(0, 0, n, pmt.intern(self.tagname))
        if tags:
            offset = tags[0].offset - self.nitems_read(0)
            self.buf = np.array(in0[offset:], dtype=np.uint8)
            self.capturing = True
        elif self.capturing:
            self.buf = np.concatenate([self.buf, np.array(in0, dtype=np.uint8)])

        if self.capturing and len(self.buf) >= self.need:
            frame_bits = self.buf[:self.need]
            frame_bytes = np.packbits(frame_bits)
            self.message_port_pub(pmt.intern('out'), make_pdu(frame_bytes))
            self.capturing = False
            self.buf = np.empty(0, dtype=np.uint8)

        return n
