"""
TX Scheduler -- fragmentation, erasure coding, node addressing, strobe pacing
=============================================================================

Takes whole messages in and emits exactly one fixed-size fragment per strobe
tick, forever. If the queue is empty it emits an idle filler frame instead, so
the physical layer never goes quiet -- which matters because a despreader that
has to re-acquire every time the transmitter pauses spends its life
re-acquiring rather than receiving. A GPS satellite does not stop transmitting
when it has nothing new to say, and neither does this.

WHAT CHANGED FROM v1, AND WHY
------------------------------
Three things, all of them in service of moving files rather than short
messages.

1. Sixteen-bit fragment indices. The v1 header used single bytes for
   FRAG_IDX and FRAG_TOTAL, which capped a message at 256 fragments -- 64 000
   bytes. Fine for chat, a hard wall for files. The v2 header (see
   dsss_link/protocol.py for the canonical definition) raises the ceiling to
   65 535 fragments, about 16 MB.

2. Reed-Solomon erasure coding. This link has no retransmission: a fragment
   whose frame fails CRC32 is dropped, and the message it belonged to never
   completes. A 1 MB file is about 4300 fragments, so at even a 0.1% loss rate
   four of them vanish and the transfer fails every single time. Parity
   fragments fix that with no reverse channel -- any k of the k+m fragments in
   an RS block reconstruct the k data fragments, so losses inside the parity
   budget simply do not matter. Measured with 20% parity: files arrive
   bit-exact through 15% fragment loss.

   Parity is generated here, at queue time, not per strobe -- encoding a whole
   file takes a second or two of CPU, and doing that inside a message handler
   that is supposed to return promptly would stall the flowgraph.

3. A TYPE field, so parity fragments and BER test patterns share the same
   framing instead of needing side channels of their own.

BERT MODE
---------
With `bert_enabled`, idle slots carry PRBS-15 instead of zeros. That turns
every otherwise-wasted idle frame into a bit-error measurement: the receiver
knows the sequence, so it can count real channel bit errors continuously,
without a file to compare against and without either end storing anything.
This is what `demo.py 7` uses to quantify BER (requirement 7).

PACING
------
Unchanged from v1, deliberately. The strobe-driven design was restored after a
"never-starving continuous source" replacement caused MORE underflow on real
hardware, not less -- the real cause being the aggressively small per-block
buffers that redesign introduced, which cut into exactly the margin real
hardware needs to absorb OS and USB scheduling jitter. See the flowgraph's
`tx_pace_margin_pct` slider for the per-machine tuning knob.

Ports
  in  'queue_in'  a whole message PDU from the UDP terminal
  in  'strobe'    a timing tick: "emit the next thing now"
  in  'ctrl'      text commands (BERT=0/1, PARITY=<pct>)
  out 'out'       one fragment payload PDU, always payload_bytes long
  out 'status'    text status lines for the ground station
"""

import numpy as np
import pmt
import struct
from collections import deque
from gnuradio import gr

# --- wire format -------------------------------------------------------------
# Canonical definition lives in dsss_link/protocol.py; this is the
# self-contained copy a GRC embedded Python block needs. They are asserted
# byte-identical by tests/test_protocol_matches_blocks.py.

HEADER_BYTES = 12
_HDR = struct.Struct(">BBBBHHHH")

TYPE_IDLE = 0
TYPE_DATA = 1
TYPE_PARITY = 2
TYPE_BERT = 3

MAX_FRAGMENTS = 0xFFFF


def pack_header(src, dst, mtype, msg_id, frag_idx, n_data, n_parity, chunk_len):
    return _HDR.pack(src & 0xFF, dst & 0xFF, mtype & 0xFF, msg_id & 0xFF,
                     frag_idx & 0xFFFF, n_data & 0xFFFF,
                     n_parity & 0xFFFF, chunk_len & 0xFFFF)


# --- GF(256) Reed-Solomon, encode side ---------------------------------------
# See dsss_link/erasure_fec.py for the full explanation and the decoder.

_PRIM = 0x11D


def _gf_tables():
    exp = np.zeros(512, dtype=np.uint8)
    log = np.zeros(256, dtype=np.uint8)
    x = 1
    for i in range(255):
        exp[i] = x
        log[x] = i
        x <<= 1
        if x & 0x100:
            x ^= _PRIM
    exp[255:] = exp[:257]
    return exp, log


_EXP, _LOG = _gf_tables()
MAX_BLOCK = 255
BLOCK_K = 200


def _gf_mul_scalar(a, b):
    if a == 0 or b == 0:
        return 0
    return int(_EXP[(int(_LOG[a]) + int(_LOG[b])) % 255])


def _gf_matmul(A, B):
    out = np.zeros((A.shape[0], B.shape[1]), dtype=np.uint8)
    for i in range(A.shape[1]):
        col = A[:, i][:, None]
        row = B[i][None, :]
        nz = (col != 0) & (row != 0)
        prod = _EXP[(_LOG[col].astype(np.int16) + _LOG[row].astype(np.int16))]
        out ^= np.where(nz, prod, np.uint8(0)).astype(np.uint8)
    return out


def _vandermonde(k, m):
    V = np.zeros((m, k), dtype=np.uint8)
    for i in range(m):
        a = int(_EXP[1 + i])
        val = 1
        for j in range(k):
            V[i, j] = val
            val = _gf_mul_scalar(val, a)
    return V


def parity_for(n_data, parity_fraction):
    if n_data <= 0 or parity_fraction <= 0:
        return 0
    n_blocks = max(1, -(-n_data // BLOCK_K))
    k_max = -(-n_data // n_blocks)
    return min(int(np.ceil(n_data * float(parity_fraction))),
               (MAX_BLOCK - k_max) * n_blocks)


def rs_plan(n_data, n_parity):
    """MUST match dsss_link/erasure_fec.plan and fragment_reassembler.rs_plan.

    Derived from the two totals alone, because those are the only things the
    receiver sees. Deriving it from the parity *fraction* instead looks
    equivalent and is not -- the two ends round differently and every decode
    fails.
    """
    if n_data <= 0:
        return []
    n_blocks = max(1, -(-n_data // BLOCK_K))
    base, extra = divmod(n_data, n_blocks)
    ks = [base + (1 if b < extra else 0) for b in range(n_blocks)]
    ks = [k for k in ks if k > 0]
    n_blocks = len(ks)
    if n_parity <= 0:
        return [(k, 0) for k in ks]
    total_k = sum(ks)
    exact = [n_parity * k / total_k for k in ks]
    ms = [int(np.floor(e)) for e in exact]
    leftover = n_parity - sum(ms)
    order = sorted(range(n_blocks), key=lambda b: (-(exact[b] - ms[b]), b))
    for i in range(leftover):
        ms[order[i % n_blocks]] += 1
    return [(k, min(m, MAX_BLOCK - k)) for k, m in zip(ks, ms)]


# --- PRBS-15, for BERT mode --------------------------------------------------

def prbs15_bytes(state, n):
    """x^15 + x^14 + 1. Returns (bytes, new_state)."""
    bits = np.empty(n * 8, dtype=np.uint8)
    s = state & 0x7FFF or 0x7FFF
    for i in range(n * 8):
        fb = ((s >> 14) ^ (s >> 13)) & 1
        s = ((s << 1) | fb) & 0x7FFF
        bits[i] = fb
    return np.packbits(bits).tobytes(), s


def pdu_data(msg):
    vec = pmt.cdr(msg) if pmt.is_pair(msg) else msg
    return np.array(pmt.u8vector_elements(vec), dtype=np.uint8)


def make_pdu(values):
    arr = np.asarray(values, dtype=np.uint8)
    return pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(arr), arr.tolist()))


class blk(gr.basic_block):
    """TX Scheduler: fragmentation + erasure coding + node addressing"""

    def __init__(self, payload_bytes=256, my_node_id=0, dest_node_id=1,
                 parity_fraction=0.20, bert_enabled=False):
        gr.basic_block.__init__(self, name='TX Scheduler',
                                in_sig=[], out_sig=[])
        self.payload_bytes = int(payload_bytes)
        self.chunk_bytes = self.payload_bytes - HEADER_BYTES
        self.max_message_bytes = self.chunk_bytes * MAX_FRAGMENTS
        self.my_node_id = int(my_node_id)
        self.dest_node_id = int(dest_node_id)
        self.parity_fraction = float(parity_fraction)
        self.bert_enabled = bool(bert_enabled)

        self.queue = deque()
        self.msg_id = 0
        self._bert_state = 0x7FFF
        self._sent = 0
        self._idle = 0

        for p in ('queue_in', 'strobe', 'ctrl'):
            self.message_port_register_in(pmt.intern(p))
        for p in ('out', 'status'):
            self.message_port_register_out(pmt.intern(p))
        self.set_msg_handler(pmt.intern('queue_in'), self.handle_queue_in)
        self.set_msg_handler(pmt.intern('strobe'), self.handle_strobe)
        self.set_msg_handler(pmt.intern('ctrl'), self.handle_ctrl)

    # -- control ------------------------------------------------------------
    def handle_ctrl(self, msg):
        try:
            text = bytes(pdu_data(msg)).decode('utf-8', 'replace').strip()
        except Exception:
            return
        key, _, val = text.partition('=')
        key = key.strip().upper()
        try:
            if key == 'BERT':
                self.bert_enabled = bool(int(val))
                self._bert_state = 0x7FFF
                self._status('TXCTRL bert=%d' % int(self.bert_enabled))
            elif key == 'PARITY':
                self.parity_fraction = max(0.0, min(0.5, float(val) / 100.0))
                self._status('TXCTRL parity_pct=%.0f'
                             % (self.parity_fraction * 100))
        except ValueError:
            pass

    # -- queueing -----------------------------------------------------------
    def handle_queue_in(self, msg):
        """Fragment a message, erasure-code it, and queue every fragment.

        All the expensive work happens here rather than per strobe tick. RS
        encoding a megabyte takes a second or two; doing that inside the strobe
        handler would stall the transmit chain and cause exactly the underflow
        this project spent a version fixing.
        """
        data = pdu_data(msg).tobytes()
        if not data:
            return
        if len(data) > self.max_message_bytes:
            self._status('TXERR message %d bytes exceeds max %d - truncated'
                         % (len(data), self.max_message_bytes))
            data = data[:self.max_message_bytes]

        cb = self.chunk_bytes
        n_data = max(1, -(-len(data) // cb))
        frags = np.zeros((n_data, cb), dtype=np.uint8)
        raw = np.frombuffer(data, dtype=np.uint8)
        frags.reshape(-1)[:len(raw)] = raw

        n_parity = parity_for(n_data, self.parity_fraction)
        parity = []
        if n_parity:
            pos = 0
            for (k, m) in rs_plan(n_data, n_parity):
                if m:
                    parity.extend(list(_gf_matmul(_vandermonde(k, m),
                                                  frags[pos:pos + k])))
                pos += k

        mid = self.msg_id
        self.msg_id = (self.msg_id + 1) & 0xFF

        left = len(data)
        for i in range(n_data):
            clen = min(cb, max(0, left))
            left -= cb
            self.queue.append((TYPE_DATA, i, n_data, n_parity, clen,
                               mid, frags[i].tobytes()))
        for i, p in enumerate(parity):
            self.queue.append((TYPE_PARITY, i, n_data, n_parity, cb,
                               mid, bytes(p)))

        self._status('TXQUEUE msg=%d bytes=%d data=%d parity=%d overhead=%.0f%%'
                     % (mid, len(data), n_data, n_parity,
                        100.0 * n_parity / max(1, n_data)))

    # -- pacing -------------------------------------------------------------
    def handle_strobe(self, msg):
        """One tick, one fragment. Never nothing."""
        if self.queue:
            mtype, idx, n_data, n_par, clen, mid, chunk = self.queue.popleft()
            self._sent += 1
        elif self.bert_enabled:
            chunk, self._bert_state = prbs15_bytes(self._bert_state,
                                                   self.chunk_bytes)
            mtype, idx, n_data, n_par, clen, mid = (
                TYPE_BERT, 0, 0, 0, self.chunk_bytes, 0)
            self._idle += 1
        else:
            mtype, idx, n_data, n_par, clen, mid = TYPE_IDLE, 0, 0, 0, 0, 0
            chunk = bytes(self.chunk_bytes)
            self._idle += 1

        payload = pack_header(self.my_node_id, self.dest_node_id, mtype,
                              mid, idx, n_data, n_par, clen) + chunk
        payload = payload[:self.payload_bytes].ljust(self.payload_bytes, b'\x00')
        self.message_port_pub(pmt.intern('out'), make_pdu(list(payload)))

    def _status(self, text):
        print('[TX] ' + text)
        data = text.encode('utf-8')
        self.message_port_pub(pmt.intern('status'),
                              make_pdu(list(data)))

    # -- introspection for the GUI ------------------------------------------
    @property
    def queue_depth(self):
        return len(self.queue)
