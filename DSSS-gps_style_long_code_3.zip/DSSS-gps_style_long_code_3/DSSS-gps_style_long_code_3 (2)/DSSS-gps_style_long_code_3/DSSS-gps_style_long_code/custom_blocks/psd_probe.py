"""
PSD Probe -- averaged power spectrum, for the below-the-noise-floor proof
=========================================================================

REQUIREMENT 6: "use a spectrum analyser to compare the spread spectrum signal
with the signal below the noise floor."

Pointing a spectrum analyser at the link and taking a photograph shows a flat
noise floor -- which is the correct result, and also completely
indistinguishable from a photograph of the analyser with the transmitter
switched off, or unplugged, or broken. A picture of nothing is not evidence of
hiding; it is evidence of nothing.

Turning it into a measurement takes two captures and a subtraction:

    TX ON      noise + signal
    TX OFF     noise alone
    difference the signal power -- recoverable even when it is 20 dB under the
               floor, because averaging beats down the noise's variance while
               the signal's contribution stays put

This block provides the captures. It computes a Welch-averaged periodogram of
the raw received samples -- the same samples the USRP source hands over,
upstream of everything -- and publishes it as text on the diagnostics port,
binned down to something a UDP datagram can carry. `demo.py 6` keys the
transmitter off and on via the control port, captures both, and reports how
far below the noise floor the signal actually sits, in dB, with the spectra
plotted side by side.

Averaging matters here. A single FFT frame of a signal 20 dB below the noise
has a per-bin standard deviation far larger than the signal itself, so no
amount of staring at one frame reveals anything. Averaging N frames reduces
the noise's variance by N while the signal's mean contribution is unchanged,
which is exactly how a real analyser's video averaging finds a signal under
the floor -- and why "below the noise floor" is a statement about a
measurement bandwidth and an integration time, not an absolute.

PURELY ADDITIVE: no stream output, a second connection alongside the signal
path rather than inside it, and a slow publish cadence. It cannot affect
decode timing or TX pacing.
"""

import numpy as np
import pmt
from gnuradio import gr


class blk(gr.sync_block):
    """PSD Probe (averaged power spectrum for the spectrum-analyser demo)"""

    def __init__(self, fft_size=256, n_average=200, out_bins=128,
                 publish_period_s=1.0, samp_rate=4092000.0):
        gr.sync_block.__init__(self, name='PSD Probe',
                               in_sig=[np.complex64], out_sig=[])
        self.fft_size = int(fft_size)
        self.n_average = max(1, int(n_average))
        self.out_bins = min(int(out_bins), int(fft_size))
        self.publish_period_s = float(publish_period_s)
        self.samp_rate = float(samp_rate)

        # Hann window, with its coherent gain divided out so the reported
        # levels are absolute (dBFS) rather than "dB relative to whatever this
        # window happened to do".
        self._win = np.hanning(self.fft_size).astype(np.float32)
        self._win_gain = float(np.sum(self._win ** 2)) / self.fft_size

        self._acc = np.zeros(self.fft_size, dtype=np.float64)
        self._frames = 0
        self._buf = np.empty(0, dtype=np.complex64)
        self._last_pub = 0.0
        self._captures = 0

        self.message_port_register_out(pmt.intern('psd'))

    def work(self, input_items, output_items):
        import time
        in0 = input_items[0]
        n = len(in0)
        if n == 0:
            return 0

        self._buf = np.concatenate([self._buf, in0])
        nframes = len(self._buf) // self.fft_size
        if nframes:
            frames = self._buf[:nframes * self.fft_size].reshape(
                nframes, self.fft_size)
            spec = np.fft.fftshift(
                np.fft.fft(frames * self._win, axis=1), axes=1)
            self._acc += np.sum(np.abs(spec) ** 2, axis=0)
            self._frames += nframes
            self._buf = self._buf[nframes * self.fft_size:]

        now = time.monotonic()
        if (self._frames >= self.n_average
                and now - self._last_pub >= self.publish_period_s):
            self._publish()
            self._last_pub = now
        return n

    def _publish(self):
        psd = self._acc / (self._frames * self.fft_size * self._win_gain)
        self._acc = np.zeros(self.fft_size, dtype=np.float64)
        frames = self._frames
        self._frames = 0
        self._captures += 1

        # Bin down so one spectrum fits comfortably in a UDP datagram.
        # Averaging within each output bin, not decimating -- decimating would
        # throw away exactly the averaging that makes a buried signal visible.
        group = self.fft_size // self.out_bins
        binned = psd[:self.out_bins * group].reshape(self.out_bins, group
                                                     ).mean(axis=1)
        db = 10.0 * np.log10(np.maximum(binned, 1e-30))

        total = float(np.mean(psd))
        text = ('PSD n=%d frames=%d bw=%.0f total_dbfs=%.2f bins=%s'
                % (self.out_bins, frames, self.samp_rate,
                   10.0 * np.log10(max(total, 1e-30)),
                   ','.join('%.2f' % v for v in db)))
        try:
            data = text.encode('utf-8')
            self.message_port_pub(
                pmt.intern('psd'),
                pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(data), list(data))))
        except Exception:
            pass
