"""
SNR Probe -- post-despread signal quality, measured without knowing the data
============================================================================

Replaces the earlier EVM Probe, and adds the measurement that one was standing
in for. Taps the carrier-recovered, pre-slicer QPSK symbols through a second,
purely additive connection: it sits alongside the signal path, not in it,
produces no stream output, and so cannot alter the existing Costas-loop to
slicer timing or buffering in any way.

Three numbers, because they disagree in informative ways
---------------------------------------------------------
EVM      RMS distance from the nearest ideal QPSK point, as a percentage of
         the ideal magnitude. The industry-standard figure, and the one to
         quote at an audience. Nearest point is chosen by quadrant, so the
         measurement is scale-invariant -- which matters because the despread
         correlation's amplitude is never normalised anywhere in this chain.

SNR(EVM) The SNR that EVM implies: -20*log10(EVM). Exact only when the error
         really is additive Gaussian. Carrier phase noise inflates EVM without
         being thermal noise, and this link runs a deliberately wide Costas
         loop because its symbol rate is so low, so this reads pessimistic.

SNR(M2M4) A moment-based estimator using only the second and fourth moments of
         the received symbols. It needs no decisions, no training sequence and
         no knowledge of the data, so unlike EVM it does not degrade when the
         slicer starts making mistakes. For a constant-modulus constellation
         in AWGN: S = sqrt(2*M2^2 - M4), N = M2 - S. Verified accurate to
         about 0.2 dB down to 3 dB SNR.

The gap between SNR(EVM) and SNR(M2M4) is itself diagnostic: they agree when
the impairment is thermal noise, and diverge when it is phase noise or a
residual frequency offset. That is worth seeing during a demo, which is why
both are published rather than just the prettier one.

WHAT THIS IS NOT
----------------
It is not a processing-gain measurement. Processing gain is the difference
between the SNR before despreading and the SNR after, so it needs both -- this
probe can only see "after". `demo.py 7` makes both measurements and reports
the gain; see dsss_link/metrics.py for why conflating the two produced a
readout that could never exceed 12 dB while being compared against 30.

Publishes on 'stats' every `period_symbols` symbols.
"""

import numpy as np
import pmt
from gnuradio import gr


class blk(gr.sync_block):
    """SNR / EVM Probe"""

    def __init__(self, period_symbols=500):
        gr.sync_block.__init__(self, name='SNR Probe',
                               in_sig=[np.complex64], out_sig=[])
        self.period_symbols = max(16, int(period_symbols))
        self._buf = np.empty(0, dtype=np.complex64)
        self.message_port_register_out(pmt.intern('stats'))

    def work(self, input_items, output_items):
        in0 = input_items[0]
        n = len(in0)
        if n == 0:
            return 0
        self._buf = np.concatenate([self._buf, in0])
        while len(self._buf) >= self.period_symbols:
            self._measure(self._buf[:self.period_symbols])
            self._buf = self._buf[self.period_symbols:]
        return n

    def _measure(self, s):
        s = s.astype(np.complex128)

        # --- EVM, nearest point by quadrant (scale-invariant) ---
        nearest = (np.where(np.real(s) >= 0, 1.0, -1.0)
                   + 1j * np.where(np.imag(s) >= 0, 1.0, -1.0)) / np.sqrt(2)
        denom = float(np.sum(np.abs(nearest) ** 2))
        evm_pct = float('nan')
        if denom > 0:
            alpha = float(np.sum(np.real(s * np.conj(nearest)))) / denom
            if alpha != 0:
                err = s - alpha * nearest
                ref = float(np.sqrt(np.mean(np.abs(alpha * nearest) ** 2)))
                if ref > 0:
                    evm_pct = 100.0 * float(
                        np.sqrt(np.mean(np.abs(err) ** 2))) / ref

        snr_evm = (-20.0 * np.log10(evm_pct / 100.0)
                   if np.isfinite(evm_pct) and evm_pct > 0 else float('nan'))

        # --- M2M4 moment estimator ---
        m2 = float(np.mean(np.abs(s) ** 2))
        m4 = float(np.mean(np.abs(s) ** 4))
        disc = 2.0 * m2 * m2 - m4
        if disc > 0:
            sig = np.sqrt(disc)
            noise = m2 - sig
            snr_m2m4 = 10.0 * np.log10(sig / noise) if noise > 0 else 99.0
        else:
            snr_m2m4 = -99.0

        text = ('QUALITY evm_pct=%.2f snr_evm_db=%.1f snr_m2m4_db=%.1f n=%d'
                % (evm_pct, snr_evm, snr_m2m4, len(s)))
        try:
            data = text.encode('utf-8')
            self.message_port_pub(
                pmt.intern('stats'),
                pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(data), list(data))))
        except Exception:
            pass
