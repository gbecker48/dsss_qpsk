#!/usr/bin/env python3
"""
demo.py -- one command per project requirement
==============================================

Each of the eight guidance points this project was given has exactly one run
that demonstrates it, produces numbers rather than impressions, and leaves a
folder behind that someone who was not in the room can read.

    python3 demo.py list            what the eight runs are
    python3 demo.py 1               run requirement 1
    python3 demo.py 1 2 7           run several
    python3 demo.py all             run all eight, ~5 minutes
    python3 demo.py all --quick     shorter sweeps, ~1 minute, for a rehearsal

Each run writes to demo_results/<timestamp>_req<N>_<name>/ containing:

    report.md      the requirement, the method, the numbers, the figures
    *.png          the figures
    *.csv          the underlying data, for replotting or a lab notebook
    data.json      every number the run produced
    console.log    everything that was printed

LIVE RUNS
---------
    python3 demo.py 7 --live

talks to a running flowgraph over the same UDP ports the ground station uses,
and measures what the radio actually did rather than what the simulation says
it would do. Start the flowgraph first. Demos that can use a live link say so
in `demo.py list`; the rest ignore the flag.

Offline runs are not a substitute for the hardware and are not presented as
one -- they exist because several of these requirements need forty operating
points to answer properly, and forty points on the bench is an afternoon per
curve. The simulation runs the same algorithms the flowgraph runs (see
dsss_link/dsss_core.py for the contract that keeps it honest), so the curve is
trustworthy and the live run pins it to reality.
"""

from __future__ import annotations

import argparse
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from demos.framework import Context, LinkClient, make_outdir, execute, BANNER
from demos.d1_code_tracking import D1
from demos.d2_spreading_factor import D2
from demos.d3_chip_vs_bit_rate import D3
from demos.d4_offset_compensation import D4
from demos.d5_full_duplex import D5
from demos.d6_spectrum import D6
from demos.d7_gain_and_ber import D7
from demos.d8_jamming import D8

DEMOS = {d.NUMBER: d for d in (D1(), D2(), D3(), D4(), D5(), D6(), D7(), D8())}


def cmd_list():
    print()
    print("  THE EIGHT REQUIREMENTS, AND THE RUN THAT DEMONSTRATES EACH")
    print("  " + "-" * 74)
    for n in sorted(DEMOS):
        d = DEMOS[n]
        radios = (f"  [{d.NEEDS_RADIOS} radios for a live run]"
                  if d.NEEDS_RADIOS else "")
        print(f"\n  {n}. {d.TITLE}{radios}")
        print(f"     requirement: {d.REQUIREMENT}")
        print(f"     run:         python3 demo.py {n}")
    print()
    print("  " + "-" * 74)
    print("  python3 demo.py all           every requirement, in order")
    print("  python3 demo.py all --quick   shorter sweeps, for a rehearsal")
    print("  python3 demo.py 7 --live      measure the running flowgraph")
    print()


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="Demonstrate each project requirement, one run each.",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("which", nargs="*", default=["list"],
                    help="requirement number(s), 'all', or 'list'")
    ap.add_argument("--live", action="store_true",
                    help="also measure a running flowgraph over UDP")
    ap.add_argument("--quick", action="store_true",
                    help="shorter sweeps -- for rehearsing, not for reporting")
    ap.add_argument("--outdir", default="demo_results",
                    help="where run folders are written (default: demo_results)")
    ap.add_argument("--host", default="127.0.0.1",
                    help="host the flowgraph is running on")
    ap.add_argument("--seed", type=int, default=12345,
                    help="random seed, so a run can be reproduced exactly")
    args = ap.parse_args(argv)

    if not args.which or args.which[0] in ("list", "-l", "--list"):
        cmd_list()
        return 0

    if args.which[0] == "all":
        numbers = sorted(DEMOS)
    else:
        numbers = []
        for w in args.which:
            try:
                n = int(w)
            except ValueError:
                print(f"not a requirement number: {w!r}", file=sys.stderr)
                return 2
            if n not in DEMOS:
                print(f"no requirement {n} (have 1-{max(DEMOS)})",
                      file=sys.stderr)
                return 2
            numbers.append(n)

    live = None
    if args.live:
        try:
            live = LinkClient(host=args.host)
            print("checking for a running flowgraph...")
            if live.alive(3.0):
                print("  flowgraph is transmitting -- live measurements enabled\n")
            else:
                print("  no status traffic on the flowgraph's ports.\n"
                      "  Start the flowgraph first, or drop --live to run the\n"
                      "  simulation only. Continuing offline.\n")
        except OSError as exc:
            print(f"  could not open the flowgraph's UDP ports ({exc}).\n"
                  f"  Is the ground station already running and holding them?\n"
                  f"  Continuing offline.\n")
            live = None

    os.makedirs(args.outdir, exist_ok=True)
    results = []
    t0 = time.time()
    for n in numbers:
        demo = DEMOS[n]
        outdir = make_outdir(args.outdir, n, demo.SLUG)
        ctx = Context(outdir=outdir, live=live, quick=args.quick,
                      seed=args.seed)
        results.append((n, demo, execute(demo, ctx), outdir))

    if len(results) > 1:
        print(BANNER)
        print(f"SUMMARY -- {len(results)} requirements in {time.time() - t0:.0f} s")
        print(BANNER)
        for n, demo, r, outdir in results:
            mark = "PASS" if r.passed else "LOOK"
            print(f"\n  [{mark}] {n}. {demo.TITLE}")
            print(f"         {r.headline}")
            print(f"         {outdir}")
        print()

    if live:
        live.close()
    return 0 if all(r.passed for _n, _d, r, _o in results) else 1


if __name__ == "__main__":
    sys.exit(main())
