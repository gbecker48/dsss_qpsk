#!/usr/bin/env python3
"""
build_flowgraphs.py -- push custom_blocks/*.py into the .grc files
===================================================================

A GRC embedded Python block keeps its source inside the .grc file, as a YAML
string. That makes the readable copies in `custom_blocks/` documentation
rather than code -- edit one and nothing happens, which is a footgun this
project's README has had to warn about for several versions.

This tool inverts that. `custom_blocks/*.py` becomes the source of truth, and
running

    python3 tools/build_flowgraphs.py

pushes each block's source into both flowgraphs, regenerates GRC's cached
introspection of the block's parameters and ports, applies the structural
changes listed in CHANGES below, and writes the sim flowgraph out of the same
definitions as the USRP one so the two cannot drift apart again. (They had:
the sim flowgraph was still on the v3 protocol with a 4-byte fragment header
and the strobe-timing bug the README describes as fixed.)

    python3 tools/build_flowgraphs.py --check

verifies the .grc files match the block sources without writing anything --
worth running before a commit, and what tests/test_flowgraph_sync.py calls.

HOW THE INTROSPECTION CACHE IS REGENERATED
-------------------------------------------
GRC stores an `_io_cache` string per embedded block holding the constructor's
parameters and defaults, the stream and message ports, the docstring summary,
and which parameters get runtime setters. Hand-editing it is error-prone and
getting it wrong means GRC silently shows the wrong ports.

So it is not hand-edited: each block is imported against the test shim in
tests/grshim.py, instantiated, and inspected. The ports come from what the
block actually registered, and a parameter is marked runtime-settable exactly
when the constructed object has an attribute of that name -- which is the rule
GRC itself uses, and the reason `search_margin` was never settable while
`code_len` was.
"""

from __future__ import annotations

import argparse
import copy
import inspect
import os
import sys
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "tests"))

import grshim  # noqa: E402

USRP_GRC = os.path.join(ROOT, "dsss_bpsk_usrp.grc")
SIM_GRC = os.path.join(ROOT, "dsss_bpsk_sim.grc")
BLOCKS = os.path.join(ROOT, "custom_blocks")

# grc block name -> custom_blocks file
BLOCK_SOURCES = {
    "dsss_despreader": "dsss_despreader.py",
    "dsss_spreader": "dsss_spreader.py",
    "fec_decoder": "fec_vote.py",
    "fec_encoder": "fec_repeat.py",
    "node_ctrl": "node_ctrl.py",
    "pkt_capture": "pkt_capture.py",
    "pkt_deframer": "pkt_deframer.py",
    "pkt_framer": "pkt_framer.py",
    "reassembler": "fragment_reassembler.py",
    "rx_health": "uhd_health_monitor.py",
    "tx_health": "uhd_health_monitor.py",
    "rx_power_probe": "rx_power_probe.py",
    "tx_scheduler": "tx_scheduler.py",
    "snr_probe": "snr_probe.py",
    "psd_probe": "psd_probe.py",
}

# How each block should be constructed for introspection -- only needed where
# a default would fail or would misrepresent the real ports.
INTROSPECT_ARGS = {
    "rx_health": dict(label="RX"),
    "tx_health": dict(label="TX"),
}


# ---------------------------------------------------------------------------
# Introspection
# ---------------------------------------------------------------------------

_TYPE_NAMES = {"complex64": "complex", "float32": "float", "int32": "int",
               "int16": "short", "uint8": "byte", "complex": "complex",
               "float": "float", "byte": "byte"}


def _sig_name(t):
    import numpy as np
    if t in (np.complex64, complex):
        return "complex"
    if t in (np.float32, float):
        return "float"
    if t is np.uint8:
        return "byte"
    if t is np.int16:
        return "short"
    if t is np.int32:
        return "int"
    return "complex"


def introspect(path, grc_name):
    """Import a block against the shim and read back what GRC needs to know."""
    mod = grshim.load_block(path)
    cls = mod.blk
    sig = inspect.signature(cls.__init__)

    params = []
    for name, prm in sig.parameters.items():
        if name == "self":
            continue
        default = prm.default
        if default is inspect.Parameter.empty:
            default = "0"
        params.append((name, repr(default) if not isinstance(default, str)
                       else repr(default)))

    inst = cls(**INTROSPECT_ARGS.get(grc_name, {}))

    inputs = []
    for i, t in enumerate(getattr(inst, "in_sig", []) or []):
        inputs.append((str(i), _sig_name(t), 1))
    for key in inst._msg_handlers:
        inputs.append((key.name, "message", 1))

    outputs = []
    for i, t in enumerate(getattr(inst, "out_sig", []) or []):
        outputs.append((str(i), _sig_name(t), 1))
    for key in inst._msg_out:
        outputs.append((key.name, "message", 1))

    doc = (cls.__doc__ or "").strip().splitlines()
    summary = doc[0].strip() if doc else grc_name

    # GRC makes a parameter runtime-settable exactly when the constructed
    # object carries an attribute of the same name. Computed rather than
    # listed, so it cannot drift when a constructor argument is renamed.
    callbacks = sorted(n for n, _d in params if hasattr(inst, n))

    io_cache = repr((cls.__name__ if cls.__name__ != "blk" else grc_name,
                     "blk", params, inputs, outputs, summary, callbacks))
    # GRC writes the block's display name first; take it from the gr block name
    # the constructor passed, which is what shows on the canvas.
    display = getattr(inst, "name_", grc_name)
    io_cache = repr((display, "blk", params, inputs, outputs, summary,
                     callbacks))

    return dict(source=open(path).read(), params=params, io_cache=io_cache,
                inputs=inputs, outputs=outputs, display=display)


# ---------------------------------------------------------------------------
# Structural changes applied on top of the original flowgraph
# ---------------------------------------------------------------------------

# Link profiles, inlined as a plain GRC dict so the flowgraph needs no imports
# to evaluate its own variables. tests/test_flowgraph_sync.py asserts this
# matches dsss_link/link_profiles.PROFILES, which is the canonical definition.
PROFILE_DICT = (
    "{'stealth':(1023,511500.0,8,2,4,5000.0,0.20),"
    "'standard':(1023,2046000.0,4,2,4,5000.0,0.20),"
    "'fast':(511,2046000.0,4,2,8,5000.0,0.25),"
    "'bulk':(127,1651000.0,4,2,8,5000.0,0.30)}"
)

NEW_VARIABLES = [
    ("tx_amp", "1.0", [1080, 24],
     "Transmitter output scaling, 0.0 to 1.0. Set live from the ground\n"
     "station (TXGAIN=) or by demo 6, which mutes the transmitter to take\n"
     "a noise-only reference capture and then restores it."),
    ("link_profile", "'stealth'", [40, 24],
     "Which operating point to run. 'stealth' is the original configuration:\n"
     "1023-chip code, 511.5 kcps, maximum hiding, about 100 bytes/second.\n"
     "'standard' and 'fast' trade spreading for rate; 'bulk' is the\n"
     "file-transfer profile, roughly 26x the payload rate of 'stealth'.\n"
     "See dsss_link/link_profiles.py and `python3 demo.py 3` for the trade.\n"
     "Change this and re-generate -- it cannot be changed while running,\n"
     "because sample rates and filter taps are built from it."),
    ("link_profiles", PROFILE_DICT, [160, 24],
     "(code_len, chip_rate, sps, search_margin, acq_epochs,\n"
     " freq_search_hz, parity_fraction) per profile.\n"
     "Mirrors dsss_link/link_profiles.py; a test asserts they agree."),
    ("search_margin", "link_profiles[link_profile][3]", [560, 24],
     "Despreader code-tracking window, in chips. Small on purpose: real\n"
     "clock drift is ~0.002 chips/symbol, and every extra chip of search\n"
     "is another chance for noise to win the argmax and destroy a symbol.\n"
     "Widening this to 30 costs about 5 dB of link margin -- see demo 1."),
    ("acq_epochs", "link_profiles[link_profile][4]", [680, 24],
     "Code periods integrated during acquisition. 1 false-locks up to 47%\n"
     "of the time at low SNR; 2 or more never does. See demo 1."),
    ("freq_search_hz", "link_profiles[link_profile][5]", [800, 24],
     "Acquisition also searches carrier frequency over +- this range.\n"
     "Two free-running B205mini-i TCXOs can sit 3.7 kHz apart at 915 MHz\n"
     "and the Costas loop only pulls in about 50 Hz, so without this the\n"
     "link needs a shared 10 MHz reference. Set 0 if you have one."),
    ("parity_fraction", "link_profiles[link_profile][6]", [940, 24],
     "Reed-Solomon erasure-coding overhead for file transfers. 0.20 means\n"
     "20% extra fragments, which lets a file survive ~15% fragment loss\n"
     "with no retransmission. Adjustable live from the ground station."),
]

VARIABLE_OVERRIDES = {
    "code_len": "link_profiles[link_profile][0]",
    "chip_rate": "link_profiles[link_profile][1]",
    "sps": "link_profiles[link_profile][2]",
    "frag_header_bytes": "12",
    "access_code_threshold": "8",
}

# Parameters for the rewritten blocks, as GRC expressions.
BLOCK_PARAM_VALUES = {
    "tx_scheduler": {
        "payload_bytes": "payload_bytes",
        "my_node_id": "my_node_id",
        "dest_node_id": "dest_node_id",
        "parity_fraction": "parity_fraction",
        "bert_enabled": "False",
    },
    "reassembler": {
        "payload_bytes": "payload_bytes",
        "stale_after": "256",
        "my_node_id": "my_node_id",
        "dest_node_id": "dest_node_id",
        "bert_report_bits": "100000",
    },
    "dsss_despreader": {
        "code_len": "code_len",
        "prn_taps": "node_prn_table[dest_node_id]",
        "search_margin": "search_margin",
        "acq_threshold": "3.0",
        "lock_loss_symbols": "500",
        "stats_period_symbols": "50",
        "acq_epochs": "acq_epochs",
        "track_hysteresis": "3.0",
        "track_threshold": "1.6",
        "chip_rate": "chip_rate",
        "freq_search_hz": "freq_search_hz",
    },
    "snr_probe": {"period_symbols": "500"},
    "psd_probe": {
        "fft_size": "256",
        "n_average": "200",
        "out_bins": "128",
        "publish_period_s": "1.0",
        "samp_rate": "samp_rate",
    },
    "node_ctrl": {"table_size": "16"},
}

# Message connections added for the new ports.
NEW_CONNECTIONS = [
    ["node_ctrl", "gain_msg", "msgpair_gain", "inpair"],
    ["snr_probe", "stats", "net_diag", "pdus"],
    ["psd_probe", "psd", "net_diag", "pdus"],
    ["tx_scheduler", "status", "net_rx_status", "pdus"],
    ["node_ctrl", "status", "net_rx_status", "pdus"],
    ["node_ctrl", "tx_ctrl", "tx_scheduler", "ctrl"],
]

REMOVED_CONNECTIONS = [
    ["evm_probe", "evm", "net_diag", "pdus"],
]


def _mk_block(name, blk_id, params, coord, comment=""):
    return {
        "name": name,
        "id": blk_id,
        "parameters": dict(params, comment=comment),
        "states": {"bus_sink": False, "bus_source": False,
                   "bus_structure": None, "coordinate": list(coord),
                   "rotation": 0, "state": "enabled"},
    }


# ---------------------------------------------------------------------------
# Building
# ---------------------------------------------------------------------------

def apply_changes(doc, introspected, variant):
    doc = copy.deepcopy(doc)
    blocks = {b["name"]: b for b in doc["blocks"]}

    # --- rename evm_probe -> snr_probe, in place, keeping its position ---
    if "evm_probe" in blocks:
        b = blocks.pop("evm_probe")
        b["name"] = "snr_probe"
        blocks["snr_probe"] = b
        doc["blocks"] = [x for x in doc["blocks"] if x["name"] != "evm_probe"]
        doc["blocks"].append(b)
        for c in doc["connections"]:
            if c[0] == "evm_probe":
                c[0] = "snr_probe"
                c[1] = "stats"
            if c[2] == "evm_probe":
                c[2] = "snr_probe"

    # --- add the PSD probe next to the RX power probe ---
    if "psd_probe" not in blocks:
        near = blocks.get("rx_power_probe")
        coord = list(near["states"]["coordinate"]) if near else [600, 1500]
        coord[1] = coord[1] + 120
        nb = _mk_block("psd_probe", "epy_block", {"affinity": "", "alias": "",
                                                  "maxoutbuf": "0",
                                                  "minoutbuf": "0"}, coord,
                       "Averaged power spectrum of the raw received samples.\n"
                       "Feeds demo 6's below-the-noise-floor measurement: the\n"
                       "ground station captures one spectrum with the\n"
                       "transmitter keyed and one with it off, and the\n"
                       "difference is the signal. Purely additive -- a second\n"
                       "connection off the source, no stream output.")
        doc["blocks"].append(nb)
        blocks["psd_probe"] = nb
        src = "usrp_source" if variant == "usrp" else "channel"
        doc["connections"].append([src, "0", "psd_probe", "0"])

    # --- transmitter gate -------------------------------------------------
    # A multiply-by-zero rather than the USRP's gain control, for two reasons:
    # it genuinely silences the transmitter (minimum normalised gain is not
    # zero output), and it works identically on both flowgraphs, so demo 6's
    # transmitter-off reference capture is the same measurement in simulation
    # and on the radio.
    if "tx_gate" not in blocks:
        sink = "usrp_sink" if variant == "usrp" else "throttle"
        gate = _mk_block("tx_gate", "blocks_multiply_const_vxx", {
            "const": "tx_amp", "maxoutbuf": "0", "minoutbuf": "0",
            "type": "complex", "vlen": "1"}, [1500, 700],
            "Transmitter gate. TXGAIN=0 from the ground station or from\n"
            "demo 6 mutes the transmitter completely, for a noise-only\n"
            "reference capture; TXGAIN=1 restores it. Also how demo 8 sets\n"
            "jammer-to-signal ratios without touching the radio's own gain.")
        doc["blocks"].append(gate)
        blocks["tx_gate"] = gate
        rewired = []
        for c in doc["connections"]:
            if c[0] == "tx_rrc" and c[2] == sink:
                rewired.append(["tx_gate", "0", sink, "0"])
                c[2], c[3] = "tx_gate", "0"
        doc["connections"].extend(rewired)

        mp = _mk_block("msgpair_gain", "blocks_msgpair_to_var",
                       {"target": "tx_amp"}, [420, 1300],
                       "Routes the ground station's TXGAIN= command to the\n"
                       "tx_amp variable.")
        doc["blocks"].append(mp)
        blocks["msgpair_gain"] = mp

    # --- variables ---
    existing = {b["name"] for b in doc["blocks"]}
    for name, value, coord, comment in NEW_VARIABLES:
        if name in existing:
            blocks[name]["parameters"]["value"] = value
            blocks[name]["parameters"]["comment"] = comment
        else:
            doc["blocks"].append(_mk_block(name, "variable", {"value": value},
                                           coord, comment))
    for name, value in VARIABLE_OVERRIDES.items():
        if name in blocks:
            blocks[name]["parameters"]["value"] = value

    # --- embedded block sources, parameters and io caches ---
    for grc_name, info in introspected.items():
        b = blocks.get(grc_name)
        if b is None:
            continue
        b["parameters"]["_source_code"] = info["source"]
        b["states"]["_io_cache"] = info["io_cache"]
        wanted = BLOCK_PARAM_VALUES.get(grc_name)
        if wanted is not None:
            keep = {k: v for k, v in b["parameters"].items()
                    if k in ("_source_code", "affinity", "alias", "comment",
                             "maxoutbuf", "minoutbuf")}
            keep.update(wanted)
            b["parameters"] = keep
        else:
            # Drop parameters the constructor no longer takes.
            valid = {n for n, _d in info["params"]}
            b["parameters"] = {
                k: v for k, v in b["parameters"].items()
                if k in valid or k in ("_source_code", "affinity", "alias",
                                       "comment", "maxoutbuf", "minoutbuf")}
            for n, d in info["params"]:
                b["parameters"].setdefault(n, d.strip("'"))

    # --- connections ---
    conns = [c for c in doc["connections"]
             if list(c) not in [list(r) for r in REMOVED_CONNECTIONS]]
    have = {tuple(c) for c in conns}
    for c in NEW_CONNECTIONS:
        if tuple(c) not in have and c[0] in blocks and c[2] in blocks:
            conns.append(list(c))
    # Sort by the FULL connection tuple, not a partial key. Connections are
    # de-duplicated through a set above, whose iteration order varies per
    # process (string hashing is randomised), so a partial sort key leaves
    # ties in an arbitrary order and the file fails to reproduce. Sorting on
    # everything makes the output byte-stable across runs, which is what the
    # --check test relies on.
    doc["connections"] = sorted(([str(x) for x in c] for c in conns))
    return doc


def make_sim(usrp_doc, introspected):
    """Derive the simulation flowgraph from the USRP one.

    Built rather than maintained, because the two had already drifted: the sim
    flowgraph was several versions behind, still using a 4-byte fragment
    header and the 1.3x strobe period this project's README describes as a
    fixed bug. Generating it from one definition is what stops that recurring.
    """
    doc = copy.deepcopy(usrp_doc)
    doc["options"]["parameters"]["id"] = "dsss_bpsk_sim"
    doc["options"]["parameters"]["title"] = (
        "GPS-Style DSSS + QPSK Continuous Comms Link (Simulated Channel)")
    doc["options"]["parameters"]["description"] = (
        "GPS-style long-code DSSS + QPSK continuous comms link, simulated "
        "channel -- no radio required")
    doc["options"]["parameters"]["comment"] = (
        "Simulated-channel variant. GENERATED from dsss_bpsk_usrp.grc by\n"
        "tools/build_flowgraphs.py -- edit the USRP flowgraph or the files in\n"
        "custom_blocks/ and re-run that tool rather than editing this file,\n"
        "or the two will drift apart again.\n\n"
        "Identical DSP chain to the USRP variant; the uhd_usrp_sink /\n"
        "uhd_usrp_source pair is replaced by channels.channel_model plus a\n"
        "throttle, with sliders for noise, frequency offset and clock skew.\n"
        "Run this one first -- it needs no hardware and the ground station\n"
        "works against it exactly as it does against the radio.")

    blocks = {b["name"]: b for b in doc["blocks"]}
    drop = {"usrp_source", "usrp_sink", "tx_health", "rx_health"}
    doc["blocks"] = [b for b in doc["blocks"] if b["name"] not in drop]
    doc["connections"] = [c for c in doc["connections"]
                          if c[0] not in drop and c[2] not in drop]

    # Simulation-only variables and controls.
    sim_vars = [
        ("noise_voltage", "2.0", [40, 300],
         "AWGN level in the simulated channel. The default puts the signal\n"
         "well below the noise floor per chip -- watch the BEFORE-despread\n"
         "plots show nothing while the constellation stays clean."),
        ("freq_offset_hz", "0", [180, 300],
         "Simulated carrier frequency offset between the two ends."),
        ("timing_epsilon", "1.0", [320, 300],
         "Simulated sample-clock ratio. 1.0 is a perfect clock; 1.000002 is\n"
         "about what two real TCXOs differ by."),
        ("freq_offset_norm", "freq_offset_hz/samp_rate", [460, 300], ""),
    ]
    existing = {b["name"] for b in doc["blocks"]}
    for name, value, coord, comment in sim_vars:
        if name not in existing:
            doc["blocks"].append(_mk_block(name, "variable", {"value": value},
                                           coord, comment))

    for name, (lo, hi, step, default, label) in {
            "noise_voltage": (0, 20, 0.1, 2.0, "Noise Voltage"),
            "freq_offset_hz": (-150, 150, 1, 0, "Frequency Offset (Hz)"),
            "timing_epsilon": (0.999, 1.001, 0.000001, 1.0,
                               "Timing Offset (clock epsilon)")}.items():
        rng_name = name + "_range"
        if rng_name in existing:
            continue
        doc["blocks"].append(_mk_block(
            rng_name, "variable_qtgui_range",
            {"gui_hint": "", "label": f"'{label}'", "min_len": "200",
             "orient": "QtCore.Qt.Horizontal", "rangeType": "float",
             "start": str(lo), "step": str(step), "stop": str(hi),
             "value": str(default), "widget": "counter_slider"},
            [40, 400], ""))

    ch = _mk_block("channel", "channels_channel_model", {
        "block_tags": "False", "epsilon": "timing_epsilon",
        "freq_offset": "freq_offset_norm", "maxoutbuf": "0", "minoutbuf": "0",
        "noise_voltage": "noise_voltage", "seed": "0", "taps": "1.0 + 1.0j",
    }, [1000, 1000],
        "The whole RF world, simulated: AWGN, carrier offset and clock skew.\n"
        "Everything the USRP variant gets from the air, on three sliders.")
    thr = _mk_block("throttle", "blocks_throttle2", {
        "ignoretag": "True", "limit": "auto", "maximum": "0.1",
        "maxoutbuf": "0", "minoutbuf": "0", "samples_per_second": "samp_rate",
        "type": "complex", "vlen": "1",
    }, [860, 1000],
        "Paces the simulation to real time. The USRP variant does not need\n"
        "this -- there the radio sets the pace.")
    doc["blocks"] += [ch, thr]

    doc["connections"] += [
        # tx_gate, not tx_rrc: the transmitter gate sits between the pulse
        # shaper and whatever consumes the waveform, so TXGAIN=0 mutes the
        # simulated transmitter exactly as it mutes the radio.
        ["tx_gate", "0", "throttle", "0"],
        ["throttle", "0", "channel", "0"],
        ["channel", "0", "rx_mf", "0"],
        ["channel", "0", "gui_before_freq", "0"],
        ["channel", "0", "gui_before_waterfall", "0"],
        ["channel", "0", "rx_power_probe", "0"],
        ["channel", "0", "psd_probe", "0"],
    ]
    doc["connections"] = sorted(
        {tuple(str(x) for x in c) for c in doc["connections"]})
    doc["connections"] = [list(c) for c in doc["connections"]]
    return doc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true",
                    help="verify without writing")
    args = ap.parse_args()

    introspected = {}
    for grc_name, fname in BLOCK_SOURCES.items():
        path = os.path.join(BLOCKS, fname)
        if not os.path.exists(path):
            print(f"  missing block source: {path}", file=sys.stderr)
            return 2
        introspected[grc_name] = introspect(path, grc_name)

    usrp = yaml.safe_load(open(USRP_GRC))
    new_usrp = apply_changes(usrp, introspected, "usrp")
    new_sim = make_sim(new_usrp, introspected)

    def dump(doc):
        return yaml.safe_dump(doc, sort_keys=False, default_flow_style=False,
                              width=100000, allow_unicode=True)

    if args.check:
        ok = True
        for path, doc in ((USRP_GRC, new_usrp), (SIM_GRC, new_sim)):
            cur = yaml.safe_load(open(path)) if os.path.exists(path) else None
            if cur != doc:
                print(f"  OUT OF DATE: {os.path.basename(path)}")
                ok = False
            else:
                print(f"  up to date:  {os.path.basename(path)}")
        return 0 if ok else 1

    for path, doc in ((USRP_GRC, new_usrp), (SIM_GRC, new_sim)):
        with open(path, "w") as f:
            f.write(dump(doc))
        nb = len(doc["blocks"])
        nc = len(doc["connections"])
        print(f"  wrote {os.path.basename(path)}: {nb} blocks, "
              f"{nc} connections")
    print("\n  Open either flowgraph in gnuradio-companion and hit Generate "
          "to rebuild its .py,\n  or run the pre-generated .py directly.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
