# Wire protocol and file transfer

The canonical definition is `dsss_link/protocol.py`. This document explains the
format and the reasoning; the code is the authority, and the GNU Radio blocks
carry byte-identical copies that a test
(`tests/run_tests.py::test_tx_rx_plan_agreement`) keeps honest.

## Frame

Outermost first, this is what goes over the air per fragment:

```
[ SYNC 8B (fixed, never scrambled) ][ SEQ 1B ][ PAYLOAD 256B ][ CRC32 4B ]
                                    \____________ scrambled ____________/
```

- **SYNC** is a fixed 64-bit word the receiver's access-code correlator
  searches for. It is never scrambled, because it has to be a literal byte
  pattern to find.
- **SEQ** is a rolling low-level packet counter, for diagnostics only.
- **PAYLOAD** carries the fragment (below). Fixed at 256 bytes.
- **CRC32** covers SEQ+PAYLOAD. A fragment that fails it is *discarded* — which
  is what makes the erasure coding an erasure problem rather than an error
  problem (see below).

This layer is unchanged from the original design and lives in
`custom_blocks/pkt_framer.py` / `pkt_deframer.py`.

## Fragment header (v2)

12 bytes at the head of every 256-byte payload:

```
off  size  field       meaning
0    1     SRC         sending node id
1    1     DST         destination node id, or 0xFF broadcast
2    1     TYPE        IDLE=0 / DATA=1 / PARITY=2 / BERT=3
3    1     MSG_ID      rolling message id, wraps at 256
4    2     FRAG_IDX    fragment index within its class (big-endian)
6    2     N_DATA      total data fragments in this message
8    2     N_PARITY    total parity fragments in this message
10   2     CHUNK_LEN   valid data bytes in this fragment
12   244   DATA        the fragment payload
```

### What changed from v1, and why

The v1 header used single bytes for the fragment index and total, capping a
message at 256 fragments — about 64 KB. That is fine for chat and a hard wall
for files. Three changes lifted it:

1. **16-bit FRAG_IDX and N_DATA** raise the ceiling to 65 535 fragments, about
   **16 MB** — past anything this link's data rate makes reasonable anyway.
2. **A TYPE field** lets parity fragments and BER test patterns share the same
   framing instead of needing separate channels.
3. **N_PARITY on every fragment** means a receiver can reconstruct the whole
   erasure-coding layout from any single fragment it catches — no setup
   handshake, and a receiver that joins mid-transfer still knows what it is
   looking at.

IDLE frames keep their v1 meaning (TYPE=IDLE, N_DATA=0). The physical layer
never goes quiet, because a despreader that has to re-acquire every time the
transmitter pauses spends its life re-acquiring.

## Reed-Solomon erasure coding

This link has no retransmission. Without protection, a single lost fragment
loses the whole message it belonged to — fatal for a file, which is thousands
of fragments. Erasure coding fixes that with no reverse channel.

### The scheme

Systematic Reed-Solomon over GF(256), applied **across** fragments. For `k`
data fragments and `m` parity fragments, byte *j* of each of the `k` data
fragments is treated as a codeword of length `k`, extended to `k+m` with a
Vandermonde generator; byte *j* of each parity fragment is one of the extra
symbols. Every byte position is an independent codeword, all computed at once
with NumPy.

**Any `k` of the `k+m` fragments reconstruct the original `k`.** That is the
guarantee, and it holds exactly because a Vandermonde matrix on distinct points
has every square submatrix invertible.

### Why erasures, not errors

Because the frame CRC has already done the hard part. A corrupted fragment is
discarded, not passed up half-broken, so the decoder always knows *which*
fragments are missing — their positions are known and only their values are
unknown. That is the erasure case, and it is twice as efficient as error
correction: `m` parity fragments recover `m` erasures but only `m/2` errors.

### Block striping

GF(256) addresses at most 255 fragments, so a file is split into RS blocks of
at most 200 data fragments each, with parity allocated across the blocks by
largest-remainder apportionment. Both ends derive the identical layout from
`(N_DATA, N_PARITY)` alone — the two numbers every fragment carries — so there
is nothing to negotiate. Deriving the layout from the parity *fraction* instead
looks equivalent and is not: the two ends round differently and every decode
fails. That was a real bug on the way to this version; the fix is that the
layout is a pure function of the two integer totals
(`dsss_link/erasure_fec.py::plan`).

### Measured

With the default 20% parity, a file survives roughly **10–15% fragment loss**
and still verifies bit-exact. Uniform loss lands unevenly across RS blocks, so
15% is marginal (one block can exceed its budget by variance); 10% is the
reliable figure. Raise the parity for a worse link.

## File transfer

A file becomes a message payload:

```
[ MAGIC "DSF1" 4B ][ VER 1B ][ FLAGS 1B ][ NAME_LEN 2B ][ SIZE 8B ]
[ SHA256 32B ][ NAME ][ FILE DATA ]
```

The SHA-256 is inside the payload, so it is covered by the same erasure coding
as the file — a lost header fragment is reconstructed like any other, rather
than being a single point of failure.

### Two integrity checks, two different questions

- The **CRC32** in each frame proves each *fragment* arrived intact.
- The **SHA-256** over the whole file proves the *reassembled, erasure-decoded*
  file is the file that was sent.

Those are different claims. A file is written to disk only after the SHA-256
matches; a mismatch is reported as a failure, never quietly saved. A silently
corrupt file is worse than no file.

## BER test pattern (PRBS-15)

TYPE=BERT fragments carry a PRBS-15 sequence (x¹⁵ + x¹⁴ + 1, the ITU-T O.150
pattern). The receiver seeds its own generator from the received bits and then
*predicts* every subsequent bit; any mismatch is a genuine channel bit error,
counted over an unbounded run with nothing stored on either side.

The receiver re-syncs whenever it loses lock, and reports "sync lost" rather
than a meaningless ~0.5 BER when the link drops — because no channel produces a
*correlated* half of the bits wrong; that is what loss of sync looks like, and
reporting it as a BER would be a lie.

Every BER is reported with a bit count and a 95% confidence interval, because a
ratio alone says nothing about how well it is known. Three errors in ten
thousand bits and three thousand in ten million are the same BER and very
different measurements. A credible 1e-5 measurement takes about 10 million bits
(`dsss_link/metrics.py::bits_needed_for_ber`).

## Status line grammar

The flowgraph emits UTF-8 status lines the consoles parse. This is a frozen
contract — adding keys is safe (parsing is lenient), renaming or reordering is
not.

```
FRAG msg= idx= type= data= parity= have= seq= len= src= dst=
IDLE seq= src= dst=
DONE msg= fragments= bytes= src= recovered=
INCOMPLETE msg= missing= blocks_lost=
FOREIGN src= dst= msg= (...)
WARN unexpected src= ...
BERT errors= bits= ber= synced=
TXQUEUE msg= bytes= data= parity= overhead=
```

Diagnostics port (telemetry):

```
LOCK state= cfo_hz= code_phase=
SNR symbol_db= psr_db= cfo_hz= drift= slips= locked=
QUALITY evm_pct= snr_evm_db= snr_m2m4_db= n=
RXPOWER dbfs=
FEC corrected= pct=
PSD n= frames= bw= total_dbfs= bins=
```

## UDP ports

| Port | Direction | Carries |
|---|---|---|
| 52001 | console → flowgraph | outgoing messages (whole, one datagram) |
| 52002 | flowgraph → console | complete reassembled messages |
| 52003 | flowgraph → console | status lines |
| 52004 | console → flowgraph | NODE= DEST= TXGAIN= BERT= PARITY= |
| 52005 | flowgraph → console | diagnostics telemetry |
| 52010 | demo → jammer | JSR= WAVEFORM= AMP= OFF (jammer control) |
