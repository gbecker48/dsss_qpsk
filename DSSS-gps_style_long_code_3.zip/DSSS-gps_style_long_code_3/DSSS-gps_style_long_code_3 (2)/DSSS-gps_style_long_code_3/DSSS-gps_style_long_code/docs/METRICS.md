# Metrics reference

Every SNR, gain and error figure this project reports is defined in
`dsss_link/metrics.py`. This document explains what each one means and, more
importantly, how to avoid confusing the ones that look alike. This project had
a mislabelled metric, and a mislabelled metric is worse than a missing one
because it gets believed.

## The three SNRs

Confusing these is the single easiest way to report a wrong number, so they
have distinct names everywhere in the codebase.

| Name | Where it is measured | Typical value on this link |
|---|---|---|
| **chip SNR** (`snr_chip_db`) | in the spread bandwidth — what a spectrum analyser sees | **negative**, around −19 dB |
| **symbol SNR** (`snr_symbol_db`) | after the correlator collapses 1023 chips into one symbol | around +11 dB |
| **Eb/N0** (`ebn0_db`) | per information bit — what BER curves plot against | symbol SNR − 3 dB, for QPSK |

The chip SNR is negative because the signal is genuinely below the noise floor
in its own bandwidth — that is the point of the link. The correlator's
processing gain is exactly the difference between chip SNR and symbol SNR.

Conversions:

```
esn0_to_ebn0_db(esn0, rate)          Es/N0 -> Eb/N0  (QPSK: -3 dB, before FEC)
symbol_snr_to_chip_snr_db(snr, L)    after -> before despreading (-10log10 L)
chip_snr_to_symbol_snr_db(snr, L)    before -> after
```

## Processing gain — and the metric that was wrong

Processing gain is the SNR improvement the spreading buys. It is the difference
between two measurements — the SNR before despreading and the SNR after — so
computing it *needs both*:

```
processing_gain_db(snr_symbol_db, snr_chip_db)   # = symbol - chip
ideal_processing_gain_db(code_len)               # = 10*log10(code_len) = 30.1 dB
```

### What went wrong before

An earlier version reported the correlation peak divided by its neighbouring
correlations as "processing gain, actual", alongside 10·log10(1023) = 30.1 dB
as "ideal", inviting the reader to treat the difference as implementation loss.

Those are **different quantities**. Peak-over-neighbours is the code's
**peak-to-sidelobe ratio**. For a length-1023 Gold code the sidelobes are
pinned at 65, so this number saturates — at 10·log10(1023/65) = **12.0 dB** as
the original computed it, or 23.9 dB expressed correctly as 20·log10 of an
amplitude ratio. Either way it can *never* approach 30 dB, even on a perfect
noiseless link. The apparent 18 dB shortfall was an artefact of comparing two
different measurements, not a property of the receiver.

Peak-to-sidelobe is a real and useful number — it tells you the correlator is
sitting on the peak — but it is a **lock-quality indicator, not the gain**. It
now appears under its own name (`peak_to_sidelobe_db`), and processing gain is
derived properly. `demo.py 7` measures the gain three independent ways (from
the code length, from before/after SNR, and from tolerable channel noise
versus an unspread link) and shows them agreeing at ~30 dB.

## SNR estimators that work on live samples

Two estimators run on the recovered symbols, and the gap between them is itself
informative — they agree under thermal noise and diverge under phase noise or a
residual frequency offset.

- **EVM** (`evm_percent`) — RMS error from the nearest ideal QPSK point, by
  quadrant so it is scale-invariant. The standard figure to quote. Its implied
  SNR (`evm_to_snr_db` = −20·log10(EVM)) is exact only under additive Gaussian
  noise; carrier phase jitter inflates EVM, so on this link's deliberately wide
  Costas loop it reads pessimistic.
- **M2M4** (`snr_m2m4_db`) — a moment-based estimator using only the second and
  fourth moments of the symbols. Needs no decisions, no training and no data
  knowledge, so unlike EVM it does not degrade when the slicer starts making
  mistakes. Verified accurate to ~0.2 dB down to 3 dB SNR.

## BER

```
qpsk_ber_theory(ebn0)     coherent Gray QPSK: Q(sqrt(2 Eb/N0))
dqpsk_ber_theory(ebn0)    differentially DECODED coherent QPSK: ~2x the above
ber_confidence_interval(errors, bits)   95% interval (rule of three at 0 errors)
bits_needed_for_ber(target)             bits for a credible measurement
implementation_loss_from_ber(ber, ebn0) dB this receiver needs beyond theory
```

Two points worth stating:

- **This link is differentially decoded, not differentially detected.** The
  carrier is recovered coherently by the Costas loop; the differential decoding
  only resolves that loop's four-fold phase ambiguity. So a symbol error
  corrupts the decisions on both sides of it and the BER roughly doubles —
  costing ~0.3 dB, not the ~2.3 dB that true differential detection costs.
  `dqpsk_ber_theory` is the right curve to compare against, and the demos do.
- **A BER without a bit count is not a measurement.** Every reported BER
  carries an error count and a confidence interval. Zero errors uses the rule
  of three (upper bound 3/n), because "BER = 0" is never a result — only a
  statement that the run was too short to see an error.

Measured implementation loss on this link is about **0.5 dB** across the usable
range — the receiver runs within half a dB of differentially-decoded QPSK
theory. Before the despreader fixes (see below) it was 5–6 dB.

## Jamming

```
jamming_margin_db(code_len)              Gp - (Eb/N0 required) + modulation gain
jsr_to_effective_esn0_db(...)            effective Es/N0 with a jammer added
```

The jamming margin — how much stronger than the signal a wideband jammer can be
before the link fails — is about **20 dB** for this link. `demo.py 8` measures
it for four jammer types, because DSSS suppresses each differently: a CW tone by
nearly the full processing gain, broadband noise by only the processing gain,
and partial-band noise by less than either (concentrating power in less
bandwidth raises the fraction that survives despreading).

## What the despreader fixes changed

Three defects were found and fixed in the despreader while building the
measurement framework. They are documented here because they moved the numbers:

1. **Acquisition false-lock.** A single code period straddles two data symbols
   that can partly cancel, letting a noise bin win the code-phase search — up
   to 47% of the time at 10 dB Es/N0. Integrating several code periods
   non-coherently drops it to 0%. (This is almost certainly the origin of the
   original "first message sometimes gets lost, just resend it" behaviour.)
2. **Tracking slips.** The original ±30-chip search took the argmax every
   symbol, so noise won often enough to destroy ~2% of symbols and floor the
   BER 5–6 dB above where the SNR said it should be. Narrowing the window to
   ±2 chips (real drift is ~0.002 chips/symbol) with hysteresis toward the
   prediction recovers that margin — and runs 3× faster, which is what makes
   the higher-rate profiles possible.
3. **Mislabelled processing gain**, described above.

All three are covered by `tests/run_tests.py` and demonstrated in `demo.py 1`
and `demo.py 7`.
