# Architecture

How the pieces fit together, and the one structural idea that ties them: the
readable Python in `dsss_link/` and `custom_blocks/` is the source of truth,
and everything else is generated from it or tested against it.

## The layers

```
                        demo.py  ─── one command per requirement
                           │         writes demo_results/<run>/{report.md,*.png,*.csv}
                           │
     ground_station.py ────┤          terminal.py
     (PyQt5 console)       │          (scriptable console)
     file xfer, metrics,   │          same features, text
     demo launcher         │
                           │  UDP :52001-5
                    ┌──────┴──────┐
                    │  flowgraph  │   dsss_bpsk_usrp.grc  (real radios)
                    │             │   dsss_bpsk_sim.grc   (simulated channel)
                    └──────┬──────┘
                           │  embedded Python blocks
                    custom_blocks/*.py
                           │
                    dsss_link/   ─── the shared, importable DSP + protocol
                      dsss_core, link_profiles, erasure_fec,
                      protocol, metrics, filexfer

     jammer.py  ─── third radio, interference source (requirement 8)
     tests/     ─── offline verification of all of the above
     tools/     ─── build_flowgraphs.py: pushes blocks into the .grc
```

## The source-of-truth idea

A GNU Radio embedded Python block stores its source *inside* the `.grc` file,
as a YAML string. That makes the readable copies in `custom_blocks/`
documentation rather than code — edit one and nothing happens. The original
project had to warn about this in its README for several versions.

This revision inverts it. `custom_blocks/*.py` are the real source, and
`tools/build_flowgraphs.py` pushes them into both flowgraphs, regenerating
GRC's cached block introspection by actually importing each block and reading
back its ports and parameters. So:

- You edit a block in `custom_blocks/`, run `python3 tools/build_flowgraphs.py`,
  and both `.grc` files are updated with the new source and correct ports.
- `python3 tools/build_flowgraphs.py --check` verifies they are in sync, and a
  test (`test_flowgraphs_in_sync`) fails if they drift.
- The simulation flowgraph is *generated* from the USRP one, so the two cannot
  diverge. (They had: the sim flowgraph was several versions behind, still on
  the v3 protocol with a 4-byte fragment header and the strobe-timing bug the
  README described as fixed.)

The same discipline runs deeper: the Gold-code generator, the RS plan, and the
protocol constants all exist once in `dsss_link/` and are duplicated into the
self-contained blocks only where GRC forces it — with tests asserting the
copies stay byte-identical.

## dsss_link/ — the shared library

Pure Python (NumPy only), importable, hardware-free. This is what makes the
offline demos legitimate: they run the same algorithms the radio runs.

| Module | What it is |
|---|---|
| `dsss_core.py` | The DSP: Gold codes, spreader, the acquisition+tracking despreader, RRC shaping, differential QPSK, Costas loop, and an AWGN/CFO/clock-drift channel. Every algorithm the flowgraph performs, in reference form. |
| `link_profiles.py` | The four operating points (stealth/standard/fast/bulk) and the chip-rate/bit-rate trade between them. |
| `erasure_fec.py` | GF(256) Reed-Solomon erasure coding across fragments. |
| `protocol.py` | The wire format: fragment header, file payload, PRBS BERT, RS layout derivation. |
| `metrics.py` | Every SNR/gain/BER/jamming figure, defined once. |
| `filexfer.py` | Host-side file send/receive with progress and SHA-256 verification. |

The contract that keeps the offline work honest is
`tests/run_tests.py::test_despreader_block_matches_core`: it runs the GNU Radio
block (through a shim) and the reference despreader on the same input and
asserts they produce identical symbols.

## custom_blocks/ — the GNU Radio blocks

The embedded Python blocks. The signal-path ones (spreader, despreader,
framer/deframer, scheduler, reassembler, capture) plus the additive probes
(SNR, PSD, RX power, UHD health) and control (node control, FEC).

Each is self-contained because GRC requires it. `tests/grshim.py` provides
enough of the GNU Radio runtime (basic_block, sync_block, tags, message ports,
and a scheduler that drives `general_work` with varying chunk sizes) to run and
test them without GNU Radio installed — which is how the consume/produce
accounting gets tested, since an off-by-one in `consume()` produces a block that
works in a notebook and slowly walks off the signal on hardware.

## The signal chain

```
TX:  message ─▶ TX Scheduler (fragment + RS erasure code + node address)
              ─▶ Packet Framer (sync + seq + CRC32 + scramble)
              ─▶ repack to bits ─▶ FEC ─▶ repack to dibits
              ─▶ differential encode ─▶ QPSK map
              ─▶ DSSS Spreader (× 1023-chip Gold code)
              ─▶ RRC shape ─▶ TX gate ─▶ [ channel / USRP sink ]

RX:  [ USRP source / channel ] ─▶ RRC matched filter
              ─▶ DSSS Despreader   ← acquisition + tracking, BEFORE carrier
                                     recovery: the processing gain is applied
                                     first, so the Costas loop sees a signal
                                     that is already above the noise
              ─▶ Costas loop ─▶ QPSK slice ─▶ differential decode
              ─▶ repack ─▶ FEC vote ─▶ access-code correlate
              ─▶ Packet Capture ─▶ Deframer (descramble + CRC)
              ─▶ Fragment Reassembler (RS decode + verify) ─▶ message
```

Despreading happens **before** carrier recovery, and that ordering is the crux
of the design: a Costas loop cannot lock onto a signal it cannot see, so the
~30 dB of processing gain has to be applied before anything tries to. This is
also how a GPS receiver structures its code and carrier loops.

## demos/ — the requirement demonstrations

`demo.py` is the entry point; `demos/framework.py` provides the shared
plumbing (result folders, plots in a validated colourblind-safe palette, the
live UDP client). Each `demos/dN_*.py` implements one requirement as a
self-contained run.

## Testing

`tests/run_tests.py` is a plain script (no pytest dependency) grouped by area:
`core`, `gold`, `rs`, `protocol`, `blocks`, `flowgraph`, `ber`, `jammer`,
`imports`. It checks the DSP against theory, the erasure coding against random
worst-case loss, the protocol round-trip, the block-vs-reference equivalence,
the flowgraph sync, and that every host module parses. Run it before any
change to the DSP or protocol:

```
python3 tests/run_tests.py
```
