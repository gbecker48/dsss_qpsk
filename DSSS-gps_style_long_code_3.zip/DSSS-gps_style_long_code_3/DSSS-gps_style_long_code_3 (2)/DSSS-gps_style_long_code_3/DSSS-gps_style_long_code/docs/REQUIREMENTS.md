# Requirements traceability

Each of the eight guidance points, the one command that demonstrates it, the
code that implements it, and the headline number the run produces. Every number
here comes from `python3 demo.py all`; re-run it and the run's own `report.md`
will carry the same figures (they are deterministic under the default seed).

The point of this table is that a demo is not a slideshow. For each requirement
there is a single command that produces a result folder with a written report,
figures, and the raw data behind them — so "it's done" is something you can
show, not just assert.

| # | Requirement | Demo | Implemented in | Result |
|---|---|---|---|---|
| 1 | Receiver aligns its PN code in time and tracks to hold lock | `demo.py 1` | `custom_blocks/dsss_despreader.py` | Acquires the exact chip (correlation peak ~4× the noise floor); tracks through **200 ppm** of clock drift, 100× worse than the hardware; multi-epoch acquisition drops false-lock from **47% to 0%** |
| 2 | Use a high spreading factor | `demo.py 2` | `dsss_link/dsss_core.py` (`gold_code`) | **1023 chips/symbol**, verified Gold code: exact period 1023, 512/511 balance, three-valued autocorrelation {−65, −1, 63}, all 16 node codes checked |
| 3 | Calculate chip rate vs bit rate for an SNR improvement | `demo.py 3` | `dsss_link/metrics.py`, `link_profiles.py` | Rc/Rs = 1023 → **30.1 dB** at the correlator; Rc/Rb = 511.5 → 27.1 dB Eb/N0 gain; predicted gain matches measured to **within 0.4 dB** across a 16× range |
| 4 | Decide if CFO and timing-drift compensation is needed | `demo.py 4` | `dsss_despreader.py` (frequency search) | **CFO: required** — hardware produces ±3.7 kHz, the Costas loop reaches ±35 Hz (a ~100× shortfall). **Timing drift: not required** — code tracking already absorbs 25× what the clocks produce |
| 5 | Full duplex | `demo.py 5` | `node_ctrl.py`, `dsss_spreader.py`, `fragment_reassembler.py` | Both directions demodulated from the same samples at **BER ~5×10⁻⁴**; peer link survives own-transmission up to **+10 dB** over the peer signal, matching the 24 dB code separation |
| 6 | Spectrum analyser: signal below the noise floor | `demo.py 6` | `custom_blocks/psd_probe.py` | Keying TX raises in-band power by **+0.07 dB** (invisible), while the same unspread signal stands **10 dB** above the floor; the buried samples still despread to an 11 dB constellation at BER 0 |
| 7 | Quantify processing gain and BER | `demo.py 7` | `dsss_link/metrics.py`, `snr_probe.py`, PRBS BERT | Gain **30.1 dB theory / 30.2 dB measured** (three independent methods agree); BER tracks differentially-decoded QPSK theory to **within 0.5 dB** |
| 8 | Stretch: third radio jamming the link | `demo.py 8` | `jammer.py` | Absorbs a **broadband jammer to J/S +18 dB** and a **CW jammer to +21 dB**, against a 20 dB predicted margin; four jammer types measured separately |

## How to read a result folder

Every run writes `demo_results/<timestamp>_req<N>_<name>/` containing:

- **`report.md`** — the requirement text, the method, a table of measured
  numbers, and the figures. This is the thing to put in front of a reviewer.
- **`*.png`** — the figures, also embedded in the report.
- **`*.csv`** — the raw data behind each figure, for a lab notebook or to
  overlay against a bench measurement.
- **`data.json`** — every number the run produced, for scripting.
- **`console.log`** — the full run output.

## Live versus offline

Requirements 1–4, 6, 7 and 8 run fully offline, in simulation, because they
need sweeps of dozens of operating points that would take an afternoon each on
the bench. The simulation runs *the same algorithms the flowgraph runs* — a
test (`tests/run_tests.py::test_despreader_block_matches_core`) asserts the
offline despreader and the GNU Radio block produce identical output — so the
curves are trustworthy.

Requirements 5, 6, 7 and 8 additionally take `--live` and measure a running
flowgraph over UDP, so you can pin the simulated curve to what the hardware
actually did:

```
# start dsss_bpsk_usrp.py (or dsss_bpsk_sim.py) first, then:
python3 demo.py 7 --live
python3 demo.py 6 --live       # keys the transmitter off and on itself
python3 demo.py 8 --live       # step jammer.py's level as prompted
```

The number a live run adds is the honest one; the offline sweep is what puts
it in context.

## Suggested demo order

Run them in requirement order — `demo.py all` does exactly this, in about five
minutes — because the story builds:

1. **Code tracking (1)** establishes that the receiver can find and hold the
   signal at all.
2. **Spreading factor (2)** shows what it is holding onto and why the code is a
   real Gold code.
3. **Chip vs bit rate (3)** quantifies what that spreading buys and what it
   costs, and introduces the link profiles.
4. **Offset compensation (4)** is the one honest "we had to add something"
   result — it decides a design question with a measurement.
5. **Full duplex (5)** shows two links coexisting on one frequency.
6. **Spectrum (6)** is the visual payoff: the signal is genuinely invisible.
7. **Processing gain and BER (7)** is the quantitative payoff: here is exactly
   how much the spreading bought and how close to theory the receiver runs.
8. **Jamming (8)** is the stretch, and the practical argument for the whole
   design: this is what 30 dB of processing gain is *for*.
