# Demo guide

A walkthrough for running the demonstration in front of a reviewer, with and
without hardware. Read `REQUIREMENTS.md` first for the one-line summary of what
each run proves; this document is the operational detail.

## The one thing to know

Every requirement has exactly one command:

```
python3 demo.py 1        # requirement 1
python3 demo.py all      # all eight, in order, ~5 minutes
python3 demo.py list     # what the eight are
```

Each writes a self-contained folder under `demo_results/`. You can run these
with no radio attached — the sweeps run in simulation against the same DSP the
flowgraph uses. Add `--live` to also measure a running flowgraph.

## Rehearsing without hardware

Everything except the physical radio runs on a laptop with Python, NumPy and
Matplotlib. Nothing else is needed to rehearse the entire demonstration:

```
python3 demo.py all --quick     # shorter sweeps, ~1 minute, for a dry run
python3 demo.py all             # the real thing, ~5 minutes
```

Open any `demo_results/*/report.md` to see exactly what a reviewer will see.

## Running it live, with the radios

### One radio (or none): the simulation flowgraph

`dsss_bpsk_sim.grc` is a complete link with a simulated channel — no radio
required. Open it in GNU Radio Companion, hit **Generate** then **Execute**
(see the note on regenerating below), and it starts transmitting to itself over
a simulated RF channel with noise, carrier-offset and clock-skew sliders. Then:

```
python3 ground_station.py       # the graphical console
# or
python3 terminal.py             # the scriptable text console
```

Type a message, or use the **File** tab to send a file. This is the loopback
demo and it exercises the entire signal chain.

### Two radios: full duplex (requirement 5)

Run `dsss_bpsk_usrp.grc` on two machines, each with a B205/B206mini:

1. Node A: leave `my_node_id = 0`, `dest_node_id = 1` (the defaults).
2. Node B: set MY NODE = 1, TALKING TO = 0 (the spin boxes in the ground
   station header, or `/node 1` and `/dest 0` in the terminal).
3. Point each antenna at the other's, a few metres apart, with **separate TX
   and RX antennas** and low TX gain. Both radios now transmit continuously on
   their own code and receive on their peer's, at the same time, on the same
   frequency.
4. `python3 demo.py 5 --live` measures both directions and confirms they
   overlap in time rather than taking turns.

If a live duplex test misbehaves, the cause is almost always antenna isolation,
not the DSP — separate the antennas and drop the TX gain before suspecting the
code.

### Three radios: jamming (requirement 8)

Add a third radio running `jammer.py`:

```
python3 jammer.py --waveform broadband --freq 915e6 --tx-gain 20 \
                  --ref-amplitude 0.3 --jsr 0
```

Then raise the jammer-to-signal ratio while watching the link's BER in the
ground station's diagnostics window, or drive the sweep automatically:

```
python3 demo.py 8 --live
```

**Keep the jammer conducted and attenuated.** It transmits deliberate
co-channel interference; the default TX gain is 0 so nothing radiates until you
raise it knowingly. Radiating an interferer over the air is very likely
illegal — use cables, attenuators and a dummy load, and stay inside your local
rules.

## Regenerating the flowgraph .py files (important)

The flowgraph logic was rebuilt in this revision, so **the pre-generated
`dsss_bpsk_*.py` files from the previous version are stale**. Before a live
run, regenerate them:

```
gnuradio-companion dsss_bpsk_usrp.grc     # then hit Generate (the gear icon)
gnuradio-companion dsss_bpsk_sim.grc      # then hit Generate
```

or from the command line if you have `grcc`:

```
grcc dsss_bpsk_usrp.grc
grcc dsss_bpsk_sim.grc
```

This re-emits the `.py` for your exact GNU Radio version. If you run an old
`dsss_bpsk_usrp.py` without regenerating, you will get the previous version's
behaviour (6-byte fragment header, no erasure coding, the old despreader) and
the ground station's file transfer will not interoperate with it.

The `.grc` files are the source of truth and have been validated structurally
(`tests/run_tests.py::test_flowgraphs_in_sync`); GRC turns them into runnable
`.py`.

## The metrics window

The ground station's **Diagnostics** button opens a live readout that maps
directly onto the requirements:

- **Code lock / drift / slips** — requirement 1, live.
- **Processing gain** (symbol SNR, implied pre-despread SNR, peak-to-sidelobe)
  — requirement 7. Note that peak-to-sidelobe is labelled as a lock-quality
  indicator, *not* the gain — see `METRICS.md` for why that distinction
  matters.
- **EVM and two SNR estimators** — requirement 7.
- **BER (PRBS-15)** — requirement 7. Toggle it with the **BER test** button.
- **Carrier offset found** — requirement 4, live.

## Choosing a link profile

The link ships four operating points, selected at launch by an environment
variable:

```
LINK_PROFILE=stealth  python3 ...     # 1023 chips, max hiding, ~100 B/s (default)
LINK_PROFILE=standard python3 ...     # 1023 chips, 4× chip rate, ~450 B/s
LINK_PROFILE=fast     python3 ...     # 511 chips, ~900 B/s
LINK_PROFILE=bulk     python3 ...     # 127 chips, ~2.9 KB/s, for file transfer
```

Set it before launching the flowgraph (it is baked into the sample rate and
filter taps, so it cannot change while running), and pass the same
`--profile` to the ground station so its airtime estimates are right. Use
`stealth` for the below-the-noise-floor demos (6, and the spreading-gain story
in 2 and 7); use `bulk` when you actually want to move a file in front of an
audience, since a megabyte on `stealth` takes hours and on `bulk` takes
minutes. `python3 demo.py 3` shows the full trade.

## If something goes wrong

- **No link / NO LINK in the ground station.** The flowgraph is not running,
  or is bound to different UDP ports. Confirm it is running and that no other
  console is holding the receive ports.
- **File transfer reports INCOMPLETE.** More fragments were lost than the
  parity could cover. Raise the parity overhead (File tab, or `/parity` in the
  terminal) or improve the link, then resend. On `stealth` at high noise this
  is expected — that profile is built for hiding, not throughput.
- **A demo says "no telemetry".** The `--live` run could not reach the
  flowgraph's diagnostics port. Drop `--live` to run offline, or check the
  flowgraph is running and the PSD/SNR probes are wired in (they are, in the
  regenerated flowgraphs).
- **TX underflow / RX overflow on real hardware.** Push `tx_pace_margin_pct`
  more negative (more timing margin), or drop to a lower chip-rate profile.
  Watch the orange HEALTH lines in the Link Log.
