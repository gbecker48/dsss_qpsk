"""
TX Scheduler
-------------
This is what makes the link *continuous* instead of burst-mode: it keeps
exactly one fragment's worth of data flowing into the Packet Framer every
slot period, forever, whether or not there's anything real to send.

Two message inputs:
  'queue_in' - a raw user message PDU (any length, up to MAX_MESSAGE_BYTES)
               arriving from the UDP terminal. It gets split into
               fixed-size fragments (CHUNK_BYTES of real data each) and
               all of them are pushed onto an internal FIFO queue - not
               sent immediately. A message longer than one fragment holds
               no special priority over ones already queued; fragments
               are sent strictly in the order they were queued.
  'strobe'   - a timing tick (from a message_strobe running at exactly
               one slot period - see the flowgraph) that means "produce
               the next thing to transmit right now". If the queue has a
               pending fragment, that's popped and sent; if the queue is
               empty, an IDLE filler fragment (frag_total=0) is sent
               instead. This is what keeps the physical layer always-on:
               there is never a moment with nothing being spread and
               transmitted, exactly like GPS satellites (which never
               "turn off" between useful navigation bits).

Each fragment payload (always exactly PAYLOAD_BYTES, zero-padded) is:
    [ MSG_ID 1B ][ FRAG_IDX 1B ][ FRAG_TOTAL 1B ][ CHUNK_LEN 1B ][ DATA up to CHUNK_BYTES ]
FRAG_TOTAL == 0 is the reserved idle/no-data marker.

Output: PDU (payload bytes, always length PAYLOAD_BYTES) on port 'out',
        handed to the Packet Framer next.
"""

import numpy as np
import pmt
from gnuradio import gr
from collections import deque


def pdu_data(msg):
    vec = pmt.cdr(msg) if pmt.is_pair(msg) else msg
    return np.array(pmt.u8vector_elements(vec), dtype=np.uint8)


def make_pdu(values):
    arr = np.asarray(values, dtype=np.uint8)
    return pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(arr), arr.tolist()))


class blk(gr.basic_block):
    """TX Scheduler: fragmentation + continuous-transmission pacing"""

    def __init__(self, payload_bytes=256, header_bytes=4):
        gr.basic_block.__init__(self, name='TX Scheduler', in_sig=[], out_sig=[])
        self.payload_bytes = int(payload_bytes)
        self.header_bytes = int(header_bytes)
        self.chunk_bytes = self.payload_bytes - self.header_bytes
        self.max_message_bytes = self.chunk_bytes * 256  # FRAG_IDX is 1 byte

        self.queue = deque()
        self.msg_id = 0

        self.message_port_register_in(pmt.intern('queue_in'))
        self.message_port_register_in(pmt.intern('strobe'))
        self.message_port_register_out(pmt.intern('out'))
        self.set_msg_handler(pmt.intern('queue_in'), self.handle_queue_in)
        self.set_msg_handler(pmt.intern('strobe'), self.handle_strobe)

    def handle_queue_in(self, msg):
        data = pdu_data(msg).tobytes()
        if len(data) > self.max_message_bytes:
            print("[TX Scheduler] message too long (%d bytes, max %d) - truncating" %
                  (len(data), self.max_message_bytes))
            data = data[:self.max_message_bytes]
        if len(data) == 0:
            return

        n_frags = (len(data) + self.chunk_bytes - 1) // self.chunk_bytes
        mid = self.msg_id
        self.msg_id = (self.msg_id + 1) & 0xFF
        print("[TX Scheduler] queued msg id=%d, %d bytes -> %d fragment(s)" %
              (mid, len(data), n_frags))
        for idx in range(n_frags):
            chunk = data[idx * self.chunk_bytes:(idx + 1) * self.chunk_bytes]
            payload = bytes([mid, idx, n_frags, len(chunk)]) + chunk + \
                bytes(self.chunk_bytes - len(chunk))
            assert len(payload) == self.payload_bytes
            self.queue.append(payload)

    def handle_strobe(self, msg):
        if self.queue:
            payload = self.queue.popleft()
        else:
            payload = bytes(self.payload_bytes)  # all-zero -> frag_total=0 -> idle
        self.message_port_pub(pmt.intern('out'), make_pdu(list(payload)))
