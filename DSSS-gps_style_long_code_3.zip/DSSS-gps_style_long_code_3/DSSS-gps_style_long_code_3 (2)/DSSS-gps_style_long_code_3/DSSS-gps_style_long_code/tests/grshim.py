"""
grshim.py -- enough of GNU Radio to run the custom blocks without GNU Radio
===========================================================================

The embedded Python blocks in this project carry the parts that are easiest to
get wrong: a `general_work` that must consume exactly the right number of input
samples, a `forecast` that must ask for enough, and tag offsets that must be
rescaled by the block's own interpolation factor. None of that is exercised by
testing the algorithms in isolation -- an off-by-one in `consume()` produces a
block that despreads perfectly in a notebook and slowly walks off the signal on
real hardware.

So this shim implements the small slice of the GNU Radio runtime those blocks
actually touch -- basic_block, sync_block, interp_block, decim_block, tags, and
the message-port plumbing -- and `run_block` drives a block the way the real
scheduler does: in chunks of varying size, honouring forecast, consume and the
returned item counts, with a buffer that only advances by what the block
consumed.

It is a test harness, not a GNU Radio reimplementation. It deliberately does
not model back-pressure, multiple threads, or buffer sizing. What it does model
is the item accounting, which is the part that bites.
"""

from __future__ import annotations

import sys
import types
import numpy as np


# ---------------------------------------------------------------------------
# pmt
# ---------------------------------------------------------------------------

class _Symbol:
    __slots__ = ("name",)

    def __init__(self, name):
        self.name = name

    def __eq__(self, other):
        return isinstance(other, _Symbol) and other.name == self.name

    def __hash__(self):
        return hash(("sym", self.name))

    def __repr__(self):
        return f"<pmt {self.name}>"


class _Pair:
    __slots__ = ("car", "cdr")

    def __init__(self, car, cdr):
        self.car = car
        self.cdr = cdr


class _U8Vector:
    __slots__ = ("data",)

    def __init__(self, data):
        self.data = list(data)


def _build_pmt():
    m = types.ModuleType("pmt")
    m.PMT_NIL = _Symbol("NIL")
    m._interned = {}

    def intern(name):
        return m._interned.setdefault(name, _Symbol(name))

    m.intern = intern
    m.cons = lambda a, b: _Pair(a, b)
    m.car = lambda p: p.car
    m.cdr = lambda p: p.cdr
    m.is_pair = lambda p: isinstance(p, _Pair)
    m.is_dict = lambda p: isinstance(p, dict)
    m.init_u8vector = lambda n, vals: _U8Vector(vals)
    m.u8vector_elements = lambda v: list(v.data)
    m.from_double = lambda x: float(x)
    m.from_long = lambda x: int(x)
    m.to_long = lambda x: int(x)
    m.is_integer = lambda x: isinstance(x, int)
    m.is_uinteger = lambda x: isinstance(x, int) and x >= 0
    m.symbol_to_string = lambda s: s.name if isinstance(s, _Symbol) else str(s)
    m.write_string = lambda x: repr(x)
    m.eq = lambda a, b: a is b or a == b
    m.dict_ref = lambda d, k, default: d.get(k, default) if isinstance(d, dict) else default
    return m


# ---------------------------------------------------------------------------
# gnuradio.gr
# ---------------------------------------------------------------------------

class Tag:
    __slots__ = ("offset", "key", "value")

    def __init__(self, offset, key, value):
        self.offset = offset
        self.key = key
        self.value = value


class _BlockBase:
    TPP_DONT = 0
    TPP_ALL_TO_ALL = 1

    def _shim_init(self):
        self._nread = [0]
        self._nwritten = [0]
        self._out_tags = []
        self._in_tags = []
        self._msg_handlers = {}
        self._msg_out = {}
        self._tpp = 1

    # -- item accounting --
    def nitems_read(self, which=0):
        return self._nread[which]

    def nitems_written(self, which=0):
        return self._nwritten[which]

    def consume(self, which, n):
        self._consumed = int(n)

    def consume_each(self, n):
        self._consumed = int(n)

    def set_tag_propagation_policy(self, p):
        self._tpp = p

    # -- tags --
    def add_item_tag(self, which, offset, key, value):
        self._out_tags.append(Tag(int(offset), key, value))

    def get_tags_in_window(self, which, start, end, key=None):
        base = self._nread[which]
        out = []
        for t in self._in_tags:
            if base + start <= t.offset < base + end:
                if key is None or t.key == key:
                    out.append(t)
        return out

    # -- messages --
    def message_port_register_in(self, name):
        self._msg_handlers.setdefault(name, None)

    def message_port_register_out(self, name):
        self._msg_out.setdefault(name, [])

    def set_msg_handler(self, name, fn):
        self._msg_handlers[name] = fn

    def message_port_pub(self, name, msg):
        self._msg_out.setdefault(name, []).append(msg)

    # -- test helpers --
    def shim_send(self, port, msg):
        """Deliver a message to one of this block's input ports."""
        h = self._msg_handlers.get(_PMT.intern(port) if isinstance(port, str)
                                   else port)
        if h is None:
            for k, fn in self._msg_handlers.items():
                if getattr(k, "name", None) == port:
                    h = fn
                    break
        if h is None:
            raise KeyError(f"no handler for message port {port!r}")
        h(msg)

    def shim_messages(self, port):
        """Everything this block published on `port`, as decoded text/bytes."""
        key = _PMT.intern(port)
        out = []
        for m in self._msg_out.get(key, []):
            vec = m.cdr if isinstance(m, _Pair) else m
            if isinstance(vec, _U8Vector):
                out.append(bytes(bytearray(vec.data)))
            else:
                out.append(m)
        return out


class basic_block(_BlockBase):
    def __init__(self, name="", in_sig=None, out_sig=None):
        self._shim_init()
        self.name_ = name
        self.in_sig = in_sig or []
        self.out_sig = out_sig or []


class sync_block(_BlockBase):
    def __init__(self, name="", in_sig=None, out_sig=None):
        self._shim_init()
        self.name_ = name
        self.in_sig = in_sig or []
        self.out_sig = out_sig or []


class interp_block(_BlockBase):
    def __init__(self, name="", in_sig=None, out_sig=None, interp=1):
        self._shim_init()
        self.name_ = name
        self.in_sig = in_sig or []
        self.out_sig = out_sig or []
        self.interpolation = int(interp)


class decim_block(_BlockBase):
    def __init__(self, name="", in_sig=None, out_sig=None, decim=1):
        self._shim_init()
        self.name_ = name
        self.in_sig = in_sig or []
        self.out_sig = out_sig or []
        self.decimation = int(decim)


def _build_gr():
    m = types.ModuleType("gnuradio.gr")
    m.basic_block = basic_block
    m.sync_block = sync_block
    m.interp_block = interp_block
    m.decim_block = decim_block
    m.TPP_DONT = 0
    m.TPP_ALL_TO_ALL = 1
    m.log_levels = types.SimpleNamespace(info=0, debug=1, warn=2, error=3)
    m.GR_MSB_FIRST = 0
    m.types = types.SimpleNamespace(byte_t=0)
    return m


def install():
    """Put the shim modules on sys.modules so `from gnuradio import gr` works."""
    global _PMT
    _PMT = _build_pmt()
    sys.modules["pmt"] = _PMT

    gnuradio = types.ModuleType("gnuradio")
    gr = _build_gr()
    gnuradio.gr = gr
    sys.modules["gnuradio"] = gnuradio
    sys.modules["gnuradio.gr"] = gr
    return _PMT, gr


_PMT = None


# ---------------------------------------------------------------------------
# Driving a block the way the scheduler does
# ---------------------------------------------------------------------------

def run_block(block, input_array, out_dtype=np.complex64,
              max_out=4096, rng=None, in_tags=None):
    """Feed `input_array` through a streaming block and collect its output.

    Chunk sizes are deliberately random. A block whose consume accounting is
    subtly wrong will often still work when fed one big uniform buffer, and
    fail when the scheduler hands it whatever happens to be available -- which
    is what real hardware does. Varying the chunk size is how that bug surfaces
    in a test instead of on the bench.
    """
    rng = rng or np.random.default_rng(0)
    x = np.asarray(input_array)
    block._in_tags = list(in_tags or [])

    produced_all = []
    pos = 0                     # absolute index of the start of the window
    while pos < len(x):
        avail = len(x) - pos
        want = int(rng.integers(max(1, max_out // 4), max_out + 1))

        need = avail
        if hasattr(block, "forecast"):
            try:
                need = block.forecast(want, 1)[0]
            except Exception:
                need = avail
        window = min(avail, max(need, want))
        chunk = x[pos:pos + window]

        out = np.zeros(want, dtype=out_dtype)
        block._consumed = None

        if hasattr(block, "general_work"):
            n = block.general_work([chunk], [out])
            consumed = block._consumed
            if consumed is None:
                consumed = 0
        else:
            n = block.work([chunk], [out])
            if isinstance(block, interp_block):
                consumed = (n // block.interpolation) if n else 0
            elif isinstance(block, decim_block):
                consumed = n * block.decimation if n else 0
            else:
                consumed = n if n else 0

        if n:
            produced_all.append(out[:n].copy())
            block._nwritten[0] += n

        if consumed <= 0:
            if window >= avail:
                break          # block wants more than exists; we are done
            # Otherwise give it a bigger window next time by not advancing.
            max_out = min(max_out * 2, 1 << 20)
            if max_out >= (1 << 20):
                break
            continue

        block._nread[0] += consumed
        pos += consumed

    if produced_all:
        return np.concatenate(produced_all)
    return np.zeros(0, dtype=out_dtype)


def load_block(path, class_name="blk"):
    """Import a custom_blocks/*.py module against the shim."""
    import importlib.util
    import os
    install()
    name = "shimblk_" + os.path.basename(path).replace(".py", "")
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod
