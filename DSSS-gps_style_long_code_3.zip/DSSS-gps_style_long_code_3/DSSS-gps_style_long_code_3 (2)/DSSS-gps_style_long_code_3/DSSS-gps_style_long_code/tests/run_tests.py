#!/usr/bin/env python3
"""
run_tests.py -- the offline verification suite
==============================================

Everything in this project that can be checked without a radio is checked
here, so a change that breaks the DSP, the coding, the protocol, or the
consistency between the readable block sources and the flowgraphs fails loudly
rather than on the bench.

    python3 tests/run_tests.py            # everything
    python3 tests/run_tests.py core rs    # named groups only

Groups: core, gold, rs, protocol, blocks, flowgraph, ber, jammer, imports.

No pytest dependency -- it is a plain script so it runs anywhere Python and
NumPy do, which is the same bar the rest of the project sets.
"""

from __future__ import annotations

import math
import os
import sys
import traceback

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "tests"))

_RESULTS = []


def check(cond, msg):
    if not cond:
        raise AssertionError(msg)


def group(name):
    def deco(fn):
        fn._group = name
        return fn
    return deco


# ===========================================================================
# core DSP
# ===========================================================================

@group("core")
def test_rrc_matches_firdes_shape():
    """RRC taps: symmetric, unit energy, peak at centre."""
    from dsss_link import dsss_core as core
    taps = core.rrc_taps(8, 0.35)
    check(len(taps) % 2 == 1, "tap count must be odd")
    check(abs(np.sum(taps ** 2) - 1.0) < 1e-5, "taps should have unit energy")
    check(np.argmax(taps) == len(taps) // 2, "peak should be centred")
    check(np.allclose(taps, taps[::-1], atol=1e-6), "taps should be symmetric")


@group("core")
def test_differential_qpsk_roundtrip():
    from dsss_link import dsss_core as core
    rng = np.random.default_rng(0)
    dibits = rng.integers(0, 4, 1000)
    check(np.array_equal(core.diff_decode(core.diff_encode(dibits)),
                         dibits % 4), "diff enc/dec must round-trip")
    bits = rng.integers(0, 2, 2000).astype(np.uint8)
    check(np.array_equal(core.dibits_to_bits(core.bits_to_dibits(bits)), bits),
          "bit/dibit packing must round-trip")


@group("core")
def test_channel_esn0_calibration():
    """The channel's Es/N0 should be the Es/N0 you measure back."""
    from dsss_link import dsss_core as core
    L = 1023
    code = core.gold_code(L)
    rng = np.random.default_rng(3)
    for target in (10, 15, 20):
        bits = rng.integers(0, 2, 4000).astype(np.uint8)
        tx = core.transmit(bits, code, sps=1)
        ch = core.Channel(esn0_db=target, code_len=L, samp_rate=1.023e6,
                          seed=1)
        rx = ch.apply(tx, sps=1)
        d = core.Despreader(L, chip_rate=1.023e6)
        d.process(rx)
        meas = d.symbol_snr_db()
        check(abs(meas - target) < 1.5,
              f"measured symbol SNR {meas:.1f} should be near Es/N0 {target}")


# ===========================================================================
# Gold codes
# ===========================================================================

@group("gold")
def test_gold_code_properties():
    from dsss_link import dsss_core as core
    for node in range(16):
        p = core.code_properties(core.gold_code(1023, core.NODE_PRN_TABLE[node]))
        check(p["length"] == 1023, "period must be 1023")
        check(p["balance"] == 1, f"node {node} must be balanced 512/511")
        check(p["autocorr_offpeak"] == [-65, -1, 63],
              f"node {node} off-peak autocorr must be the three Gold values")


@group("gold")
def test_gold_cross_correlation_bounded():
    from dsss_link import dsss_core as core
    worst = 0
    for i in range(16):
        ci = core.gold_code(1023, core.NODE_PRN_TABLE[i])
        for j in range(i + 1, 16):
            cj = core.gold_code(1023, core.NODE_PRN_TABLE[j])
            worst = max(worst, core.cross_correlation_peak(ci, cj))
    check(worst <= 65, f"cross-correlation {worst} must be within the bound 65")


@group("gold")
def test_gold_family_multiple_lengths():
    from dsss_link import dsss_core as core
    expected = {31: [-9, -1, 7], 63: [-17, -1, 15], 127: [-17, -1, 15],
                511: [-33, -1, 31], 1023: [-65, -1, 63]}
    for L, off in expected.items():
        p = core.code_properties(core.gold_code_family(L, 2))
        check(p["autocorr_offpeak"] == off,
              f"length {L} off-peak autocorr must be {off}, got "
              f"{p['autocorr_offpeak']}")
    for bad in (255, 4095):
        try:
            core.gold_code_family(bad, 0)
            check(False, f"length {bad} should have no Gold family")
        except ValueError:
            pass


@group("gold")
def test_core_matches_block_gold_code():
    """The three copies of the Gold generator must be bit-identical."""
    from dsss_link import dsss_core as core
    import grshim
    grshim.install()
    for fname in ("dsss_spreader.py", "dsss_despreader.py"):
        path = os.path.join(ROOT, "custom_blocks", fname)
        src = open(path).read()
        head = src.split("class blk")[0]
        head = head.replace("import pmt\n", "").replace(
            "from gnuradio import gr\n", "")
        ns = {}
        exec(head, ns)
        for prn in [(2, 6), (3, 7), (9, 10)]:
            a = ns["gps_style_gold_code"](1023, prn)
            b = core.gold_code(1023, prn)
            check(np.array_equal(a, b),
                  f"{fname} Gold code for PRN {prn} differs from dsss_core")


# ===========================================================================
# Reed-Solomon erasure coding
# ===========================================================================

@group("rs")
def test_gf256_field():
    from dsss_link import erasure_fec as F
    for a in range(1, 256):
        check(int(F.gf_mul(np.uint8(a), np.uint8(F.gf_inv(a)))) == 1,
              f"{a} * inv({a}) must be 1 in GF(256)")
    check(int(F.gf_mul(np.uint8(0), np.uint8(200))) == 0, "0 * x = 0")


@group("rs")
def test_rs_recovers_worst_case_erasures():
    from dsss_link import erasure_fec as F
    rng = np.random.default_rng(0)
    L = 244
    for (k, m) in [(10, 4), (100, 20), (200, 55), (1, 1)]:
        data = rng.integers(0, 256, (k, L)).astype(np.uint8)
        par = F.encode_block(data, m)
        for _ in range(40):
            lost = set(rng.choice(k + m, size=m, replace=False))
            recv = {i: (data[i] if i < k else par[i - k])
                    for i in range(k + m) if i not in lost}
            rec = F.decode_block(recv, k, m, L)
            check(np.array_equal(rec, data),
                  f"RS({k}+{m}) must recover any {m} erasures exactly")


@group("rs")
def test_rs_fails_past_capacity():
    from dsss_link import erasure_fec as F
    rng = np.random.default_rng(1)
    data = rng.integers(0, 256, (20, 244)).astype(np.uint8)
    par = F.encode_block(data, 5)
    recv = {i: (data[i] if i < 20 else par[i - 20]) for i in range(25)}
    for i in range(6):
        recv.pop(i)
    try:
        F.decode_block(recv, 20, 5, 244)
        check(False, "6 losses with 5 parity must fail, not return garbage")
    except ValueError:
        pass


@group("rs")
def test_tx_rx_plan_agreement():
    """The transmitter and receiver must derive identical RS layouts."""
    from dsss_link import erasure_fec as F, protocol as P
    for nd in (1, 5, 199, 200, 201, 300, 4300, 17000, 65000):
        for pf in (0.0, 0.1, 0.2, 0.3):
            npar = F.parity_for(nd, pf)
            tx = F.plan_blocks(nd, pf)
            rx = P.plan_from_counts(nd, npar)
            check(tx == rx, f"tx/rx RS plan disagree at nd={nd}, pf={pf}")
            check(sum(k for k, _ in rx) == nd, "data fragment count must match")
            check(sum(mm for _, mm in rx) == npar, "parity count must match")
            check(all(k + mm <= 255 for k, mm in rx),
                  "no RS block may exceed GF(256)")


# ===========================================================================
# protocol / file transfer
# ===========================================================================

@group("protocol")
def test_header_roundtrip():
    from dsss_link import protocol as P
    h = P.pack_header(3, 7, P.TYPE_PARITY, 42, 60000, 65000, 1200, 244)
    u = P.unpack_header(h + b"\x00" * 244)
    check(u["src"] == 3 and u["dst"] == 7 and u["type"] == P.TYPE_PARITY,
          "header src/dst/type must round-trip")
    check(u["frag_idx"] == 60000 and u["n_data"] == 65000,
          "16-bit fields must round-trip past 255")
    check(P.max_message_bytes() > 15_000_000, "ceiling should be ~16 MB")


@group("protocol")
def test_file_transfer_survives_loss():
    from dsss_link import protocol as P, erasure_fec as F
    rng = np.random.default_rng(5)
    data = rng.integers(0, 256, 120_000).astype(np.uint8).tobytes()
    msg = P.pack_file_payload("capture.bin", data)
    frags, par = P.fragment_message(msg, parity_fraction=0.20)
    layout = P.plan_from_counts(len(frags), len(par))
    # 20% parity reliably survives loss comfortably below the parity
    # fraction. It does NOT reliably survive loss AT the fraction: uniform
    # loss lands unevenly across RS blocks, so some block exceeds its budget
    # by variance alone. 10% is the honest guaranteed figure; the demo plots
    # the full curve including where it starts to fail.
    for loss in (0.0, 0.05, 0.10):
        dr = {i: f for i, f in enumerate(frags) if rng.random() > loss}
        pr = {i: f for i, f in enumerate(par) if rng.random() > loss}
        rec, missing = F.decode_striped(layout, dr, pr, len(frags[0]))
        blob = b"".join(x.tobytes() for x in rec)[:len(msg)]
        info = P.unpack_file_payload(blob)
        check(info is not None and info["sha_ok"],
              f"file must verify after {loss:.0%} fragment loss "
              f"(unrecoverable={len(missing)})")


@group("protocol")
def test_prbs_ber_counting():
    from dsss_link import protocol as P
    g = P.PRBS15()
    bits = g.bits(200000)
    check(abs(bits.mean() - 0.5) < 0.02, "PRBS-15 must be balanced")
    r = P.prbs15_check(bits)
    check(r["synced"] and r["errors"] == 0, "clean PRBS must show zero errors")
    noisy = bits.copy()
    idx = np.random.default_rng(1).choice(len(bits), 200, replace=False)
    noisy[idx] ^= 1
    r2 = P.prbs15_check(noisy)
    check(abs(r2["errors"] - 200) <= 2,
          f"should count ~200 injected errors, got {r2['errors']}")
    r3 = P.prbs15_check(np.random.default_rng(2).integers(0, 2, 50000)
                        .astype(np.uint8))
    check(not r3["synced"], "pure noise must report loss of sync, not a BER")


# ===========================================================================
# blocks, through the GNU Radio shim
# ===========================================================================

@group("blocks")
def test_all_blocks_import():
    import grshim
    grshim.install()
    for f in os.listdir(os.path.join(ROOT, "custom_blocks")):
        if f.endswith(".py"):
            grshim.load_block(os.path.join(ROOT, "custom_blocks", f))


@group("blocks")
def test_despreader_block_matches_core():
    """The streaming block and the array reference must agree symbol for symbol."""
    from dsss_link import dsss_core as core
    import grshim
    grshim.install()
    mod = grshim.load_block(os.path.join(ROOT, "custom_blocks",
                                         "dsss_despreader.py"))
    L, prn, CHIP = 1023, (2, 6), 511500.0
    rng = np.random.default_rng(12)
    bits = rng.integers(0, 2, 5000).astype(np.uint8)
    tx = core.transmit(bits, core.gold_code(L, prn), sps=1)
    ch = core.Channel(esn0_db=12, code_len=L, samp_rate=CHIP,
                      delay_samples=613.0, seed=4)
    rx = ch.apply(tx, sps=1)
    b = mod.blk(code_len=L, prn_taps=prn, chip_rate=CHIP)
    block_syms = grshim.run_block(b, rx, max_out=2048,
                                  rng=np.random.default_rng(7))
    d = core.Despreader(L, prn, chip_rate=CHIP)
    core_syms = d.process(rx)
    n = min(len(block_syms), len(core_syms))
    check(n > 1000, "both paths should produce plenty of symbols")
    # Correlation at the correct lag must be essentially 1.
    a, c = core_syms[:n], block_syms[:n]
    corr = abs(np.vdot(a, c)) / np.sqrt(
        (np.vdot(a, a).real * np.vdot(c, c).real))
    check(corr > 0.999,
          f"block and core despreader must match (corr {corr:.4f})")


@group("blocks")
def test_scheduler_reassembler_file_roundtrip():
    """End to end through the two GNU Radio blocks, with fragment loss."""
    from dsss_link import protocol as P
    import grshim
    pmt, _gr = grshim.install()
    tx = grshim.load_block(os.path.join(ROOT, "custom_blocks",
                                        "tx_scheduler.py"))
    rxm = grshim.load_block(os.path.join(ROOT, "custom_blocks",
                                         "fragment_reassembler.py"))

    def run(loss, seed):
        rng = np.random.default_rng(seed)
        t = tx.blk(payload_bytes=256, my_node_id=0, dest_node_id=1,
                   parity_fraction=0.20)
        r = rxm.blk(payload_bytes=256, my_node_id=1, dest_node_id=0)
        data = rng.integers(0, 256, 50000).astype(np.uint8).tobytes()
        msg = P.pack_file_payload("x.bin", data)
        t.shim_send("queue_in", pmt.cons(pmt.PMT_NIL,
                    pmt.init_u8vector(len(msg), list(msg))))
        for _ in range(t.queue_depth + 4):
            t.shim_send("strobe", pmt.PMT_NIL)
        seq = 0
        for m in t._msg_out[pmt.intern("out")]:
            payload = bytes(bytearray(m.cdr.data))
            if rng.random() < loss:
                seq = (seq + 1) & 0xFF
                continue
            framed = bytes([seq]) + payload
            seq = (seq + 1) & 0xFF
            r.shim_send("in", pmt.cons(pmt.PMT_NIL,
                        pmt.init_u8vector(len(framed), list(framed))))
        outs = r.shim_messages("msg")
        if not outs:
            return False
        info = P.unpack_file_payload(outs[0])
        return info is not None and info["sha_ok"]

    check(run(0.0, 1), "clean file transfer must verify")
    check(run(0.10, 2), "file transfer must survive 10% loss with 20% parity")


# ===========================================================================
# flowgraph consistency
# ===========================================================================

@group("flowgraph")
def test_flowgraphs_in_sync():
    """The .grc files must match the block sources and profile table."""
    import subprocess
    r = subprocess.run([sys.executable,
                        os.path.join(ROOT, "tools", "build_flowgraphs.py"),
                        "--check"], capture_output=True, text=True)
    check(r.returncode == 0,
          "flowgraphs are out of date -- run tools/build_flowgraphs.py:\n"
          + r.stdout + r.stderr)


@group("flowgraph")
def test_profile_table_matches():
    """The dict inlined in the flowgraphs must match link_profiles."""
    import yaml
    from dsss_link import link_profiles
    d = yaml.safe_load(open(os.path.join(ROOT, "dsss_bpsk_usrp.grc")))
    blocks = {b["name"]: b for b in d["blocks"]}
    table = eval(blocks["link_profiles"]["parameters"]["value"])
    for name, p in link_profiles.PROFILES.items():
        got = table[name]
        check(got[0] == p.code_len and got[1] == p.chip_rate
              and got[2] == p.sps,
              f"flowgraph profile {name} disagrees with link_profiles")


# ===========================================================================
# BER against theory
# ===========================================================================

@group("ber")
def test_ber_tracks_theory():
    """The end-to-end BER must sit within a few dB of QPSK theory."""
    from dsss_link import dsss_core as core, metrics
    L, prn, CHIP = 1023, (2, 6), 511500.0
    code = core.gold_code(L, prn)
    rng = np.random.default_rng(99)
    losses = []
    for esn0 in (12, 10, 8):
        te = tn = 0
        for t in range(4):
            bits = rng.integers(0, 2, 4000).astype(np.uint8)
            tx = core.transmit(bits, code, sps=1)
            ch = core.Channel(esn0_db=esn0, code_len=L, samp_rate=CHIP,
                              delay_samples=float(rng.integers(0, L)),
                              seed=200 + t)
            out, _d, _ = core.receive(ch.apply(tx, sps=1), L, prn, sps=1,
                                      costas_bw=0.02, chip_rate=CHIP)
            _b, e, n = core.ber_between(bits, out)
            te += e
            tn += n
        ber = te / max(tn, 1)
        ebn0 = metrics.esn0_to_ebn0_db(esn0)
        if 0 < ber < 0.4:
            losses.append(metrics.implementation_loss_from_ber(ber, ebn0))
    check(losses, "should have measured at least one BER point")
    check(max(losses) < 4.0,
          f"implementation loss {max(losses):.1f} dB is too high -- the "
          f"despreader has regressed")


# ===========================================================================
# jammer waveforms
# ===========================================================================

@group("jammer")
def test_jammer_waveforms():
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        "jammer", os.path.join(ROOT, "jammer.py"))
    jam = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(jam)
    for kind in jam.WAVEFORMS:
        w = jam.make_waveform(kind, 8192, 2.046e6, seed=1)
        check(abs(np.mean(np.abs(w) ** 2) - 1.0) < 0.05,
              f"{kind} must be unit power")


# ===========================================================================
# host modules import
# ===========================================================================

@group("imports")
def test_host_modules_parse():
    import ast
    for f in ("ground_station.py", "terminal.py", "demo.py", "jammer.py"):
        ast.parse(open(os.path.join(ROOT, f)).read())
    for f in os.listdir(os.path.join(ROOT, "demos")):
        if f.endswith(".py"):
            ast.parse(open(os.path.join(ROOT, "demos", f)).read())


# ===========================================================================
# runner
# ===========================================================================

def main():
    wanted = set(sys.argv[1:])
    tests = [(name, fn) for name, fn in sorted(globals().items())
             if name.startswith("test_") and callable(fn)]
    if wanted:
        tests = [(n, f) for n, f in tests if f._group in wanted]

    passed = failed = 0
    current_group = None
    for name, fn in tests:
        if fn._group != current_group:
            current_group = fn._group
            print(f"\n[{current_group}]")
        try:
            fn()
            print(f"  PASS  {name[5:]}")
            passed += 1
        except Exception as exc:
            print(f"  FAIL  {name[5:]}: {exc}")
            traceback.print_exc()
            failed += 1

    print(f"\n{'=' * 60}")
    print(f"{passed} passed, {failed} failed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
