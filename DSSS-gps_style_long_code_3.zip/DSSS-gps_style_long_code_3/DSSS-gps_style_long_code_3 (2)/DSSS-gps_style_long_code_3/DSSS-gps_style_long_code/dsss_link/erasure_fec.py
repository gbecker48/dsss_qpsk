"""
erasure_fec.py -- Reed-Solomon erasure coding across fragments
==============================================================

The problem this solves
-----------------------
This link has no retransmission. A fragment whose frame fails CRC32 is dropped,
and the message it belonged to never completes. For a short text message that
is a mild annoyance -- send it again. For a file, it is fatal: a 1 MB transfer
is about 4300 fragments, so even a 0.1% fragment loss rate loses four of them
and the whole file fails, every single time.

Erasure coding fixes that without a reverse channel. Send `k` data fragments
plus `m` parity fragments; *any* `k` of the `k+m` reconstruct the original. Lose
three fragments out of a 20% parity budget and the file still lands, bit-exact,
with nothing to ask for and nothing to wait for.

Why erasure coding and not error correction
-------------------------------------------
Because the frame CRC has already done the hard part. Every fragment that
arrives has been checked; a corrupted one is *discarded*, not passed up
half-broken. So the decoder always knows exactly which fragments are missing --
their positions are known, only their values are unknown. That is the erasure
case, and it is twice as efficient as the error case: `m` parity fragments
correct `m` erasures but only `m/2` errors. Spending the parity budget on
erasures is the right call given a CRC is already in the frame.

How it works
------------
Systematic Reed-Solomon over GF(256), applied *across* fragments rather than
within them. Take byte `j` of each of the `k` data fragments as a codeword of
length `k`, extend it to `k+m` with a Vandermonde generator, and byte `j` of
each parity fragment is one of the extra symbols. Every byte position is an
independent RS codeword, and they are all computed at once with NumPy, so the
per-fragment cost is a handful of table lookups per byte.

Decoding inverts the k-by-k submatrix of rows that actually arrived. Because
the matrix is Vandermonde on distinct points, every square submatrix is
invertible -- which is precisely the guarantee that *any* k of the k+m work.

Block size
----------
GF(256) has 255 non-zero elements, so one RS block can hold at most 255
fragments total. Files bigger than that are split into several independent
blocks (`stripe`), each with its own parity. That also bounds the decoder's
work, which is O(k^3) in the field for the matrix inversion -- fine at k=200,
unpleasant at k=4000.
"""

from __future__ import annotations

import numpy as np

# ---------------------------------------------------------------------------
# GF(256) arithmetic
#
# Field: GF(2^8) with the primitive polynomial x^8 + x^4 + x^3 + x^2 + 1
# (0x11d), the same one used by QR codes and most RS implementations.
# Multiplication is done through log/antilog tables so the whole thing stays
# vectorised: a multiply becomes a pair of table lookups and an integer add.
# ---------------------------------------------------------------------------

_PRIM = 0x11D

def _build_tables():
    exp = np.zeros(512, dtype=np.uint8)
    log = np.zeros(256, dtype=np.uint8)
    x = 1
    for i in range(255):
        exp[i] = x
        log[x] = i
        x <<= 1
        if x & 0x100:
            x ^= _PRIM
    for i in range(255, 512):
        exp[i] = exp[i - 255]
    return exp, log

_EXP, _LOG = _build_tables()


def gf_mul(a, b):
    """Multiply in GF(256), elementwise over arrays.

    Zero has no logarithm, so it is handled by masking rather than by any
    clever arithmetic trick -- getting this wrong produces a codec that works
    on random data and fails on anything containing a zero byte.
    """
    a = np.asarray(a, dtype=np.uint8)
    b = np.asarray(b, dtype=np.uint8)
    out = _EXP[(_LOG[a].astype(np.int16) + _LOG[b].astype(np.int16))]
    return np.where((a == 0) | (b == 0), np.uint8(0), out).astype(np.uint8)


def gf_div(a, b):
    a = np.asarray(a, dtype=np.uint8)
    b = np.asarray(b, dtype=np.uint8)
    if np.any(b == 0):
        raise ZeroDivisionError("division by zero in GF(256)")
    out = _EXP[(_LOG[a].astype(np.int16) - _LOG[b].astype(np.int16)) % 255]
    return np.where(a == 0, np.uint8(0), out).astype(np.uint8)


def gf_inv(a: int) -> int:
    if a == 0:
        raise ZeroDivisionError("no inverse of zero in GF(256)")
    return int(_EXP[(255 - int(_LOG[a])) % 255])


def gf_matmul(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    """Matrix product over GF(256): multiply with tables, add with XOR.

    Accumulating with XOR is what makes this the field's addition; using + here
    would silently compute something that is not Reed-Solomon at all.
    """
    A = np.asarray(A, dtype=np.uint8)
    B = np.asarray(B, dtype=np.uint8)
    n, k = A.shape
    k2, m = B.shape
    assert k == k2, (A.shape, B.shape)
    out = np.zeros((n, m), dtype=np.uint8)
    for i in range(k):
        col = A[:, i][:, None]
        row = B[i][None, :]
        nz = (col != 0) & (row != 0)
        prod = _EXP[(_LOG[col].astype(np.int16) + _LOG[row].astype(np.int16))]
        out ^= np.where(nz, prod, np.uint8(0)).astype(np.uint8)
    return out


# ---------------------------------------------------------------------------
# Generator matrix
# ---------------------------------------------------------------------------

MAX_BLOCK = 255          # GF(256) cannot address more than this many fragments


def vandermonde(k: int, m: int) -> np.ndarray:
    """The m-by-k parity generator: rows are powers of distinct field elements.

    Row i, column j is alpha_i^j with alpha_i = exp(i+1), all distinct and
    non-zero. Distinctness is the whole ballgame: it is what makes every k-by-k
    submatrix of the stacked [identity; vandermonde] matrix invertible, and
    therefore what makes "any k of the k+m fragments" true rather than
    approximately true.
    """
    if k + m > MAX_BLOCK:
        raise ValueError(f"k+m must be <= {MAX_BLOCK}, got {k}+{m}")
    alphas = _EXP[1:1 + m].astype(np.uint8)
    V = np.zeros((m, k), dtype=np.uint8)
    for i in range(m):
        a = int(alphas[i])
        val = 1
        for j in range(k):
            V[i, j] = val
            val = int(gf_mul(np.uint8(val), np.uint8(a)))
    return V


def encode_block(data: np.ndarray, m: int) -> np.ndarray:
    """Add `m` parity fragments to `k` data fragments.

    `data` is (k, L) -- k fragments of L bytes. Returns (m, L) parity.
    """
    data = np.asarray(data, dtype=np.uint8)
    k = data.shape[0]
    if m <= 0:
        return np.zeros((0, data.shape[1]), dtype=np.uint8)
    return gf_matmul(vandermonde(k, m), data)


def decode_block(received: dict[int, np.ndarray], k: int, m: int,
                 frag_len: int) -> np.ndarray:
    """Reconstruct the k data fragments from any k of the k+m.

    `received` maps index -> fragment bytes, where indices 0..k-1 are data
    fragments and k..k+m-1 are parity fragments. Raises if fewer than k
    fragments are present, because at that point reconstruction is not merely
    hard but information-theoretically impossible, and returning something
    plausible would be worse than failing.
    """
    idx = sorted(received.keys())
    if len(idx) < k:
        raise ValueError(
            f"need {k} fragments to reconstruct, have {len(idx)} "
            f"({k - len(idx)} short)"
        )
    idx = idx[:k]

    # Fast path: every data fragment arrived, so there is nothing to invert.
    if all(i < k for i in idx):
        return np.stack([received[i] for i in range(k)])

    # Rows of the full [I; V] encoding matrix corresponding to what arrived.
    V = vandermonde(k, m)
    rows = np.zeros((k, k), dtype=np.uint8)
    rhs = np.zeros((k, frag_len), dtype=np.uint8)
    for r, i in enumerate(idx):
        if i < k:
            rows[r, i] = 1
        else:
            rows[r] = V[i - k]
        rhs[r] = received[i]

    return gf_matmul(_gf_inverse(rows), rhs)


def _gf_inverse(A: np.ndarray) -> np.ndarray:
    """Gauss-Jordan inversion over GF(256).

    Row operations are vectorised across the whole augmented row, so the Python
    loop is only over the k pivots.
    """
    n = A.shape[0]
    M = np.concatenate([A.copy(), np.eye(n, dtype=np.uint8)], axis=1)

    for col in range(n):
        piv = -1
        for r in range(col, n):
            if M[r, col] != 0:
                piv = r
                break
        if piv < 0:
            # Cannot happen for a Vandermonde-derived submatrix on distinct
            # points; if it does, the generator matrix has been changed in a
            # way that breaks the any-k-of-n guarantee, and silently returning
            # garbage would be far worse than saying so.
            raise ValueError("singular matrix -- generator is not MDS")
        if piv != col:
            M[[col, piv]] = M[[piv, col]]

        inv = gf_inv(int(M[col, col]))
        M[col] = gf_mul(M[col], np.uint8(inv))

        factors = M[:, col].copy()
        factors[col] = 0
        nz = factors != 0
        if np.any(nz):
            M[nz] ^= gf_mul(factors[nz][:, None],
                            np.broadcast_to(M[col], (int(nz.sum()), M.shape[1])))
    return M[:, n:]


# ---------------------------------------------------------------------------
# Striping: files larger than one RS block
# ---------------------------------------------------------------------------


BLOCK_K = 200            # data fragments per RS block (see plan())


def parity_for(n_data: int, parity_fraction: float) -> int:
    """How many parity fragments a given overhead implies, capped to what
    GF(256) can actually address alongside the data."""
    if n_data <= 0 or parity_fraction <= 0:
        return 0
    n_blocks = max(1, -(-n_data // BLOCK_K))
    k_max = -(-n_data // n_blocks)                      # largest block's k
    m_max_per_block = MAX_BLOCK - k_max
    n_parity = int(np.ceil(n_data * float(parity_fraction)))
    return min(n_parity, m_max_per_block * n_blocks)


def plan(n_data: int, n_parity: int) -> list[tuple[int, int]]:
    """The RS block layout, as a pure function of (n_data, n_parity).

    Both ends must agree on this exactly, and the receiver only ever sees the
    two totals -- they are in every fragment header. So the layout is derived
    from those two numbers and nothing else. An earlier version derived the
    blocks from the parity *fraction* instead, which looked equivalent and was
    not: the transmitter rounded 0.20 and the receiver rounded 861/4300, the
    two disagreed by one parity fragment per block, and every decode failed.

    Data fragments are split into blocks of at most BLOCK_K, as evenly as
    possible. Parity is then allocated across those blocks by largest-remainder
    apportionment, which is deterministic, gives every block a share
    proportional to its size, and distributes the leftover with no ambiguity
    about who gets it.
    """
    if n_data <= 0:
        return []
    n_blocks = max(1, -(-n_data // BLOCK_K))
    base, extra = divmod(n_data, n_blocks)
    ks = [base + (1 if b < extra else 0) for b in range(n_blocks)]
    ks = [k for k in ks if k > 0]
    n_blocks = len(ks)

    if n_parity <= 0:
        return [(k, 0) for k in ks]

    total_k = sum(ks)
    exact = [n_parity * k / total_k for k in ks]
    ms = [int(np.floor(e)) for e in exact]
    leftover = n_parity - sum(ms)
    order = sorted(range(n_blocks), key=lambda b: (-(exact[b] - ms[b]), b))
    for i in range(leftover):
        ms[order[i % n_blocks]] += 1

    # Never ask GF(256) for more symbols than it has.
    return [(k, min(m, MAX_BLOCK - k)) for k, m in zip(ks, ms)]


def plan_blocks(n_data_fragments: int, parity_fraction: float,
                max_block: int = MAX_BLOCK) -> list[tuple[int, int]]:
    """Convenience wrapper: plan straight from an overhead fraction."""
    return plan(n_data_fragments, parity_for(n_data_fragments, parity_fraction))


def encode_striped(fragments: list[np.ndarray], parity_fraction: float
                   ) -> tuple[list[np.ndarray], list[tuple[int, int]]]:
    """Encode a whole file's fragment list; returns (parity fragments, plan)."""
    layout = plan_blocks(len(fragments), parity_fraction)
    parity: list[np.ndarray] = []
    pos = 0
    for (k, m) in layout:
        block = np.stack(fragments[pos:pos + k])
        if m:
            parity.extend(list(encode_block(block, m)))
        pos += k
    return parity, layout


def decode_striped(layout: list[tuple[int, int]],
                   data_received: dict[int, np.ndarray],
                   parity_received: dict[int, np.ndarray],
                   frag_len: int) -> tuple[list[np.ndarray], list[int]]:
    """Reconstruct every block it can; returns (fragments, still-missing indices).

    Blocks are independent, so a file with one unrecoverable block still
    recovers every other block -- worth knowing when reporting a failure, since
    "one block short" is a very different situation from "the link is down".
    """
    out: list[np.ndarray] = []
    unrecoverable: list[int] = []
    d_pos = 0
    p_pos = 0
    for (k, m) in layout:
        have = {}
        for i in range(k):
            f = data_received.get(d_pos + i)
            if f is not None:
                have[i] = f
        for i in range(m):
            f = parity_received.get(p_pos + i)
            if f is not None:
                have[k + i] = f
        if len(have) >= k:
            out.extend(list(decode_block(have, k, m, frag_len)))
        else:
            for i in range(k):
                if (d_pos + i) not in data_received:
                    unrecoverable.append(d_pos + i)
                    out.append(np.zeros(frag_len, dtype=np.uint8))
                else:
                    out.append(data_received[d_pos + i])
        d_pos += k
        p_pos += m
    return out, unrecoverable
