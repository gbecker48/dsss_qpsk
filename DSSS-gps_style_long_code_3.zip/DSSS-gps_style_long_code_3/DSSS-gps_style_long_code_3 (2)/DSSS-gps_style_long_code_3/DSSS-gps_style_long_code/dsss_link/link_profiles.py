"""
link_profiles.py -- named operating points for the link
=======================================================

One set of DSP parameters cannot serve both of this project's goals at once.
Requirement 2 wants the spreading factor as high as possible so the signal
sits far below the noise floor; a usable file transfer wants throughput. Those
pull in opposite directions through one equation:

    symbol_rate = chip_rate / code_len

so at a fixed chip rate, every dB of processing gain is paid for directly in
data rate. That is not a limitation to work around -- it *is* requirement 3
("calculate required chip rate versus bit rate to achieve an SNR improvement"),
and making it a selectable, measurable knob turns a calculation into a
demonstration.

So the link has profiles. `stealth` is the original operating point and the one
the below-the-noise-floor demos use. The others trade spreading gain and chip
rate for throughput, and the table below is generated from the same arithmetic
the flowgraph uses, so the numbers quoted here are the numbers you get.

Choosing a profile
------------------
The profile is selected at *launch* time, not at runtime. Changing code length
or chip rate live would mean resizing filter taps, USRP sample rates and block
buffers underneath a running flowgraph, which GNU Radio does not support in any
way that could be called safe. Instead:

    LINK_PROFILE=bulk python3 dsss_bpsk_usrp.py

Both .grc files read `link_profiles.active()` in their variable blocks, so
every derived quantity -- sample rate, RRC taps, strobe period, despreader
search margin -- follows from the one environment variable. Leave it unset and
you get `stealth`, which is bit-for-bit the original configuration.

Sustainable rates
-----------------
The ceiling is not the radio. A B205mini-i over USB 3 will stream far more than
this link asks for; the limit is the despreader, which is a Python block doing
a correlation per candidate offset per symbol. Measured on a typical laptop
core after the vectorisation in dsss_core.Despreader, tracking sustains roughly
14 000 symbols/s at code_len=1023 -- so the profiles below are set at about a
third of that, leaving headroom for the RRC filters, the GUI sinks and the rest
of the flowgraph. `sustainable_headroom()` re-measures on the machine you are
actually on, because that margin is a claim worth checking rather than trusting.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, asdict


@dataclass(frozen=True)
class LinkProfile:
    """One complete operating point.

    Everything the flowgraph needs that depends on the spreading/rate trade
    lives here; anything that does not (framing, node ids, UDP ports) stays in
    the flowgraph, because it does not change between profiles.
    """

    name: str
    code_len: int
    chip_rate: float
    sps: int                      # samples per chip out of the pulse shaper
    search_margin: int            # despreader tracking window, in chips
    acq_epochs: int               # code periods integrated during acquisition
    freq_search_hz: float         # +- range of the 2-D acquisition search
    parity_fraction: float        # default erasure-coding overhead for files
    description: str

    # -- derived ------------------------------------------------------------
    @property
    def symbol_rate(self) -> float:
        return self.chip_rate / self.code_len

    @property
    def samp_rate(self) -> float:
        return self.chip_rate * self.sps

    @property
    def raw_bit_rate(self) -> float:
        """Channel bits per second. QPSK carries 2 bits per symbol."""
        return self.symbol_rate * 2.0

    @property
    def processing_gain_db(self) -> float:
        import math
        return 10.0 * math.log10(self.code_len)

    def payload_rate_bytes_per_s(self, payload_bytes: int = 256,
                                 frag_header_bytes: int = 12) -> float:
        """Useful bytes per second, after every layer of overhead.

        Counts the 8-byte sync word, the 1-byte sequence number, the 4-byte
        CRC32 and the fragment header -- i.e. what a file transfer actually
        achieves, not the channel bit rate that looks twice as good.
        """
        frame_bytes = 8 + 1 + payload_bytes + 4
        useful = payload_bytes - frag_header_bytes
        return self.raw_bit_rate / 8.0 * (useful / frame_bytes)

    def seconds_for(self, n_bytes: int, payload_bytes: int = 256,
                    frag_header_bytes: int = 12,
                    parity_fraction: float | None = None) -> float:
        """Wall-clock time to move `n_bytes`, including parity overhead."""
        pf = self.parity_fraction if parity_fraction is None else parity_fraction
        rate = self.payload_rate_bytes_per_s(payload_bytes, frag_header_bytes)
        return n_bytes * (1.0 + pf) / rate if rate > 0 else float("inf")

    def as_dict(self) -> dict:
        d = asdict(self)
        d.update(
            symbol_rate=self.symbol_rate,
            samp_rate=self.samp_rate,
            raw_bit_rate=self.raw_bit_rate,
            processing_gain_db=self.processing_gain_db,
            payload_rate_bytes_per_s=self.payload_rate_bytes_per_s(),
        )
        return d


# ---------------------------------------------------------------------------
# The profiles
#
# `stealth` reproduces the project's original USRP settings exactly -- same
# code length, chip rate and samples per chip -- so that "nothing changed"
# really means nothing changed. Only search_margin, acq_epochs and
# freq_search_hz differ, and those are the despreader fixes (see
# dsss_core.Despreader), which improve this profile rather than redefining it.
# ---------------------------------------------------------------------------

PROFILES: dict[str, LinkProfile] = {
    "stealth": LinkProfile(
        name="stealth",
        code_len=1023,
        chip_rate=511500.0,
        sps=8,
        search_margin=2,
        acq_epochs=4,
        freq_search_hz=5000.0,
        parity_fraction=0.20,
        description=(
            "Maximum hiding. 1023-chip GPS-style Gold code, 30.1 dB of "
            "processing gain, signal roughly 20 dB below the noise floor in "
            "its own bandwidth. The original operating point, and the one the "
            "spectrum-analyser and processing-gain demos use. About 100 bytes "
            "per second -- fine for messages, painful for files."
        ),
    ),
    "standard": LinkProfile(
        name="standard",
        code_len=1023,
        chip_rate=2046000.0,
        sps=4,
        search_margin=2,
        acq_epochs=4,
        freq_search_hz=5000.0,
        parity_fraction=0.20,
        description=(
            "Same 1023-chip code and the same 30.1 dB of processing gain, but "
            "four times the chip rate -- so four times the data rate for "
            "exactly the same hiding, paid for in occupied bandwidth (4 MHz "
            "instead of 1 MHz). This is requirement 3's trade in its clearest "
            "form: bandwidth buys rate at constant gain."
        ),
    ),
    "fast": LinkProfile(
        name="fast",
        code_len=511,
        chip_rate=2046000.0,
        sps=4,
        search_margin=2,
        acq_epochs=8,
        freq_search_hz=5000.0,
        parity_fraction=0.25,
        description=(
            "Shorter code: 511 chips, 27.1 dB of gain. Gives up 3 dB of hiding "
            "for twice the throughput at the same bandwidth. Still well below "
            "the noise floor."
        ),
    ),
    "bulk": LinkProfile(
        name="bulk",
        code_len=127,
        chip_rate=1651000.0,
        sps=4,
        search_margin=2,
        acq_epochs=8,
        freq_search_hz=5000.0,
        parity_fraction=0.30,
        description=(
            "File-transfer profile. 127-chip code, 21.0 dB of gain. About 26x "
            "the stealth profile's payload rate -- the difference between a "
            "megabyte taking three hours and taking six minutes. Note it needs "
            "LESS bandwidth than `fast`, not more: the shorter code is what "
            "buys the rate here, and the chip rate is actually backed off to "
            "keep the Python despreader comfortably ahead of real time. Still "
            "spread spectrum, still DSSS, just not invisible."
        ),
    ),
}

DEFAULT_PROFILE = "stealth"


def get(name: str | None = None) -> LinkProfile:
    """Look up a profile by name, with a clear error for a typo."""
    if name is None:
        name = DEFAULT_PROFILE
    key = str(name).strip().lower()
    if key not in PROFILES:
        raise KeyError(
            f"unknown link profile {name!r}; available: "
            + ", ".join(sorted(PROFILES))
        )
    return PROFILES[key]


def active() -> LinkProfile:
    """The profile this process should run, from $LINK_PROFILE.

    Called from the .grc variable blocks, so a bad value has to fail loudly
    here rather than half-configuring a flowgraph.
    """
    return get(os.environ.get("LINK_PROFILE", DEFAULT_PROFILE))


def comparison_table(n_bytes: int = 1_000_000) -> str:
    """The chip-rate / bit-rate / processing-gain trade, as a table.

    This is requirement 3's deliverable in text form; demo 3 plots the same
    numbers and then measures them to check they are true.
    """
    lines = [
        f"{'profile':10} {'code':>5} {'chip rate':>11} {'sym rate':>9} "
        f"{'raw bps':>9} {'payload':>9} {'PG dB':>6} {'BW MHz':>7} "
        f"{'1 MB in':>10}",
        "-" * 92,
    ]
    for p in PROFILES.values():
        secs = p.seconds_for(n_bytes)
        if secs >= 3600:
            t = f"{secs / 3600:.1f} h"
        elif secs >= 60:
            t = f"{secs / 60:.1f} min"
        else:
            t = f"{secs:.0f} s"
        lines.append(
            f"{p.name:10} {p.code_len:>5} {p.chip_rate / 1e6:>10.3f}M "
            f"{p.symbol_rate:>9.0f} {p.raw_bit_rate:>9.0f} "
            f"{p.payload_rate_bytes_per_s():>8.0f}B {p.processing_gain_db:>6.1f} "
            f"{2 * p.chip_rate / 1e6:>7.2f} {t:>10}"
        )
    return "\n".join(lines)


def sustainable_headroom(profile: LinkProfile | None = None,
                         n_symbols: int = 3000) -> dict:
    """Measure, on this machine, how much faster than real time the despreader
    runs for a profile.

    A ratio comfortably above 1 means the profile is sustainable here. Below
    about 3 means the flowgraph will probably work but with little margin for
    the GUI sinks, the OS, and USB scheduling jitter -- which on real hardware
    shows up as TX underflow and RX overflow rather than as a clean slowdown.
    """
    import time
    import numpy as np
    from . import dsss_core as core

    p = profile or active()
    code = core.gold_code_family(p.code_len, 2)
    syms = core.qpsk_modulate(
        np.random.default_rng(0).integers(0, 4, n_symbols))
    chips = core.spread(syms, code)

    d = core.Despreader(p.code_len, search_margin=p.search_margin,
                        chip_rate=p.chip_rate)
    d.code = code
    d.acquired = True
    d.center = p.code_len

    t0 = time.perf_counter()
    out = d.process(chips)
    elapsed = time.perf_counter() - t0

    achieved = len(out) / elapsed if elapsed > 0 else float("inf")
    return {
        "profile": p.name,
        "symbols_processed": len(out),
        "elapsed_s": elapsed,
        "symbols_per_s": achieved,
        "required_symbols_per_s": p.symbol_rate,
        "realtime_ratio": achieved / p.symbol_rate if p.symbol_rate else 0.0,
    }


if __name__ == "__main__":
    print(comparison_table())
    print()
    for name in PROFILES:
        r = sustainable_headroom(get(name))
        print(f"{name:10} despreader runs {r['realtime_ratio']:6.1f}x real time "
              f"({r['symbols_per_s']:.0f} sym/s vs {r['required_symbols_per_s']:.0f} needed)")
