"""
protocol.py -- the wire format, canonical definition
====================================================

Everything that goes over the air, defined once. The GNU Radio blocks
(custom_blocks/tx_scheduler.py, custom_blocks/fragment_reassembler.py) carry
their own copies of the pack/unpack routines because a GRC embedded Python
block must be self-contained; tests/test_protocol_matches_blocks.py asserts
those copies agree with this file byte for byte.

Frame, outermost first
----------------------
    [ SYNC 8B (fixed, never scrambled) ][ SEQ 1B ][ PAYLOAD 256B ][ CRC32 4B ]
                                        \\______________ scrambled ______________/

That layer is unchanged from the original design and is not this file's
business -- see custom_blocks/pkt_framer.py. What changed is the PAYLOAD.

Fragment header (v2), 12 bytes at the head of every PAYLOAD
------------------------------------------------------------
    off  size  field
    0    1     SRC          sending node id
    1    1     DST          destination node id, or 0xFF broadcast
    2    1     TYPE         IDLE / DATA / PARITY / BERT
    3    1     MSG_ID       rolling message id, wraps at 256
    4    2     FRAG_IDX     big-endian fragment index within its class
    6    2     N_DATA       total data fragments in this message
    8    2     N_PARITY     total parity fragments in this message
    10   2     CHUNK_LEN    valid bytes in DATA
    12   244   DATA

Why it grew from 6 bytes to 12
-------------------------------
The v1 header used single bytes for FRAG_IDX and FRAG_TOTAL, capping a message
at 256 fragments -- 64 000 bytes. That is a fine ceiling for chat and a hard
wall for file transfer. Sixteen-bit indices raise it to 65 535 fragments, about
16 MB, which is past anything this link's data rate makes reasonable to attempt
anyway.

The other four bytes buy two things the file transfer genuinely needs: TYPE, so
parity fragments and BER test patterns can share the same framing instead of
needing side channels, and N_PARITY, so a receiver can work out the
erasure-coding layout from any single fragment it happens to catch first. That
last property matters more than it sounds -- it means a receiver that misses the
start of a transfer still knows exactly what it is looking at.

IDLE frames keep their v1 meaning: TYPE_IDLE with N_DATA == 0. The physical
layer never goes quiet, because a despreader that has to re-acquire every time
the transmitter pauses is a despreader that spends its life re-acquiring.
"""

from __future__ import annotations

import hashlib
import struct
import numpy as np

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

HEADER_BYTES = 12
PROTOCOL_VERSION = 2

TYPE_IDLE = 0
TYPE_DATA = 1
TYPE_PARITY = 2
TYPE_BERT = 3

TYPE_NAMES = {
    TYPE_IDLE: "IDLE",
    TYPE_DATA: "DATA",
    TYPE_PARITY: "PARITY",
    TYPE_BERT: "BERT",
}

BROADCAST_NODE = 0xFF
MAX_FRAGMENTS = 0xFFFF

FILE_MAGIC = b"DSF1"          # marks a message whose payload is a file


# ---------------------------------------------------------------------------
# Fragment header
# ---------------------------------------------------------------------------

_HDR = struct.Struct(">BBBBHHHH")
assert _HDR.size == HEADER_BYTES


def pack_header(src: int, dst: int, msg_type: int, msg_id: int, frag_idx: int,
                n_data: int, n_parity: int, chunk_len: int) -> bytes:
    return _HDR.pack(src & 0xFF, dst & 0xFF, msg_type & 0xFF, msg_id & 0xFF,
                     frag_idx & 0xFFFF, n_data & 0xFFFF,
                     n_parity & 0xFFFF, chunk_len & 0xFFFF)


def unpack_header(payload: bytes) -> dict:
    """Parse a fragment header. Returns a dict; never raises on short input.

    Tolerant on purpose: this runs on data that has passed CRC32, so it should
    always be well-formed, but a receiver that crashes on a malformed frame is
    a receiver that can be taken down by one unlucky bit flip in the length
    field. A bad fragment should be dropped, not fatal.
    """
    if len(payload) < HEADER_BYTES:
        return {"valid": False}
    src, dst, mtype, mid, idx, n_data, n_par, clen = _HDR.unpack(
        payload[:HEADER_BYTES])
    max_chunk = len(payload) - HEADER_BYTES
    return {
        "valid": True,
        "src": src,
        "dst": dst,
        "type": mtype,
        "type_name": TYPE_NAMES.get(mtype, f"UNKNOWN_{mtype}"),
        "msg_id": mid,
        "frag_idx": idx,
        "n_data": n_data,
        "n_parity": n_par,
        "chunk_len": min(clen, max_chunk),
        "data": payload[HEADER_BYTES:HEADER_BYTES + min(clen, max_chunk)],
        "raw_chunk": payload[HEADER_BYTES:],
    }


def chunk_bytes(payload_bytes: int = 256) -> int:
    return payload_bytes - HEADER_BYTES


def max_message_bytes(payload_bytes: int = 256) -> int:
    return chunk_bytes(payload_bytes) * MAX_FRAGMENTS


# ---------------------------------------------------------------------------
# Erasure-coding layout, derived from header fields alone
# ---------------------------------------------------------------------------


def plan_from_counts(n_data: int, n_parity: int) -> list[tuple[int, int]]:
    """Reconstruct the RS block layout from (N_DATA, N_PARITY).

    Both ends have to agree on how the message was split into RS blocks.
    Rather than carry the layout on the wire, it is derived from the two totals
    every fragment already carries, by a rule both ends run identically -- so a
    receiver needs no handshake and no state from before it started listening.
    See erasure_fec.plan for why it is keyed on the totals and not the fraction.
    """
    from . import erasure_fec
    return erasure_fec.plan(n_data, n_parity)


def parity_count_for(n_data: int, parity_fraction: float) -> int:
    """How many parity fragments `parity_fraction` implies for `n_data`.

    The transmitter calls this to fill N_PARITY; the receiver feeds that value
    back into plan_from_counts. A mismatch is a silent, total decode failure,
    so both go through erasure_fec rather than recomputing the arithmetic here.
    """
    from . import erasure_fec
    return erasure_fec.parity_for(n_data, parity_fraction)


# ---------------------------------------------------------------------------
# File transfer payload
# ---------------------------------------------------------------------------

_FILE_HDR = struct.Struct(">4sBBHQ32s")   # magic, ver, flags, name_len, size, sha


def pack_file_payload(filename: str, data: bytes) -> bytes:
    """Wrap a file into a message payload: header, name, then the bytes.

    The header is part of the payload rather than a separate control fragment,
    so it is covered by the same erasure coding as the file body. A lost header
    fragment is reconstructed like any other -- whereas an unprotected
    out-of-band header would be a single point of failure for the whole
    transfer, and would fail exactly when the link is worst.
    """
    name = filename.encode("utf-8")[:65535]
    digest = hashlib.sha256(data).digest()
    return (_FILE_HDR.pack(FILE_MAGIC, PROTOCOL_VERSION, 0, len(name),
                           len(data), digest) + name + data)


def unpack_file_payload(payload: bytes) -> dict | None:
    """Parse a file message. Returns None if it is not one (i.e. plain text).

    `sha_ok` is the point of the whole exercise: the CRC32 in each frame proves
    each *fragment* arrived intact, but only an end-to-end hash proves the
    reassembled, erasure-decoded file is the file that was sent. Those are
    different claims, and for a file transfer the second is the one that
    matters.
    """
    if len(payload) < _FILE_HDR.size or payload[:4] != FILE_MAGIC:
        return None
    magic, ver, flags, name_len, size, digest = _FILE_HDR.unpack(
        payload[:_FILE_HDR.size])
    off = _FILE_HDR.size
    name = payload[off:off + name_len].decode("utf-8", "replace")
    off += name_len
    data = payload[off:off + size]
    return {
        "version": ver,
        "flags": flags,
        "filename": name,
        "declared_size": size,
        "actual_size": len(data),
        "sha256": digest.hex(),
        "sha_ok": hashlib.sha256(data).digest() == digest,
        "complete": len(data) == size,
        "data": data,
    }


def is_file_payload(payload: bytes) -> bool:
    return len(payload) >= 4 and payload[:4] == FILE_MAGIC


# ---------------------------------------------------------------------------
# Fragmentation
# ---------------------------------------------------------------------------


def fragment_message(data: bytes, payload_bytes: int = 256,
                     parity_fraction: float = 0.0
                     ) -> tuple[list[np.ndarray], list[np.ndarray]]:
    """Split a message into data fragments and compute its parity fragments.

    Fragments are zero-padded to a fixed length before encoding, because Reed-
    Solomon operates column-wise across fragments and needs them all the same
    size. The real length of the last one is carried in CHUNK_LEN.
    """
    from . import erasure_fec

    cb = chunk_bytes(payload_bytes)
    n = max(1, int(np.ceil(len(data) / cb)))
    if n > MAX_FRAGMENTS:
        raise ValueError(
            f"message of {len(data)} bytes needs {n} fragments, "
            f"over the {MAX_FRAGMENTS} the 16-bit index allows "
            f"(max {max_message_bytes(payload_bytes)} bytes)"
        )

    frags = []
    for i in range(n):
        chunk = data[i * cb:(i + 1) * cb]
        buf = np.zeros(cb, dtype=np.uint8)
        buf[:len(chunk)] = np.frombuffer(chunk, dtype=np.uint8)
        frags.append(buf)

    parity = []
    if parity_fraction > 0:
        parity, _plan = erasure_fec.encode_striped(frags, parity_fraction)
    return frags, parity


def true_chunk_lengths(total_bytes: int, n_frags: int, cb: int) -> list[int]:
    """Per-fragment valid byte counts (only the last one is short)."""
    out = []
    left = total_bytes
    for _ in range(n_frags):
        out.append(min(cb, max(0, left)))
        left -= cb
    return out


# ---------------------------------------------------------------------------
# PRBS bit-error-rate test pattern
# ---------------------------------------------------------------------------


class PRBS15:
    """PRBS-15 generator, x^15 + x^14 + 1 -- the ITU-T O.150 test pattern.

    A real BER measurement needs data the receiver already knows, and a
    pseudo-random sequence is how that is done without sending the answer along
    with the question: the receiver seeds its own generator from the bits it
    receives and then *predicts* every bit after that. Any mismatch is a genuine
    channel bit error, counted over an unlimited run length with no file to
    compare against and no storage growing on either side.

    Period is 32767 bits, long enough that the pattern's own structure cannot
    flatter the link the way a short repeating pattern would.
    """

    def __init__(self, seed: int = 0x7FFF):
        self.state = seed & 0x7FFF or 0x7FFF

    def next_bit(self) -> int:
        fb = ((self.state >> 14) ^ (self.state >> 13)) & 1
        self.state = ((self.state << 1) | fb) & 0x7FFF
        return fb

    def bits(self, n: int) -> np.ndarray:
        out = np.empty(n, dtype=np.uint8)
        s = self.state
        for i in range(n):
            fb = ((s >> 14) ^ (s >> 13)) & 1
            s = ((s << 1) | fb) & 0x7FFF
            out[i] = fb
        self.state = s
        return out

    def bytes(self, n: int) -> bytes:
        return np.packbits(self.bits(n * 8)).tobytes()


def prbs15_check(received_bits: np.ndarray, min_sync_bits: int = 32
                 ) -> dict:
    """Count bit errors in a received PRBS-15 stream.

    Sync first: load 15 received bits into the generator state and run forward.
    If those 15 bits happened to contain an error the prediction is nonsense
    and the error count comes out near 50%, so several candidate start offsets
    are tried and the best is kept -- standard BERT practice, and the reason a
    BERT reports "sync lost" rather than "BER = 0.5" when the link drops.

    Returns errors, bits compared, BER, and a 95% confidence interval, because
    a BER quoted without a bit count is not a measurement. Three errors in
    10 000 bits and 3000 errors in 10 000 000 bits are the same ratio and very
    different levels of confidence.
    """
    bits = np.asarray(received_bits, dtype=np.uint8).ravel()
    if len(bits) < min_sync_bits + 15:
        return {"synced": False, "errors": 0, "bits": 0, "ber": float("nan")}

    best = None
    for start in range(0, min(8, max(1, len(bits) - 15 - min_sync_bits))):
        seed = 0
        for b in bits[start:start + 15]:
            seed = ((seed << 1) | int(b)) & 0x7FFF
        if seed == 0:
            continue
        gen = PRBS15(seed)
        n = len(bits) - start - 15
        predicted = gen.bits(n)
        errs = int(np.count_nonzero(predicted ^ bits[start + 15:start + 15 + n]))
        if best is None or errs < best[0]:
            best = (errs, n, start)

    if best is None:
        return {"synced": False, "errors": 0, "bits": 0, "ber": float("nan")}

    errs, n, start = best
    ber = errs / n if n else float("nan")
    # A BER above ~30% means the generator never synced -- there is no channel
    # so bad that it produces a *correlated* half of the bits wrong; that is
    # what loss of sync looks like, and reporting it as a BER would be a lie.
    synced = n > 0 and ber < 0.3

    if n > 0 and errs > 0:
        se = np.sqrt(ber * (1 - ber) / n)
        lo, hi = max(0.0, ber - 1.96 * se), min(1.0, ber + 1.96 * se)
    elif n > 0:
        # Rule of three: zero errors in n trials bounds BER below 3/n at 95%.
        lo, hi = 0.0, 3.0 / n
    else:
        lo = hi = float("nan")

    return {
        "synced": synced,
        "errors": errs,
        "bits": n,
        "ber": ber,
        "ci95": (lo, hi),
        "sync_offset": start,
    }
