"""
filexfer.py -- host-side file transfer, shared by the GUI and the terminal
===========================================================================

The flowgraph moves *messages*. This turns a file into one, and turns one back
into a file, with an end-to-end integrity check that means something.

Two layers of checking, and they answer different questions
------------------------------------------------------------
The CRC32 in every frame proves each fragment arrived intact. It says nothing
about whether the file did: fragments can be missing entirely, the erasure
decoder can have reconstructed some of them, and the reassembled order could
in principle be wrong. Only a hash over the whole file answers that.

So every transfer carries a SHA-256 of the original bytes inside the message,
where it is covered by the same Reed-Solomon parity as the data. A received
file is written to disk only after that hash matches, and a mismatch is
reported as a failure rather than quietly saved -- a silently corrupt file is
worse than no file.

Progress
--------
`TransferProgress` tracks a send against the FRAG status lines the flowgraph
emits, so the GUI's progress bar reflects fragments the *receiver*
acknowledged seeing rather than bytes this process handed to a socket. Those
are very different numbers on a link with no flow control: the UDP send
completes in microseconds and the transmission takes minutes.
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass, field

from . import protocol


MAX_SENSIBLE_BYTES = 8 * 1024 * 1024     # refuse obviously silly transfers


def prepare_file(path: str, parity_fraction: float = 0.20,
                 payload_bytes: int = 256) -> dict:
    """Read a file and work out exactly what sending it will involve.

    Returns the message bytes plus the numbers the UI needs to tell the user
    what they are committing to *before* they start -- fragment counts,
    parity overhead and estimated airtime. On a link that moves a hundred
    bytes a second, "this will take three hours" is information the user
    needs in advance, not a discovery they make twenty minutes in.
    """
    with open(path, "rb") as f:
        data = f.read()

    name = os.path.basename(path)
    message = protocol.pack_file_payload(name, data)
    cb = protocol.chunk_bytes(payload_bytes)
    n_data = max(1, -(-len(message) // cb))
    n_parity = protocol.parity_count_for(n_data, parity_fraction)

    return {
        "path": path,
        "filename": name,
        "file_bytes": len(data),
        "message": message,
        "message_bytes": len(message),
        "n_data": n_data,
        "n_parity": n_parity,
        "n_total": n_data + n_parity,
        "parity_fraction": parity_fraction,
        "sha256": protocol.unpack_file_payload(message)["sha256"],
        "too_large": len(message) > protocol.max_message_bytes(payload_bytes),
        "max_bytes": protocol.max_message_bytes(payload_bytes),
    }


def estimate_seconds(n_total_fragments: int, profile) -> float:
    """Airtime for a given fragment count on a given link profile."""
    frame_bits = (8 + 1 + 256 + 4) * 8
    symbols_per_frame = frame_bits / 2
    return n_total_fragments * symbols_per_frame / profile.symbol_rate


def human_bytes(n: float) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if abs(n) < 1024 or unit == "GB":
            return f"{n:,.0f} {unit}" if unit == "B" else f"{n:,.1f} {unit}"
        n /= 1024.0
    return f"{n:.1f} GB"


def human_duration(seconds: float) -> str:
    if not (seconds == seconds) or seconds < 0:      # NaN guard
        return "--"
    if seconds < 90:
        return f"{seconds:.0f}s"
    if seconds < 5400:
        return f"{seconds / 60:.1f} min"
    return f"{seconds / 3600:.1f} h"


@dataclass
class TransferProgress:
    """One in-flight send, tracked against what the receiver reports seeing."""
    msg_id: int
    filename: str
    file_bytes: int
    n_data: int
    n_parity: int
    started: float = field(default_factory=time.monotonic)
    seen_data: set = field(default_factory=set)
    seen_parity: set = field(default_factory=set)
    done: bool = False
    failed: bool = False
    note: str = ""

    @property
    def n_total(self):
        return self.n_data + self.n_parity

    @property
    def seen(self):
        return len(self.seen_data) + len(self.seen_parity)

    @property
    def fraction(self):
        return min(1.0, self.seen / self.n_total) if self.n_total else 0.0

    @property
    def elapsed(self):
        return time.monotonic() - self.started

    @property
    def rate_bytes_per_s(self):
        e = self.elapsed
        if e <= 0 or not self.seen:
            return 0.0
        return self.file_bytes * self.fraction / e

    @property
    def eta_seconds(self):
        f = self.fraction
        if f <= 0.01:
            return float("nan")
        return self.elapsed * (1.0 - f) / f

    def note_fragment(self, kind: str, idx: int):
        (self.seen_parity if kind == "PARITY" else self.seen_data).add(idx)

    def summary(self) -> str:
        if self.failed:
            return f"failed -- {self.note}"
        if self.done:
            return (f"delivered in {human_duration(self.elapsed)} "
                    f"({human_bytes(self.rate_bytes_per_s)}/s)")
        return (f"{self.seen}/{self.n_total} fragments · "
                f"{self.fraction * 100:.0f}% · "
                f"{human_duration(self.eta_seconds)} left")


class IncomingFiles:
    """Turns complete received messages into verified files on disk."""

    def __init__(self, save_dir: str):
        self.save_dir = save_dir
        self.received = []

    def handle(self, payload: bytes) -> dict | None:
        """Process one complete message. Returns a record if it was a file."""
        info = protocol.unpack_file_payload(payload)
        if info is None:
            return None

        os.makedirs(self.save_dir, exist_ok=True)
        safe = os.path.basename(info["filename"]) or "received.bin"
        # Never overwrite: a second transfer of the same name is a second
        # file, and silently replacing the first would lose data the link
        # spent minutes delivering.
        dest = os.path.join(self.save_dir, safe)
        stem, ext = os.path.splitext(dest)
        n = 1
        while os.path.exists(dest):
            dest = f"{stem}_{n}{ext}"
            n += 1

        record = {
            "filename": safe,
            "bytes": info["actual_size"],
            "declared": info["declared_size"],
            "sha256": info["sha256"],
            "sha_ok": info["sha_ok"],
            "complete": info["complete"],
            "path": dest if info["sha_ok"] else None,
            "when": time.time(),
        }

        if info["sha_ok"]:
            with open(dest, "wb") as f:
                f.write(info["data"])
        self.received.append(record)
        return record
