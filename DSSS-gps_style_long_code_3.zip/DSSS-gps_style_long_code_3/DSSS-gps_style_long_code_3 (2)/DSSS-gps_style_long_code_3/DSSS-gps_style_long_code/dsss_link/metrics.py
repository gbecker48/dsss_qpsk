"""
metrics.py -- the link's measurements, defined once so they agree
=================================================================

Every SNR, gain and error-rate figure this project quotes is computed here.
Putting them in one file is not tidiness: this project had a metric that was
mislabelled, and a mislabelled metric is worse than a missing one because it
gets believed.

The one that was wrong
----------------------
The Debug window reported "Processing gain, actual" as the despread
correlation peak divided by the median of the nearby correlations, alongside
"Processing gain, ideal" of 10*log10(1023) = 30.1 dB, inviting the reader to
treat the difference as implementation loss.

Those are not the same measurement. Peak-over-neighbours is the code's
**peak-to-sidelobe ratio**, and for a length-1023 Gold code the sidelobes are
fixed at 65, so the number saturates at 10*log10(1023/65) = 12 dB on a perfect
noiseless link. It can never approach 30 dB, and the 18 dB "gap" it appears to
show is an artefact of comparing two different quantities.

Processing gain is a property of a *pair* of measurements -- SNR before
despreading and SNR after -- so measuring it needs both. `processing_gain_db`
takes both and says so in its signature; `peak_to_sidelobe_db` is kept as the
lock-quality indicator it always was, under its real name.

The three SNRs
--------------
Named consistently across this whole codebase:

    snr_chip_db     in the spread bandwidth, what a spectrum analyser sees.
                    Negative on this link -- that is the point.
    snr_symbol_db   after the correlator collapses code_len chips to one
                    symbol. Equals Es/N0 for an ideal correlator.
    ebn0_db         per information bit. What BER curves are plotted against.
"""

from __future__ import annotations

import math
import numpy as np

# ---------------------------------------------------------------------------
# Conversions
# ---------------------------------------------------------------------------

BITS_PER_QPSK_SYMBOL = 2


def esn0_to_ebn0_db(esn0_db: float, code_rate: float = 1.0) -> float:
    """Es/N0 -> Eb/N0. QPSK carries 2 bits per symbol; FEC lowers the rate."""
    return esn0_db - 10.0 * math.log10(BITS_PER_QPSK_SYMBOL * code_rate)


def ebn0_to_esn0_db(ebn0_db: float, code_rate: float = 1.0) -> float:
    return ebn0_db + 10.0 * math.log10(BITS_PER_QPSK_SYMBOL * code_rate)


def symbol_snr_to_chip_snr_db(snr_symbol_db: float, code_len: int) -> float:
    """What the same signal looks like *before* despreading."""
    return snr_symbol_db - 10.0 * math.log10(code_len)


def chip_snr_to_symbol_snr_db(snr_chip_db: float, code_len: int) -> float:
    return snr_chip_db + 10.0 * math.log10(code_len)


def ideal_processing_gain_db(code_len: int) -> float:
    return 10.0 * math.log10(code_len)


def processing_gain_db(snr_symbol_db: float, snr_chip_db: float) -> float:
    """Measured processing gain: the SNR the despreader actually recovered.

    Requires BOTH measurements, deliberately. There is no way to measure
    processing gain from the despread signal alone -- the ratio of the
    correlation peak to its own neighbours tells you about the *code*, not
    about how much SNR the spreading bought.
    """
    return snr_symbol_db - snr_chip_db


def implementation_loss_db(measured_gain_db: float, code_len: int) -> float:
    """How far short of 10*log10(code_len) the real receiver fell."""
    return ideal_processing_gain_db(code_len) - measured_gain_db


def required_chip_rate(bit_rate: float, required_gain_db: float) -> float:
    """Chip rate needed for a target processing gain at a given bit rate.

    Requirement 3, solved forwards. Gp = 10*log10(Rc/Rb) for BPSK-per-chip
    spreading, so Rc = Rb * 10^(Gp/10). The answer is also, directly, the
    occupied bandwidth you are asking for -- which is usually what makes the
    requirement binding in practice.
    """
    return bit_rate * (10.0 ** (required_gain_db / 10.0))


def required_gain_db(snr_chip_db: float, required_ebn0_db: float = 9.6,
                     code_rate: float = 1.0) -> float:
    """Processing gain needed to close a link from a given input SNR.

    9.6 dB is the Eb/N0 at which coherent QPSK reaches BER 1e-5; pass your own
    target if you need a different operating point.
    """
    required_esn0 = ebn0_to_esn0_db(required_ebn0_db, code_rate)
    return required_esn0 - snr_chip_db


# ---------------------------------------------------------------------------
# Estimators that work on real samples
# ---------------------------------------------------------------------------


def evm_percent(symbols: np.ndarray) -> float:
    """RMS error vector magnitude, as a percentage of the ideal magnitude.

    Nearest ideal point is found by quadrant, so no assumption is made about
    the absolute amplitude -- which matters here because the despread
    correlation's scale depends on code length and received power and is never
    normalised in the chain.
    """
    s = np.asarray(symbols, dtype=np.complex128)
    if len(s) == 0:
        return float("nan")
    nearest = (np.where(np.real(s) >= 0, 1.0, -1.0)
               + 1j * np.where(np.imag(s) >= 0, 1.0, -1.0)) / np.sqrt(2)
    denom = float(np.sum(np.abs(nearest) ** 2))
    if denom <= 0:
        return float("nan")
    alpha = float(np.sum(np.real(s * np.conj(nearest)))) / denom
    if alpha == 0:
        return float("nan")
    err = s - alpha * nearest
    ref_rms = float(np.sqrt(np.mean(np.abs(alpha * nearest) ** 2)))
    if ref_rms <= 0:
        return float("nan")
    return 100.0 * float(np.sqrt(np.mean(np.abs(err) ** 2))) / ref_rms


def evm_to_snr_db(evm_pct: float) -> float:
    """SNR implied by an EVM figure: SNR = -20*log10(EVM).

    Exact only when the error really is additive Gaussian. Phase noise from a
    wide carrier loop inflates EVM without being thermal noise, so on this link
    -- whose Costas loop is deliberately wide because the symbol rate is low --
    this reads pessimistic. `snr_m2m4_db` does not have that bias and is the
    better estimator when both are available.
    """
    if not np.isfinite(evm_pct) or evm_pct <= 0:
        return float("inf")
    return -20.0 * math.log10(evm_pct / 100.0)


def snr_m2m4_db(symbols: np.ndarray) -> float:
    """M2M4 moment-based SNR estimate for a QPSK (constant-modulus) signal.

    Uses only the second and fourth moments of the received symbols, so it
    needs no decisions, no training sequence and no knowledge of the data --
    which makes it usable on a live link and immune to the decision errors
    that bias an EVM estimate at low SNR.

    For a constant-modulus constellation in AWGN:
        M2 = S + N
        M4 = S^2 + 4*S*N + 2*N^2
        S  = sqrt(2*M2^2 - M4)
    """
    s = np.asarray(symbols, dtype=np.complex128)
    if len(s) < 16:
        return float("nan")
    m2 = float(np.mean(np.abs(s) ** 2))
    m4 = float(np.mean(np.abs(s) ** 4))
    disc = 2.0 * m2 * m2 - m4
    if disc <= 0:
        return float("-inf")
    sig = math.sqrt(disc)
    noise = m2 - sig
    if noise <= 0:
        return float("inf")
    return 10.0 * math.log10(sig / noise)


def spectral_snr_db(psd_signal: np.ndarray, psd_noise_only: np.ndarray
                    ) -> float:
    """In-band SNR from a spectrum with the transmitter on versus off.

    This is the honest way to measure the pre-despread SNR, and the
    measurement requirement 6 is really asking for: the spread signal is below
    the noise floor, so it cannot be separated from the noise in a single
    capture. Taking one capture with the transmitter keyed and one without, the
    difference in total in-band power is the signal power, and the TX-off
    capture is the noise power.
    """
    p_sig = float(np.mean(psd_signal))
    p_noise = float(np.mean(psd_noise_only))
    if p_noise <= 0:
        return float("inf")
    excess = p_sig - p_noise
    if excess <= 0:
        # The signal did not raise the noise floor measurably -- which is the
        # expected outcome for a deeply spread signal, and is a result rather
        # than a failure. Report the detection floor instead of a fake number.
        return float("-inf")
    return 10.0 * math.log10(excess / p_noise)


# ---------------------------------------------------------------------------
# BER
# ---------------------------------------------------------------------------


def qfunc(x: float) -> float:
    return 0.5 * math.erfc(x / math.sqrt(2.0))


def qpsk_ber_theory(ebn0_db: float) -> float:
    """Coherent Gray-coded QPSK in AWGN: BER = Q(sqrt(2*Eb/N0))."""
    return qfunc(math.sqrt(2.0 * 10.0 ** (ebn0_db / 10.0)))


def dqpsk_ber_theory(ebn0_db: float) -> float:
    """Differentially *decoded* coherent QPSK.

    Not the same thing as differentially *detected* DQPSK. Here the carrier is
    recovered coherently by the Costas loop and the differential decoding only
    resolves that loop's four-fold phase ambiguity -- so a symbol error
    corrupts the decision either side of it and the bit error rate roughly
    doubles, rather than costing the ~2.3 dB that true differential detection
    does.
    """
    return 2.0 * qpsk_ber_theory(ebn0_db)


def ber_confidence_interval(errors: int, bits: int, z: float = 1.96
                            ) -> tuple[float, float]:
    """95% interval for a measured BER.

    A BER without a bit count is not a measurement. Zero errors uses the rule
    of three -- an upper bound of 3/n -- because "BER = 0" is never a result,
    only a statement that the run was too short to see one.
    """
    if bits <= 0:
        return (float("nan"), float("nan"))
    if errors == 0:
        return (0.0, 3.0 / bits)
    p = errors / bits
    se = math.sqrt(p * (1 - p) / bits)
    return (max(0.0, p - z * se), min(1.0, p + z * se))


def bits_needed_for_ber(target_ber: float, min_errors: int = 100) -> int:
    """How many bits a credible measurement of `target_ber` takes.

    Useful before starting a BER run, so nobody spends twenty minutes
    measuring and reports a number built on three errors.
    """
    if target_ber <= 0:
        return 0
    return int(math.ceil(min_errors / target_ber))


def implementation_loss_from_ber(measured_ber: float, ebn0_db: float,
                                 theory=dqpsk_ber_theory,
                                 max_db: float = 20.0) -> float:
    """dB of Eb/N0 the real link needs beyond theory to reach the same BER.

    The single most useful summary of receiver quality: it collapses "how good
    is this implementation" into one number, in the units the link budget is
    written in.
    """
    if not (0 < measured_ber < 0.5):
        return float("nan")
    lo, hi = 0.0, max_db
    for _ in range(80):
        mid = (lo + hi) / 2.0
        if theory(ebn0_db - mid) < measured_ber:
            lo = mid
        else:
            hi = mid
    return lo


# ---------------------------------------------------------------------------
# Jamming
# ---------------------------------------------------------------------------


def jamming_margin_db(code_len: int, required_ebn0_db: float = 9.6,
                      code_rate: float = 1.0) -> float:
    """Theoretical jamming margin: how much stronger than the signal a
    wideband jammer can be before the link fails.

        M_j = Gp - (Eb/N0)_required - L_sys

    This is the number requirement 8 exists to demonstrate, and the reason a
    30 dB spreading gain is worth its cost in bandwidth.
    """
    return (ideal_processing_gain_db(code_len)
            - ebn0_to_esn0_db(required_ebn0_db, code_rate)
            + 10.0 * math.log10(BITS_PER_QPSK_SYMBOL))


def jsr_to_effective_esn0_db(esn0_db: float, jsr_db: float, code_len: int,
                             jammer_bandwidth_fraction: float = 1.0) -> float:
    """Effective Es/N0 once a jammer is added to the thermal noise.

    A jammer at J/S adds interference power J = S * 10^(JSR/10), which the
    despreader spreads over the full code bandwidth exactly as it does the
    signal -- so a jammer occupying only a fraction of the band has only that
    fraction of its power land in the despread bandwidth. That asymmetry is why
    a narrowband tone is nearly harmless to DSSS while broadband noise is not,
    and demo 8 measures both.
    """
    s_over_n = 10.0 ** (esn0_db / 10.0)
    j_over_s = 10.0 ** (jsr_db / 10.0)
    # Jammer power after despreading, relative to signal: suppressed by the
    # processing gain, scaled by how much of the band it actually occupies.
    j_effective = j_over_s * jammer_bandwidth_fraction / code_len
    total = 1.0 / s_over_n + j_effective
    if total <= 0:
        return float("inf")
    return 10.0 * math.log10(1.0 / total)
