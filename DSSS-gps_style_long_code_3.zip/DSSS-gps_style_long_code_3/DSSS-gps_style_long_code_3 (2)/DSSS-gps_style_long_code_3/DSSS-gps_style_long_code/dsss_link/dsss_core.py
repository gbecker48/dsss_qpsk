"""
dsss_core.py -- the link's DSP, as an importable, hardware-free reference
=========================================================================

Every algorithm the flowgraph performs on the air is reimplemented here, in
plain NumPy, with *identical* maths: the GPS-style Gold code generator, the
symbol-domain spreader, the FFT-acquisition + bounded-local-search-tracking
despreader, RRC pulse shaping, differential QPSK, and an AWGN/CFO/clock-drift
channel.

Why this file exists
--------------------
The eight project requirements all have to be *demonstrated*, and several of
them (processing gain, BER vs. Eb/N0, the chip-rate/bit-rate trade, whether
carrier-offset compensation is actually needed, jamming margin) need a sweep
over dozens of operating points. Sweeping those on real hardware would take
hours per curve and would never be repeatable.

So the demos sweep here instead -- but that is only honest if the simulation
runs *the same algorithm the radio runs*, not a tidied-up textbook version of
it. That is the contract this file keeps:

    tests/test_core_matches_blocks.py asserts, mechanically, that the Gold
    code generated here is bit-identical to the one in
    custom_blocks/dsss_spreader.py and custom_blocks/dsss_despreader.py, and
    that this file's Despreader produces the same symbol sequence as the
    flowgraph block's algorithm on the same input.

If you change a spreading/despreading algorithm in one place and not the
other, that test fails. Do not "fix" the test by loosening it.

Units and conventions (read this before trusting any number out of here)
------------------------------------------------------------------------
Noise is specified as **Es/N0 in dB** -- the ratio of energy per transmitted
QPSK *symbol* to the one-sided noise power spectral density -- and never as a
GNU Radio "noise voltage" slider value. Slider units depend on GNU Radio's
internal noise-source amplitude convention, which has changed across versions
and is a bad thing to hang a reported measurement on. `noise_voltage_for_esn0`
converts, and documents the assumption it makes, for the one place that needs
it (setting the sim flowgraph's slider to a known operating point).

Three different SNRs get discussed in this project and confusing them is the
single easiest way to report a wrong number, so they have distinct names
everywhere in this codebase:

    snr_chip_db     SNR measured at chip rate, i.e. in the *spread* bandwidth,
                    which is what a spectrum analyser looking at the link sees.
                    This is the one that goes negative -- the signal is below
                    the noise floor.
    snr_symbol_db   SNR of the despread symbols, after the correlator has
                    collapsed code_len chips into one symbol. Roughly
                    snr_chip_db + processing_gain_db.
    ebn0_db         Energy per *information bit* over N0. The thing BER curves
                    are actually plotted against. For QPSK, Eb/N0 =
                    Es/N0 - 10*log10(2), before any FEC rate is accounted for.

`metrics.py` holds the conversions between them; nothing here should be doing
that arithmetic inline.
"""

from __future__ import annotations

import numpy as np

# ---------------------------------------------------------------------------
# GPS-style Gold codes
#
# Generated exactly the way GPS C/A codes are: two 10-bit maximal-length LFSRs,
# G1 with polynomial x^10 + x^3 + 1 and G2 with x^10 + x^9 + x^8 + x^6 + x^3 +
# x^2 + 1, both seeded all-ones, combined as G1 XOR (a 2-tap XOR of G2). The
# tap pair is the "PRN" -- it is what makes one satellite's (here, one node's)
# code different from another's.
#
# These three functions are duplicated verbatim in
# custom_blocks/dsss_spreader.py and custom_blocks/dsss_despreader.py, because
# a GRC embedded Python block has to be self-contained (GRC execs the block's
# source on its own, with no guarantee about sys.path, both at edit time and at
# code-generation time). tests/test_core_matches_blocks.py is what keeps the
# three copies honest.
# ---------------------------------------------------------------------------


def g1_sequence(n_chips: int) -> np.ndarray:
    """The GPS G1 register: x^10 + x^3 + 1, all-ones seed."""
    reg = [1] * 10
    out = np.empty(n_chips, dtype=np.uint8)
    for i in range(n_chips):
        out[i] = reg[9]
        fb = reg[2] ^ reg[9]
        reg = [fb] + reg[:-1]
    return out


def g2_sequence(taps, n_chips: int) -> np.ndarray:
    """The GPS G2 register, tapped at `taps` (1-based, as GPS publishes them)."""
    reg = [1] * 10
    t0, t1 = taps[0] - 1, taps[1] - 1
    out = np.empty(n_chips, dtype=np.uint8)
    for i in range(n_chips):
        out[i] = reg[t0] ^ reg[t1]
        fb = reg[1] ^ reg[2] ^ reg[5] ^ reg[7] ^ reg[8] ^ reg[9]
        reg = [fb] + reg[:-1]
    return out


def gold_code(code_len: int = 1023, prn_taps=(2, 6)) -> np.ndarray:
    """Bipolar (+1/-1) float32 Gold code of length `code_len` for `prn_taps`.

    MUST stay identical to the copies in custom_blocks/dsss_{spreader,
    despreader}.py -- see this module's docstring.
    """
    bits = g1_sequence(code_len) ^ g2_sequence(prn_taps, code_len)
    return 1.0 - 2.0 * bits.astype(np.float32)


# node id -> PRN tap pair. Must match `node_prn_table` in both .grc files.
NODE_PRN_TABLE = {
    0: (2, 6),   1: (3, 7),   2: (4, 8),   3: (5, 9),
    4: (1, 9),   5: (2, 10),  6: (1, 8),   7: (2, 9),
    8: (3, 10),  9: (2, 3),  10: (3, 4),  11: (5, 6),
    12: (6, 7), 13: (7, 8),  14: (8, 9),  15: (9, 10),
}


def code_properties(code: np.ndarray) -> dict:
    """Measure the defining properties of a spreading code.

    Returns the numbers that decide whether something *is* a Gold code, rather
    than merely a long sequence someone called one:

      balance            how far the +1/-1 counts are from even. A length-1023
                         Gold code is balanced 512/511, so this is 1.
      autocorr_offpeak   the set of distinct off-peak autocorrelation values.
                         Gold-code theory predicts exactly three of them for
                         length 1023: {-65, -1, 63}. Seeing three values is the
                         strong result; seeing a spread of arbitrary values
                         means the generator is wrong.
      peak_to_max_sidelobe_db
                         how far the alignment peak stands above the worst
                         off-peak value. This is the margin the acquisition
                         threshold gets to work with, and the reason a single
                         chip of misalignment is catastrophic rather than
                         merely degrading.
    """
    n = len(code)
    spec = np.fft.fft(code)
    # Circular autocorrelation via FFT: real, because the code is real.
    acorr = np.real(np.fft.ifft(spec * np.conj(spec)))
    acorr = np.rint(acorr).astype(np.int64)

    peak = int(acorr[0])
    offpeak = acorr[1:]
    max_sidelobe = int(np.max(np.abs(offpeak)))

    n_plus = int(np.sum(code > 0))
    n_minus = int(np.sum(code < 0))

    return {
        "length": n,
        "n_plus": n_plus,
        "n_minus": n_minus,
        "balance": abs(n_plus - n_minus),
        "peak": peak,
        "autocorr_offpeak": sorted(set(int(v) for v in offpeak)),
        "max_abs_sidelobe": max_sidelobe,
        "peak_to_max_sidelobe_db": 20.0 * np.log10(peak / max_sidelobe)
        if max_sidelobe else float("inf"),
        "processing_gain_db": 10.0 * np.log10(n),
    }


def cross_correlation_peak(code_a: np.ndarray, code_b: np.ndarray) -> int:
    """Worst-case (largest magnitude) circular cross-correlation between two codes.

    This is the number that decides whether two nodes can transmit
    simultaneously on the same frequency: node B's signal appears in node A's
    correlator suppressed by peak/cross_peak, so a low value here is what makes
    CDMA multiple access -- and therefore full duplex -- work.
    """
    fa = np.fft.fft(code_a)
    fb = np.fft.fft(code_b)
    xc = np.real(np.fft.ifft(fa * np.conj(fb)))
    return int(np.max(np.abs(np.rint(xc))))


# ---------------------------------------------------------------------------
# Differential QPSK
#
# The link is differentially encoded mod-4 because an order-4 Costas loop
# resolves the carrier phase only up to a multiple of 90 degrees; differential
# encoding makes that ambiguity cancel between consecutive symbols instead of
# corrupting the whole frame. (BPSK's mod-2 trick does not generalise, which is
# why the project carries its own mod-4 encoder/decoder.)
# ---------------------------------------------------------------------------

# Gray-mapped QPSK constellation, matching digital.dqpsk_constellation()'s
# points as the flowgraph instantiates them (chunks_to_symbols_bc).
QPSK_POINTS = np.array([
    1 + 1j,
    -1 + 1j,
    -1 - 1j,
    1 - 1j,
], dtype=np.complex64) * np.float32(np.sqrt(2.0))


def bits_to_dibits(bits: np.ndarray) -> np.ndarray:
    """Pack a 0/1 bit stream MSB-first into 2-bit symbols."""
    bits = np.asarray(bits, dtype=np.uint8)
    if len(bits) % 2:
        bits = np.concatenate([bits, np.zeros(1, dtype=np.uint8)])
    return (bits[0::2] << 1 | bits[1::2]).astype(np.uint8)


def dibits_to_bits(dibits: np.ndarray) -> np.ndarray:
    dibits = np.asarray(dibits, dtype=np.uint8)
    out = np.empty(len(dibits) * 2, dtype=np.uint8)
    out[0::2] = (dibits >> 1) & 1
    out[1::2] = dibits & 1
    return out


def diff_encode(dibits: np.ndarray) -> np.ndarray:
    """Mod-4 differential encoder (matches digital.diff_encoder_bb(4))."""
    return np.cumsum(np.asarray(dibits, dtype=np.int64)) % 4


def diff_decode(dibits: np.ndarray) -> np.ndarray:
    """Mod-4 differential decoder (matches digital.diff_decoder_bb(4))."""
    d = np.asarray(dibits, dtype=np.int64)
    prev = np.concatenate([[0], d[:-1]])
    return (d - prev) % 4


def qpsk_modulate(dibits: np.ndarray) -> np.ndarray:
    return QPSK_POINTS[np.asarray(dibits, dtype=np.uint8) % 4]


def qpsk_demodulate(symbols: np.ndarray) -> np.ndarray:
    """Hard-decide QPSK symbols back to dibits, by quadrant.

    Deciding by quadrant rather than by nearest-point distance makes this
    scale-invariant, which matters because the despread correlation's absolute
    amplitude depends on code length and received power and is not normalised
    anywhere in the chain.
    """
    s = np.asarray(symbols)
    idx = np.empty(len(s), dtype=np.uint8)
    re, im = np.real(s), np.imag(s)
    idx[(re >= 0) & (im >= 0)] = 0
    idx[(re < 0) & (im >= 0)] = 1
    idx[(re < 0) & (im < 0)] = 2
    idx[(re >= 0) & (im < 0)] = 3
    return idx


# ---------------------------------------------------------------------------
# Spreading
# ---------------------------------------------------------------------------


def spread(symbols: np.ndarray, code: np.ndarray) -> np.ndarray:
    """Hold each QPSK symbol for one full code period and multiply chip by chip.

    This spreads the transmitted *waveform*, not merely the bits underneath it:
    the RF energy genuinely occupies code_len times the bandwidth afterwards,
    which is what puts it under the noise floor and what the spectrum-analyser
    demo (requirement 6) shows.
    """
    n = len(symbols)
    return (np.repeat(np.asarray(symbols, dtype=np.complex64), len(code))
            * np.tile(code, n)).astype(np.complex64)


# ---------------------------------------------------------------------------
# Root-raised-cosine pulse shaping
# ---------------------------------------------------------------------------


def rrc_taps(sps: int, alpha: float = 0.35, ntaps: int | None = None,
             gain: float = 1.0) -> np.ndarray:
    """Root-raised-cosine taps, matching gnuradio.filter.firdes.root_raised_cosine.

    firdes is called in the flowgraph as
        root_raised_cosine(1, samp_rate, chip_rate, alpha, ntaps)
    i.e. one sample per `sps` at the chip rate, so only the ratio matters here.
    """
    if ntaps is None:
        ntaps = 11 * sps
    ntaps = int(ntaps) | 1  # firdes forces an odd tap count
    t = (np.arange(ntaps) - (ntaps - 1) / 2.0) / float(sps)

    taps = np.empty(ntaps, dtype=np.float64)
    for i, ti in enumerate(t):
        if abs(ti) < 1e-12:
            taps[i] = 1.0 - alpha + 4.0 * alpha / np.pi
        elif abs(abs(4.0 * alpha * ti) - 1.0) < 1e-9:
            taps[i] = (alpha / np.sqrt(2.0)) * (
                (1.0 + 2.0 / np.pi) * np.sin(np.pi / (4.0 * alpha))
                + (1.0 - 2.0 / np.pi) * np.cos(np.pi / (4.0 * alpha))
            )
        else:
            num = (np.sin(np.pi * ti * (1.0 - alpha))
                   + 4.0 * alpha * ti * np.cos(np.pi * ti * (1.0 + alpha)))
            den = np.pi * ti * (1.0 - (4.0 * alpha * ti) ** 2)
            taps[i] = num / den

    taps *= gain / np.sqrt(np.sum(taps ** 2))
    return taps.astype(np.float32)


def upsample_and_shape(chips: np.ndarray, sps: int, alpha: float = 0.35,
                       ntaps: int | None = None) -> np.ndarray:
    """Interpolate chips by `sps` and RRC-shape -- the flowgraph's tx_rrc."""
    taps = rrc_taps(sps, alpha, ntaps)
    up = np.zeros(len(chips) * sps, dtype=np.complex64)
    up[::sps] = chips
    return np.convolve(up, taps, mode="same").astype(np.complex64)


def matched_filter_and_decimate(samples: np.ndarray, sps: int,
                                alpha: float = 0.35,
                                ntaps: int | None = None) -> np.ndarray:
    """RRC matched filter then decimate to chip rate -- the flowgraph's rx_mf."""
    taps = rrc_taps(sps, alpha, ntaps)
    filt = np.convolve(samples, taps, mode="same")
    return filt[::sps].astype(np.complex64)


# ---------------------------------------------------------------------------
# Channel
# ---------------------------------------------------------------------------


def esn0_to_chip_snr_db(esn0_db: float, code_len: int) -> float:
    """Es/N0 (per QPSK symbol) -> SNR measured in the spread (chip) bandwidth.

    Spreading one symbol over code_len chips divides the per-chip energy by
    code_len while the noise density is unchanged, so the SNR an observer sees
    in the occupied bandwidth is lower by exactly the processing gain. This is
    the arithmetic behind "the signal sits below the noise floor".
    """
    return esn0_db - 10.0 * np.log10(code_len)


def noise_voltage_for_esn0(esn0_db: float, code_len: int,
                           symbol_amplitude: float = np.sqrt(2.0)) -> float:
    """Convert a target Es/N0 into the sim flowgraph's "Noise Voltage" slider.

    ASSUMPTION, stated because it is version-dependent and worth checking
    against your own GNU Radio build before quoting a slider value as if it
    were a calibrated measurement: `channels.channel_model(noise_voltage=A)`
    adds complex AWGN whose *total* power (I plus Q) is A^2.

    Under that convention, with each chip carrying energy
    symbol_amplitude^2 (the constellation points are at +-1+-1j scaled by
    sqrt(2), so |s|^2 = 4... but the spreading code is +-1, so per-chip power
    equals per-symbol power), one symbol accumulates code_len coherent chips:

        Es = code_len * |s|^2,   N0_total = A^2
        Es/N0 = code_len * |s|^2 / A^2

    Demos never rely on this; they set Es/N0 directly on their own channel.
    It exists so a live sim run can be put at a *known* operating point when
    you want the GUI and the sweep to agree.
    """
    es = code_len * (symbol_amplitude ** 2) * 2.0  # |s|^2 for +-a+-aj is 2a^2
    return float(np.sqrt(es / (10.0 ** (esn0_db / 10.0))))


class Channel:
    """AWGN + carrier frequency offset + sample-clock drift.

    Models the three impairments that actually matter between two independent
    USRPs, and nothing else:

      esn0_db        additive white Gaussian noise, set by Es/N0 (see module
                     docstring for why not "noise voltage").
      cfo_hz         carrier frequency offset: the two radios' LOs disagree.
                     A B205mini-i's TCXO is specified at +-2 ppm, so at 915 MHz
                     each end can be off by ~1.8 kHz and the pair by ~3.7 kHz.
                     Requirement 4 is a question about exactly this number.
      clock_ppm      sample-clock rate offset, applied as a resampling of the
                     waveform -- the receiver's idea of "one chip" slowly
                     diverges from the transmitter's. This is what the
                     despreader's per-symbol re-search absorbs.
      phase_rad      fixed starting carrier phase.
      delay_samples  fractional propagation/alignment delay, so acquisition has
                     a non-trivial code phase to find rather than starting
                     conveniently at zero.
    """

    def __init__(self, esn0_db: float, code_len: int, samp_rate: float,
                 cfo_hz: float = 0.0, clock_ppm: float = 0.0,
                 phase_rad: float = 0.0, delay_samples: float = 0.0,
                 seed: int | None = None):
        self.esn0_db = float(esn0_db)
        self.code_len = int(code_len)
        self.samp_rate = float(samp_rate)
        self.cfo_hz = float(cfo_hz)
        self.clock_ppm = float(clock_ppm)
        self.phase_rad = float(phase_rad)
        self.delay_samples = float(delay_samples)
        self.rng = np.random.default_rng(seed)

    def apply(self, x: np.ndarray, sps: int = 1,
              reference_power: float | None = None) -> np.ndarray:
        """Push a complex baseband waveform through the channel.

        `sps` is samples per chip, needed only to work out the per-sample noise
        power from the per-symbol Es/N0.

        `reference_power` pins the thermal noise to a specific signal power
        instead of measuring it from the input. That matters whenever the input
        already contains something other than the wanted signal -- a jammer, or
        a second node's transmission. Measuring the input power there would
        scale the *thermal* noise with the interference, so raising a jammer by
        10 dB would silently raise the receiver's noise figure by 10 dB too,
        and the measured jamming margin would come out roughly 20 dB
        pessimistic. (It did, before this parameter existed.)
        """
        y = np.asarray(x, dtype=np.complex64).copy()

        # --- sample clock offset + fractional delay, as one resampling ---
        if self.clock_ppm != 0.0 or self.delay_samples != 0.0:
            n = len(y)
            rate = 1.0 + self.clock_ppm * 1e-6
            idx = np.arange(n) * rate + self.delay_samples
            idx = np.clip(idx, 0, n - 1)
            i0 = np.floor(idx).astype(np.int64)
            i1 = np.minimum(i0 + 1, n - 1)
            frac = (idx - i0).astype(np.float32)
            y = (y[i0] * (1.0 - frac) + y[i1] * frac).astype(np.complex64)

        # --- carrier frequency/phase offset ---
        if self.cfo_hz != 0.0 or self.phase_rad != 0.0:
            t = np.arange(len(y)) / self.samp_rate
            y = (y * np.exp(1j * (2.0 * np.pi * self.cfo_hz * t
                                  + self.phase_rad))).astype(np.complex64)

        # --- AWGN ---
        # Es is the energy the receiver's correlator collects for one symbol:
        # code_len chips, each sps samples long, of mean power P.
        if np.isfinite(self.esn0_db):
            chip_power = (float(reference_power) if reference_power is not None
                          else float(np.mean(np.abs(y) ** 2)))
            if chip_power > 0:
                es = chip_power * self.code_len * sps
                n0 = es / (10.0 ** (self.esn0_db / 10.0))
                # N0 here is total complex noise power per sample; split evenly
                # between I and Q.
                sigma = np.sqrt(n0 / 2.0)
                noise = (self.rng.normal(0.0, sigma, len(y))
                         + 1j * self.rng.normal(0.0, sigma, len(y)))
                y = (y + noise).astype(np.complex64)
        return y


# ---------------------------------------------------------------------------
# Despreader -- the processing-gain step
# ---------------------------------------------------------------------------


def _refine_frequency_from_phase(x, start, code_phase, f_coarse, code,
                                 code_len, chip_rate, epochs):
    """Sub-epoch phase-based frequency refinement. See Despreader._acquire."""
    q = code_len // 4
    if q < 8:
        return f_coarse
    n = np.arange(code_len)
    incs = []
    for e in range(epochs):
        off = start + e * code_len + code_phase
        if off + code_len > len(x):
            break
        w = x[off:off + code_len]
        if f_coarse != 0.0:
            t = (off - start + n) / chip_rate
            w = w * np.exp(-2j * np.pi * f_coarse * t)
        c = [np.vdot(code[i * q:(i + 1) * q].astype(np.complex64),
                     w[i * q:(i + 1) * q]) for i in range(4)]
        for i in range(3):
            if abs(c[i]) > 0 and abs(c[i + 1]) > 0:
                incs.append(np.angle(c[i + 1] * np.conj(c[i])))
    if not incs:
        return f_coarse
    dt = q / chip_rate
    return f_coarse + float(np.mean(incs)) / (2.0 * np.pi * dt)


class Despreader:
    """FFT acquisition + bounded-local-search tracking, as the flowgraph does it.

    This is a faithful reimplementation of custom_blocks/dsss_despreader.py,
    restructured to run over a whole array at once instead of GNU Radio's
    streaming general_work() -- same acquisition, same search window, same
    threshold logic, same lock-loss rule, so the numbers it produces are the
    numbers the radio would produce.

    Two things it records that the streaming block does not bother to keep,
    because the demos need them as evidence:

      code_phase_history   the absolute sample index the tracker chose for each
                           symbol. Differencing it against the true transmitted
                           symbol boundaries is the direct proof that code
                           tracking holds lock under clock drift (requirement 1).
      corr_history         the correlation magnitude per symbol, and the local
                           noise floor it was compared against, which is where
                           the *measured* processing gain comes from
                           (requirement 7).
    """

    def __init__(self, code_len: int = 1023, prn_taps=(2, 6),
                 search_margin: int = 2, acq_threshold: float = 3.0,
                 lock_loss_symbols: int = 500, acq_epochs: int = 4,
                 track_hysteresis: float = 3.0, track_threshold: float = 1.6,
                 chip_rate: float = 511500.0,
                 freq_search_hz: float = 0.0, freq_bins: int = 0,
                 code: np.ndarray | None = None):
        self.code_len = int(code_len)
        # `code` lets a caller supply a spreading code directly, which is how
        # the spreading-factor comparison uses lengths other than 1023 -- the
        # GPS C/A construction is specific to 10-bit registers, so other
        # lengths come from gold_code_family instead.
        self.code = (np.asarray(code, dtype=np.float32) if code is not None
                     else gold_code(self.code_len, prn_taps))
        self.chip_rate = float(chip_rate)

        # Two-dimensional acquisition: code phase AND carrier frequency.
        #
        # Requirement 4 asks whether carrier-offset compensation is needed. It
        # is, and not marginally: a B205mini-i's TCXO is specified at +-2 ppm,
        # so at 915 MHz two free-running radios can sit ~3.7 kHz apart, while
        # this link's order-4 Costas loop pulls in roughly +-50 Hz -- the
        # symbol rate is only ~500 Hz, and a loop cannot pull in a fraction of
        # a symbol rate it does not have. Without help the two ends simply
        # never lock to each other.
        #
        # Searching frequency alongside code phase is how a GPS receiver solves
        # exactly this problem, and it costs one FFT pair per frequency
        # hypothesis, once, at acquisition. Coherent integration over one code
        # period T gives a usable bin width of about 1/(2T), so covering a few
        # kHz takes a few tens of bins.
        #
        # Set freq_search_hz to 0 to disable it -- correct when both radios run
        # off a shared 10 MHz reference, which is what this project's
        # flowgraphs assume today (`set_clock_source('external')`).
        self.freq_search_hz = float(freq_search_hz)
        if freq_bins > 0:
            self.freq_bins = int(freq_bins)
        elif self.freq_search_hz > 0:
            epoch_s = self.code_len / self.chip_rate
            bin_hz = 1.0 / (2.0 * epoch_s)
            self.freq_bins = int(2 * np.ceil(self.freq_search_hz / bin_hz) + 1)
        else:
            self.freq_bins = 1
        self.freq_est_hz = 0.0
        self.margin = int(search_margin)
        self.acq_threshold = float(acq_threshold)
        self.lock_loss_symbols = int(lock_loss_symbols)
        self.acq_epochs = max(1, int(acq_epochs))
        self.track_hysteresis = float(track_hysteresis)
        # Separate from `acq_threshold` on purpose. Acquisition compares its
        # peak against the median of a full 1023-bin correlogram; tracking
        # compares against an RMS noise estimate from dedicated off-peak
        # references. Those are different statistics, so one number cannot
        # sensibly serve both -- reusing acq_threshold here declares loss of
        # lock at around 9 dB symbol SNR, which throws away a link that is
        # still carrying data perfectly well. 1.6 corresponds to roughly 4 dB
        # symbol SNR, comfortably below any usable operating point.
        self.track_threshold = float(track_threshold)
        self.ideal_gain_db = 10.0 * np.log10(self.code_len)
        self.slip_guard_rejections = 0
        # Noise-floor reference correlations: `_noise_refs` of them on each
        # side, starting `_noise_gap` chips beyond the search window so they
        # are clear of the correlation peak's shoulder.
        self._noise_refs = 8
        self._noise_gap = 3

        self.acquired = False
        self.center = 0
        self.weak_count = 0

        self.code_phase_history: list[int] = []
        self.corr_history: list[float] = []
        self.floor_history: list[float] = []
        self.acquisition_index: int | None = None
        self.acquisition_correlogram: np.ndarray | None = None
        self.acquisition_peak_ratio: float | None = None
        self.acquisition_epochs_used: int = 0

    # -- acquisition ------------------------------------------------------
    def _acquire(self, x: np.ndarray, start: int) -> bool:
        """GPS parallel code-phase search, integrated over several code epochs.

        The search itself is GPS's own trick: instead of sliding the local code
        past the samples one chip at a time (1023 correlations), one FFT pair
        evaluates *every* rotation simultaneously.

        The multi-epoch accumulation is not cosmetic -- it fixes a real
        false-lock failure. A single code period's worth of samples almost
        never lines up with a data-symbol boundary, so the window straddles two
        QPSK symbols. At the correct rotation the correlation is then
        s_m*(chips of symbol m) + s_m+1*(chips of symbol m+1), and when those
        two symbols happen to be near-antipodal they partly cancel: the true
        peak collapses towards the noise floor, a noise bin wins the argmax,
        and the threshold test passes anyway on a *wrong* code phase. The
        receiver then tracks nothing for the ~lock_loss_symbols it takes to
        give up and try again.

        (That failure is almost certainly the origin of the long-standing
        "first message after starting the flowgraph occasionally gets lost,
        just send it again" behaviour in this project's README -- a false lock
        self-heals in about a second, which is exactly how it presents.)

        Accumulating the *magnitude* of the correlogram over `acq_epochs`
        consecutive code periods fixes it, because the true code phase lands in
        the same bin every epoch while the data-symbol pair that weakened it
        changes. Magnitudes are summed rather than the complex correlations, so
        the data modulation cannot cancel anything -- this is exactly the
        non-coherent integration a GPS receiver does over multiple 1 ms epochs.

        Records the accumulated correlogram, because a plot of it -- one
        needle, 1022 flat bins -- is the clearest single picture of what a long
        spreading code buys, and is the evidence artifact for requirement 1.
        """
        epochs = self.acq_epochs
        while epochs > 1 and start + epochs * self.code_len > len(x):
            epochs -= 1
        if start + self.code_len > len(x):
            return False

        code_spec_conj = np.conj(np.fft.fft(self.code))

        n = np.arange(self.code_len)

        def search(freqs):
            """Accumulated |correlogram| over `epochs`, best over `freqs`."""
            best = (-1.0, 0, 0.0, None, 0.0)
            for f in freqs:
                mags = np.zeros(self.code_len, dtype=np.float64)
                for e in range(epochs):
                    off = start + e * self.code_len
                    window = x[off:off + self.code_len]
                    if f != 0.0:
                        # Derotate this epoch by the frequency hypothesis. The
                        # phase has to continue across epochs -- derotating
                        # each one as if it started at t=0 smears the
                        # accumulated peak instead of sharpening it.
                        t = (off - start + n) / self.chip_rate
                        window = window * np.exp(-2j * np.pi * f * t)
                    corr = np.fft.ifft(np.fft.fft(window) * code_spec_conj)
                    mags += np.abs(corr)
                mags /= epochs
                k = int(np.argmax(mags))
                if mags[k] > best[0]:
                    best = (float(mags[k]), k, float(f), mags,
                            float(np.median(mags)))
            return best

        if self.freq_bins > 1:
            epoch_s = self.code_len / self.chip_rate
            coarse_step = 1.0 / (2.0 * epoch_s)
            n_coarse = int(np.ceil(self.freq_search_hz / coarse_step))
            coarse = np.arange(-n_coarse, n_coarse + 1) * coarse_step
            peak, best, f_est, mags, floor_at_best = search(coarse)

            # Refine from sub-epoch correlation phase. Grid refinement cannot
            # do this: the accumulated magnitude falls off as |sinc(f_err*T)|
            # with its first null a whole 1/T away, so half a bin of error
            # costs under a dB -- comparable to the noise -- and a finer grid
            # merely picks a random bin inside the peak's shoulder. Measured
            # that way the residual stayed around 125 Hz, still well outside
            # the Costas loop's ~50 Hz pull-in, and the link still failed.
            #
            # Phase works where magnitude does not. Within one code period the
            # data symbol is constant, so quarter-period correlations differ
            # only by the carrier's rotation over T/4 -- no modulation to
            # strip. Quarter spacing keeps phase increments inside +-pi for
            # |f| < 2/T, about 1 kHz, covering the coarse residual easily.
            f_est = _refine_frequency_from_phase(
                x, start, best, f_est, self.code, self.code_len,
                self.chip_rate, epochs)
        else:
            peak, best, f_est, mags, floor_at_best = search(np.array([0.0]))

        if floor_at_best > 0 and peak > self.acq_threshold * floor_at_best:
            self.center = start + best + self.code_len
            self.acquired = True
            self.weak_count = 0
            self.freq_est_hz = f_est
            self.acquisition_index = start + best
            self.acquisition_correlogram = mags
            self.acquisition_peak_ratio = peak / floor_at_best
            self.acquisition_epochs_used = epochs
            return True
        return False

    # -- tracking ---------------------------------------------------------
    def process(self, x: np.ndarray, max_symbols: int | None = None
                ) -> np.ndarray:
        """Despread a whole chip-rate waveform into QPSK symbols."""
        x = np.asarray(x, dtype=np.complex64)
        out: list[complex] = []
        pos = 0

        # Acquire, sliding a code period at a time until the peak stands out.
        # Capped, because a 2-D search that never succeeds (wrong PRN, dead
        # channel, an offset outside the search range) would otherwise grind
        # through the whole capture doing a full frequency sweep per step.
        attempts = 0
        max_attempts = 64
        while (not self.acquired and pos + self.code_len <= len(x)
               and attempts < max_attempts):
            if not self._acquire(x, pos):
                pos += self.code_len * max(1, self.acq_epochs)
                attempts += 1
        if not self.acquired:
            return np.array([], dtype=np.complex64)

        # Apply the frequency estimate acquisition found. Correlating against
        # the local code only integrates coherently if the carrier has been
        # taken off first; leaving a kHz-scale offset in place would smear the
        # correlation peak away over a single 2 ms code period regardless of
        # how much SNR there is.
        if self.freq_est_hz != 0.0:
            t = np.arange(len(x)) / self.chip_rate
            x = (x * np.exp(-2j * np.pi * self.freq_est_hz * t)
                 ).astype(np.complex64)

        # Precompute every length-code_len window once; the tracking search is
        # then a single matrix-vector product per symbol instead of a Python
        # loop over 2*margin+1 separate dot products. Same arithmetic, same
        # results -- just not paying NumPy's per-call overhead once per
        # candidate offset per symbol, which is what caps the sustainable chip
        # rate and therefore the file-transfer throughput.
        n_windows = len(x) - self.code_len + 1
        if n_windows <= 0:
            return np.array([], dtype=np.complex64)
        windows = np.lib.stride_tricks.sliding_window_view(x, self.code_len)

        while True:
            if max_symbols is not None and len(out) >= max_symbols:
                break
            lo = self.center - self.margin
            hi = self.center + self.margin
            if lo < 0 or hi + self.code_len > len(x):
                break

            block = windows[lo:hi + 1]            # (2*margin+1, code_len)
            vals = block @ self.code              # one matvec, all offsets
            mags = np.abs(vals)

            # Slip guard. A plain argmax over the search window re-decides the
            # code phase from scratch every symbol, which sounds conservative
            # and is in fact the link's dominant error mechanism: the aligned
            # correlation is Rice-distributed with real spread, the best of the
            # N competing misaligned ones is Rayleigh, and the two overlap long
            # before thermal noise would trouble the demodulator. Every time a
            # misaligned offset wins, that symbol is destroyed outright -- so
            # the BER floors out several dB above where the SNR says it should.
            #
            # Two things fix it, and neither is a tracking loop of the kind
            # this project tried and (correctly) rejected:
            #
            #   * A narrow window. The physical drift between two independent
            #     TCXOs is a few ppm, i.e. ~0.002 chips per symbol -- five
            #     orders of magnitude less than the +-30 chips the search was
            #     ranging over. Every extra chip of margin is another lottery
            #     ticket for a slip and buys nothing.
            #   * Hysteresis. The predicted (centre) offset is right almost
            #     always, so an off-centre candidate has to win by a margin,
            #     not by a hair, before the phase is moved.
            #
            # Measured together on the AWGN sweep: about 5-6 dB of link margin
            # recovered versus the +-30, no-hysteresis search.
            centre_k = self.center - lo
            k = int(np.argmax(mags))
            if (self.track_hysteresis > 1.0 and 0 <= centre_k < len(mags)
                    and k != centre_k
                    and mags[k] <= self.track_hysteresis * mags[centre_k]):
                k = centre_k
                self.slip_guard_rejections += 1

            best_off = lo + k
            best_mag = float(mags[k])
            best_val = complex(vals[k])

            # Noise floor, measured somewhere the signal provably is not.
            #
            # Taking the median of the search window itself (what the original
            # block does) is contaminated two ways: with a narrow window most
            # of the samples ARE the correlation peak's immediate neighbours,
            # and the ratio it yields saturates at the code's peak-to-sidelobe
            # ratio -- 10*log10(1023/65) = 12 dB for a length-1023 Gold code --
            # no matter how good the link is. Reporting that number next to
            # "ideal = 10*log10(1023) = 30.1 dB" invites the reader to conclude
            # the link is 18 dB down on theory when it is in fact fine. The two
            # quantities are simply not the same measurement.
            #
            # So the floor is estimated from correlations deliberately placed
            # several chips off, where a Gold code's autocorrelation has
            # already collapsed to its sidelobe and what is left is essentially
            # pure noise. That gives an honest post-despread symbol SNR, and
            # the correctly-named peak-to-sidelobe ratio separately.
            ref_lo = self.center - self.margin - self._noise_gap - self._noise_refs
            ref_hi = self.center + self.margin + self._noise_gap + self._noise_refs
            if ref_lo >= 0 and ref_hi + self.code_len <= len(x):
                a = np.abs(windows[ref_lo:ref_lo + self._noise_refs] @ self.code)
                b = np.abs(windows[ref_hi - self._noise_refs:ref_hi] @ self.code)
                noise_power = float(np.mean(np.concatenate([a, b]) ** 2))
            else:
                noise_power = float(np.median(mags) ** 2)
            floor = float(np.sqrt(noise_power))

            if floor <= 0 or best_mag <= self.track_threshold * floor:
                self.weak_count += 1
            else:
                self.weak_count = 0

            out.append(best_val)
            self.code_phase_history.append(best_off)
            self.corr_history.append(best_mag)
            self.floor_history.append(floor)
            self.center = best_off + self.code_len

            if self.weak_count >= self.lock_loss_symbols:
                self.acquired = False
                break

        return np.array(out, dtype=np.complex64)

    # -- measurements -----------------------------------------------------
    def symbol_snr_db(self, skip: int = 10) -> float:
        """Post-despread symbol SNR, measured from the correlator itself.

        The aligned correlation carries signal *plus* noise; the off-aligned
        reference correlations carry noise alone and have the same variance.
        Subtracting gives the signal power, so

            SNR_symbol = (|peak|^2 - E|noise|^2) / E|noise|^2

        with no knowledge of the transmitted data and no assumption about the
        absolute received amplitude. This is the number to compare against
        Es/N0, and the one the BER should follow.
        """
        c = np.asarray(self.corr_history[skip:], dtype=np.float64) ** 2
        f = np.asarray(self.floor_history[skip:], dtype=np.float64) ** 2
        ok = f > 0
        if not np.any(ok):
            return float("-inf")
        sig = float(np.mean(c[ok])) - float(np.mean(f[ok]))
        noise = float(np.mean(f[ok]))
        if sig <= 0:
            return float("-inf")
        return 10.0 * np.log10(sig / noise)

    def peak_to_sidelobe_db(self, skip: int = 10) -> float:
        """How far the aligned correlation stands above the misaligned ones.

        NOT the processing gain, however tempting the comparison is. On a
        noiseless link this saturates at the code's own peak-to-sidelobe
        ratio: for length 1023 the sidelobes are pinned at 65, so the ceiling
        is 20*log10(1023/65) = 23.9 dB. (The original block reported
        10*log10 of the same magnitude ratio, which put its ceiling at
        12.0 dB -- and it was being compared against 30.1 dB.) Either way it
        cannot reach the processing gain, because it is not measuring it.

        It is a lock-quality indicator: it says the correlator is sitting on
        the peak, not how much SNR the spreading bought. See
        `metrics.processing_gain_db` for the latter, which needs a
        before-despread measurement to mean anything.
        """
        c = np.asarray(self.corr_history[skip:], dtype=np.float64)
        f = np.asarray(self.floor_history[skip:], dtype=np.float64)
        ok = (c > 0) & (f > 0)
        if not np.any(ok):
            return float("-inf")
        return float(np.mean(20.0 * np.log10(c[ok] / f[ok])))

    def code_phase_drift_chips(self) -> np.ndarray:
        """Tracked code phase minus a constant-rate prediction, in chips.

        With no clock error this is flat at zero. With clock error it ramps,
        and the fact that it *ramps smoothly instead of jumping* is the
        evidence that the tracker is following the transmitter rather than
        re-acquiring.
        """
        ph = np.asarray(self.code_phase_history, dtype=np.float64)
        if len(ph) < 2:
            return np.zeros(0)
        ideal = ph[0] + np.arange(len(ph)) * self.code_len
        return ph - ideal


# ---------------------------------------------------------------------------
# Carrier recovery
# ---------------------------------------------------------------------------


def costas_loop(symbols: np.ndarray, loop_bw: float = 0.15, order: int = 4
                ) -> tuple[np.ndarray, np.ndarray]:
    """Order-4 Costas loop, matching digital.costas_loop_cc's structure.

    Returns (corrected symbols, per-symbol frequency estimate in rad/symbol).
    The frequency track is returned because requirement 4 -- "decide if
    compensating for carrier frequency offset is needed" -- is answered by
    showing what the loop has to pull in and where it stops being able to.

    GNU Radio's control_loop derives its gains from a damping factor of
    sqrt(2)/2 and the requested loop bandwidth; reproduced here so the pull-in
    range measured offline is the pull-in range the radio has.
    """
    damping = np.sqrt(2.0) / 2.0
    denom = 1.0 + 2.0 * damping * loop_bw + loop_bw * loop_bw
    alpha = (4.0 * damping * loop_bw) / denom
    beta = (4.0 * loop_bw * loop_bw) / denom

    max_freq, min_freq = 1.0, -1.0
    phase = 0.0
    freq = 0.0

    s = np.asarray(symbols, dtype=np.complex64)
    out = np.empty(len(s), dtype=np.complex64)
    freq_track = np.empty(len(s), dtype=np.float64)

    for i, sample in enumerate(s):
        nco = np.exp(-1j * phase)
        y = sample * nco
        out[i] = y

        # Order-4 phase detector: the error that vanishes at all four QPSK
        # points, which is also why the constellation is only recoverable up to
        # a 90-degree rotation (hence the differential encoding).
        if order == 4:
            re, im = np.real(y), np.imag(y)
            err = (np.sign(re) * im) - (np.sign(im) * re)
        else:
            err = np.real(y) * np.imag(y)
        err = float(np.clip(err, -1.0, 1.0))

        freq += beta * err
        freq = float(np.clip(freq, min_freq, max_freq))
        phase += freq + alpha * err
        phase = float(np.mod(phase + np.pi, 2.0 * np.pi) - np.pi)
        freq_track[i] = freq

    return out, freq_track


# ---------------------------------------------------------------------------
# End-to-end link, for the sweeps
# ---------------------------------------------------------------------------


def transmit(bits: np.ndarray, code: np.ndarray, sps: int = 1,
             alpha: float = 0.35, differential: bool = True) -> np.ndarray:
    """bits -> pulse-shaped complex baseband, exactly the flowgraph's TX order."""
    dibits = bits_to_dibits(bits)
    if differential:
        dibits = diff_encode(dibits)
    symbols = qpsk_modulate(dibits)
    chips = spread(symbols, code)
    if sps > 1:
        return upsample_and_shape(chips, sps, alpha)
    return chips


def receive(samples: np.ndarray, code_len: int, prn_taps, sps: int = 1,
            alpha: float = 0.35, differential: bool = True,
            costas_bw: float = 0.15, search_margin: int = 2,
            acq_threshold: float = 3.0, acq_epochs: int = 4,
            normalize_before_costas: bool = True,
            chip_rate: float = 511500.0, freq_search_hz: float = 0.0,
            track_hysteresis: float = 3.0, track_threshold: float = 1.6):
    """Complex baseband -> bits, exactly the flowgraph's RX order.

    Order matters and is the crux of the design: matched filter, then
    *despread*, and only then carrier recovery. A Costas loop cannot lock onto
    a signal that is below the noise floor, so the processing gain has to be
    applied before anything tries to.
    """
    if sps > 1:
        chips = matched_filter_and_decimate(samples, sps, alpha)
    else:
        chips = np.asarray(samples, dtype=np.complex64)

    dsp = Despreader(code_len=code_len, prn_taps=prn_taps,
                     search_margin=search_margin, acq_threshold=acq_threshold,
                     acq_epochs=acq_epochs, chip_rate=chip_rate,
                     freq_search_hz=freq_search_hz,
                     track_hysteresis=track_hysteresis,
                     track_threshold=track_threshold)
    despread_syms = dsp.process(chips)
    if len(despread_syms) == 0:
        return np.array([], dtype=np.uint8), dsp, np.array([], dtype=np.complex64)

    # The despread correlation's amplitude is code_len times the symbol
    # amplitude and is never normalised anywhere in the chain. An order-4
    # Costas phase detector clips its error to +-1, so feeding it symbols of
    # magnitude ~1400 turns a proportional loop into a bang-bang one running at
    # maximum gain -- it still locks, but with far more phase jitter than the
    # configured loop bandwidth implies. Normalising to unit RMS first is what
    # makes `costas_bw` mean what it says.
    if normalize_before_costas:
        rms = float(np.sqrt(np.mean(np.abs(despread_syms) ** 2)))
        if rms > 0:
            despread_syms = (despread_syms / rms).astype(np.complex64)

    recovered, _freq = costas_loop(despread_syms, costas_bw, 4)
    dibits = qpsk_demodulate(recovered)
    if differential:
        dibits = diff_decode(dibits)
        # The first differentially decoded symbol has no predecessor to
        # difference against, so it is structurally invalid -- not an error the
        # channel caused. Left in, it contributes a fixed couple of bit errors
        # per run regardless of SNR, which on a BER-versus-Eb/N0 plot looks
        # exactly like a receiver error floor and is not one. (It produced a
        # convincing fake floor at 2e-4 before this line existed.)
        dibits = dibits[1:]
    return dibits_to_bits(dibits), dsp, recovered


def ber_between(tx_bits: np.ndarray, rx_bits: np.ndarray,
                max_lag: int | None = None) -> tuple[float, int, int]:
    """Bit error rate between transmitted and received bits, aligned first.

    Alignment is not a detail to skip, and a small fixed search window is not
    enough. The receiver's stream starts later than the transmitter's by
    however long acquisition took -- which at low SNR can be dozens of symbols,
    or hundreds if the first few attempts failed -- while the differential
    decoder's first output is always junk. Compare the two streams without
    finding that offset and a perfectly good run reports a BER near 0.5,
    indistinguishable from no link at all. An automated sweep that does this
    silently produces a beautiful and entirely wrong BER curve. (It did, on the
    way to this version: a fixed +-64 bit window missed a 72 bit offset and
    reported a dead link at an Es/N0 the receiver was handling fine.)

    So the lag is *found*, by cross-correlating the two streams mapped to +-1
    via FFT, which costs one transform pair instead of a scan and has no window
    to be outgrown. The best few candidate lags are then scored exactly.

    Returns (ber, n_errors, n_compared).
    """
    tx = np.asarray(tx_bits, dtype=np.uint8).ravel()
    rx = np.asarray(rx_bits, dtype=np.uint8).ravel()
    if len(tx) < 64 or len(rx) < 64:
        return 1.0, 0, 0

    a = 1.0 - 2.0 * tx.astype(np.float64)
    b = 1.0 - 2.0 * rx.astype(np.float64)
    n = 1 << int(np.ceil(np.log2(len(a) + len(b))))
    xc = np.fft.irfft(np.fft.rfft(b, n) * np.conj(np.fft.rfft(a, n)), n)

    # Positive lags mean rx starts later than tx; negative, earlier. Both
    # happen -- which one depends on the channel delay, which the sweeps
    # randomise on purpose.
    span = max_lag if max_lag is not None else min(len(a), len(b)) - 1
    cand = np.concatenate([np.arange(0, min(span, n // 2)),
                           np.arange(n - min(span, n // 2), n)])
    order = cand[np.argsort(-np.abs(xc[cand]))][:8]

    best = (1.0, 0, 0)
    for raw in order:
        lag = int(raw if raw < n // 2 else raw - n)
        if lag >= 0:
            x, y = a, b[lag:]
        else:
            x, y = a[-lag:], b
        m = min(len(x), len(y))
        if m < 64:
            continue
        errs = int(np.count_nonzero(
            (x[:m] < 0).astype(np.uint8) ^ (y[:m] < 0).astype(np.uint8)))
        ber = errs / m
        if ber < best[0]:
            best = (ber, errs, m)

    # A BER near 0.5 at every candidate lag means the link never locked; no
    # alignment search can rescue that, and the caller should read the
    # despreader's lock state rather than treat this as a measurement.
    return best


# ---------------------------------------------------------------------------
# Gold codes at other lengths
#
# Requirement 2 ("use a high spreading factor") is only a meaningful claim if
# you can show what a *lower* one costs, and the bulk-transfer link profiles
# need shorter codes to reach a usable data rate at all. Both need real Gold
# codes at lengths other than 1023.
#
# Rather than copy a table of preferred-pair polynomials out of a textbook and
# hope it was transcribed correctly, the pairs are *found* here and then
# verified against the defining property: a preferred pair of m-sequences has a
# three-valued cross-correlation, taking only the values {-1, -t(n), t(n)-2}
# where t(n) = 1 + 2^floor((n+2)/2). Any pair that fails that test is rejected,
# so a wrong polynomial cannot silently produce a code that merely looks long.
# ---------------------------------------------------------------------------

_PRIMITIVE_POLYS = {
    5:  [0b100101, 0b111101, 0b110111, 0b101111, 0b111011, 0b101001],
    6:  [0b1000011, 0b1100111, 0b1011011, 0b1100001, 0b1101101, 0b1110011],
    7:  [0b10000011, 0b10001001, 0b10001111, 0b10010001, 0b10011101,
         0b10100111, 0b10101011, 0b10111001, 0b10111111, 0b11000001],
    9:  [0b1000010001, 0b1000011011, 0b1000100001, 0b1000101101,
         0b1000110011, 0b1001011001, 0b1001011111, 0b1001101001,
         0b1001101111, 0b1001110111, 0b1010000111, 0b1010010101],
    10: [0b10000001001, 0b10001101111, 0b10011010111, 0b10111000111,
         0b10001010011, 0b10010001011, 0b10100011001, 0b11000010011],
}


def _m_sequence(poly: int, n: int) -> np.ndarray:
    """Maximal-length LFSR sequence of period 2^n - 1 for a primitive `poly`.

    Raises if the polynomial is not in fact primitive -- the sequence would
    then repeat early, and every code built on it would be worthless.
    """
    length = (1 << n) - 1
    taps = poly & ((1 << n) - 1)
    state = 1
    out = np.empty(length, dtype=np.uint8)
    for i in range(length):
        out[i] = state & 1
        fb = bin(state & taps).count("1") & 1
        state = (state >> 1) | (fb << (n - 1))
    if state != 1:
        raise ValueError(f"polynomial {poly:#b} is not primitive for n={n}")
    return out


def _preferred_t(n: int) -> int:
    return 1 + (1 << ((n + 2) // 2))


def _is_preferred_pair(a: np.ndarray, b: np.ndarray, n: int) -> bool:
    """The three-valued cross-correlation property that defines a preferred
    pair -- the reason Gold codes have bounded, predictable cross-correlation
    and can therefore be used for CDMA."""
    pa = 1.0 - 2.0 * a
    pb = 1.0 - 2.0 * b
    xc = np.rint(np.real(np.fft.ifft(np.fft.fft(pa) * np.conj(np.fft.fft(pb)))))
    t = _preferred_t(n)
    return set(int(v) for v in xc) <= {-1, -t, t - 2}


_PREFERRED_CACHE: dict = {}


def preferred_pair(n: int):
    """Find (and cache) a verified preferred pair of primitive polynomials."""
    if n in _PREFERRED_CACHE:
        return _PREFERRED_CACHE[n]
    if n not in _PRIMITIVE_POLYS:
        raise ValueError(f"no primitive polynomial table for n={n}")
    seqs = {}
    for p in _PRIMITIVE_POLYS[n]:
        try:
            seqs[p] = _m_sequence(p, n)
        except ValueError:
            continue
    keys = list(seqs)
    for i, pa in enumerate(keys):
        for pb in keys[i + 1:]:
            if _is_preferred_pair(seqs[pa], seqs[pb], n):
                _PREFERRED_CACHE[n] = (pa, pb)
                return pa, pb
    raise ValueError(f"no preferred pair found for n={n}")


def gold_code_family(code_len: int, index: int = 0) -> np.ndarray:
    """A bipolar Gold code of length 2^n - 1, member `index` of the family.

    Length 1023 is special-cased to the GPS C/A construction so this project's
    existing 1023-chip codes, and the node PRN table built on them, are
    bit-for-bit unchanged. Other lengths use the verified preferred pair above.
    """
    n = int(round(np.log2(code_len + 1)))
    if (1 << n) - 1 != code_len:
        raise ValueError(f"code_len must be 2^n - 1, got {code_len}")
    # Gold families exist only for n odd or n = 2 mod 4. There is no preferred
    # pair for n = 0 mod 4, so lengths 255 and 4095 have no Gold code at all --
    # a property of the mathematics, not a gap in the table above.
    if not (n % 2 == 1 or n % 4 == 2):
        raise ValueError(
            f"no Gold code family exists for length {code_len} (n={n}); "
            "n must be odd or n = 2 mod 4 -- use 31, 63, 127, 511 or 1023")
    if code_len == 1023:
        prn = NODE_PRN_TABLE[index % len(NODE_PRN_TABLE)]
        return gold_code(1023, prn)

    pa, pb = preferred_pair(n)
    a = _m_sequence(pa, n)
    b = _m_sequence(pb, n)
    if index == 0:
        bits = a
    elif index == 1:
        bits = b
    else:
        bits = a ^ np.roll(b, -(index - 2) % code_len)
    return (1.0 - 2.0 * bits.astype(np.float32)).astype(np.float32)
