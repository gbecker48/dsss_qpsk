#!/usr/bin/env python3
"""
terminal.py -- plain-text console for the DSSS + QPSK link
===========================================================

A scriptable alternative to ground_station.py. Talks to the running flowgraph
purely over UDP and has no idea GNU Radio exists.

Everything the GUI can do except the plots: send messages, send and receive
FILES with erasure coding and SHA-256 verification, switch nodes, run the
PRBS bit error rate test, mute the transmitter, and watch live link telemetry.

Because it is line-oriented it pipes and scripts cleanly:

    echo "hello" | python3 terminal.py --once
    python3 terminal.py --send-file capture.bin --wait
    python3 terminal.py --bert 60          # 60-second BER measurement

Usage:
    python3 terminal.py
    python3 terminal.py --host 127.0.0.1 --tx-port 52001
"""

import os
import sys


def _sanitize_snap_polluted_ld_library_path():
    """See the identical guard in ground_station.py for the full story:
    an LD_LIBRARY_PATH inherited from a Snap-packaged app's environment
    can make the dynamic linker resolve libpthread.so.0 against an old,
    incompatible Snap-bundled copy instead of the system's own glibc,
    crashing with a symbol lookup error the instant any thread is created
    - which this script's UDP listener threads do immediately. Strip any
    Snap path and re-exec once, before `threading` ever gets imported."""
    if os.environ.get("_TERM_ENV_SANITIZED"):
        return
    ld_path = os.environ.get("LD_LIBRARY_PATH", "")
    if not ld_path:
        return
    parts = ld_path.split(os.pathsep)
    kept = [p for p in parts if "/snap/" not in p]
    if len(kept) == len(parts):
        return
    os.environ["_TERM_ENV_SANITIZED"] = "1"
    if kept:
        os.environ["LD_LIBRARY_PATH"] = os.pathsep.join(kept)
    else:
        os.environ.pop("LD_LIBRARY_PATH", None)
    try:
        os.execve(sys.executable, [sys.executable] + sys.argv, os.environ)
    except OSError:
        pass


_sanitize_snap_polluted_ld_library_path()

import argparse
import socket
import threading
import time

BANNER = r"""
======================================================================
  QPSK + DSSS burst link terminal
  type a message and press Enter to transmit it over the link
  /help for commands, /quit to exit
======================================================================
"""


import argparse
import socket
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from dsss_link import protocol, filexfer, link_profiles, metrics  # noqa: E402

BANNER = """
======================================================================
  DSSS + QPSK link terminal
  type a message and press Enter to transmit, /help for commands
======================================================================
"""

HELP = """
Commands:
  /help                 this help
  /quit, /exit          leave
  /stats                send and receive counters, and the link profile
  /node <n>             set MY node id (0-15) -- which PRN this radio
                        transmits on
  /dest <n>             set the DESTINATION node id -- which peer's PRN this
                        radio despreads against, i.e. who it is listening to
  /send <path>          send a file. It is fragmented, Reed-Solomon erasure
                        coded, and verified end to end with SHA-256 on
                        arrival. Prints the fragment count and the estimated
                        airtime before it starts.
  /parity <percent>     erasure-coding overhead for subsequent files
                        (default 20). Higher survives more fragment loss and
                        takes proportionally longer.
  /bert on|off          fill idle slots with PRBS-15 so the receiver counts
                        real channel bit errors continuously (requirement 7)
  /txgain <0..1>        transmitter output scaling. 0 mutes it -- which is how
                        demo 6 takes its noise-only reference capture.
  /diag on|off          show live link telemetry (SNR, lock, EVM, drift)
  /profile <name>       tell this terminal which profile the flowgraph is
                        running, so airtime estimates are right. Does NOT
                        change the flowgraph -- that is set in the .grc.
  (anything else)       sent as a message over the link
"""

NODE_TABLE_SIZE = 16


class Colors:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    CYAN = '\033[96m'
    RED = '\033[91m'
    BLUE = '\033[94m'
    DIM = '\033[2m'
    BOLD = '\033[1m'
    RESET = '\033[0m'

    @classmethod
    def disable(cls):
        for n in ('GREEN', 'YELLOW', 'CYAN', 'RED', 'BLUE', 'DIM', 'BOLD',
                  'RESET'):
            setattr(cls, n, '')


def make_listener(sock, on_message):
    def run():
        while True:
            try:
                data, _addr = sock.recvfrom(65535)
            except OSError:
                return
            try:
                on_message(data)
            except Exception:
                import traceback
                traceback.print_exc()
    t = threading.Thread(target=run, daemon=True)
    t.start()
    return t


def parse_kv(line):
    parts = line.split()
    if not parts:
        return None, {}
    kv = {}
    for tok in parts[1:]:
        if '=' in tok:
            k, _, v = tok.partition('=')
            if k:
                kv[k] = v
    return parts[0], kv


class Terminal:
    def __init__(self, args):
        self.args = args
        self.profile = link_profiles.get(args.profile)
        self.tx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.ctrl = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.incoming = filexfer.IncomingFiles(args.download_dir)
        self.parity = self.profile.parity_fraction
        self.show_diag = args.show_diag
        self.show_frags = args.show_fragments
        self.counters = {'sent': 0, 'recv': 0, 'status': 0, 'files_in': 0,
                         'files_out': 0, 'recovered': 0}
        self.transfers = {}
        self.next_msg_id = 0
        self.bert = {'errors': 0, 'bits': 0, 'synced': False}
        self.lock = threading.Lock()
        self._bind()

    def _bind(self):
        a = self.args
        self.data_sock = self._server(a.bind_host, a.rx_data_port)
        self.status_sock = self._server(a.bind_host, a.rx_status_port)
        self.diag_sock = self._server(a.bind_host, a.diag_port)
        make_listener(self.data_sock, self.on_data)
        make_listener(self.status_sock, self.on_status)
        make_listener(self.diag_sock, self.on_diag)

    @staticmethod
    def _server(host, port):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((host, port))
        return s

    # -- output helpers --------------------------------------------------
    def emit(self, text):
        sys.stdout.write('\r' + ' ' * 100 + '\r')
        print(text)
        if not self.args.once:
            sys.stdout.write(f"{Colors.CYAN}> {Colors.RESET}")
        sys.stdout.flush()

    # -- receive ---------------------------------------------------------
    def on_data(self, data):
        with self.lock:
            self.counters['recv'] += 1
        rec = self.incoming.handle(data)
        if rec is None:
            self.emit(f"{Colors.GREEN}{Colors.BOLD}[RECV]{Colors.RESET} "
                      f"{data.decode('utf-8', 'replace')}")
            return
        with self.lock:
            self.counters['files_in'] += 1
        if rec['sha_ok']:
            self.emit(f"{Colors.GREEN}{Colors.BOLD}[FILE]{Colors.RESET} "
                      f"{rec['filename']} "
                      f"({filexfer.human_bytes(rec['bytes'])}) "
                      f"sha256 verified -> {rec['path']}")
        else:
            self.emit(f"{Colors.RED}{Colors.BOLD}[FILE]{Colors.RESET} "
                      f"{rec['filename']} HASH MISMATCH -- not saved. The "
                      f"fragments passed CRC but the reassembled file does "
                      f"not match its hash.")

    def on_status(self, data):
        with self.lock:
            self.counters['status'] += 1
        text = data.decode('utf-8', 'replace').strip()
        kw, kv = parse_kv(text)

        if kw == 'IDLE':
            return
        if kw == 'FRAG':
            self._track_fragment(kv)
            if not self.show_frags:
                return
            self.emit(f"{Colors.DIM}[link] {text}{Colors.RESET}")
            return
        if kw == 'DONE':
            rec = int(kv.get('recovered', 0) or 0)
            with self.lock:
                self.counters['recovered'] += rec
            extra = (f"  {Colors.BLUE}(erasure coding reconstructed {rec} "
                     f"lost fragment{'s' if rec != 1 else ''}){Colors.RESET}"
                     if rec else "")
            mid = kv.get('msg')
            prog = self.transfers.pop(int(mid), None) if mid else None
            when = f"  in {filexfer.human_duration(prog.elapsed)}" if prog else ""
            self.emit(f"{Colors.GREEN}[link] {text}{Colors.RESET}{extra}{when}")
            return
        if kw == 'INCOMPLETE':
            self.emit(f"{Colors.RED}[link] {text}{Colors.RESET}\n"
                      f"       {Colors.DIM}more fragments were lost than the "
                      f"parity could cover -- raise /parity or improve the "
                      f"link, then resend{Colors.RESET}")
            return
        if kw == 'BERT':
            self._handle_bert(kv)
            return
        color = (Colors.RED if 'FAIL' in text else
                 Colors.YELLOW if kw in ('WARN', 'FOREIGN', 'HEALTH') else
                 Colors.BLUE if kw in ('TXQUEUE', 'TXCTRL', 'CTRL') else
                 Colors.DIM)
        self.emit(f"{color}[link] {text}{Colors.RESET}")

    def _track_fragment(self, kv):
        try:
            mid = int(kv['msg'])
        except (KeyError, ValueError):
            return
        prog = self.transfers.get(mid)
        if prog is None:
            return
        try:
            prog.note_fragment(kv.get('type', 'DATA'), int(kv['idx']))
        except (KeyError, ValueError):
            return
        now = time.monotonic()
        if now - getattr(prog, '_last_print', 0) >= 2.0:
            prog._last_print = now
            self.emit(f"{Colors.CYAN}[send]{Colors.RESET} {prog.filename}: "
                      f"{prog.summary()}")

    def _handle_bert(self, kv):
        try:
            e, b = int(kv.get('errors', 0)), int(kv.get('bits', 0))
        except ValueError:
            return
        synced = kv.get('synced') == '1'
        with self.lock:
            self.bert['errors'] += e
            self.bert['bits'] += b
            self.bert['synced'] = synced
        if not b:
            return
        ber = e / b
        lo, hi = metrics.ber_confidence_interval(e, b)
        if synced:
            self.emit(f"{Colors.BOLD}[BER]{Colors.RESET} {ber:.3e}  "
                      f"({e:,} errors in {b:,} bits, 95% CI "
                      f"[{lo:.1e}, {hi:.1e}])")
        else:
            self.emit(f"{Colors.RED}[BER] sync lost -- the link dropped; "
                      f"counting restarts{Colors.RESET}")

    def on_diag(self, data):
        if not self.show_diag:
            return
        text = data.decode('utf-8', 'replace').strip()
        kw, kv = parse_kv(text)
        if kw == 'PSD':
            return                       # a spectrum is not a terminal line
        if kw == 'SNR' and 'symbol_db' in kv:
            try:
                sym = float(kv['symbol_db'])
                chip = metrics.symbol_snr_to_chip_snr_db(
                    sym, self.profile.code_len)
                self.emit(f"{Colors.DIM}[diag] symbol SNR {sym:5.1f} dB "
                          f"(= {chip:6.1f} dB before despreading), "
                          f"drift {kv.get('drift', '?')} chips/ksym, "
                          f"slips {kv.get('slips', '?')}, "
                          f"CFO {kv.get('cfo_hz', '?')} Hz{Colors.RESET}")
                return
            except ValueError:
                pass
        self.emit(f"{Colors.DIM}[diag] {text}{Colors.RESET}")

    # -- send ------------------------------------------------------------
    def send_message(self, text):
        payload = text.encode('utf-8')
        if len(payload) > protocol.max_message_bytes():
            print(f"{Colors.RED}message is {len(payload):,} bytes; the "
                  f"ceiling is {protocol.max_message_bytes():,}{Colors.RESET}")
            return
        self.tx.sendto(payload, (self.args.host, self.args.tx_port))
        with self.lock:
            self.counters['sent'] += 1
        self.next_msg_id = (self.next_msg_id + 1) % 256
        print(f"{Colors.YELLOW}[SENT]{Colors.RESET} {text}")

    def send_file(self, path):
        try:
            prep = filexfer.prepare_file(path, self.parity)
        except OSError as exc:
            print(f"{Colors.RED}cannot read {path}: {exc}{Colors.RESET}")
            return False
        if prep['too_large']:
            print(f"{Colors.RED}{prep['filename']} needs {prep['n_data']:,} "
                  f"fragments; the wire format allows "
                  f"{protocol.MAX_FRAGMENTS:,}{Colors.RESET}")
            return False

        secs = filexfer.estimate_seconds(prep['n_total'], self.profile)
        print(f"{Colors.BOLD}sending {prep['filename']}{Colors.RESET}  "
              f"{filexfer.human_bytes(prep['file_bytes'])}")
        print(f"  {prep['n_data']:,} data + {prep['n_parity']:,} parity "
              f"fragments ({self.parity:.0%} overhead)")
        print(f"  about {filexfer.human_duration(secs)} on air at the "
              f"'{self.profile.name}' profile's "
              f"{self.profile.payload_rate_bytes_per_s():.0f} bytes/second")
        print(f"  sha256 {prep['sha256'][:32]}...")

        msg_id = self.next_msg_id
        self.transfers[msg_id] = filexfer.TransferProgress(
            msg_id=msg_id, filename=prep['filename'],
            file_bytes=prep['file_bytes'], n_data=prep['n_data'],
            n_parity=prep['n_parity'])
        self.tx.sendto(prep['message'], (self.args.host, self.args.tx_port))
        self.next_msg_id = (msg_id + 1) % 256
        with self.lock:
            self.counters['sent'] += 1
            self.counters['files_out'] += 1
        return True

    def control(self, cmd):
        self.ctrl.sendto(cmd.encode('ascii'),
                         (self.args.host, self.args.ctrl_port))

    # -- command dispatch -------------------------------------------------
    def handle_command(self, line):
        """Returns False to quit."""
        parts = line.split()
        cmd = parts[0][1:].lower()
        arg = parts[1] if len(parts) > 1 else None

        if cmd in ('quit', 'exit'):
            return False
        if cmd == 'help':
            print(HELP)
        elif cmd == 'stats':
            with self.lock:
                c = dict(self.counters)
                b = dict(self.bert)
            print(f"  profile        {self.profile.name}: "
                  f"{self.profile.code_len} chips, "
                  f"{self.profile.chip_rate / 1e6:.3f} Mcps, "
                  f"{self.profile.processing_gain_db:.1f} dB gain, "
                  f"{self.profile.payload_rate_bytes_per_s():.0f} B/s")
            print(f"  sent           {c['sent']} ({c['files_out']} files)")
            print(f"  received       {c['recv']} ({c['files_in']} files)")
            print(f"  status lines   {c['status']}")
            print(f"  fragments recovered by erasure coding  {c['recovered']}")
            if b['bits']:
                ber = b['errors'] / b['bits']
                lo, hi = metrics.ber_confidence_interval(b['errors'], b['bits'])
                print(f"  BER            {ber:.3e}  ({b['errors']:,} errors "
                      f"in {b['bits']:,} bits, 95% CI [{lo:.1e},{hi:.1e}])")
        elif cmd in ('node', 'dest'):
            if arg is None or not arg.lstrip('-').isdigit():
                print(f"{Colors.RED}usage: /{cmd} <0-{NODE_TABLE_SIZE - 1}>"
                      f"{Colors.RESET}")
            elif not (0 <= int(arg) < NODE_TABLE_SIZE):
                print(f"{Colors.RED}node id must be 0-"
                      f"{NODE_TABLE_SIZE - 1}{Colors.RESET}")
            else:
                self.control(f"{cmd.upper()}={int(arg)}")
                what = ("transmitting as node" if cmd == 'node'
                        else "now despreading node")
                print(f"{Colors.YELLOW}[CTRL]{Colors.RESET} {what} {arg}")
        elif cmd == 'send':
            if not arg:
                print(f"{Colors.RED}usage: /send <path>{Colors.RESET}")
            else:
                self.send_file(' '.join(parts[1:]))
        elif cmd == 'parity':
            if arg is None:
                print(f"  parity overhead is {self.parity:.0%}")
            else:
                try:
                    self.parity = max(0.0, min(0.5, float(arg) / 100.0))
                except ValueError:
                    print(f"{Colors.RED}usage: /parity <percent>{Colors.RESET}")
                    return True
                self.control(f"PARITY={self.parity * 100:.0f}")
                print(f"{Colors.YELLOW}[CTRL]{Colors.RESET} parity overhead "
                      f"-> {self.parity:.0%}")
        elif cmd == 'bert':
            on = (arg or 'on').lower() in ('on', '1', 'true')
            self.control(f"BERT={1 if on else 0}")
            print(f"{Colors.YELLOW}[CTRL]{Colors.RESET} BER test "
                  f"{'on -- idle slots now carry PRBS-15' if on else 'off'}")
        elif cmd == 'txgain':
            try:
                g = max(0.0, min(1.0, float(arg)))
            except (TypeError, ValueError):
                print(f"{Colors.RED}usage: /txgain <0..1>{Colors.RESET}")
                return True
            self.control(f"TXGAIN={g:.3f}")
            print(f"{Colors.YELLOW}[CTRL]{Colors.RESET} transmitter "
                  f"{'MUTED' if g == 0 else f'scaled to {g:.2f}'}")
        elif cmd == 'diag':
            self.show_diag = (arg or 'on').lower() in ('on', '1', 'true')
            print(f"  telemetry {'on' if self.show_diag else 'off'}")
        elif cmd == 'profile':
            try:
                self.profile = link_profiles.get(arg)
            except KeyError as exc:
                print(f"{Colors.RED}{exc}{Colors.RESET}")
                return True
            print(f"  estimates now assume the '{self.profile.name}' profile "
                  f"({self.profile.payload_rate_bytes_per_s():.0f} B/s). "
                  f"This does NOT change the flowgraph.")
        else:
            print(f"{Colors.RED}unknown command {line!r} -- /help"
                  f"{Colors.RESET}")
        return True

    def close(self):
        for s in (self.tx, self.ctrl, self.data_sock, self.status_sock,
                  self.diag_sock):
            try:
                s.close()
            except OSError:
                pass


def main():
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--host', default='127.0.0.1')
    ap.add_argument('--tx-port', type=int, default=52001)
    ap.add_argument('--rx-data-port', type=int, default=52002)
    ap.add_argument('--rx-status-port', type=int, default=52003)
    ap.add_argument('--ctrl-port', type=int, default=52004)
    ap.add_argument('--diag-port', type=int, default=52005)
    ap.add_argument('--bind-host', default='127.0.0.1')
    ap.add_argument('--download-dir',
                    default=os.path.join(os.path.dirname(
                        os.path.abspath(__file__)), 'received_files'))
    ap.add_argument('--profile', default=os.environ.get('LINK_PROFILE',
                                                        'stealth'),
                    help='which profile the flowgraph is running, so airtime '
                         'estimates are right')
    ap.add_argument('--show-diag', action='store_true',
                    help='print live link telemetry')
    ap.add_argument('--show-fragments', action='store_true',
                    help='print every fragment (a megabyte file is thousands)')
    ap.add_argument('--no-color', action='store_true')
    ap.add_argument('--send-file', metavar='PATH',
                    help='send this file and exit (with --wait, wait for it)')
    ap.add_argument('--bert', type=float, metavar='SECONDS',
                    help='run a bit error rate measurement for this long, '
                         'print the result, and exit')
    ap.add_argument('--wait', type=float, default=0, metavar='SECONDS',
                    help='stay open this long after a scripted action; 0 with '
                         '--send-file means wait for delivery or failure')
    ap.add_argument('--once', action='store_true',
                    help='read one message from stdin, send it, and exit')
    args = ap.parse_args()

    if args.no_color or not sys.stdout.isatty():
        Colors.disable()

    try:
        term = Terminal(args)
    except OSError as exc:
        print(f"could not bind a receive port ({exc}).\n"
              f"Is ground_station.py already running and holding them?")
        return 1

    # ---- scripted modes ------------------------------------------------
    if args.bert is not None:
        print(f"measuring bit error rate for {args.bert:.0f} s...")
        term.control("BERT=1")
        time.sleep(args.bert)
        term.control("BERT=0")
        time.sleep(1.0)
        b = term.bert
        if b['bits']:
            ber = b['errors'] / b['bits']
            lo, hi = metrics.ber_confidence_interval(b['errors'], b['bits'])
            need = metrics.bits_needed_for_ber(max(ber, 1e-7))
            print(f"\n  BER        {ber:.3e}")
            print(f"  errors     {b['errors']:,}")
            print(f"  bits       {b['bits']:,}")
            print(f"  95% CI     [{lo:.2e}, {hi:.2e}]")
            if b['bits'] < need:
                print(f"\n  A credible measurement at this error rate wants "
                      f"about {need:,} bits;\n  this run saw "
                      f"{b['bits']:,}. Run longer, or use a faster profile.")
        else:
            print("  no BERT reports arrived -- is the flowgraph running?")
        term.close()
        return 0

    if args.send_file:
        ok = term.send_file(args.send_file)
        if not ok:
            term.close()
            return 1
        deadline = (time.monotonic() + args.wait if args.wait
                    else time.monotonic() + 3600)
        while time.monotonic() < deadline and term.transfers:
            time.sleep(0.5)
        term.close()
        return 0

    if args.once:
        data = sys.stdin.read().strip()
        if data:
            term.send_message(data)
            time.sleep(max(args.wait, 0.5))
        term.close()
        return 0

    # ---- interactive ---------------------------------------------------
    print(f"{Colors.BOLD}{BANNER}{Colors.RESET}")
    print(f"  sending to    {args.host}:{args.tx_port}")
    print(f"  data from     {args.bind_host}:{args.rx_data_port}")
    print(f"  status from   {args.bind_host}:{args.rx_status_port}")
    print(f"  control to    {args.host}:{args.ctrl_port}")
    print(f"  received files -> {term.incoming.save_dir}")
    print(f"  profile '{term.profile.name}': {term.profile.code_len} chips, "
          f"{term.profile.processing_gain_db:.1f} dB gain, "
          f"~{term.profile.payload_rate_bytes_per_s():.0f} bytes/s")
    print()

    try:
        while True:
            try:
                line = input(f"{Colors.CYAN}> {Colors.RESET}")
            except EOFError:
                break
            if not line:
                continue
            if line.startswith('/'):
                if not term.handle_command(line):
                    break
                continue
            term.send_message(line)
    except KeyboardInterrupt:
        pass
    finally:
        term.close()
        print("\nbye")
    return 0


if __name__ == '__main__':
    sys.exit(main())
