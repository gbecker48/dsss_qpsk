"""
Fragment Reassembler
----------------------
Mirror of the TX Scheduler: parses each validated packet payload's inner
header [MSG_ID 1B][FRAG_IDX 1B][FRAG_TOTAL 1B][CHUNK_LEN 1B][DATA] and
accumulates fragments per message id until all of them have arrived, at
which point the complete original message is published.

FRAG_TOTAL == 0 marks an idle/keep-alive filler fragment (see TX
Scheduler) - these are reported as an "IDLE" status line and otherwise
ignored.

There is no retransmission/ARQ in this link - if a fragment is lost (its
packet failed CRC and was dropped upstream by the Packet Deframer), the
message it belonged to will simply never complete. To keep that visible
rather than silent, each in-progress message is given a generous fragment
budget (see `stale_after`) after which, if it still isn't complete, it's
reported INCOMPLETE and dropped rather than held onto forever.

Status line grammar (this is a frozen contract with ground_station.py /
terminal.py - see the project README before changing it):
    "FRAG msg=<id> idx=<i> total=<n> seq=<seq> crc=OK len=<bytes>"
    "IDLE seq=<seq>"
    "DONE msg=<id> fragments=<n> bytes=<total_bytes>"
    "INCOMPLETE msg=<id> missing=<comma,separated,fragment,indices>"
(CRC failures are reported directly by the Packet Deframer in plain text,
since a corrupted packet's own MSG_ID/FRAG_IDX can't be trusted.)

Input : PDU - [SEQ 1B][payload_bytes] (payload_bytes from Packet Deframer,
        CRC-validated, SEQ prepended so idle heartbeats can quote it)
Outputs: 'msg'    - PDU, a complete reassembled message (only when done)
         'status' - PDU, one of the status lines above (always)
"""

import numpy as np
import pmt
from gnuradio import gr


def pdu_data(msg):
    vec = pmt.cdr(msg) if pmt.is_pair(msg) else msg
    return np.array(pmt.u8vector_elements(vec), dtype=np.uint8)


def make_pdu(values):
    arr = np.asarray(values, dtype=np.uint8)
    return pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(arr), arr.tolist()))


class blk(gr.basic_block):
    """Fragment Reassembler"""

    def __init__(self, chunk_bytes=252, stale_after=64):
        gr.basic_block.__init__(self, name='Fragment Reassembler', in_sig=[], out_sig=[])
        self.chunk_bytes = int(chunk_bytes)
        self.stale_after = int(stale_after)
        self.pending = {}       # msg_id -> {'total': n, 'chunks': {idx: bytes}, 'age': int}
        self.message_port_register_in(pmt.intern('in'))
        self.message_port_register_out(pmt.intern('msg'))
        self.message_port_register_out(pmt.intern('status'))
        self.set_msg_handler(pmt.intern('in'), self.handle_msg)

    def handle_msg(self, msg):
        raw = pdu_data(msg).tobytes()
        if len(raw) < 1 + 4:
            return
        seq = raw[0]
        payload = raw[1:]
        mid, idx, total, clen = payload[0], payload[1], payload[2], payload[3]
        data = payload[4:4 + self.chunk_bytes][:clen]

        if total == 0:
            self._status("IDLE seq=%d" % seq)
            self._age_pending()
            return

        entry = self.pending.setdefault(mid, {'total': total, 'chunks': {}, 'age': 0})
        entry['total'] = total
        entry['chunks'][idx] = data
        entry['age'] = 0

        self._status("FRAG msg=%d idx=%d total=%d seq=%d crc=OK len=%d" %
                      (mid, idx, total, seq, len(data)))

        if len(entry['chunks']) >= total:
            complete = b''.join(entry['chunks'][i] for i in range(total))
            del self.pending[mid]
            self.message_port_pub(pmt.intern('msg'), make_pdu(list(complete)))
            self._status("DONE msg=%d fragments=%d bytes=%d" % (mid, total, len(complete)))
        else:
            self._age_pending(exclude=mid)

    def _age_pending(self, exclude=None):
        stale = []
        for mid, entry in self.pending.items():
            if mid == exclude:
                continue
            entry['age'] += 1
            if entry['age'] >= self.stale_after:
                stale.append(mid)
        for mid in stale:
            entry = self.pending.pop(mid)
            missing = [i for i in range(entry['total']) if i not in entry['chunks']]
            self._status("INCOMPLETE msg=%d missing=%s" %
                          (mid, ','.join(str(i) for i in missing)))

    def _status(self, text):
        print("[RX] " + text)
        self.message_port_pub(pmt.intern('status'), make_pdu(list(text.encode('utf-8'))))
