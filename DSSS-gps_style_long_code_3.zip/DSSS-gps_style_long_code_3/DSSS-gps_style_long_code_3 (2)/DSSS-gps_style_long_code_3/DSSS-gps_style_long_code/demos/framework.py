"""
framework.py -- shared plumbing for the eight requirement demos
===============================================================

Every demo produces the same three things, because a demo that only exists as
something happening on a screen is not evidence of anything an hour later:

  1. A spoken result -- one headline sentence and a short table of numbers,
     printed to the console as the run proceeds.
  2. Plots, saved as PNG.
  3. A self-contained report.md in the run's own timestamped directory,
     holding the requirement text, the method, the numbers, and the plots.

So a run can be given to someone who was not in the room, and the folder is
the deliverable.

Live versus offline
-------------------
Demos declare which modes they support. Offline runs use dsss_link.dsss_core,
which is the same algorithm the flowgraph runs (see that module's docstring for
the contract that keeps it so) -- that is what makes it legitimate to sweep 40
operating points offline instead of spending an afternoon per curve on the
bench. Live runs drive a running flowgraph over its UDP ports and measure what
the radio actually did.

Where both are possible, both are worth running: the offline sweep gives the
curve, the live run gives the point on it that the hardware actually achieved,
and the gap between them is the honest measure of how much the model is
leaving out.
"""

from __future__ import annotations

import io
import json
import os
import socket
import sys
import time
import contextlib
from dataclasses import dataclass, field
from datetime import datetime

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ---------------------------------------------------------------------------
# Plot style
#
# Palette from the project's validated categorical set (blue / orange / aqua,
# plus a reserved red for failure thresholds and a neutral for references).
# Verified all-pairs colourblind-safe: worst CVD dE 9.2, worst normal-vision
# dE 24.0. Aqua sits under 3:1 against the surface, so every chart that uses it
# carries a legend and direct labels rather than relying on colour alone.
# ---------------------------------------------------------------------------

C_MEASURED = "#2a78d6"    # slot 1, blue   -- what we measured
C_THEORY   = "#eb6834"    # slot 2, orange -- what theory predicts
C_ALT      = "#1baf7a"    # slot 3, aqua   -- a second measured series
C_BAD      = "#e34948"    # status: failure / threshold
C_GRID     = "#d8d7d2"
C_INK      = "#0b0b0b"
C_INK2     = "#52514e"

plt.rcParams.update({
    "figure.facecolor": "#fcfcfb",
    "axes.facecolor": "#fcfcfb",
    "axes.edgecolor": C_GRID,
    "axes.labelcolor": C_INK2,
    "axes.titlecolor": C_INK,
    "axes.titlesize": 11,
    "axes.titleweight": "bold",
    "axes.labelsize": 9,
    "axes.grid": True,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "grid.color": C_GRID,
    "grid.linewidth": 0.6,
    "xtick.color": C_INK2,
    "ytick.color": C_INK2,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "legend.frameon": False,
    "legend.fontsize": 8,
    "lines.linewidth": 2.0,
    "lines.markersize": 5,
    "font.size": 9,
    "figure.dpi": 130,
})


# ---------------------------------------------------------------------------
# Results
# ---------------------------------------------------------------------------

@dataclass
class Result:
    """What a demo produced."""
    passed: bool
    headline: str
    rows: list = field(default_factory=list)       # (label, value) pairs
    notes: list = field(default_factory=list)      # free-text paragraphs
    artifacts: list = field(default_factory=list)  # file paths
    data: dict = field(default_factory=dict)       # raw numbers, saved as JSON

    def row(self, label, value):
        self.rows.append((str(label), str(value)))
        return self

    def note(self, text):
        self.notes.append(text.strip())
        return self


@dataclass
class Context:
    """Everything a demo needs from the outside world."""
    outdir: str
    live: "LinkClient | None" = None
    quick: bool = False
    seed: int = 12345
    args: dict = field(default_factory=dict)

    def path(self, name: str) -> str:
        return os.path.join(self.outdir, name)

    def rng(self, salt: int = 0):
        return np.random.default_rng(self.seed + salt)

    def save_fig(self, fig, name: str, result: Result, caption: str = ""):
        p = self.path(name)
        fig.tight_layout()
        fig.savefig(p, bbox_inches="tight")
        plt.close(fig)
        result.artifacts.append((name, caption))
        return p

    def save_csv(self, name: str, header: list, rows: list, result: Result,
                 caption: str = ""):
        p = self.path(name)
        with open(p, "w") as f:
            f.write(",".join(str(h) for h in header) + "\n")
            for r in rows:
                f.write(",".join(
                    ("%.6g" % v) if isinstance(v, float) else str(v)
                    for v in r) + "\n")
        result.artifacts.append((name, caption))
        return p


class Demo:
    """Base class. Subclasses set the metadata and implement run()."""
    NUMBER = 0
    SLUG = "demo"
    TITLE = ""
    REQUIREMENT = ""
    SHOWS = ""
    NEEDS_LIVE = False           # True if it cannot run offline at all
    NEEDS_RADIOS = 0             # how many radios a live run wants

    def run(self, ctx: Context) -> Result:
        raise NotImplementedError


# ---------------------------------------------------------------------------
# Live link client
# ---------------------------------------------------------------------------

class LinkClient:
    """UDP client for a running flowgraph. Same ports the ground station uses.

    Fire-and-forget on the way out, because that is what the flowgraph's
    socket_pdu blocks are: there is no ack and no connection, so a send that
    "succeeds" only means the datagram left. Everything that needs confirmation
    is confirmed by watching the status stream instead.
    """

    def __init__(self, host="127.0.0.1", tx_port=52001, status_port=52003,
                 ctrl_port=52004, diag_port=52005, data_port=52002,
                 bind_host="127.0.0.1"):
        self.host = host
        self.tx_port = tx_port
        self.ctrl_port = ctrl_port
        self.tx_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.status = self._bind(bind_host, status_port)
        self.diag = self._bind(bind_host, diag_port)
        self.data = self._bind(bind_host, data_port)

    @staticmethod
    def _bind(host, port):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((host, port))
        s.settimeout(0.2)
        return s

    def send_message(self, payload: bytes):
        self.tx_sock.sendto(payload, (self.host, self.tx_port))

    def control(self, cmd: str):
        self.tx_sock.sendto(cmd.encode("ascii"), (self.host, self.ctrl_port))

    def drain(self, sock, seconds: float) -> list:
        """Collect datagrams for a fixed wall-clock window."""
        out = []
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            try:
                d, _ = sock.recvfrom(65535)
            except socket.timeout:
                continue
            except OSError:
                break
            out.append(d.decode("utf-8", "replace").strip())
        return out

    def collect_status(self, seconds): return self.drain(self.status, seconds)
    def collect_diag(self, seconds): return self.drain(self.diag, seconds)

    def alive(self, seconds: float = 3.0) -> bool:
        """Is a flowgraph actually transmitting? Idle heartbeats say yes."""
        return len(self.drain(self.status, seconds)) > 0

    def close(self):
        for s in (self.tx_sock, self.status, self.diag, self.data):
            try:
                s.close()
            except OSError:
                pass


def parse_kv(line: str):
    """Lenient 'KEYWORD k=v k=v' parser, matching the ground station's."""
    parts = line.strip().split()
    if not parts:
        return None, {}
    kv = {}
    for tok in parts[1:]:
        if "=" in tok:
            k, _, v = tok.partition("=")
            if k:
                kv[k] = v
    return parts[0], kv


# ---------------------------------------------------------------------------
# Running a demo and writing its report
# ---------------------------------------------------------------------------

BANNER = "=" * 78


def make_outdir(base: str, number: int, slug: str) -> str:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    d = os.path.join(base, f"{stamp}_req{number}_{slug}")
    os.makedirs(d, exist_ok=True)
    return d


class _Tee(io.TextIOBase):
    """Console output also goes to the run's console.log."""
    def __init__(self, *streams):
        self.streams = streams

    def write(self, s):
        for st in self.streams:
            st.write(s)
            st.flush()
        return len(s)

    def flush(self):
        for st in self.streams:
            st.flush()


def execute(demo: Demo, ctx: Context) -> Result:
    """Run one demo with its console captured, then write report.md."""
    log_path = ctx.path("console.log")
    started = time.time()
    with open(log_path, "w") as logf:
        tee = _Tee(sys.__stdout__, logf)
        with contextlib.redirect_stdout(tee):
            print(BANNER)
            print(f"REQUIREMENT {demo.NUMBER}: {demo.REQUIREMENT}")
            print(BANNER)
            print(f"\n{demo.TITLE}\n")
            print(demo.SHOWS.strip())
            print(f"\nmode: {'LIVE (talking to a running flowgraph)' if ctx.live else 'OFFLINE (simulation)'}")
            print(f"output: {ctx.outdir}\n")
            print("-" * 78)
            try:
                result = demo.run(ctx)
            except Exception as exc:
                import traceback
                traceback.print_exc()
                result = Result(False, f"demo failed: {exc}")
            print("-" * 78)
            print(f"\n{'PASS' if result.passed else 'ATTENTION'}: {result.headline}\n")
            if result.rows:
                w = max(len(r[0]) for r in result.rows)
                for label, value in result.rows:
                    print(f"  {label:<{w}}   {value}")
            for n in result.notes:
                print(f"\n{n}")
            if result.artifacts:
                print("\nsaved:")
                for name, cap in result.artifacts:
                    print(f"  {name}" + (f"  -- {cap}" if cap else ""))
            print()

    elapsed = time.time() - started
    _write_report(demo, ctx, result, elapsed)
    if result.data:
        with open(ctx.path("data.json"), "w") as f:
            json.dump(_jsonable(result.data), f, indent=2)
    return result


def _jsonable(obj):
    if isinstance(obj, dict):
        return {k: _jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_jsonable(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.floating, np.integer)):
        return obj.item()
    return obj


def _write_report(demo, ctx, result, elapsed):
    lines = [
        f"# Requirement {demo.NUMBER} -- {demo.TITLE}",
        "",
        f"> **{demo.REQUIREMENT}**",
        "",
        f"Run {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} · "
        f"{'live against a running flowgraph' if ctx.live else 'offline simulation'} · "
        f"{elapsed:.1f} s",
        "",
        "## Result",
        "",
        f"**{'PASS' if result.passed else 'NEEDS ATTENTION'}** -- {result.headline}",
        "",
    ]
    if result.rows:
        lines += ["| Measurement | Value |", "|---|---|"]
        lines += [f"| {l} | {v} |" for l, v in result.rows]
        lines.append("")
    if result.notes:
        lines += ["## Notes", ""]
        for n in result.notes:
            lines += [n, ""]
    figs = [(n, c) for n, c in result.artifacts if n.endswith(".png")]
    if figs:
        lines += ["## Figures", ""]
        for name, cap in figs:
            lines += [f"### {cap or name}", "", f"![{cap or name}]({name})", ""]
    other = [(n, c) for n, c in result.artifacts if not n.endswith(".png")]
    if other:
        lines += ["## Data files", ""]
        lines += [f"- `{n}`" + (f" -- {c}" if c else "") for n, c in other]
        lines.append("")
    lines += ["## What this demonstrates", "", demo.SHOWS.strip(), "",
              "---", "", "`console.log` in this folder holds the full run output."]
    with open(ctx.path("report.md"), "w") as f:
        f.write("\n".join(lines))
