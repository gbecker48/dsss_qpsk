"""Requirement 8 (stretch) -- a third radio jamming the link."""

from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt

from dsss_link import dsss_core as core
from dsss_link import link_profiles, metrics
from .framework import (Demo, Result, Context, C_MEASURED, C_THEORY, C_ALT,
                        C_BAD, C_INK2, parse_kv)


def make_jammer(kind, n, samp_rate, chip_rate, rng):
    """Generate one of four jamming waveforms at unit average power.

    The four are chosen because DSSS treats them very differently, and the
    difference IS the result:

      cw         a single tone. The despreader spreads it across the full code
                 bandwidth while collapsing the wanted signal, so it is
                 suppressed by very close to the full processing gain. This is
                 the textbook DSSS anti-jam case.
      swept      a tone sweeping across the band -- a common real jammer, and
                 harder than CW because it is in the correlator's way for part
                 of every symbol rather than at one fixed frequency.
      partial    noise filling a fraction of the band. Worse per watt than
                 broadband, because concentrating the same power in less
                 bandwidth puts more of it where it lands after despreading.
      broadband  white noise across the whole band. The worst case, because it
                 is indistinguishable from thermal noise and gets no
                 suppression beyond the processing gain.
    """
    t = np.arange(n) / samp_rate
    if kind == "cw":
        j = np.exp(2j * np.pi * (samp_rate * 0.13) * t)
    elif kind == "swept":
        sweep_hz = samp_rate * 0.4
        period = n / samp_rate / 8
        f = sweep_hz * (2 * ((t / period) % 1.0) - 1.0)
        j = np.exp(2j * np.pi * np.cumsum(f) / samp_rate)
    elif kind == "partial":
        frac = 0.1
        w = (rng.normal(0, 1, n) + 1j * rng.normal(0, 1, n)) / np.sqrt(2)
        spec = np.fft.fft(w)
        keep = int(len(spec) * frac / 2)
        mask = np.zeros(len(spec), dtype=bool)
        mask[:keep] = True
        mask[-keep:] = True
        spec[~mask] = 0
        j = np.fft.ifft(spec)
    elif kind == "broadband":
        j = (rng.normal(0, 1, n) + 1j * rng.normal(0, 1, n)) / np.sqrt(2)
    else:
        raise ValueError(kind)
    j = np.asarray(j, dtype=np.complex64)
    pw = float(np.mean(np.abs(j) ** 2))
    return (j / np.sqrt(pw)).astype(np.complex64) if pw > 0 else j


class D8(Demo):
    NUMBER = 8
    SLUG = "jamming"
    TITLE = "Stretch: a third radio jamming the link"
    REQUIREMENT = ("Stretch requirement: add a third B206mini and use it to "
                   "jam the link.")
    SHOWS = """
How much jamming the link absorbs before it fails, measured as a
jammer-to-signal ratio, for four jammer types.

The headline prediction is the jamming margin:

    M_j = Gp - (Eb/N0 required) - implementation loss

which for this link is about 20 dB -- meaning a broadband jammer has to be
roughly a hundred times stronger than the signal before the link breaks. That
is the entire practical argument for spending 1023 chips per symbol, and this
demo measures whether the link delivers it.

The four jammer types are measured separately because DSSS treats them very
differently. A narrowband tone is nearly free to reject; broadband noise is
not. Showing both is the difference between a real anti-jam result and a
flattering one.

`jammer.py` drives the third radio for a live run. This demo runs the same
sweep in simulation, so the curves exist whether or not the third radio is on
the bench.
"""

    NEEDS_RADIOS = 3

    def run(self, ctx: Context) -> Result:
        res = Result(True, "")
        p = link_profiles.get("stealth")
        L, prn = p.code_len, core.NODE_PRN_TABLE[0]
        code = core.gold_code(L, prn)

        # ---------------- (a) predicted jamming margin -------------------
        req_ebn0 = 9.6
        margin_theory = metrics.jamming_margin_db(L, req_ebn0)
        print("(a) predicted jamming margin")
        print(f"    processing gain               {metrics.ideal_processing_gain_db(L):5.1f} dB")
        print(f"    Eb/N0 needed for BER 1e-5     {req_ebn0:5.1f} dB")
        print(f"    predicted jamming margin      {margin_theory:5.1f} dB")
        print(f"    i.e. a broadband jammer must be ~{10 ** (margin_theory / 10):.0f}x "
              f"the signal power to break the link")

        # ---------------- (b) measured, four jammer types ---------------
        print("\n(b) measured BER versus jammer-to-signal ratio")
        rng = ctx.rng(12)
        bits = rng.integers(0, 2, 4000).astype(np.uint8)
        tx = core.transmit(bits, code, sps=1)
        esn0 = 16.0
        jsrs = ([-10, 0, 5, 10, 15, 18, 21, 24, 27, 30, 35, 40]
                if not ctx.quick else [0, 10, 20, 30, 40])
        kinds = (["cw", "swept", "partial", "broadband"] if not ctx.quick
                 else ["cw", "broadband"])
        cols = {"cw": C_MEASURED, "swept": C_ALT, "partial": C_THEORY,
                "broadband": C_BAD}
        curves = {}
        sig_power = float(np.mean(np.abs(tx) ** 2))

        for kind in kinds:
            bers = []
            for jsr in jsrs:
                j = make_jammer(kind, len(tx), p.chip_rate, p.chip_rate,
                                np.random.default_rng(77))
                amp = np.sqrt(sig_power * 10 ** (jsr / 10.0))
                ch = core.Channel(esn0_db=esn0, code_len=L,
                                  samp_rate=p.chip_rate,
                                  delay_samples=401.0, seed=55)
                # Thermal noise is pinned to the signal power, then the jammer
                # is added. Letting the channel measure the combined input
                # would scale the receiver's own noise floor with the jammer
                # and understate the jamming margin by about 20 dB.
                rx = ch.apply(tx, sps=1, reference_power=sig_power) + amp * j
                out, _d, _ = core.receive(rx, L, prn, sps=1, costas_bw=0.02,
                                          chip_rate=p.chip_rate)
                b = core.ber_between(bits, out)[0] if len(out) else 1.0
                bers.append(b)
            curves[kind] = bers
            broke = [j for j, b in zip(jsrs, bers) if b >= 1e-2]
            limit = min(broke) if broke else float("inf")
            print(f"    {kind:10}: link survives to J/S = "
                  + (f"{max([j for j, b in zip(jsrs, bers) if b < 1e-2]):+3} dB"
                     if any(b < 1e-2 for b in bers) else "never works")
                  + (f", fails at {limit:+} dB" if np.isfinite(limit) else ""))

        fig, ax = plt.subplots(figsize=(7.2, 4.2))
        for kind in kinds:
            ax.semilogy(jsrs, np.maximum(curves[kind], 1e-6), marker="o",
                        color=cols[kind], label=f"{kind} jammer")
            ax.annotate(kind, xy=(jsrs[-1], max(curves[kind][-1], 1e-6)),
                        xytext=(5, 0), textcoords="offset points",
                        fontsize=8, color=cols[kind], va="center")
        ax.axvline(margin_theory, color=C_INK2, ls="--", lw=1.2)
        ax.annotate(f"predicted margin\n{margin_theory:.0f} dB",
                    xy=(margin_theory, 2e-5), xytext=(-105, 0),
                    textcoords="offset points", fontsize=8, color=C_INK2,
                    arrowprops=dict(arrowstyle="->", color=C_INK2, lw=0.8))
        ax.axhline(1e-2, color=C_THEORY, ls=":", lw=1.2)
        ax.set_xlabel("jammer-to-signal ratio (dB)")
        ax.set_ylabel("bit error rate")
        ax.set_ylim(1e-6, 1)
        ax.set_title("Jamming margin: how much stronger the jammer has to be")
        ax.legend(loc="upper left")
        ctx.save_fig(fig, "jamming_margin.png", res,
                     "BER versus jammer-to-signal ratio for four jammer types")
        ctx.save_csv("jamming_margin.csv",
                     ["jsr_db"] + [f"ber_{k}" for k in kinds],
                     [[jsrs[i]] + [curves[k][i] for k in kinds]
                      for i in range(len(jsrs))], res,
                     "jamming margin measurement data")

        measured_margins = {}
        for kind in kinds:
            ok = [j for j, b in zip(jsrs, curves[kind]) if b < 1e-2]
            measured_margins[kind] = max(ok) if ok else float("-inf")
        bb = measured_margins.get("broadband", float("nan"))
        cw = measured_margins.get("cw", float("nan"))

        # ---------------- (c) what the jammer does to the spectrum -------
        print("\n(c) what a jammer looks like before and after despreading")
        jsr_demo = 20
        fig, axes = plt.subplots(1, 2, figsize=(9.0, 3.4))
        for ax, kind in zip(axes, ["cw", "broadband"]):
            j = make_jammer(kind, len(tx), p.chip_rate, p.chip_rate,
                            np.random.default_rng(77))
            amp = np.sqrt(sig_power * 10 ** (jsr_demo / 10.0))
            comb = tx + amp * j
            nfft = 512
            nfr = len(comb) // nfft
            f = comb[:nfr * nfft].reshape(nfr, nfft) * np.hanning(nfft)
            P = np.fft.fftshift(np.abs(np.fft.fft(f, axis=1)) ** 2,
                                axes=1).mean(axis=0)
            fr = np.linspace(-p.chip_rate / 2, p.chip_rate / 2, nfft) / 1e3
            ax.plot(fr, 10 * np.log10(P), color=cols[kind], lw=0.9,
                    label=f"{kind} jammer at J/S = +{jsr_demo} dB")
            Ps = np.fft.fftshift(np.abs(np.fft.fft(
                tx[:nfr * nfft].reshape(nfr, nfft) * np.hanning(nfft),
                axis=1)) ** 2, axes=1).mean(axis=0)
            ax.plot(fr, 10 * np.log10(Ps), color=C_INK2, lw=0.9,
                    label="wanted signal alone")
            ax.set_xlabel("frequency (kHz)")
            ax.set_title(f"{kind}: link BER "
                         f"{curves[kind][jsrs.index(jsr_demo)]:.1e}"
                         if jsr_demo in jsrs else kind, fontsize=9.5)
            ax.legend(fontsize=7.5)
        axes[0].set_ylabel("power spectral density (dB)")
        fig.suptitle("Same jammer power, very different effect on a DSSS link",
                     fontsize=10.5, fontweight="bold")
        ctx.save_fig(fig, "jammer_spectra.png", res,
                     "Jammer spectra at equal power")

        # ---------------- (d) live ---------------------------------------
        live_rows = []
        if ctx.live:
            print("\n(live) sweeping the third radio's jammer level")
            print("    (start jammer.py on the third B206mini first; this "
                  "reads the link's reported BER at each step)")
            steps = ctx.args.get("jsr_steps", [0, 10, 20, 25, 30])
            live_curve = []
            ctx.live.control("BERT=1")
            for jsr in steps:
                print(f"    set the jammer to J/S = {jsr:+} dB "
                      f"(jammer.py --jsr {jsr}) ...")
                lines = ctx.live.collect_status(12.0)
                rep = [parse_kv(l) for l in lines if l.startswith("BERT")]
                e = sum(int(kv.get("errors", 0)) for _k, kv in rep)
                n = sum(int(kv.get("bits", 0)) for _k, kv in rep)
                ber = e / n if n else float("nan")
                live_curve.append((jsr, ber, e, n))
                print(f"      measured BER {ber:.2e} ({e}/{n} bits)")
            ctx.live.control("BERT=0")
            if live_curve:
                ctx.save_csv("live_jamming.csv",
                             ["jsr_db", "ber", "errors", "bits"],
                             live_curve, res, "live jamming sweep")
                ok = [j for j, b, _e, _n in live_curve
                      if np.isfinite(b) and b < 1e-2]
                if ok:
                    live_rows.append(("live jamming margin",
                                      f"link survived to J/S = {max(ok):+} dB"))

        res.passed = bool(np.isfinite(bb) and bb >= margin_theory - 6)
        res.headline = (
            f"The link absorbs a broadband jammer up to J/S = {bb:+.0f} dB "
            f"against a predicted margin of {margin_theory:.0f} dB, and a CW "
            f"jammer up to {cw:+.0f} dB -- the spreading gain is doing exactly "
            f"what it is there for.")
        res.row("processing gain", f"{metrics.ideal_processing_gain_db(L):.1f} dB")
        res.row("predicted jamming margin", f"{margin_theory:.1f} dB")
        for kind in kinds:
            res.row(f"measured margin, {kind} jammer",
                    f"{measured_margins[kind]:+.0f} dB"
                    if np.isfinite(measured_margins[kind]) else "link never worked")
        res.row("broadband jammer power at the limit",
                f"{10 ** (bb / 10):.0f}x the signal" if np.isfinite(bb) else "n/a")
        for l, v in live_rows:
            res.row(l, v)

        res.note(
            "**Why the four jammer types give different answers, and why that "
            "is the interesting part.** The despreader multiplies everything "
            "it receives by the local code. The wanted signal, being spread by "
            f"that same code, collapses back into one symbol and gains "
            f"{metrics.ideal_processing_gain_db(L):.0f} dB. A CW tone is not "
            "spread by anything, so the same multiplication smears it across "
            "the full code bandwidth and only a tiny fraction lands in the "
            "symbol bandwidth -- hence the large measured margin. Broadband "
            "noise is already spread, so spreading it again changes nothing "
            "and it gets only the processing gain. Any real jammer sits "
            "somewhere between those two, which is why a result quoted for CW "
            "alone would be flattering and a result quoted for broadband alone "
            "would be pessimistic.")
        res.note(
            "**Partial-band is worth noticing.** Concentrating the same jammer "
            "power into a tenth of the band is *more* effective per watt than "
            "spreading it across all of it, because the fraction landing in "
            "the despread bandwidth goes up while the total stays the same. "
            "That is a well-known result and the sweep reproduces it -- a "
            "partial-band jammer is the one to worry about, not the loud "
            "broadband one.")
        res.note(
            "**Running it with the third radio.** `jammer.py` drives a third "
            "B206mini with any of these four waveforms and takes `--jsr` in "
            "the same units as this plot, so the measured curve can be laid "
            "directly over the simulated one. Set the jammer's centre "
            "frequency to the link's, start at a low J/S, and raise it while "
            "watching the Debug window's BER and lock indicator. Keep the "
            "jammer's output low and use attenuators -- this is deliberately "
            "transmitting interference, so keep it on the bench and inside "
            "whatever your local rules allow.")

        res.data = dict(margin_theory_db=margin_theory, jsrs=jsrs,
                        curves=curves, measured_margins=measured_margins)
        return res
