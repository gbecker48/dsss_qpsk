"""Requirement 3 -- chip rate versus bit rate for a target SNR improvement."""

from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt

from dsss_link import dsss_core as core
from dsss_link import link_profiles, metrics
from .framework import (Demo, Result, Context, C_MEASURED, C_THEORY, C_ALT,
                        C_BAD, C_INK2)


class D3(Demo):
    NUMBER = 3
    SLUG = "chip_vs_bit_rate"
    TITLE = "Chip rate versus bit rate for a target SNR improvement"
    REQUIREMENT = ("Calculate the required chip rate versus bit rate to "
                   "achieve an SNR improvement.")
    SHOWS = """
The design equation, solved in both directions, and then checked against a
measurement rather than left as algebra.

    Gp = 10*log10(Rc / Rb)          the SNR improvement spreading buys
    Rc = Rb * 10^(Gp/10)            the chip rate a target improvement needs

Forwards: what the link's chosen rates give. Backwards: what chip rate would
be required to close a link from a given input SNR to a given bit error rate.
Then a sweep that actually measures the recovered SNR at a range of chip-rate
to bit-rate ratios, to confirm the predicted gain is the gain you get.

Finally the trade itself, because it is the part that bites: this is not a
free improvement. Every dB of processing gain at a fixed chip rate is a dB
taken out of the data rate, and every dB bought by raising the chip rate is
paid for in occupied bandwidth. The link profiles are four points on that
curve, and the table shows what each one costs.
"""

    def run(self, ctx: Context) -> Result:
        res = Result(True, "")

        # ---------------- (a) the calculation, forwards ------------------
        p = link_profiles.get("stealth")
        Rc, Rb, L = p.chip_rate, p.raw_bit_rate, p.code_len
        gp_from_rates = 10 * np.log10(Rc / Rb)
        gp_from_code = metrics.ideal_processing_gain_db(L)
        gap = gp_from_code - gp_from_rates
        print("(a) the link as configured")
        print(f"    chip rate    Rc = {Rc:,.0f} chips/s")
        print(f"    symbol rate  Rs = {p.symbol_rate:,.0f} symbols/s")
        print(f"    bit rate     Rb = {Rb:,.0f} bits/s   "
              f"(QPSK carries 2 bits per symbol)")
        print()
        print(f"    Rc/Rs = {Rc / p.symbol_rate:7.1f} -> "
              f"{gp_from_code:5.2f} dB   SNR improvement at the correlator")
        print(f"    Rc/Rb = {Rc / Rb:7.1f} -> "
              f"{gp_from_rates:5.2f} dB   Eb/N0 gain over channel SNR")
        print(f"    the two differ by {gap:.2f} dB = 10*log10(2), "
              f"the two bits per QPSK symbol")
        print("    both are called 'processing gain' in the literature; they "
              "answer different questions")

        # ---------------- (b) the calculation, backwards -----------------
        print("\n(b) required chip rate to close a link, by input SNR")
        target_ber = 1e-5
        req_ebn0 = 9.6      # coherent QPSK at BER 1e-5
        back_rows = []
        for chip_snr in (-30, -25, -20, -15, -10, -5):
            need_gain = metrics.required_gain_db(chip_snr, req_ebn0)
            need_rc = metrics.required_chip_rate(Rb, need_gain)
            need_sf = 10 ** (need_gain / 10)
            back_rows.append([chip_snr, need_gain, need_sf, need_rc])
            print(f"    channel SNR {chip_snr:+4.0f} dB -> need {need_gain:5.1f} dB "
                  f"of gain -> SF {need_sf:8.0f} -> Rc {need_rc / 1e6:7.3f} Mcps "
                  f"at {Rb:.0f} bps")
        ctx.save_csv("required_chip_rate.csv",
                     ["channel_snr_db", "required_gain_db",
                      "required_spreading_factor", "required_chip_rate_hz"],
                     back_rows, res,
                     "chip rate required to reach BER 1e-5 from a given input SNR")

        actual_headroom = gp_from_code - metrics.required_gain_db(
            metrics.symbol_snr_to_chip_snr_db(
                metrics.ebn0_to_esn0_db(req_ebn0), L), req_ebn0)

        fig, ax = plt.subplots(figsize=(6.6, 3.6))
        snrs = np.linspace(-35, 0, 80)
        need = [metrics.required_chip_rate(Rb, metrics.required_gain_db(s, req_ebn0))
                for s in snrs]
        ax.semilogy(snrs, np.array(need) / 1e6, color=C_THEORY,
                    label=f"required, at {Rb:.0f} bps and BER {target_ber:g}")
        ax.axhline(Rc / 1e6, color=C_MEASURED, ls="--",
                   label=f"this link's chip rate ({Rc / 1e6:.3f} Mcps)")
        ax.set_xlabel("channel SNR before despreading (dB)")
        ax.set_ylabel("required chip rate (Mcps)")
        ax.set_title("Chip rate needed to close the link, versus how buried "
                     "the signal is")
        ax.annotate(f"stealth profile\n{Rc / 1e6:.3f} Mcps",
                    xy=(-33, Rc / 1e6), xytext=(4, 6),
                    textcoords="offset points", color=C_MEASURED, fontsize=8)
        ax.legend(loc="upper right")
        ctx.save_fig(fig, "required_chip_rate.png", res,
                     "Required chip rate versus input SNR")

        # ---------------- (c) measured: does the gain appear? ------------
        print("\n(c) measuring the SNR improvement at several Rc/Rb ratios")
        rng = ctx.rng(4)
        bits = rng.integers(0, 2, 3000).astype(np.uint8)
        chip_snr_db = -12.0
        meas_rows = []
        for cl in ([63, 127, 511, 1023] if not ctx.quick else [127, 1023]):
            code = core.gold_code_family(cl, 2)
            esn0 = chip_snr_db + 10 * np.log10(cl)
            ch = core.Channel(esn0_db=esn0, code_len=cl, samp_rate=1.023e6,
                              delay_samples=211.0, seed=17)
            tx = core.transmit(bits, code, sps=1)
            d = core.Despreader(cl, chip_rate=1.023e6, acq_epochs=8, code=code)
            syms = d.process(ch.apply(tx, sps=1))
            measured_symbol_snr = d.symbol_snr_db() if len(syms) > 50 else np.nan
            measured_gain = measured_symbol_snr - chip_snr_db
            ideal_gain = 10 * np.log10(cl)
            ratio = cl  # Rc/Rb for QPSK with one code period per symbol is cl
            meas_rows.append([cl, ratio, ideal_gain, measured_gain,
                              ideal_gain - measured_gain])
            print(f"    Rc/Rb = {ratio:5}: predicted gain {ideal_gain:5.1f} dB, "
                  f"measured {measured_gain:5.1f} dB, "
                  f"loss {ideal_gain - measured_gain:4.1f} dB")

        fig, ax = plt.subplots(figsize=(6.4, 3.6))
        rr = [r[1] for r in meas_rows]
        ax.semilogx(rr, [r[2] for r in meas_rows], marker="s", color=C_THEORY,
                    label="predicted, 10*log10(Rc/Rb)")
        ax.semilogx(rr, [r[3] for r in meas_rows], marker="o", color=C_MEASURED,
                    label="measured (symbol SNR - channel SNR)")
        for r in meas_rows:
            ax.annotate(f"{r[3]:.1f}", xy=(r[1], r[3]), xytext=(0, -13),
                        textcoords="offset points", ha="center", fontsize=8,
                        color=C_MEASURED)
        ax.set_xlabel("chip rate / bit rate")
        ax.set_ylabel("SNR improvement (dB)")
        ax.set_title("The predicted SNR improvement is the one you measure")
        ax.legend(loc="lower right")
        ctx.save_fig(fig, "measured_snr_improvement.png", res,
                     "Predicted versus measured SNR improvement")
        ctx.save_csv("measured_snr_improvement.csv",
                     ["code_len", "rc_over_rb", "predicted_gain_db",
                      "measured_gain_db", "implementation_loss_db"],
                     meas_rows, res, "measured processing gain by rate ratio")

        worst_loss = max(r[4] for r in meas_rows if np.isfinite(r[4]))

        # ---------------- (d) the trade --------------------------------
        print("\n(d) the trade, as the link's four profiles")
        print(link_profiles.comparison_table())
        prof_rows = []
        for name, pr in link_profiles.PROFILES.items():
            prof_rows.append([name, pr.code_len, pr.chip_rate, pr.raw_bit_rate,
                              pr.payload_rate_bytes_per_s(),
                              pr.processing_gain_db, 2 * pr.chip_rate,
                              pr.seconds_for(1_000_000)])
        ctx.save_csv("link_profiles.csv",
                     ["profile", "code_len", "chip_rate_hz", "raw_bit_rate_bps",
                      "payload_bytes_per_s", "processing_gain_db",
                      "occupied_bw_hz", "seconds_per_MB"],
                     prof_rows, res, "the four link profiles")

        fig, ax = plt.subplots(figsize=(6.8, 3.8))
        for i, (name, pr) in enumerate(link_profiles.PROFILES.items()):
            col = [C_MEASURED, C_ALT, C_THEORY, C_BAD][i % 4]
            ax.scatter(pr.payload_rate_bytes_per_s(), pr.processing_gain_db,
                       s=90, color=col, zorder=3)
            ax.annotate(f"{name}\n{pr.code_len} chips @ "
                        f"{pr.chip_rate / 1e6:.2f} Mcps",
                        xy=(pr.payload_rate_bytes_per_s(), pr.processing_gain_db),
                        xytext=(8, -4), textcoords="offset points",
                        fontsize=8, color=col)
        ax.set_xscale("log")
        ax.set_xlabel("useful payload rate (bytes/s)")
        ax.set_ylabel("processing gain (dB)")
        ax.set_xlim(70, 20000)
        ax.set_ylim(18, 34)
        ax.set_title("What a dB of processing gain costs in throughput")
        ctx.save_fig(fig, "profile_tradeoff.png", res,
                     "The four link profiles on the gain/throughput trade")

        res.passed = bool(abs(gap - 10 * np.log10(2)) < 0.01
                          and worst_loss < 3.0)
        res.headline = (
            f"Rc/Rb = {L} gives {gp_from_code:.1f} dB of predicted SNR "
            f"improvement, and the measured improvement matches to within "
            f"{worst_loss:.1f} dB across a 16x range of rate ratios.")
        res.row("chip rate (stealth profile)", f"{Rc:,.0f} chips/s")
        res.row("bit rate", f"{Rb:,.0f} bits/s")
        res.row("symbol rate", f"{p.symbol_rate:,.0f} symbols/s")
        res.row("Rc / Rs (chips per symbol)", f"{Rc / p.symbol_rate:.0f}")
        res.row("SNR improvement, 10*log10(Rc/Rs)", f"{gp_from_code:.2f} dB")
        res.row("Rc / Rb (chips per information bit)", f"{Rc / Rb:.1f}")
        res.row("Eb/N0 gain, 10*log10(Rc/Rb)", f"{gp_from_rates:.2f} dB")
        res.row("worst measured implementation loss", f"{worst_loss:.1f} dB")
        res.row("chip rate for 30 dB gain at 1 kbps",
                f"{metrics.required_chip_rate(1000, 30.1) / 1e6:.3f} Mcps")
        res.row("to close a -20 dB link at BER 1e-5",
                f"{metrics.required_gain_db(-20.0):.1f} dB of gain, "
                f"SF >= {10 ** (metrics.required_gain_db(-20.0) / 10):.0f}")

        res.note(
            "**Two numbers, both correctly called processing gain, three dB "
            "apart -- and it matters which one is quoted.** Against the "
            "SYMBOL rate, Rc/Rs = "
            f"{Rc / p.symbol_rate:.0f} and the gain is {gp_from_code:.1f} dB: "
            "that is what the correlator does to SNR, and it is the number to "
            "compare a measured before/after SNR against. Against the "
            f"information BIT rate, Rc/Rb = {Rc / Rb:.1f} and the gain is "
            f"{gp_from_rates:.1f} dB: that is how far Eb/N0 sits above the "
            "channel SNR, and it is the number that belongs in a link budget "
            "or a jamming-margin calculation. The difference is exactly "
            "10*log10(2), the two bits a QPSK symbol carries. A BPSK link "
            "would have them equal, which is why the distinction is easy to "
            "lose when moving from BPSK to QPSK -- as this project did between "
            "v1 and v2.")
        res.note(
            "**Solving it backwards is the useful direction.** Given how far "
            "below the noise floor the signal must sit, and the Eb/N0 the "
            "demodulator needs, the required chip rate follows directly. At "
            f"this link's {Rb:.0f} bps and a target of BER 1e-5, a signal "
            f"20 dB under the noise needs {metrics.required_gain_db(-20.0):.0f} dB "
            "of gain -- more than the 30.1 dB the 1023-chip code provides, "
            "which is a real and quantified statement about where this link "
            "stops working rather than a vague one.")
        res.note(
            "**The cost is real.** Notice that the chip rate for 30 dB of gain "
            "at 1 kbps comes out at 1.023 Mcps -- exactly the GPS C/A chip "
            "rate. That is the same trade GPS made, for the same reason, and "
            "it is why a 50 bps navigation message occupies 2 MHz of spectrum. "
            "The profile chart shows this link's four points on that curve: "
            "going from `stealth` to `bulk` buys 26x the throughput and costs "
            "9 dB of hiding.")

        res.data = dict(chip_rate=Rc, bit_rate=Rb, gp=gp_from_code,
                        required=back_rows, measured=meas_rows,
                        profiles=prof_rows)
        return res
