"""Requirement 7 -- quantify processing gain and bit error rate."""

from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt

from dsss_link import dsss_core as core
from dsss_link import link_profiles, metrics, protocol
from .framework import (Demo, Result, Context, C_MEASURED, C_THEORY, C_ALT,
                        C_BAD, C_INK2, parse_kv)


class D7(Demo):
    NUMBER = 7
    SLUG = "gain_and_ber"
    TITLE = "Quantifying DSSS processing gain and bit error rate"
    REQUIREMENT = "Quantify the DSSS processing gain and bit error rate."
    SHOWS = """
PROCESSING GAIN, measured three independent ways and compared:

  theoretical   10*log10(code_len) -- a property of the code alone
  by SNR        the SNR after despreading minus the SNR before, both measured
  by BER        how much extra noise the link tolerates versus an unspread one
                carrying the same data

The three should agree. Where they do not, the difference is implementation
loss, and that is a real number about this receiver rather than about DSSS.

A NOTE ON A METRIC THAT WAS WRONG: the Debug window used to report the
correlation peak over its neighbours as "processing gain, actual" next to
10*log10(1023) = 30.1 dB as "ideal". Those are different quantities.
Peak-over-neighbours is the code's peak-to-sidelobe ratio, pinned for length
1023 by the sidelobe value of 65: it saturates at 23.9 dB, or at 12.0 dB in
the form the original used. Neither can reach 30.1 dB, so the apparent
shortfall was an artefact of the comparison. Processing gain needs a
before-despreading measurement, which is why this demo makes one.

BIT ERROR RATE, measured against theory across Eb/N0, with confidence
intervals, and converted into the one number that summarises a receiver:
implementation loss in dB.
"""

    def run(self, ctx: Context) -> Result:
        res = Result(True, "")
        p = link_profiles.get("stealth")
        L, prn = p.code_len, core.NODE_PRN_TABLE[0]
        code = core.gold_code(L, prn)

        # ---------------- (a) processing gain, three ways ----------------
        print("(a) processing gain, measured three independent ways")
        ideal = metrics.ideal_processing_gain_db(L)
        print(f"    1. theoretical, 10*log10({L})            = {ideal:5.2f} dB")

        rng = ctx.rng(10)
        bits = rng.integers(0, 2, 6000).astype(np.uint8)
        tx = core.transmit(bits, code, sps=1)
        esn0 = 12.0
        ch = core.Channel(esn0_db=esn0, code_len=L, samp_rate=p.chip_rate,
                          delay_samples=401.0, seed=41)
        rx = ch.apply(tx, sps=1)
        noise_only = rx - tx[:len(rx)]

        # Before: SNR in the occupied bandwidth, from signal and noise power.
        sig_p = float(np.mean(np.abs(tx) ** 2))
        noi_p = float(np.mean(np.abs(noise_only) ** 2))
        snr_before = 10 * np.log10(sig_p / noi_p)
        d = core.Despreader(L, prn, chip_rate=p.chip_rate,
                            search_margin=p.search_margin,
                            acq_epochs=p.acq_epochs)
        syms = d.process(rx)
        snr_after = d.symbol_snr_db()
        gain_snr = metrics.processing_gain_db(snr_after, snr_before)
        print(f"    2. by SNR: {snr_after:5.2f} dB after - {snr_before:6.2f} dB "
              f"before = {gain_snr:5.2f} dB")

        psr = d.peak_to_sidelobe_db()
        print(f"       (peak-to-sidelobe ratio is {psr:.1f} dB -- a "
              f"lock-quality indicator, NOT the gain; it is capped at "
              f"{20 * np.log10(L / 65):.1f} dB by the code's own sidelobes "
              f"however good the link gets)")

        # ---------------- (b) BER versus Eb/N0 ---------------------------
        print("\n(b) bit error rate versus Eb/N0, against theory")
        esn0_list = ([15, 14, 13, 12, 11, 10, 9, 8]
                     if not ctx.quick else [13, 11, 9])
        reps = 4 if ctx.quick else 10
        nbits = 4000
        rows = []
        for e in esn0_list:
            te = tn = 0
            snrs = []
            for t in range(reps):
                b = rng.integers(0, 2, nbits).astype(np.uint8)
                t2 = core.transmit(b, code, sps=1)
                c2 = core.Channel(esn0_db=e, code_len=L, samp_rate=p.chip_rate,
                                  delay_samples=float(rng.integers(0, L)),
                                  seed=6000 + t)
                out, dd, _ = core.receive(c2.apply(t2, sps=1), L, prn, sps=1,
                                          costas_bw=0.02, chip_rate=p.chip_rate)
                _b, err, n = core.ber_between(b, out)
                te += err
                tn += n
                if len(out):
                    snrs.append(dd.symbol_snr_db())
            ber = te / max(tn, 1)
            ebn0 = metrics.esn0_to_ebn0_db(e)
            th = metrics.dqpsk_ber_theory(ebn0)
            lo, hi = metrics.ber_confidence_interval(te, tn)
            loss = metrics.implementation_loss_from_ber(ber, ebn0)
            rows.append([e, ebn0, metrics.symbol_snr_to_chip_snr_db(e, L),
                         np.mean(snrs) if snrs else np.nan,
                         ber, te, tn, lo, hi, th, loss])
            print(f"    Eb/N0 {ebn0:5.1f} dB (channel SNR "
                  f"{metrics.symbol_snr_to_chip_snr_db(e, L):6.1f} dB): "
                  f"BER {ber:.2e} [{lo:.1e},{hi:.1e}] {te}/{tn} errors, "
                  f"theory {th:.2e}, loss {loss:4.1f} dB")

        good = [r for r in rows if r[5] >= 5 and np.isfinite(r[10])]
        mean_loss = float(np.mean([r[10] for r in good])) if good else float("nan")

        fig, ax = plt.subplots(figsize=(7.0, 4.2))
        ebs = np.linspace(min(r[1] for r in rows) - 1,
                          max(r[1] for r in rows) + 1, 200)
        ax.semilogy(ebs, [metrics.dqpsk_ber_theory(e) for e in ebs],
                    color=C_THEORY, label="theory: differentially decoded QPSK")
        ax.semilogy(ebs, [metrics.qpsk_ber_theory(e) for e in ebs],
                    color=C_THEORY, ls=":", lw=1.2,
                    label="theory: ideal coherent QPSK")
        meas_x = [r[1] for r in rows]
        meas_y = [max(r[4], 1e-6) for r in rows]
        ax.semilogy(meas_x, meas_y, marker="o", color=C_MEASURED,
                    label="measured, this receiver")
        yerr_lo = [max(r[4] - r[7], 0) for r in rows]
        yerr_hi = [max(r[8] - r[4], 0) for r in rows]
        ax.errorbar(meas_x, meas_y, yerr=[yerr_lo, yerr_hi], fmt="none",
                    ecolor=C_MEASURED, elinewidth=1, capsize=3, alpha=0.7)
        ax.annotate(f"implementation loss\n{mean_loss:.1f} dB",
                    xy=(meas_x[len(meas_x) // 2], meas_y[len(meas_y) // 2]),
                    xytext=(28, 22), textcoords="offset points", fontsize=8,
                    color=C_MEASURED,
                    arrowprops=dict(arrowstyle="->", color=C_MEASURED, lw=0.9))
        ax.set_xlabel("Eb/N0 (dB)")
        ax.set_ylabel("bit error rate")
        ax.set_ylim(1e-6, 1)
        ax.set_title("Measured BER against theory, with 95% confidence intervals")
        ax.legend(loc="lower left")
        ctx.save_fig(fig, "ber_vs_ebn0.png", res,
                     "BER versus Eb/N0 with confidence intervals")
        ctx.save_csv("ber_vs_ebn0.csv",
                     ["esn0_db", "ebn0_db", "channel_snr_db",
                      "measured_symbol_snr_db", "ber", "errors", "bits",
                      "ci95_low", "ci95_high", "theory_ber",
                      "implementation_loss_db"], rows, res,
                     "BER measurement data")

        # ---------------- (c) gain by BER --------------------------------
        print("\n(c) processing gain expressed as tolerable channel noise")
        working = [r for r in rows if r[4] < 1e-2]
        if working:
            worst = max(working, key=lambda r: -r[2])
            worst_chip_snr = min(r[2] for r in working)
            gain_by_ber = metrics.ebn0_to_esn0_db(
                min(r[1] for r in working)) - worst_chip_snr
            print(f"    link still works at a channel SNR of "
                  f"{worst_chip_snr:.1f} dB")
            print(f"    an unspread QPSK link carrying the same data needs "
                  f"{metrics.ebn0_to_esn0_db(min(r[1] for r in working)):.1f} dB")
            print(f"    3. by BER: gain = {gain_by_ber:.2f} dB")
        else:
            gain_by_ber = float("nan")

        gains = [("theoretical, 10*log10(code_len)", ideal),
                 ("measured, SNR before vs after", gain_snr),
                 ("measured, tolerable noise vs unspread", gain_by_ber)]
        fig, ax = plt.subplots(figsize=(6.6, 3.2))
        names = [g[0] for g in gains]
        vals = [g[1] for g in gains]
        cols = [C_THEORY, C_MEASURED, C_ALT]
        ax.barh(range(len(gains)), vals, color=cols, height=0.55)
        for i, v in enumerate(vals):
            ax.annotate(f"{v:.1f} dB", xy=(v, i), xytext=(5, 0),
                        textcoords="offset points", va="center", fontsize=9,
                        color=C_INK2)
        ax.set_yticks(range(len(gains)))
        ax.set_yticklabels(names, fontsize=8.5)
        ax.invert_yaxis()
        ax.set_xlabel("processing gain (dB)")
        ax.set_xlim(0, max(v for v in vals if np.isfinite(v)) * 1.25)
        ax.set_title("Three independent measurements of the same quantity")
        ctx.save_fig(fig, "processing_gain_three_ways.png", res,
                     "Processing gain measured three ways")

        # ---------------- (d) live BERT ----------------------------------
        live_rows = []
        if ctx.live:
            print("\n(live) running the PRBS bit error rate test on the radio")
            ctx.live.control("BERT=1")
            lines = ctx.live.collect_status(30.0)
            ctx.live.control("BERT=0")
            reports = [parse_kv(l) for l in lines if l.startswith("BERT")]
            tot_e = sum(int(kv.get("errors", 0)) for _k, kv in reports)
            tot_b = sum(int(kv.get("bits", 0)) for _k, kv in reports)
            if tot_b:
                ber = tot_e / tot_b
                lo, hi = metrics.ber_confidence_interval(tot_e, tot_b)
                live_rows = [
                    ("live BER (PRBS-15)",
                     f"{ber:.2e}  [{lo:.1e}, {hi:.1e}] 95% CI"),
                    ("live bits measured", f"{tot_b:,}"),
                    ("live errors", f"{tot_e:,}"),
                ]
                print(f"    {tot_e:,} errors in {tot_b:,} bits -> "
                      f"BER {ber:.2e}  95% CI [{lo:.1e}, {hi:.1e}]")
                need = metrics.bits_needed_for_ber(max(ber, 1e-7))
                print(f"    (a credible measurement at this rate wants "
                      f"about {need:,} bits -- run longer with --duration)")
            else:
                print("    no BERT reports -- check the flowgraph is running "
                      "and the TX scheduler has BERT support wired up")

        res.passed = bool(abs(gain_snr - ideal) < 2.0)
        res.headline = (
            f"Processing gain is {ideal:.1f} dB in theory and {gain_snr:.1f} dB "
            f"measured -- {ideal - gain_snr:+.1f} dB of implementation loss -- "
            f"and the BER curve tracks differentially-decoded QPSK theory to "
            f"within {mean_loss:.1f} dB.")
        res.row("processing gain, theoretical", f"{ideal:.2f} dB")
        res.row("processing gain, measured by SNR", f"{gain_snr:.2f} dB")
        res.row("processing gain, measured by BER",
                f"{gain_by_ber:.2f} dB" if np.isfinite(gain_by_ber) else "n/a")
        res.row("implementation loss (gain)", f"{ideal - gain_snr:.2f} dB")
        res.row("implementation loss (BER curve)", f"{mean_loss:.2f} dB")
        res.row("peak-to-sidelobe ratio (NOT the gain)",
                f"{psr:.1f} dB, capped at {20 * np.log10(L / 65):.1f} dB "
                f"by the code's sidelobes")
        res.row("lowest channel SNR still working",
                f"{min(r[2] for r in rows if r[4] < 1e-2):.1f} dB"
                if any(r[4] < 1e-2 for r in rows) else "n/a")
        for l, v in live_rows:
            res.row(l, v)

        res.note(
            "**Three measurements, one quantity.** The theoretical gain is a "
            "property of the code and takes no measurement at all. The SNR "
            "measurement takes the signal and noise powers before the "
            "correlator and the symbol SNR after it. The BER measurement asks "
            "a different question entirely -- how much more channel noise this "
            "link tolerates than an unspread one carrying the same data -- and "
            "arrives at the same answer by a route that shares none of the "
            "same assumptions. Agreement between them is what makes the number "
            "trustworthy.")
        res.note(
            "**On implementation loss.** The BER curve sits about "
            f"{mean_loss:.1f} dB to the right of theory. Roughly half of that "
            "is the differential decoding, which doubles the bit error rate "
            "because an error corrupts the decisions on both sides of it -- "
            "the price of resolving the Costas loop's four-fold phase "
            "ambiguity, and already included in the plotted theory curve. The "
            "rest is carrier phase jitter from a deliberately wide loop and "
            "the residual code-tracking slips measured in requirement 1. "
            "Before the despreader fixes described there, this same curve sat "
            "5 to 6 dB further right.")
        res.note(
            "**What a BER number needs to be believed.** Every point above "
            "carries an error count and a 95% confidence interval, because a "
            "ratio alone says nothing about how well it is known: three errors "
            "in ten thousand bits and three thousand in ten million are the "
            "same BER and very different measurements. Reaching a credible "
            "1e-5 takes about ten million bits -- roughly three hours on the "
            "stealth profile, or six minutes on `bulk`, which is a good reason "
            "to run the live BERT on a faster profile.")

        res.data = dict(ideal_gain_db=ideal, gain_by_snr_db=gain_snr,
                        gain_by_ber_db=gain_by_ber, psr_db=psr,
                        mean_implementation_loss_db=mean_loss, ber_rows=rows)
        return res
