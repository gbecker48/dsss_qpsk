"""Requirement 2 -- high spreading factor."""

from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt

from dsss_link import dsss_core as core
from dsss_link import link_profiles, metrics
from .framework import (Demo, Result, Context, C_MEASURED, C_THEORY, C_ALT,
                        C_BAD, C_INK2)


class D2(Demo):
    NUMBER = 2
    SLUG = "spreading_factor"
    TITLE = "High spreading factor"
    REQUIREMENT = "For DSSS, use a high spreading factor."
    SHOWS = """
That the spreading factor is 1023 and that the code carrying it is a genuine
Gold code, verified against the defining mathematical properties rather than
asserted:

  * exact period 1023, no early repeat
  * balanced 512/511 chip distribution
  * the textbook three-valued autocorrelation {-65, -1, 63} that Gold-code
    theory predicts for length 1023 -- a single sharp peak and nothing else
  * bounded cross-correlation between all 16 node codes, which is what lets
    several nodes share one frequency (and therefore what makes full duplex
    possible at all)

It also shows what the spreading factor is worth, by comparing 1023 against
the shorter codes this project used in earlier versions and against the
shorter-code link profiles, in processing gain and in how far below the noise
floor the signal ends up.
"""

    def run(self, ctx: Context) -> Result:
        res = Result(True, "")
        L = 1023

        # ---------------- (a) verify the code is a Gold code -------------
        print("(a) verifying the 1023-chip code against Gold-code theory")
        props = {}
        for node in range(16):
            c = core.gold_code(L, core.NODE_PRN_TABLE[node])
            props[node] = core.code_properties(c)
        p0 = props[0]
        expected_offpeak = [-65, -1, 63]
        all_three_valued = all(
            props[n]["autocorr_offpeak"] == expected_offpeak for n in props)
        all_balanced = all(props[n]["balance"] == 1 for n in props)
        print(f"    period                 {p0['length']} chips")
        print(f"    chip balance           {p0['n_plus']}/{p0['n_minus']} "
              f"(difference {p0['balance']})")
        print(f"    off-peak autocorrelation values  {p0['autocorr_offpeak']}"
              f"  (theory predicts {expected_offpeak})")
        print(f"    all 16 node codes three-valued and balanced: "
              f"{all_three_valued and all_balanced}")
        print(f"    processing gain        10*log10({L}) = "
              f"{p0['processing_gain_db']:.2f} dB")

        c0 = core.gold_code(L, core.NODE_PRN_TABLE[0])
        spec = np.fft.fft(c0)
        acorr = np.rint(np.real(np.fft.ifft(spec * np.conj(spec)))).astype(int)

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(9.5, 3.3),
                                       gridspec_kw={"width_ratios": [2, 1]})
        ax1.plot(np.arange(-60, 61), np.roll(acorr, 60)[:121],
                 color=C_MEASURED, lw=1.4)
        ax1.set_xlabel("lag (chips)")
        ax1.set_ylabel("autocorrelation")
        ax1.set_title(f"Autocorrelation: one chip off and the gain is gone")
        ax1.annotate(f"peak = {acorr[0]}", xy=(0, acorr[0]), xytext=(12, -14),
                     textcoords="offset points", fontsize=8, color=C_MEASURED)
        ax1.annotate("sidelobes bounded at 65",
                     xy=(25, 63), xytext=(20, 300), fontsize=8, color=C_INK2,
                     arrowprops=dict(arrowstyle="->", color=C_INK2, lw=0.8))

        vals, counts = np.unique(acorr[1:], return_counts=True)
        ax2.bar([str(v) for v in vals], counts, color=C_MEASURED, width=0.6)
        ax2.set_ylabel("number of lags")
        ax2.set_xlabel("off-peak autocorrelation value")
        ax2.set_title("Exactly three values")
        for v, n in zip(vals, counts):
            ax2.annotate(str(n), xy=(str(v), n), xytext=(0, 3),
                         textcoords="offset points", ha="center", fontsize=8,
                         color=C_INK2)
        ctx.save_fig(fig, "gold_code_autocorrelation.png", res,
                     "The defining property of a Gold code, measured")

        # ---------------- (b) cross-correlation between node codes -------
        print("\n(b) cross-correlation between the 16 node codes")
        xc = np.zeros((16, 16), dtype=int)
        for i in range(16):
            ci = core.gold_code(L, core.NODE_PRN_TABLE[i])
            for j in range(16):
                if i == j:
                    xc[i, j] = L
                else:
                    xc[i, j] = core.cross_correlation_peak(
                        ci, core.gold_code(L, core.NODE_PRN_TABLE[j]))
        off = xc[~np.eye(16, dtype=bool)]
        worst = int(off.max())
        bound = core._preferred_t(10)
        sep_db = 20 * np.log10(L / worst)
        print(f"    worst cross-correlation peak {worst} of {L} "
              f"(theoretical bound {bound})")
        print(f"    one node's signal is suppressed {sep_db:.1f} dB in "
              f"another node's correlator")

        fig, ax = plt.subplots(figsize=(5.2, 4.4))
        m = ax.imshow(20 * np.log10(np.maximum(xc, 1) / L), cmap="Blues_r",
                      vmin=-30, vmax=0)
        ax.set_xlabel("despreading against node")
        ax.set_ylabel("transmitting node")
        ax.set_title("Code separation between nodes (dB)")
        ax.set_xticks(range(0, 16, 3))
        ax.set_yticks(range(0, 16, 3))
        cb = fig.colorbar(m, ax=ax, fraction=0.046)
        cb.set_label("correlation relative to own code (dB)", fontsize=8)
        ctx.save_fig(fig, "node_code_separation.png", res,
                     "Cross-correlation between all 16 node codes")

        # ---------------- (c) what the spreading factor buys -------------
        print("\n(c) what spreading factor buys, measured")
        lengths = [31, 63, 127, 511, 1023]
        rows = []
        rng = ctx.rng(7)
        bits = rng.integers(0, 2, 3000).astype(np.uint8)
        for cl in lengths:
            code = core.gold_code_family(cl, 2)
            pr = core.code_properties(code)
            # Measure the SNR the despreader recovers, at a fixed *chip* SNR
            # -- i.e. holding constant what an observer of the channel sees,
            # which is the comparison that matters for hiding.
            chip_snr_db = -15.0
            esn0 = chip_snr_db + 10 * np.log10(cl)
            ch = core.Channel(esn0_db=esn0, code_len=cl,
                              samp_rate=1.023e6, delay_samples=101.0, seed=3)
            tx = core.transmit(bits, code, sps=1)
            d = core.Despreader(cl, chip_rate=1.023e6, acq_epochs=8,
                                code=code)
            syms = d.process(ch.apply(tx, sps=1))
            meas = d.symbol_snr_db() if len(syms) > 50 else float("nan")
            rows.append([cl, pr["processing_gain_db"], chip_snr_db, meas,
                         pr["max_abs_sidelobe"]])
            print(f"    SF {cl:5}: ideal gain {pr['processing_gain_db']:5.1f} dB, "
                  f"chip SNR {chip_snr_db:+.0f} dB -> measured symbol SNR "
                  f"{meas:6.1f} dB")

        fig, ax = plt.subplots(figsize=(6.6, 3.6))
        ideal = [r[1] for r in rows]
        meas = [r[3] for r in rows]
        x = np.arange(len(lengths))
        ax.bar(x - 0.19, ideal, width=0.36, color=C_THEORY,
               label="ideal 10*log10(SF)")
        ax.bar(x + 0.19, [m - (-15.0) for m in meas], width=0.36,
               color=C_MEASURED, label="measured gain (symbol SNR - chip SNR)")
        for i, (a, b) in enumerate(zip(ideal, meas)):
            ax.annotate(f"{a:.0f}", xy=(i - 0.19, a), xytext=(0, 3),
                        textcoords="offset points", ha="center", fontsize=8,
                        color=C_INK2)
            ax.annotate(f"{b + 15:.0f}", xy=(i + 0.19, b + 15), xytext=(0, 3),
                        textcoords="offset points", ha="center", fontsize=8,
                        color=C_INK2)
        ax.set_xticks(x)
        ax.set_xticklabels([str(l) for l in lengths])
        ax.set_xlabel("spreading factor (chips per symbol)")
        ax.set_ylabel("processing gain (dB)")
        ax.set_title("Processing gain versus spreading factor, at a fixed "
                     "channel SNR of -15 dB")
        ax.legend()
        ctx.save_fig(fig, "spreading_factor_gain.png", res,
                     "Ideal and measured processing gain across spreading factors")
        ctx.save_csv("spreading_factor_gain.csv",
                     ["spreading_factor", "ideal_gain_db", "chip_snr_db",
                      "measured_symbol_snr_db", "max_autocorr_sidelobe"],
                     rows, res, "processing gain versus spreading factor")

        # ---------------- (d) project history ----------------------------
        history = [("v1 (BPSK)", 7), ("v2 (QPSK)", 11), ("v3-v5 (current)", 1023)]
        print("\n(d) spreading factor across this project's versions")
        for name, sf in history:
            print(f"    {name:18} SF {sf:5}  ->  "
                  f"{10 * np.log10(sf):5.1f} dB of processing gain")

        p = link_profiles.get("stealth")
        below = metrics.symbol_snr_to_chip_snr_db(11.0, L)
        res.passed = bool(all_three_valued and all_balanced and worst <= bound)
        res.headline = (
            f"Spreading factor is {L} chips per symbol -- "
            f"{p0['processing_gain_db']:.1f} dB of processing gain -- and the "
            f"code is a verified Gold code with the exact three-valued "
            f"autocorrelation theory predicts.")
        res.row("spreading factor", f"{L} chips/symbol")
        res.row("processing gain", f"{p0['processing_gain_db']:.2f} dB")
        res.row("period", f"{p0['length']} (exact, no early repeat)")
        res.row("chip balance", f"{p0['n_plus']}/{p0['n_minus']}")
        res.row("off-peak autocorrelation",
                f"{p0['autocorr_offpeak']} (theory: {expected_offpeak})")
        res.row("all 16 node codes verified",
                "yes" if all_three_valued and all_balanced else "NO")
        res.row("worst inter-node cross-correlation",
                f"{worst}/{L} = {-sep_db:.1f} dB (bound {bound})")
        res.row("signal sits below noise floor by",
                f"{-below:.0f} dB at a working symbol SNR of 11 dB")
        res.row("versus this project's v1", f"{L}/7 = {L / 7:.0f}x the code length")

        res.note(
            "**Verified, not asserted.** A long sequence is not automatically a "
            "Gold code. The checks above are the defining properties: exact "
            "period, balanced chip distribution, and a three-valued off-peak "
            "autocorrelation taking only {-65, -1, 63}. All three hold for all "
            "sixteen node codes. A generator with a wrong tap pair fails the "
            "third check immediately -- it produces a spread of arbitrary "
            "values instead of three.")
        res.note(
            "**Why the sidelobes matter as much as the peak.** The "
            f"autocorrelation is {L} at perfect alignment and at most 65 one "
            "chip away. There is no gradual roll-off and no 'mostly aligned' "
            "middle ground, which is exactly why acquisition has to find the "
            "right chip rather than approximately the right region, and why "
            "requirement 1's tracking is not optional.")
        res.note(
            "**Why this bounds how many nodes can share the band.** Two nodes "
            f"transmitting simultaneously on different codes interfere at "
            f"{-sep_db:.0f} dB relative to the wanted signal. That margin is "
            "what makes CDMA work here, and it is the physical basis for the "
            "full-duplex operation demonstrated in requirement 5 -- each radio "
            "hears its peer through its own transmission because its own "
            "signal despreads to noise.")

        res.data = dict(properties=p0, worst_xcorr=worst, bound=bound,
                        gain_rows=rows, history=history)
        return res
