"""
DSSS Spreader (GPS-style, symbol-domain)
------------------------------------------
Spreads the actual QPSK WAVEFORM, not just the underlying bits: every
incoming complex QPSK symbol is held for one full period of a long
pseudo-noise "chip" code and multiplied, chip by chip, by that code
(+1/-1) - exactly how GPS spreads its 50 bps navigation data with a
1023-chip Gold code repeated once per data bit (well, once per 20
repetitions in real GPS; here once per symbol, since our "data rate" IS
one Gold-code period per symbol - see the flowgraph README for the exact
timing this maps to). This is a real interpolating stream block (not a
one-shot message-domain array build like earlier revisions of this
project used) so there is no upper limit on how long a transmission can
run - unlike a burst design, this scales to continuous, arbitrarily long
transmissions.

The code is generated exactly the way GPS C/A codes are: two 10-bit LFSRs
(G1: x^10+x^3+1, G2: x^10+x^9+x^8+x^6+x^3+x^2+1, both all-ones seeded)
combined as G1 XOR (a fixed two-tap XOR of G2, "PRN 1"'s published tap
pair) - this yields a genuine 1023-chip Gold code with the textbook
Gold-code autocorrelation spectrum {-1, -65, 63} and a sharp, singular
correlation peak at exact alignment. See dsss_despreader.py for how that
peak is what lets the receiver claw a buried signal back out of the
noise floor - the processing gain here is 10*log10(1023) ~= 30.1 dB.

Input : stream of complex64 QPSK symbols, 1 per item
Output: stream of complex64 chips, `code_len` per input symbol
"""

import numpy as np
import pmt
from gnuradio import gr


def g1_sequence(n_chips):
    reg = [1] * 10
    out = np.empty(n_chips, dtype=np.uint8)
    for i in range(n_chips):
        out[i] = reg[9]
        fb = reg[2] ^ reg[9]
        reg = [fb] + reg[:-1]
    return out


def g2_sequence(taps, n_chips):
    reg = [1] * 10
    t0, t1 = taps[0] - 1, taps[1] - 1
    out = np.empty(n_chips, dtype=np.uint8)
    for i in range(n_chips):
        out[i] = reg[t0] ^ reg[t1]
        fb = reg[1] ^ reg[2] ^ reg[5] ^ reg[7] ^ reg[8] ^ reg[9]
        reg = [fb] + reg[:-1]
    return out


def gps_style_gold_code(code_len=1023, prn_taps=(2, 6)):
    """MUST match dsss_despreader.py's code generation exactly."""
    bits = g1_sequence(code_len) ^ g2_sequence(prn_taps, code_len)
    return 1.0 - 2.0 * bits.astype(np.float32)  # bipolar +-1


class blk(gr.interp_block):
    """DSSS Spreader (GPS-style Gold code)"""

    def __init__(self, code_len=1023):
        gr.interp_block.__init__(
            self, name='DSSS Spreader',
            in_sig=[np.complex64], out_sig=[np.complex64],
            interp=int(code_len))
        self.code_len = int(code_len)
        self.code = gps_style_gold_code(self.code_len)
        self.set_tag_propagation_policy(gr.TPP_DONT)

    def work(self, input_items, output_items):
        in0 = input_items[0]
        out = output_items[0]
        n = len(in0)
        # out[k*code_len : (k+1)*code_len] = in0[k] * code[:]
        out[:n * self.code_len] = (
            np.repeat(in0, self.code_len) * np.tile(self.code, n)
        )

        # manually propagate + rescale any tags (e.g. packet_len) since we
        # disabled automatic propagation above (TPP_DONT) to avoid GRC's
        # default policy mis-scaling tag VALUES, only offsets
        for t in self.get_tags_in_window(0, 0, n):
            rel = t.offset - self.nitems_read(0)
            new_offset = self.nitems_written(0) + rel * self.code_len
            key = pmt.symbol_to_string(t.key)
            val = t.value
            if key == 'packet_len' and pmt.is_integer(val):
                val = pmt.from_long(pmt.to_long(val) * self.code_len)
            self.add_item_tag(0, new_offset, t.key, val)

        return n * self.code_len
