# Requirement 2 -- High spreading factor

> **For DSSS, use a high spreading factor.**

Run 2026-09-22 09:55:53 · offline simulation · 0.8 s

## Result

**PASS** -- Spreading factor is 1023 chips per symbol -- 30.1 dB of processing gain -- and the code is a verified Gold code with the exact three-valued autocorrelation theory predicts.

| Measurement | Value |
|---|---|
| spreading factor | 1023 chips/symbol |
| processing gain | 30.10 dB |
| period | 1023 (exact, no early repeat) |
| chip balance | 511/512 |
| off-peak autocorrelation | [-65, -1, 63] (theory: [-65, -1, 63]) |
| all 16 node codes verified | yes |
| worst inter-node cross-correlation | 65/1023 = -23.9 dB (bound 65) |
| signal sits below noise floor by | 19 dB at a working symbol SNR of 11 dB |
| versus this project's v1 | 1023/7 = 146x the code length |

## Notes

**Verified, not asserted.** A long sequence is not automatically a Gold code. The checks above are the defining properties: exact period, balanced chip distribution, and a three-valued off-peak autocorrelation taking only {-65, -1, 63}. All three hold for all sixteen node codes. A generator with a wrong tap pair fails the third check immediately -- it produces a spread of arbitrary values instead of three.

**Why the sidelobes matter as much as the peak.** The autocorrelation is 1023 at perfect alignment and at most 65 one chip away. There is no gradual roll-off and no 'mostly aligned' middle ground, which is exactly why acquisition has to find the right chip rather than approximately the right region, and why requirement 1's tracking is not optional.

**Why this bounds how many nodes can share the band.** Two nodes transmitting simultaneously on different codes interfere at -24 dB relative to the wanted signal. That margin is what makes CDMA work here, and it is the physical basis for the full-duplex operation demonstrated in requirement 5 -- each radio hears its peer through its own transmission because its own signal despreads to noise.

## Figures

### The defining property of a Gold code, measured

![The defining property of a Gold code, measured](gold_code_autocorrelation.png)

### Cross-correlation between all 16 node codes

![Cross-correlation between all 16 node codes](node_code_separation.png)

### Ideal and measured processing gain across spreading factors

![Ideal and measured processing gain across spreading factors](spreading_factor_gain.png)

## Data files

- `spreading_factor_gain.csv` -- processing gain versus spreading factor

## What this demonstrates

That the spreading factor is 1023 and that the code carrying it is a genuine
Gold code, verified against the defining mathematical properties rather than
asserted:

  * exact period 1023, no early repeat
  * balanced 512/511 chip distribution
  * the textbook three-valued autocorrelation {-65, -1, 63} that Gold-code
    theory predicts for length 1023 -- a single sharp peak and nothing else
  * bounded cross-correlation between all 16 node codes, which is what lets
    several nodes share one frequency (and therefore what makes full duplex
    possible at all)

It also shows what the spreading factor is worth, by comparing 1023 against
the shorter codes this project used in earlier versions and against the
shorter-code link profiles, in processing gain and in how far below the noise
floor the signal ends up.

---

`console.log` in this folder holds the full run output.