"""
Fragment Reassembler (node-addressed)
----------------------------------------
Mirror of TX Frame Source: parses each validated packet payload's inner
header [SRC 1B][DST 1B][MSG_ID 1B][FRAG_IDX 1B][FRAG_TOTAL 1B][CHUNK_LEN 1B]
[DATA] and accumulates fragments per message id until all of them have
arrived, at which point the complete original message is published.

FRAG_TOTAL == 0 marks an idle/keep-alive filler fragment (see TX Frame
Source) - these are reported as an "IDLE" status line and otherwise
ignored.

NETWORKING / addressing: two independent checks happen here, on top of the
physical-layer separation that already comes from each node transmitting
on its own DSSS code (see dsss_spreader.py / dsss_despreader.py):

  1. DST filter - a fragment not addressed to `my_node_id` (and not the
     0xFF broadcast id) did not fail CRC and is not corrupt, it's simply
     not for us (e.g. we're tuned to a peer's code for RX but they're
     addressing a third node) - it's dropped, quietly for idle heartbeats,
     with a one-line "FOREIGN" note for real data fragments so a
     misconfigured node table is easy to spot rather than silently eating
     someone else's traffic.

  2. SRC sanity check - since this receiver is despreading against
     `dest_node_id`'s code specifically, every fragment that reaches this
     block should have SRC == dest_node_id. If it doesn't, that's a strong
     signal of a Gold-code collision (two nodes accidentally sharing a
     code, or a very unlucky false acquisition on a code sidelobe) rather
     than a normal event, so it's called out explicitly.

There is no retransmission/ARQ in this link - if a fragment is lost (its
packet failed CRC and was dropped upstream by the Packet Deframer), the
message it belonged to will simply never complete. To keep that visible
rather than silent, each in-progress message is given a generous fragment
budget (see `stale_after`) after which, if it still isn't complete, it's
reported INCOMPLETE and dropped rather than held onto forever.

Status line grammar (this is a frozen contract with ground_station.py /
terminal.py - see the project README before changing it):
    "FRAG msg=<id> idx=<i> total=<n> seq=<seq> crc=OK len=<bytes> src=<s> dst=<d>"
    "IDLE seq=<seq> src=<s> dst=<d>"
    "DONE msg=<id> fragments=<n> bytes=<total_bytes> src=<s>"
    "INCOMPLETE msg=<id> missing=<comma,separated,fragment,indices>"
    "FOREIGN src=<s> dst=<d> msg=<id> (not addressed to node <my_node_id>)"
    "WARN unexpected src=<s> while listening on node <dest_node_id>'s code"
(CRC failures are reported directly by the Packet Deframer in plain text,
since a corrupted packet's own header fields can't be trusted.)

Input : PDU - [SEQ 1B][payload_bytes] (payload_bytes from Packet Deframer,
        CRC-validated, SEQ prepended so idle heartbeats can quote it)
Outputs: 'msg'    - PDU, a complete reassembled message (only when done)
         'status' - PDU, one of the status lines above (always, except
                    silently-dropped idle foreign traffic)
"""

import numpy as np
import pmt
from gnuradio import gr


def pdu_data(msg):
    vec = pmt.cdr(msg) if pmt.is_pair(msg) else msg
    return np.array(pmt.u8vector_elements(vec), dtype=np.uint8)


def make_pdu(values):
    arr = np.asarray(values, dtype=np.uint8)
    return pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(arr), arr.tolist()))


BROADCAST_NODE = 0xFF


class blk(gr.basic_block):
    """Fragment Reassembler (node-addressed)"""

    def __init__(self, chunk_bytes=250, stale_after=64, my_node_id=0,
                 dest_node_id=1):
        gr.basic_block.__init__(self, name='Fragment Reassembler', in_sig=[], out_sig=[])
        self.chunk_bytes = int(chunk_bytes)
        self.stale_after = int(stale_after)
        self.my_node_id = int(my_node_id)
        self.dest_node_id = int(dest_node_id)
        self.pending = {}       # msg_id -> {'total': n, 'chunks': {idx: bytes}, 'age': int, 'src': int}
        self.message_port_register_in(pmt.intern('in'))
        self.message_port_register_out(pmt.intern('msg'))
        self.message_port_register_out(pmt.intern('status'))
        self.set_msg_handler(pmt.intern('in'), self.handle_msg)

    def handle_msg(self, msg):
        raw = pdu_data(msg).tobytes()
        if len(raw) < 1 + 6:
            return
        seq = raw[0]
        payload = raw[1:]
        src, dst, mid, idx, total, clen = payload[0], payload[1], payload[2], \
            payload[3], payload[4], payload[5]
        data = payload[6:6 + self.chunk_bytes][:clen]

        addressed_to_me = (dst == self.my_node_id) or (dst == BROADCAST_NODE)

        if total == 0:
            if addressed_to_me:
                self._status("IDLE seq=%d src=%d dst=%d" % (seq, src, dst))
            self._age_pending()
            self._check_src(src)
            return

        if not addressed_to_me:
            self._status("FOREIGN src=%d dst=%d msg=%d (not addressed to node %d)" %
                          (src, dst, mid, self.my_node_id))
            return

        self._check_src(src)

        entry = self.pending.setdefault(mid, {'total': total, 'chunks': {}, 'age': 0, 'src': src})
        entry['total'] = total
        entry['chunks'][idx] = data
        entry['age'] = 0
        entry['src'] = src

        self._status("FRAG msg=%d idx=%d total=%d seq=%d crc=OK len=%d src=%d dst=%d" %
                      (mid, idx, total, seq, len(data), src, dst))

        if len(entry['chunks']) >= total:
            complete = b''.join(entry['chunks'][i] for i in range(total))
            del self.pending[mid]
            self.message_port_pub(pmt.intern('msg'), make_pdu(list(complete)))
            self._status("DONE msg=%d fragments=%d bytes=%d src=%d" %
                          (mid, total, len(complete), src))
        else:
            self._age_pending(exclude=mid)

    def _check_src(self, src):
        # Not fatal (a fresh acquisition can land on a foreign code's
        # sidelobe for a single symbol before the acquisition threshold
        # rejects it), but persistent mismatches are worth surfacing since
        # they usually mean two nodes picked the same PRN by mistake.
        if src != self.dest_node_id:
            self._status("WARN unexpected src=%d while listening on node %d's code" %
                          (src, self.dest_node_id))

    def _age_pending(self, exclude=None):
        stale = []
        for mid, entry in self.pending.items():
            if mid == exclude:
                continue
            entry['age'] += 1
            if entry['age'] >= self.stale_after:
                stale.append(mid)
        for mid in stale:
            entry = self.pending.pop(mid)
            missing = [i for i in range(entry['total']) if i not in entry['chunks']]
            self._status("INCOMPLETE msg=%d missing=%s" %
                          (mid, ','.join(str(i) for i in missing)))

    def _status(self, text):
        print("[RX] " + text)
        self.message_port_pub(pmt.intern('status'), make_pdu(list(text.encode('utf-8'))))
