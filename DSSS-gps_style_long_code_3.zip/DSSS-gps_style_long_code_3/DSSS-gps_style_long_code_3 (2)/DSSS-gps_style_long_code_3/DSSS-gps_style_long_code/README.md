# GPS-Style Long-Code DSSS + QPSK Comms Link

A continuous (non-burst) direct-sequence spread-spectrum radio link built
around the same idea GPS uses: a very long pseudo-noise code buys a lot of
processing gain, which lets you pull a signal out from *underneath* the noise
floor rather than just above it. QPSK modulation, forward error correction, a
professional PyQt5 ground-station console, and — new in this revision — **large
file transfer, real BER/SNR instrumentation, and a one-command demonstration
for each of eight project requirements**.

Built from scratch on stock GNU Radio 3.10. Nothing to compile, no
out-of-tree modules.

---

## What's new in this revision

If you know the previous version, here is what changed. If you don't, skip to
[Quick start](#quick-start).

- **File transfer.** The GUI and terminal can now send and receive files, not
  just short messages. Files are fragmented, protected with Reed-Solomon
  erasure coding (so a transfer survives lost fragments with no
  retransmission), and verified end-to-end with SHA-256. The wire format's
  message ceiling went from 64 KB to ~16 MB.
- **Real metrics.** A continuous PRBS-15 bit-error-rate test, two SNR
  estimators (EVM and moment-based), and processing gain measured properly —
  the old "processing gain" readout was actually the code's peak-to-sidelobe
  ratio and could never exceed 12 dB; see [`docs/METRICS.md`](docs/METRICS.md).
- **One command per requirement.** `python3 demo.py <N>` runs a self-contained
  demonstration of project requirement *N*, writes a report with figures and
  data, and — where hardware helps — can measure a live flowgraph. This is the
  headline feature; see [The eight demos](#the-eight-demos).
- **Link profiles.** Four selectable operating points trading spreading gain
  for throughput, so you can run maximum-hiding for the spectrum demo and a
  fast profile for actually moving a file.
- **A third-radio jammer** (`jammer.py`) for the stretch requirement.
- **Several real despreader fixes** found while building the measurement
  framework — a false-lock bug, tracking slips, and carrier-offset handling —
  documented honestly in [`docs/METRICS.md`](docs/METRICS.md). The link now
  runs within ~0.5 dB of theory, down from 5–6 dB.
- **The readable block sources are now the source of truth**, pushed into the
  `.grc` files by a tool rather than the other way around. See
  [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

> **If you are upgrading:** the flowgraph logic changed, so the pre-generated
> `dsss_bpsk_*.py` files are stale. Open each `.grc` in GNU Radio Companion and
> hit **Generate** before a live run — see [Running the flowgraphs](#running-the-flowgraphs).

---

## Quick start

Two flowgraphs are provided:

- **`dsss_bpsk_sim.grc`** — runs standalone, no radio needed. TX and RX in one
  flowgraph joined by a simulated noisy/offset channel. Open this first.
- **`dsss_bpsk_usrp.grc`** — the same signal chain with real USRP source/sink,
  for when you have B205/B206minis.

```bash
gnuradio-companion dsss_bpsk_sim.grc      # hit Generate, then Execute
```

A window with plots and sliders opens and the link starts transmitting
continuously. In another terminal:

```bash
python3 ground_station.py                  # graphical console
# or
python3 terminal.py                        # scriptable text console
```

Type a message and send it, or use the **File** tab to send a file. To run the
requirement demonstrations, you don't even need the flowgraph running:

```bash
python3 demo.py list                       # what the eight demos are
python3 demo.py all                        # run all eight, ~5 minutes
python3 demo.py 7                           # just requirement 7
```

Everything the demos need is stock Python + NumPy + Matplotlib.

---

## The eight demos

The project was built against eight guidance points, and each one has exactly
one command that demonstrates it — producing a folder with a written report,
figures, and the raw data behind them, so "done" is something you show rather
than assert. Full detail in
[`docs/REQUIREMENTS.md`](docs/REQUIREMENTS.md) and
[`docs/DEMO_GUIDE.md`](docs/DEMO_GUIDE.md).

| # | Requirement | Command | Headline result |
|---|---|---|---|
| 1 | PN code alignment + tracking | `demo.py 1` | Aligns to the exact chip; tracks through 200 ppm drift; false-lock 47%→0% |
| 2 | High spreading factor | `demo.py 2` | 1023 chips/symbol, verified Gold code, 30.1 dB gain |
| 3 | Chip rate vs bit rate for SNR | `demo.py 3` | 30.1 dB predicted, matches measured within 0.4 dB |
| 4 | CFO / timing compensation decision | `demo.py 4` | CFO **required** (~100× the loop's reach); timing drift **not** |
| 5 | Full duplex | `demo.py 5` | Both directions from the same samples, BER ~5×10⁻⁴ |
| 6 | Spectrum below the noise floor | `demo.py 6` | TX on raises in-band power +0.07 dB — invisible — yet decodes |
| 7 | Processing gain + BER | `demo.py 7` | 30.2 dB measured (3 ways agree); within 0.5 dB of theory |
| 8 | Stretch: third-radio jammer | `demo.py 8` | Absorbs +18 dB broadband, +21 dB CW jamming |

Add `--live` to demos 5–8 to also measure a running flowgraph. Add `--quick`
to any for shorter sweeps when rehearsing.

---

## File transfer

The **File** tab (or `/send <path>` in the terminal) sends a file over the same
DSP as everything else. Before it starts, it tells you the fragment count and
the estimated airtime — which matters, because on the maximum-hiding profile a
megabyte takes hours. Pick a faster [profile](#link-profiles) to actually move
data.

Files survive lost fragments without retransmission: Reed-Solomon erasure
coding sends parity fragments so that *any* `k` of the `k+m` reconstruct the
file. With the default 20% overhead a file arrives bit-exact through ~10–15%
fragment loss. Every received file is verified against a SHA-256 carried inside
the transfer and written to disk only if it matches. See
[`docs/PROTOCOL.md`](docs/PROTOCOL.md).

A **BER test** button (or `/bert on`) fills the link's idle slots with a
PRBS-15 pattern the receiver knows, so it counts real channel bit errors
continuously — reported with a bit count and a confidence interval, because a
BER without a bit count is not a measurement.

---

## Link profiles

One set of DSP parameters can't serve both maximum hiding and usable
throughput, because `symbol_rate = chip_rate / code_len` ties every dB of
processing gain directly to data rate. So the link has four operating points,
selected at launch:

| Profile | Code | Chip rate | Gain | Payload rate | 1 MB takes |
|---|---|---|---|---|---|
| `stealth` (default) | 1023 | 0.51 Mcps | 30.1 dB | ~113 B/s | 2.9 h |
| `standard` | 1023 | 2.05 Mcps | 30.1 dB | ~454 B/s | 44 min |
| `fast` | 511 | 2.05 Mcps | 27.1 dB | ~908 B/s | 23 min |
| `bulk` | 127 | 1.65 Mcps | 21.0 dB | ~2.9 KB/s | 7 min |

```bash
LINK_PROFILE=bulk gnuradio-companion dsss_bpsk_usrp.grc
```

Set it before launching the flowgraph (it's baked into sample rates and filter
taps) and pass the same `--profile` to the console. `python3 demo.py 3` shows
the full trade with measurements.

---

## How the link works

### GPS-style Gold codes

The spreading code is generated exactly the way GPS C/A codes are: two 10-bit
LFSRs (**G1**: x¹⁰+x³+1; **G2**: x¹⁰+x⁹+x⁸+x⁶+x³+x²+1, both all-ones seeded)
combined into a 1023-chip Gold code. It's verified against the defining
properties — exact period 1023, balanced 512/511 chips, and the textbook
three-valued autocorrelation {−65, −1, 63} — before being trusted, and all 16
node codes pass. Processing gain: 10·log10(1023) ≈ 30.1 dB.

### Despread *before* carrier recovery

The receive chain despreads immediately after the matched filter, before any
carrier or timing recovery. That ordering is the crux: a Costas loop can't lock
onto a signal below the noise floor, so the ~30 dB of processing gain has to be
applied first, exactly as a GPS receiver structures its code and carrier loops.

### Acquisition and tracking

Acquisition is GPS's own parallel code-phase search — one FFT pair evaluates
all 1023 chip alignments at once — extended to search carrier frequency at the
same time (see requirement 4 below for why that's necessary). Tracking re-finds
the alignment every symbol in a narrow ±2-chip window with hysteresis toward
the prediction. Both are in `custom_blocks/dsss_despreader.py`, and
`demo.py 1` plots them.

Three real bugs were found and fixed here while building the demos — a
false-lock at low SNR, tracking slips that floored the BER, and a mislabelled
gain metric. They're documented in [`docs/METRICS.md`](docs/METRICS.md)
because being honest about them is more useful than hiding them, and the link is
measurably better for the fixes.

### Continuous transmission

The transmitter never goes quiet — idle slots carry filler (or PRBS during a
BER test) so the despreader never has to re-acquire from a cold start. Pacing is
a wall-clock strobe with a live **TX Pace Margin %** slider for per-machine
underflow tuning.

### Multi-node / full duplex

Each node spreads with its own Gold code and despreads against its peer's. Gold
codes cross-correlate at only −24 dB, so combined with despreading gain, one
node's transmission looks like harmless noise to a receiver locked on a
different code. Two nodes set to each other's id get genuine full duplex on one
frequency — `demo.py 5` measures it.

---

## Running the flowgraphs

> **The pre-generated `.py` files are stale after this revision.** Regenerate
> before a live run:
>
> ```bash
> gnuradio-companion dsss_bpsk_usrp.grc     # hit Generate (gear icon)
> gnuradio-companion dsss_bpsk_sim.grc      # hit Generate
> # or, with grcc:  grcc dsss_bpsk_usrp.grc
> ```
>
> The `.grc` files are the source of truth and are validated by the test suite;
> GRC turns them into runnable `.py` for your exact GNU Radio version. Running
> an un-regenerated old `.py` gives the previous version's behaviour and won't
> interoperate with the new file transfer.

### Two-node (full-duplex) setup

Run `dsss_bpsk_usrp.grc` on two machines, each with its own B205/B206mini:

1. Node A: leave `my_node_id = 0`, `dest_node_id = 1`.
2. Node B: set MY NODE = 1, TALKING TO = 0 (GUI spin boxes, or `/node 1` /
   `/dest 0`).
3. Point each antenna at the other's, well separated, with **separate TX and RX
   antennas** and low TX gain. **Check your local spectrum rules before
   transmitting.**

### Three-node (jamming) setup

A third radio runs `jammer.py` as a controlled interference source — see
[`docs/DEMO_GUIDE.md`](docs/DEMO_GUIDE.md). Keep it **conducted and
attenuated**: it transmits deliberate co-channel interference, the default TX
gain is 0, and radiating it over the air is very likely illegal.

---

## Testing

Everything checkable without a radio is checked offline:

```bash
python3 tests/run_tests.py          # 22 checks: DSP, coding, protocol, sync
```

This includes a mechanical assertion that the offline reference despreader and
the actual GNU Radio block produce identical output — which is what makes it
legitimate to run the demos in simulation.

---

## Repository layout

```
demo.py                 one command per requirement -> demo_results/<run>/
ground_station.py       PyQt5 console: messages, files, metrics, demo launcher
terminal.py             scriptable text console with the same features
jammer.py               third-radio interference source (requirement 8)

dsss_bpsk_sim.grc       flowgraph, simulated channel (run first)
dsss_bpsk_usrp.grc      flowgraph, real USRPs

dsss_link/              shared, importable DSP + protocol (the source of truth)
  dsss_core.py            Gold codes, spreader/despreader, channel, QPSK
  link_profiles.py        the four operating points
  erasure_fec.py          Reed-Solomon erasure coding
  protocol.py             wire format, file payload, PRBS BERT
  metrics.py              every SNR / gain / BER / jamming figure
  filexfer.py             host-side file transfer

custom_blocks/          GNU Radio embedded Python blocks (readable copies)
demos/                  one module per requirement demonstration
tools/build_flowgraphs.py   pushes custom_blocks/ into the .grc files
tests/run_tests.py      offline verification suite

docs/
  REQUIREMENTS.md         traceability: requirement -> demo -> result
  DEMO_GUIDE.md           how to run the demonstration, with and without radios
  PROTOCOL.md             wire format and file transfer in detail
  METRICS.md              what every metric means, and the ones that look alike
  ARCHITECTURE.md         how the pieces fit and the source-of-truth idea
```

---

## Requirements

Built and tested against GNU Radio 3.10.x, Python 3.11+, PyQt5, NumPy. The
flowgraphs use only stock blocks. `ground_station.py`, `terminal.py`,
`demo.py`, and the `dsss_link` library need only Python + NumPy (+ PyQt5 for
the GUI, + Matplotlib for the demo plots) and run without a GNU Radio install,
so the consoles and demos can live on a different machine from the radio.

---

## Known quirks

- GRC prints `Warning: The block 'access_corr' is deprecated.` — still fully
  functional, safe to ignore.
- On the `stealth` profile a large file transfer is genuinely slow (that
  profile is built for hiding, not throughput) and may report `INCOMPLETE`
  under heavy noise — raise the parity overhead or switch to `bulk`.
- If you see TX underflow / RX overflow on real hardware, push
  `tx_pace_margin_pct` more negative or drop to a lower chip-rate profile.
- The `.grc` files are authoritative; if you edit a block, edit it in
  `custom_blocks/` and run `python3 tools/build_flowgraphs.py`, not the other
  way around.
