"""
Packet Deframer
----------------
Inverse of the Packet Framer: descrambles the captured frame body
(SEQ+PAYLOAD+CRC32 - the sync word itself was never part of this, it was
stripped off by the access-code correlator/Packet Capture already),
recomputes the CRC32 and compares it to what was received. On a match,
the raw PAYLOAD bytes (still containing the TX Scheduler's
MSG_ID/FRAG_IDX/FRAG_TOTAL/CHUNK_LEN header - that's the Fragment
Reassembler's job to interpret, not this block's) are published for
reassembly. A short status line is always published, whether the CRC
passed or not.

Input  : PDU - the frame body bytes (SEQ+PAYLOAD+CRC32, still scrambled)
Outputs: 'payload' - PDU, the descrambled PAYLOAD bytes (only on CRC OK)
         'status'  - PDU, a short ASCII status line (always)
"""

import numpy as np
import zlib
import pmt
from gnuradio import gr


def pdu_data(msg):
    vec = pmt.cdr(msg) if pmt.is_pair(msg) else msg
    return np.array(pmt.u8vector_elements(vec), dtype=np.uint8)


def make_pdu(values):
    arr = np.asarray(values, dtype=np.uint8)
    return pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(arr), arr.tolist()))


def lfsr_sequence(n_bits, taps, seed, length):
    state = seed & ((1 << n_bits) - 1)
    if state == 0:
        state = 1
    out = np.empty(length, dtype=np.uint8)
    for i in range(length):
        out[i] = state & 1
        fb = bin(state & taps).count('1') & 1
        state = (state >> 1) | (fb << (n_bits - 1))
    return out


# Must match pkt_framer.py exactly.
SCRAMBLER_NBITS, SCRAMBLER_TAPS, SCRAMBLER_SEED = 9, 0b110011, 0b011010110


def descramble_bytes(data):
    bits = np.unpackbits(np.frombuffer(data, dtype=np.uint8))
    ks = lfsr_sequence(SCRAMBLER_NBITS, SCRAMBLER_TAPS, SCRAMBLER_SEED, len(bits))
    return np.packbits(bits ^ ks).tobytes()


class blk(gr.basic_block):
    """Packet Deframer"""

    def __init__(self, payload_bytes=256):
        gr.basic_block.__init__(self, name='Packet Deframer', in_sig=[], out_sig=[])
        self.payload_bytes = int(payload_bytes)
        self.body_bytes = 1 + self.payload_bytes + 4  # SEQ + PAYLOAD + CRC32
        self.message_port_register_in(pmt.intern('in'))
        self.message_port_register_out(pmt.intern('payload'))
        self.message_port_register_out(pmt.intern('status'))
        self.set_msg_handler(pmt.intern('in'), self.handle_msg)

    def handle_msg(self, msg):
        raw = pdu_data(msg).tobytes()[:self.body_bytes]
        if len(raw) < self.body_bytes:
            self._status("seq=???  frame too short (%d/%d bytes) - dropped" %
                         (len(raw), self.body_bytes))
            return

        body = descramble_bytes(raw)
        seq = body[0]
        payload = body[1:1 + self.payload_bytes]
        crc_off = 1 + self.payload_bytes
        rx_crc = int.from_bytes(body[crc_off:crc_off + 4], 'big')
        calc_crc = zlib.crc32(body[:crc_off]) & 0xFFFFFFFF

        if calc_crc == rx_crc:
            # prepend SEQ so the Fragment Reassembler downstream can quote
            # it in its own status lines (idle heartbeats in particular)
            self.message_port_pub(pmt.intern('payload'), make_pdu([seq] + list(payload)))
        else:
            self._status("seq=%3d  CRC FAIL (packet dropped)" % seq)

    def _status(self, text):
        self.message_port_pub(pmt.intern('status'), make_pdu(list(text.encode('utf-8'))))
