"""Drive the patched ground station headlessly.

Constructs the real window under an offscreen Qt platform and feeds it
genuine telemetry and status lines produced by the actual blocks, so the
parsing and display paths are exercised rather than assumed."""
import os
import sys

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, 'deploy'))

FAIL = []


def check(name, cond, extra=""):
    if not cond:
        FAIL.append(name)
    print("  [%s] %s %s" % ("ok  " if cond else "FAIL", name, extra))


import ground_station as GS
from PyQt5.QtWidgets import QApplication

app = QApplication([])

print("=== Constants updated for the new wire format ===")
check("fragment payload is 428 bytes", GS.FRAGMENT_PAYLOAD_BYTES == 428,
      "(%d)" % GS.FRAGMENT_PAYLOAD_BYTES)

print("\n=== Helpers ===")
check("human_bytes", GS.human_bytes(1536) == "1.5 KB", GS.human_bytes(1536))
check("human_rate", GS.human_rate(1663) == "1.66 kbit/s", GS.human_rate(1663))
check("human_secs", GS.human_secs(125) == "2.1 min", GS.human_secs(125))

print("\n=== Window construction ===")
win = GS.GroundStationWindow(
    host='127.0.0.1', tx_port=52001, rx_data_port=52002,
    rx_status_port=52003, bind_host='127.0.0.1', ctrl_port=52004,
    diag_port=52005)
check("main window builds", win is not None)
check("attach button present", hasattr(win, 'attach_button'))
check("transfer progress bar present", hasattr(win, 'transfer_bar'))
check("transfer bar hidden until needed", not win.transfer_bar.isVisible())

win._toggle_debug_window(True)
w = win.diag_window
check("diagnostics window opens", w is not None)

print("\n=== Telemetry line from the real Link Metrics block ===")
# Produced by running link_metrics.blk against the mock runtime.
LINK = (
    "LINK uptime=42 chiprate=2046000 samprate=8184000 codelen=1023 "
    "procgain_ideal=30.1 symrate=2000.0 rawbitrate=4000.0 coderate=0.4284 "
    "maxpayloadrate=1713.5 framesyms=4118 frameperiod=2.059 "
    "payloadperframe=441 goodput=1420.0 txrate=1500.0 framerate=0.49 "
    "efficiency=0.829 framesok=118 framesbad=2 fer=1.6667e-02 "
    "prefec_ber=7.3050e-02 prefec_errbits=51234 prefec_totalbits=701280 "
    "postfec_ber=0.0000e+00 postfec_bits=384000 rs_corrected=142 "
    "rs_uncorrectable=0 rs_worst=6 rs_limit=16 rs_headroom=10 "
    "ebno_est=4.05 locked=1 resyncs=0 falsesync=0 procgain_actual=24.2 "
    "acquisitions=1 locklosses=0 acqsecs=0.31 chipcorrections=4 "
    "txqueued=0 txframes=120 txidle=98 txdata=22 rxtext=3 rxfiles=1 "
    "rxverified=1 health_tx_underflow=0 xfer=report.pdf:820/1400:512"
)
win._handle_diag_line(LINK)

vals = {k: lbl.text() for k, lbl in w.labels.items()}
for key, want in [
    ('cfg_chip', 'Mcps'), ('cfg_code', '1023 chips'),
    ('cfg_sym', 'sym/s'), ('cfg_frame', '4118 symbols'),
    ('cfg_ceiling', 'kbit/s'), ('goodput', 'kbit/s'),
    ('framerate', 'frames/s'), ('efficiency', '%'),
    ('ber_pre', '7.305e-02'), ('ber_post', 'no errors'),
    ('ebno', '+4.05 dB'), ('rs_worst', '6 of 16'),
    ('rs_uncorr', '0'), ('fer', '1.667e-02'),
    ('frames', '118 ok / 2 failed'), ('proc_actual', '24.2 dB'),
    ('acq', '1 acquisitions'), ('sync', 'LOCKED'),
    ('files', '1 received / 1 sha256-verified'),
]:
    check("%-12s shows %r" % (key, want), want in vals.get(key, ''),
          "-> %r" % vals.get(key, '<missing>'))

check("Eb/N0 is interpreted, not just printed",
      'comfortable' in vals['ebno'], vals['ebno'])
check("active transfer shown", 'report.pdf' in vals.get('xfer', ''),
      vals.get('xfer'))

print("\n=== Per-frame FEC report ===")
FEC = ("FECFRAME crc=1 seq=17 syncorr=0.912 rot=0 chanber=7.3050e-02 "
       "chanerr=597 codedbits=8172 rscorr=3,5 rsworst=5 rsmargin=11 "
       "rsuncorr=0 pathmetric=6012.5 locked=1")
win._handle_diag_line(FEC)
vals = {k: lbl.text() for k, lbl in w.labels.items()}
check("Viterbi repair count shown",
      '597 of 8172' in vals.get('viterbi', ''), vals.get('viterbi'))
check("per-codeword RS corrections shown",
      '[3,5]' in vals.get('rs_last', ''), vals.get('rs_last'))
check("RS headroom drawn as a bar",
      '11/16' in vals.get('rs_head', '') and '#' in vals.get('rs_head', ''),
      vals.get('rs_head'))

print("\n=== Low-margin link is visibly flagged ===")
win._handle_diag_line(LINK.replace('ebno_est=4.05', 'ebno_est=2.4')
                          .replace('rs_headroom=10', 'rs_headroom=1'))
vals = {k: lbl.text() for k, lbl in w.labels.items()}
check("marginal Eb/N0 called out", 'cliff' in vals['ebno'], vals['ebno'])
win._handle_diag_line(LINK.replace('ebno_est=4.05', 'ebno_est=1.2'))
vals = {k: lbl.text() for k, lbl in w.labels.items()}
check("sub-threshold Eb/N0 called out",
      'BELOW' in vals['ebno'], vals['ebno'])

print("\n=== File transfer status lines ===")
win._handle_status_line("FILESTART msg=7 name=payload.bin bytes=4194304 frags=9800")
check("incoming file announced and bar shown",
      win.transfer_bar.maximum() == 9800)
win._handle_status_line("FILEPROG msg=7 got=4900 total=9800 pct=50.0 "
                        "bytes=2097152 rate=1750 eta=1200")
check("progress bar tracks the transfer",
      win.transfer_bar.value() == 4900,
      "(%d/%d)" % (win.transfer_bar.value(), win.transfer_bar.maximum()))
check("rate and ETA in the bar text",
      '/s' in win.transfer_bar.format() and 'ETA' in win.transfer_bar.format(),
      win.transfer_bar.format())
win._handle_status_line(
    "FILEDONE msg=7 path=/home/g/rx_files/payload.bin bytes=4194304 "
    "secs=2400.0 rate=1747 sha256=9f86d081884c7d65 verify=OK")
check("completion hides the bar", not win.transfer_bar.isVisible())
log = win.log_edit.toPlainText()
check("completion logged with verification",
      'payload.bin' in log and 'verified' in log)

win._handle_status_line(
    "FILEDONE msg=8 path=/home/g/rx_files/b.bin bytes=10 secs=1 rate=10 "
    "sha256=deadbeef verify=MISMATCH")
check("hash mismatch reported differently",
      'MISMATCH' in win.log_edit.toPlainText() or
      'hash' in win.log_edit.toPlainText())

print("\n=== Text message flow still works ===")
before = win.recv_table.rowCount()
win._on_data_datagram(b'hello from the other node')
check("received message lands in the table",
      win.recv_table.rowCount() == before + 1)

win._handle_status_line("FRAG type=TEXT msg=3 idx=0 total=2 seq=9 crc=OK "
                        "len=428 src=1 dst=0")
win._handle_status_line("DONE type=TEXT msg=3 fragments=2 bytes=856 src=1")
check("fragment and completion lines parse without error", True)

print("\n=== Error lines surface ===")
win._handle_status_line("FILEERR msg=4 cannot open inbox (permission denied)")
check("errors reach the log", 'FILEERR' in win.log_edit.toPlainText())
win._handle_status_line("UPLOADACK 5")
check("upload acknowledgements tracked", win._upload_ack >= 0)

print("\n=== Health counters ===")
for _ in range(3):
    win._handle_status_line("HEALTH TX UNDERFLOW #1 (total async events=1)")
win._refresh_debug_window()
vals = {k: lbl.text() for k, lbl in w.labels.items()}
check("underflow events counted", vals.get('underflow', '0') not in ('0', '--'),
      vals.get('underflow'))

win.close()
print("\n" + "=" * 62)
if FAIL:
    print("FAILURES (%d): %s" % (len(FAIL), ", ".join(FAIL)))
    sys.exit(1)
print("GROUND STATION TESTS PASSED")
