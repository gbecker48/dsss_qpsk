"""Framing, mapping and FrameScanner tests - including regression tests for
the two bugs that cost the most time to find."""
import os
import sys
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import dsss_frame as FR
import dsss_fec as FEC

FAIL = []


def check(name, cond, extra=""):
    if not cond:
        FAIL.append(name)
    print("  [%s] %s %s" % ("ok  " if cond else "FAIL", name, extra))


N_CW = 2
rng = np.random.default_rng(77)


def mod(bits, mode):
    g = FR.bits_to_gray_dibits(bits).astype(np.int64)
    if mode == FR.MODE_DIFFERENTIAL:
        g = np.cumsum(g) % 4
    return np.exp(1j * (np.pi / 4 + g * (np.pi / 2))).astype(np.complex64)


def noise(x, esno_db, r):
    p = float(np.mean(np.abs(x) ** 2))
    n = p / (10 ** (esno_db / 10.0))
    return (x + r.normal(0, np.sqrt(n / 2), len(x))
            + 1j * r.normal(0, np.sqrt(n / 2), len(x))).astype(np.complex64)


def stream(n_frames, mode):
    pay = [bytes(rng.integers(0, 256, FR.payload_bytes(N_CW), dtype=np.uint8))
           for _ in range(n_frames)]
    bits = np.concatenate([FR.build_frame_bits(i & 0xFF, p, N_CW)
                           for i, p in enumerate(pay)])
    bits = np.concatenate([np.zeros(64, dtype=np.uint8), bits])
    return pay, mod(bits, mode)


print("=== Geometry ===")
check("payload is 441 bytes", FR.payload_bytes(N_CW) == 441,
      "(%d)" % FR.payload_bytes(N_CW))
check("frame is 8236 bits", FR.frame_bits(N_CW) == 8236,
      "(%d bits, %d symbols)" % (FR.frame_bits(N_CW), FR.frame_symbols(N_CW)))
check("frame bit count is even (symbol aligned)", FR.frame_bits(N_CW) % 2 == 0)
check("overall code rate ~0.43", 0.42 < FR.code_rate(N_CW) < 0.44,
      "(%.4f)" % FR.code_rate(N_CW))

print("\n=== Gray mapping ===")
check("Gray map is self-inverse",
      list(FR.GRAY_MAP[FR.GRAY_MAP]) == [0, 1, 2, 3])
# adjacent constellation points must differ in exactly one bit
pts = {}
for m in range(4):
    g = int(FR.GRAY_MAP[m])
    pts[g] = (m >> 1, m & 1)
adjacent_ok = True
for g in range(4):
    a, b = pts[g], pts[(g + 1) % 4]
    if (a[0] != b[0]) + (a[1] != b[1]) != 1:
        adjacent_ok = False
check("adjacent constellation points differ in one bit", adjacent_ok)

print("\n=== Soft demodulation sign conventions ===")
# The differential encoder's implicit "symbol before the first" sits at
# pi/4, since d[0] = g[0] means s[0] is that reference rotated by g[0].
DIFF_REF = np.complex64(np.exp(1j * np.pi / 4))

for mode, demod in ((FR.MODE_COHERENT, lambda s: FR.soft_coherent(s)),
                    (FR.MODE_DIFFERENTIAL,
                     lambda s: FR.soft_dqpsk(s, prev=DIFF_REF)[0])):
    bits = rng.integers(0, 2, 2000, dtype=np.uint8)
    sym = mod(bits, mode)
    soft = demod(sym)
    hard = (soft < 0).astype(np.uint8)
    n = min(len(hard), len(bits))
    check("%s: noiseless demod is exact" % mode,
          np.array_equal(hard[:n], bits[:n]),
          "(%d bits)" % n)

print("\n=== REGRESSION: soft_dqpsk must not silently drop a dibit ===")
sym = mod(rng.integers(0, 2, 400, dtype=np.uint8), FR.MODE_DIFFERENTIAL)
half = len(sym) // 2                       # 400 bits -> 200 symbols
s1, last = FR.soft_dqpsk(sym[:half], prev=None)
s2, _ = FR.soft_dqpsk(sym[half:], prev=last)
one_shot, _ = FR.soft_dqpsk(sym, prev=None)
check("chunked demod == one-shot demod when prev is carried",
      len(s2) > 0 and
      np.allclose(np.concatenate([s1, s2]), one_shot, atol=1e-5),
      "(%d + %d vs %d)" % (len(s1), len(s2), len(one_shot)))
s2_bad, _ = FR.soft_dqpsk(sym[half:], prev=None)
check("dropping prev really does lose a dibit (the bug)",
      len(s2_bad) == len(s2) - 2,
      "(%d vs %d soft values)" % (len(s2_bad), len(s2)))

print("\n=== REGRESSION: a spurious sync hit must not destroy alignment ===")
# Force a false alarm by handing the scanner noise ahead of real frames.
pay, sym = stream(4, FR.MODE_COHERENT)
junk = (rng.normal(0, 1, 3000) + 1j * rng.normal(0, 1, 3000)).astype(np.complex64)
sc = FR.FrameScanner(n_cw=N_CW, mode=FR.MODE_COHERENT)
got = []
mixed = np.concatenate([junk, sym])
for i in range(0, len(mixed), 4096):
    got.extend(sc.feed(mixed[i:i + 4096]))
good = [g for g in got if g['payload'] is not None]
check("frames still recovered after leading noise", len(good) >= 3,
      "(%d good frames, %d false syncs)" % (len(good), sc.false_sync))
check("recovered payloads are correct",
      all(g['payload'] == pay[g['seq']] for g in good))

print("\n=== Scanner: lock, prediction and statistics ===")
pay, sym = stream(8, FR.MODE_COHERENT)
noisy = noise(sym, 4.0, np.random.default_rng(5))
sc = FR.FrameScanner(n_cw=N_CW, mode=FR.MODE_COHERENT)
got = []
for i in range(0, len(noisy), 2048):
    got.extend(sc.feed(noisy[i:i + 2048]))
good = [g for g in got if g['payload'] is not None]
check("locks and decodes a noisy stream", len(good) >= 6,
      "(%d/8 frames)" % len(good))
check("scanner reports locked", sc.locked)
check("payloads correct", all(g['payload'] == pay[g['seq']] for g in good))
check("per-frame FEC stats present",
      all(k in good[0]['stats'] for k in
          ('chan_ber', 'rs_corrected', 'rs_margin', 'path_metric', 'crc_ok')))
check("no false syncs once locked", sc.false_sync == 0,
      "(%d)" % sc.false_sync)

print("\n=== Scanner is chunk-size invariant ===")
results = {}
for chunk in (512, 2048, 8192, 100000):
    s = FR.FrameScanner(n_cw=N_CW, mode=FR.MODE_COHERENT)
    out = []
    for i in range(0, len(noisy), chunk):
        out.extend(s.feed(noisy[i:i + chunk]))
    results[chunk] = sorted(g['seq'] for g in out if g['payload'] is not None)
base = results[2048]
check("same frames recovered at every chunk size",
      all(v == base for v in results.values()),
      str({k: len(v) for k, v in results.items()}))

print("\n=== Phase and frequency tolerance (coherent) ===")
pay, sym = stream(6, FR.MODE_COHERENT)
for label, ph, fo in (("clean", 0.0, 0.0), ("phase 2.3 rad", 2.3, 0.0),
                      ("phase pi", np.pi, 0.0), ("freq +3 Hz", 0.0, 3.0),
                      ("freq -3 Hz", 0.0, -3.0),
                      ("phase 2.3 + freq 2 Hz", 2.3, 2.0)):
    t = np.arange(len(sym)) / 2000.0
    r = (sym * np.exp(1j * (2 * np.pi * fo * t + ph))).astype(np.complex64)
    r = noise(r, 4.0, np.random.default_rng(5))
    s = FR.FrameScanner(n_cw=N_CW, mode=FR.MODE_COHERENT)
    out = []
    for i in range(0, len(r), 2048):
        out.extend(s.feed(r[i:i + 2048]))
    ok = sum(1 for g in out if g['payload'] is not None
             and g['payload'] == pay[g['seq']])
    check("survives %s" % label, ok >= 4, "(%d/6 frames)" % ok)

print("\n=== Idle-frame PRBS enables post-FEC BER measurement ===")
p = FEC.prbs15(441)
check("PRBS regenerates identically", p == FEC.prbs15(441))
body = FR.build_frame_bits(0, p, N_CW)
soft = FR.soft_coherent(mod(body, FR.MODE_COHERENT))
seq, payload, st = FR.decode_frame_soft(soft[FR.SYNC_NBITS:], N_CW)
check("idle frame decodes back to the known pattern",
      payload == p and st['crc_ok'])

print("\n" + "=" * 60)
if FAIL:
    print("FAILURES (%d): %s" % (len(FAIL), ", ".join(FAIL)))
    sys.exit(1)
print("ALL FRAME TESTS PASSED")
