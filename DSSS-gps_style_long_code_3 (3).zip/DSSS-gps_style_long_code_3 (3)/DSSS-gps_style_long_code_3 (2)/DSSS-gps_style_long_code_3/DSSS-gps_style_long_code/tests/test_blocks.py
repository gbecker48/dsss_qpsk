"""Exercise the GNU Radio blocks against a mock runtime.

GNU Radio is not installed here, so this cannot prove the flowgraph runs -
but it does prove every block imports, constructs with the parameters the
flowgraph passes, and that its logic works end to end: a full transmit ->
channel -> receive loop through the real block code, including file
transfer."""
import os
import sys
import shutil
import tempfile
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, 'grmock'))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, 'blocks'))

import pmt
from gnuradio import gr

import dsss_frame as FR
import dsss_codes as CODES

FAIL = []


def check(name, cond, extra=""):
    if not cond:
        FAIL.append(name)
    print("  [%s] %s %s" % ("ok  " if cond else "FAIL", name, extra))


def pdu(data):
    data = bytes(data)
    return pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(data), list(data)))


def pdu_text(msg):
    return bytes(bytearray(pmt.u8vector_elements(pmt.cdr(msg)))).decode(
        'utf-8', 'replace')


print("=== Imports and construction ===")
import tx_frame_source
import rx_frame_decoder
import dsss_spreader
import dsss_despreader
import file_reassembler
import link_metrics
import node_ctrl

N_CW = 2
CODE_LEN = 1023
tmp = tempfile.mkdtemp(prefix='dsss_blk_')

tx = tx_frame_source.blk(rs_codewords=N_CW, my_node_id=0, dest_node_id=1,
                         mode='coherent', spool_dir=os.path.join(tmp, 'spool'))
rx = rx_frame_decoder.blk(rs_codewords=N_CW, mode='coherent')
spr = dsss_spreader.blk(code_len=CODE_LEN, node_id=0)
dsp = dsss_despreader.blk(code_len=CODE_LEN, node_id=0, acq_periods=32)
rea = file_reassembler.blk(rs_codewords=N_CW, my_node_id=1, dest_node_id=0,
                           inbox=os.path.join(tmp, 'inbox'))
ctl = node_ctrl.blk(table_size=16)
check("all seven blocks construct", True)
check("TX payload size matches frame layout",
      tx.payload_bytes == FR.payload_bytes(N_CW), "(%d)" % tx.payload_bytes)
check("TX bounds its own output buffer (latency cap)",
      getattr(tx, '_max_out_buf', 0) > 0,
      "(%d symbols ~= %.1f frames)" % (tx._max_out_buf,
                                       tx._max_out_buf / FR.frame_symbols(N_CW)))
check("despreader declares its decimation to the scheduler",
      abs(getattr(dsp, '_relative_rate', 0) - 1.0 / CODE_LEN) < 1e-12)

print("\n=== TX source can always satisfy a demand (no underflow by design) ===")
sizes = [1, 7, 100, 4096, 33333, FR.frame_symbols(N_CW) * 3]
ok = True
produced = []
for want in sizes:
    out = [np.zeros(want, dtype=np.uint8)]
    n = tx.work([], out)
    if n != want or not np.all(out[0] < 4):
        ok = False
    produced.append(out[0].copy())
check("every request satisfied in full, whatever the size", ok,
      "(sizes %s)" % sizes)
check("output is valid QPSK symbol indices 0-3",
      all(v.max() <= 3 for v in produced))

t0 = time.perf_counter()
NREQ = 200
for _ in range(NREQ):
    out = [np.zeros(8192, dtype=np.uint8)]
    tx.work([], out)
dt = time.perf_counter() - t0
sym_s = NREQ * 8192 / dt
# The demanding case is the shortest code (63 chips at 2.046 Mcps), which
# needs ~32.5k symbols/s. Require an order of magnitude of headroom over
# that, so generation is never the thing the radio waits on.
FASTEST_SYM_RATE = 2046000.0 / 63
check("source keeps well ahead of the radio",
      sym_s > 10 * FASTEST_SYM_RATE,
      "(%.0f symbols/s generated; %.0f needed at 1023 chips, %.0f at 63)"
      % (sym_s, 2046000.0 / CODE_LEN, FASTEST_SYM_RATE))

print("\n=== Spreader ===")
syms = np.exp(1j * (np.pi / 4 + np.arange(50) % 4 * np.pi / 2)).astype(np.complex64)
out = [np.zeros(50 * CODE_LEN, dtype=np.complex64)]
n = spr.work([syms], out)
check("spreads by exactly code_len", n == 50 * CODE_LEN)
code = CODES.gold_code(CODE_LEN, 0)
check("first symbol spread correctly",
      np.allclose(out[0][:CODE_LEN], syms[0] * code, atol=1e-5))
check("spread signal has constant envelope",
      np.allclose(np.abs(out[0][:n]), 1.0, atol=1e-4))

print("\n=== Full loopback: TX source -> spread -> noise -> despread -> decode ===")
tx2 = tx_frame_source.blk(rs_codewords=N_CW, my_node_id=0, dest_node_id=1,
                          mode='coherent', spool_dir=os.path.join(tmp, 'spool2'))
msg = b'Buried under the noise floor and still readable. ' * 12

# Two frames of idle filler first, so the despreader has something to
# acquire on before the real message arrives. A receiver joining a
# continuous stream always loses the frame it acquires during - which is
# exactly why the transmitter is always on rather than bursting.
lead = [np.zeros(FR.frame_symbols(N_CW) * 2, dtype=np.uint8)]
tx2.work([], lead)

tx2.post_msg('queue_in', pdu(msg))
time.sleep(0.3)

NSYM = FR.frame_symbols(N_CW) * 6
out = [np.zeros(NSYM, dtype=np.uint8)]
tx2.work([], out)
dibits = np.concatenate([lead[0], out[0]])
NSYM = len(dibits)
tx_syms = np.exp(1j * (np.pi / 4 + dibits.astype(np.int64) * np.pi / 2)
                 ).astype(np.complex64)

sout = [np.zeros(len(tx_syms) * CODE_LEN, dtype=np.complex64)]
spr.work([tx_syms], sout)
chips = sout[0]

# AWGN at chip level: 30 dB of processing gain means the signal sits far
# below the noise floor on the air.
rng = np.random.default_rng(3)
CHIP_SNR = -22.0
p = float(np.mean(np.abs(chips) ** 2))
npow = p / (10 ** (CHIP_SNR / 10.0))
noisy = (chips + rng.normal(0, np.sqrt(npow / 2), len(chips))
         + 1j * rng.normal(0, np.sqrt(npow / 2), len(chips))).astype(np.complex64)
check("signal is genuinely below the noise floor",
      10 * np.log10(p / np.mean(np.abs(noisy - chips) ** 2)) < -20,
      "(%.1f dB chip SNR)" % CHIP_SNR)

# despread in chunks, the way GNU Radio would
dsp2 = dsss_despreader.blk(code_len=CODE_LEN, node_id=0, acq_periods=32)
desp = []
pos = 0
CH = 200000
while pos < len(noisy):
    seg = noisy[pos:pos + CH]
    if len(seg) < CODE_LEN * 2:
        break
    dsp2._nread = pos
    if not dsp2.tracker.acquired:
        used = dsp2.tracker.acquire(seg, pos)
        pos += max(used, 1)
        continue
    s, consumed = dsp2.tracker.track(seg, pos, len(seg) // CODE_LEN + 1)
    if len(s):
        desp.append(s)
    pos += max(consumed, CODE_LEN)
desp = np.concatenate(desp) if desp else np.zeros(0, dtype=np.complex64)
check("despreader recovered symbols", len(desp) > NSYM * 0.6,
      "(%d of %d symbols, margin %.1f dB)"
      % (len(desp), NSYM, dsp2.tracker.margin_db))

# feed the decoder
rx2 = rx_frame_decoder.blk(rs_codewords=N_CW, mode='coherent')
for i in range(0, len(desp), 4096):
    rx2.work([desp[i:i + 4096]], [])
payloads = [pmt.cdr(m) for port, m in rx2.published if port == 'payload']
check("decoder produced frames", len(payloads) > 0,
      "(%d frames ok, %d bad, pre-FEC BER %.3e)"
      % (rx2.frames_ok, rx2.frames_bad, rx2.stats()['chan_ber']))

# reassemble
rea2 = file_reassembler.blk(rs_codewords=N_CW, my_node_id=1, dest_node_id=0,
                            inbox=os.path.join(tmp, 'inbox2'))
for port, m in rx2.published:
    if port == 'payload':
        rea2.handle(m)
got = [bytes(bytearray(pmt.u8vector_elements(pmt.cdr(m))))
       for port, m in rea2.published if port == 'msg']
check("message reassembled byte-for-byte through the whole chain",
      msg in got, "(%d messages out, %d bytes)"
      % (len(got), len(got[0]) if got else 0))

print("\n=== File transfer through the block chain ===")
src = os.path.join(tmp, 'send.bin')
data = np.random.default_rng(5).integers(0, 256, 60000, dtype=np.uint8).tobytes()
with open(src, 'wb') as fh:
    fh.write(data)

tx3 = tx_frame_source.blk(rs_codewords=N_CW, my_node_id=0, dest_node_id=1,
                          mode='coherent', spool_dir=os.path.join(tmp, 'spool3'))
tx3.post_msg('ctrl', pdu(('FILE=%s' % src).encode()))
time.sleep(0.6)

rea3 = file_reassembler.blk(rs_codewords=N_CW, my_node_id=1, dest_node_id=0,
                            inbox=os.path.join(tmp, 'inbox3'))
# Noiseless path for the protocol test: build frames, decode them back.
import dsss_transfer as XFER
nfrag = (len(data) + XFER.chunk_bytes_for(tx3.payload_bytes) - 1) \
    // XFER.chunk_bytes_for(tx3.payload_bytes) + 8
# Generous budget: this loop drains the transmitter far faster than any
# radio would, so the background file reader inserts idle frames while it
# catches up. Those are real frames on the air, just not file data.
for i in range(nfrag * 20):
    payload = tx3.tx.next_payload()
    rea3.handle(pdu(bytes([i & 0xFF]) + payload))
    if any('FILEDONE' in pdu_text(m) for p, m in rea3.published[-3:]
           if p == 'status'):
        break
done = [pdu_text(m) for p, m in rea3.published
        if p == 'status' and pdu_text(m).startswith('FILEDONE')]
check("file transfer completed", bool(done),
      done[0][:88] if done else "(no FILEDONE)")
check("sha256 verified", bool(done) and 'verify=OK' in done[0])
inbox3 = os.path.join(tmp, 'inbox3')
files = [f for f in os.listdir(inbox3) if not f.startswith('.')] \
    if os.path.isdir(inbox3) else []
check("file landed with its original name", files == ['send.bin'], str(files))
if files:
    with open(os.path.join(inbox3, files[0]), 'rb') as fh:
        check("file contents identical", fh.read() == data)

print("\n=== Node control ===")
ctl.post_msg('in', pdu(b'NODE=3'))
ctl.post_msg('in', pdu(b'DEST=7'))
ctl.post_msg('in', pdu(b'FILE=/tmp/x.bin'))
ctl.post_msg('in', pdu(b'NODE=99'))
ports = [p for p, _ in ctl.published]
check("NODE accepted", 'node_msg' in ports)
check("DEST accepted", 'dest_msg' in ports)
check("FILE routed to its own port", 'file_msg' in ports)
check("out-of-range node id rejected",
      sum(1 for p in ports if p == 'node_msg') == 1)

print("\n=== Live node switching drops despreader lock ===")
dsp3 = dsss_despreader.blk(code_len=CODE_LEN, node_id=0, acq_periods=8)
dsp3.tracker.acquired = True
dsp3.node_id = 4
check("changing node id forces re-acquisition", not dsp3.tracker.acquired)
check("spreader rebuilds its code on node change",
      not np.array_equal(CODES.gold_code(CODE_LEN, 0),
                         CODES.gold_code(CODE_LEN, 4)))

print("\n=== Metrics aggregator ===")
lm = link_metrics.blk(tx_source=tx2, rx_decoder=rx2, despreader=dsp2,
                      reassembler=rea2, chip_rate=2046000.0,
                      code_len=CODE_LEN, sps=4, rs_codewords=N_CW,
                      period_s=60)
lm._emit()
lm._emit()
lines = [pdu_text(m) for p, m in lm.published if p == 'diag']
check("emits a telemetry line", bool(lines))
if lines:
    fields = dict(kv.split('=', 1) for kv in lines[-1].split()[1:] if '=' in kv)
    need = ['chiprate', 'samprate', 'codelen', 'symrate', 'rawbitrate',
            'coderate', 'maxpayloadrate', 'goodput', 'framerate', 'fer',
            'prefec_ber', 'postfec_ber', 'rs_corrected', 'rs_headroom',
            'rs_limit', 'ebno_est', 'locked', 'procgain_ideal',
            'procgain_actual', 'acquisitions', 'efficiency']
    missing = [k for k in need if k not in fields]
    check("reports every headline metric", not missing,
          "(%d fields; missing %s)" % (len(fields), missing or 'none'))
    check("derived rates are sane",
          abs(float(fields['symrate']) - 2046000.0 / CODE_LEN) < 1 and
          abs(float(fields['rawbitrate']) - 2 * 2046000.0 / CODE_LEN) < 1,
          "(symrate=%s raw=%s maxpayload=%s bps)"
          % (fields['symrate'], fields['rawbitrate'], fields['maxpayloadrate']))
    check("RS headroom within limits",
          0 <= int(fields['rs_headroom']) <= int(fields['rs_limit']),
          "(headroom %s of %s)" % (fields['rs_headroom'], fields['rs_limit']))
    lm.post_msg('health', pdu(b'HEALTH TX UNDERFLOW #1 (total async events=1)'))
    lm._emit()
    last = [pdu_text(m) for p, m in lm.published if p == 'diag'][-1]
    check("UHD health events counted", 'health_tx_underflow=1' in last)

for b in (tx, tx2, tx3):
    b.stop()
lm.stop()
shutil.rmtree(tmp, ignore_errors=True)

print("\n" + "=" * 60)
if FAIL:
    print("FAILURES (%d): %s" % (len(FAIL), ", ".join(FAIL)))
    sys.exit(1)
print("ALL BLOCK TESTS PASSED")
