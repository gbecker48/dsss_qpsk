"""Check the regenerated flowgraph Python against the .grc it must match."""
import ast
import os
import re
import sys

import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
PY = os.path.join(HERE, 'deploy', 'dsss_bpsk_usrp.py')
GRC = os.path.join(HERE, 'deploy', 'dsss_bpsk_usrp.grc')

FAIL = []


def check(name, cond, extra=""):
    if not cond:
        FAIL.append(name)
    print("  [%s] %s %s" % ("ok  " if cond else "FAIL", name, extra))


src = open(PY, encoding='utf-8').read()
tree = ast.parse(src)
doc = yaml.safe_load(open(GRC, encoding='utf-8'))
grc_blocks = {b['name']: b for b in doc['blocks']}

print("=== Structure ===")
cls = [n for n in tree.body if isinstance(n, ast.ClassDef)]
check("flowgraph class present", len(cls) == 1 and cls[0].name == 'dsss_bpsk_usrp')
methods = {n.name for n in cls[0].body if isinstance(n, ast.FunctionDef)}
for m in ('__init__', 'closeEvent'):
    check("method %s survives" % m, m in methods)
check("module-level main() survives",
      any(isinstance(n, ast.FunctionDef) and n.name == 'main' for n in tree.body))
check("__main__ guard survives", "if __name__ == '__main__':" in src)

print("\n=== No references to removed blocks ===")
removed = ['tx_scheduler', 'pkt_framer', 'pkt_deframer', 'pkt_capture',
           'pdu2tagged', 'idle_strobe', 'access_corr', 'diff_enc', 'diff_dec',
           'slicer', 'unpack_dibits', 'bytes_to_bits', 'bits_to_dibits',
           'fec_encoder', 'fec_decoder', 'msg_debug']
leftovers = []
for name in removed:
    for m in re.finditer(r'\bself\.%s\b' % name, src):
        line = src[:m.start()].count('\n') + 1
        leftovers.append("%s at line %d" % (name, line))
check("no stale self.<block> references", not leftovers,
      "\n      " + "\n      ".join(leftovers[:8]) if leftovers else "")

stale_vars = ['strobe_period_ms', 'tx_pace_margin_pct', 'access_code_str',
              'access_code_threshold', 'fec_repeat', 'node_prn_table',
              'frame_capture_bits', 'frag_header_bytes', 'symbols_per_frame',
              'coded_bits', 'frame_body_bytes']
sv = []
for name in stale_vars:
    for m in re.finditer(r'\b%s\b' % name, src):
        sv.append("%s at line %d" % (name, src[:m.start()].count('\n') + 1))
check("no stale variable references", not sv,
      "\n      " + "\n      ".join(sv[:8]) if sv else "")

print("\n=== Every block used is instantiated ===")
assigned = set(re.findall(r'^\s+self\.(\w+) = ', src, re.M))
used = set(re.findall(r'\(self\.(\w+),\s*[\'0-9]', src))
missing = sorted(used - assigned)
check("all connected blocks are constructed", not missing, str(missing))

print("\n=== Python and .grc agree ===")
grc_conn = {(c[0], str(c[1]), c[2], str(c[3])) for c in doc['connections']}
py_conn = set()
for m in re.finditer(
        r"self\.(?:msg_)?connect\(\(self\.(\w+), '?(\w+)'?\), "
        r"\(self\.(\w+), '?(\w+)'?\)\)", src):
    py_conn.add(m.groups())
check("same number of connections",
      len(py_conn) == len(grc_conn),
      "(py %d, grc %d)" % (len(py_conn), len(grc_conn)))
only_py = sorted(py_conn - grc_conn)
only_grc = sorted(grc_conn - py_conn)
check("connection sets identical", not only_py and not only_grc,
      ("\n      only in py:  %s\n      only in grc: %s"
       % (only_py[:5], only_grc[:5])) if (only_py or only_grc) else "")

grc_epy = {n for n, b in grc_blocks.items() if b['id'] == 'epy_block'}
py_imports = set(re.findall(
    r'import dsss_bpsk_usrp_(\w+) as \w+  # embedded python block', src))
check("an import for every embedded block", grc_epy <= py_imports,
      "(missing %s)" % sorted(grc_epy - py_imports))
check("no import for a block that no longer exists", py_imports <= grc_epy,
      "(extra %s)" % sorted(py_imports - grc_epy))
check("shared modules imported",
      all("import %s" % m in src
          for m in ('dsss_frame', 'dsss_fec', 'dsss_codes')))

print("\n=== Variables ===")
grc_vars = {n: b['parameters'].get('value')
            for n, b in grc_blocks.items() if b['id'] == 'variable'}
py_vars = dict(re.findall(r'^\s+self\.(\w+) = \1 = (.+)$', src, re.M))
mismatched = []
for name, val in sorted(grc_vars.items()):
    if name not in py_vars:
        mismatched.append("%s missing from py" % name)
    elif py_vars[name].strip() != str(val).strip():
        mismatched.append("%s: py %r vs grc %r"
                          % (name, py_vars[name], val))
check("every .grc variable present with the same value", not mismatched,
      "\n      " + "\n      ".join(mismatched[:8]) if mismatched else "")

print("\n=== Setters exist for every variable a block consumes ===")
need_setters = ['my_node_id', 'dest_node_id', 'samp_rate', 'center_freq',
                'rx_gain', 'tx_gain', 'chip_rate', 'code_len', 'sps']
miss = [v for v in need_setters if 'def set_%s' % v not in src]
check("setters present", not miss, str(miss))
check("node change retunes spreader, despreader, reassembler and TX",
      all(s in src for s in
          ('self.dsss_spreader.node_id = self.my_node_id',
           'self.dsss_despreader.node_id = self.dest_node_id',
           'self.reassembler.my_node_id = self.my_node_id',
           'self.tx_frame_source.dest_node_id = self.dest_node_id')))

print("\n=== Radio configuration ===")
check("device args plumbed into both sink and source",
      src.count('",".join((usrp_dev_addr, usrp_dev_args))') == 2)
check("clock source is the variable, not a literal",
      "set_clock_source(clock_source, 0)" in src and
      "set_clock_source('external'" not in src)
check("RX AGC follows the variable",
      "set_rx_agc(bool(rx_agc), 0)" in src)
check("sample rate reaches both radios",
      'self.usrp_sink.set_samp_rate(self.samp_rate)' in src and
      'self.usrp_source.set_samp_rate(self.samp_rate)' in src)

print("\n" + "=" * 62)
if FAIL:
    print("FAILURES (%d): %s" % (len(FAIL), ", ".join(FAIL)))
    sys.exit(1)
print("GENERATED PYTHON VALIDATION PASSED")
