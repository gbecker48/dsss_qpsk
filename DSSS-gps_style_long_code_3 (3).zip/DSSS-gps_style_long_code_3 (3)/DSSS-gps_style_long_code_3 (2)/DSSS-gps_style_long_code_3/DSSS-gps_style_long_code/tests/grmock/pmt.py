"""Minimal PMT stand-in - enough for the blocks' message plumbing."""


class _Symbol(str):
    pass


class _Pair:
    __slots__ = ('car', 'cdr')

    def __init__(self, car, cdr):
        self.car = car
        self.cdr = cdr


class _U8Vector:
    __slots__ = ('data',)

    def __init__(self, data):
        self.data = list(data)


PMT_NIL = _Symbol('#nil')


def intern(s):
    return _Symbol(s)


def symbol_to_string(s):
    return str(s)


def cons(a, b):
    return _Pair(a, b)


def car(p):
    return p.car


def cdr(p):
    return p.cdr


def is_pair(p):
    return isinstance(p, _Pair)


def init_u8vector(n, data):
    return _U8Vector(list(data)[:n])


def u8vector_elements(v):
    if isinstance(v, _U8Vector):
        return list(v.data)
    raise TypeError('not a u8vector')


def from_long(n):
    return int(n)


def to_long(n):
    return int(n)


def from_double(x):
    return float(x)


def to_double(x):
    return float(x)


def is_integer(x):
    return isinstance(x, int)


def is_uinteger(x):
    return isinstance(x, int) and x >= 0


def is_dict(x):
    return False


def dict_ref(d, k, default):
    return default


def eq(a, b):
    return a is b or a == b


def write_string(x):
    return repr(x)
