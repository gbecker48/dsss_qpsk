"""Minimal stand-in for GNU Radio, so the embedded blocks can be
imported and exercised without a GNU Radio install. Implements just
enough of gr.basic_block / sync_block / interp_block semantics to drive
the blocks' own logic in tests."""

import numpy as np


class _Tag:
    def __init__(self, offset, key, value):
        self.offset = offset
        self.key = key
        self.value = value


class _Block:
    TPP_DONT = 0
    GR_MSB_FIRST = 0

    def __init__(self, name='block', in_sig=None, out_sig=None, **kw):
        self._name = name
        self._in_sig = in_sig or []
        self._out_sig = out_sig or []
        self._msg_handlers = {}
        self._msg_out = {}
        self._msg_in = set()
        self._nread = 0
        self._nwritten = 0
        self._consumed = 0
        self.tags = []
        self.published = []          # (port, payload) for assertions

    # -- ports -------------------------------------------------------------
    def message_port_register_in(self, port):
        self._msg_in.add(str(port))

    def message_port_register_out(self, port):
        self._msg_out[str(port)] = []

    def set_msg_handler(self, port, fn):
        self._msg_handlers[str(port)] = fn

    def message_port_pub(self, port, msg):
        self.published.append((str(port), msg))
        self._msg_out.setdefault(str(port), []).append(msg)

    def post_msg(self, port, msg):
        """Test helper: deliver a message as if it arrived on `port`."""
        fn = self._msg_handlers.get(str(port))
        if fn:
            fn(msg)

    # -- stream bookkeeping -------------------------------------------------
    def nitems_read(self, i=0):
        return self._nread

    def nitems_written(self, i=0):
        return self._nwritten

    def consume(self, i, n):
        self._consumed = int(n)

    def consume_each(self, n):
        self._consumed = int(n)

    def add_item_tag(self, port, offset, key, value):
        self.tags.append(_Tag(offset, key, value))

    def set_tag_propagation_policy(self, p):
        pass

    def set_relative_rate(self, r):
        self._relative_rate = r

    def set_max_output_buffer(self, n):
        self._max_out_buf = n

    def get_tags_in_window(self, *a, **kw):
        return []

    def stop(self):
        return True


class basic_block(_Block):
    pass


class sync_block(_Block):
    pass


class interp_block(_Block):
    def __init__(self, name='block', in_sig=None, out_sig=None, interp=1, **kw):
        _Block.__init__(self, name=name, in_sig=in_sig, out_sig=out_sig)
        self.interp = interp


class decim_block(_Block):
    def __init__(self, name='block', in_sig=None, out_sig=None, decim=1, **kw):
        _Block.__init__(self, name=name, in_sig=in_sig, out_sig=out_sig)
        self.decim = decim


class _GrModule:
    basic_block = basic_block
    sync_block = sync_block
    interp_block = interp_block
    decim_block = decim_block
    TPP_DONT = 0
    TPP_ALL_TO_ALL = 1
    GR_MSB_FIRST = 0
    GR_LSB_FIRST = 1

    class log_levels:
        info = 'info'


gr = _GrModule()
