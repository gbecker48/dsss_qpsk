"""Unit tests for dsss_fec.py - run before anything depends on it."""
import os
import sys
import time
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import dsss_fec as F

rng = np.random.default_rng(1234)
FAIL = []


def check(name, cond, extra=""):
    status = "ok  " if cond else "FAIL"
    if not cond:
        FAIL.append(name)
    print("  [%s] %s %s" % (status, name, extra))


print("=== GF(256) field ===")
# every nonzero element has a unique log, and exp/log invert
vals = np.arange(1, 256, dtype=np.uint8)
check("log/exp roundtrip", all(int(F._GF_EXP[F._GF_LOG[v]]) == int(v) for v in vals))
check("mul commutes", int(F.gf_mul(7, 13)) == int(F.gf_mul(13, 7)))
check("mul/div inverse", all(int(F.gf_div(F.gf_mul(a, b), b)) == int(a)
                             for a in (0, 1, 5, 200) for b in (1, 3, 77, 255)))
check("inv correct", all(int(F.gf_mul(v, F.gf_inv(int(v)))) == 1 for v in vals))
check("distributive",
      int(F.gf_mul(5, 9)) ^ int(F.gf_mul(5, 12)) == int(F.gf_mul(5, 9 ^ 12)))
# alpha has order 255
check("alpha order 255", F.gf_pow(2, 255) == 1 and
      all(F.gf_pow(2, k) != 1 for k in range(1, 255)))

print("\n=== Reed-Solomon (255,223) ===")
gen = F.RS_GEN
check("generator degree 32", len(gen) - 1 == 32, "(len=%d)" % len(gen))
# every root alpha^0..alpha^31 must zero the generator
roots_ok = all(F.gf_poly_eval(gen, F.gf_pow(2, i + F.RS_FCR)) == 0
               for i in range(32))
check("generator has 32 consecutive roots", roots_ok)
check("no spurious roots outside the 32",
      sum(1 for i in range(255) if F.gf_poly_eval(gen, F.gf_pow(2, i)) == 0) == 32)

msg = bytes(rng.integers(0, 256, F.RS_K, dtype=np.uint8))
cw = F.rs_encode(msg)
check("codeword length 255", len(cw) == 255)
check("systematic (msg preserved)", cw[:F.RS_K] == msg)
dec, ncorr, ok = F.rs_decode(cw)
check("clean decode", dec == msg and ncorr == 0 and ok)

for nerr in (1, 5, 15, 16):
    worst = 0
    allok = True
    for trial in range(30):
        c = bytearray(F.rs_encode(bytes(rng.integers(0, 256, F.RS_K, dtype=np.uint8))))
        orig = bytes(c)
        pos = rng.choice(255, nerr, replace=False)
        for p in pos:
            e = int(rng.integers(1, 256))
            c[p] ^= e
        d, n, o = F.rs_decode(bytes(c))
        if not (o and d == orig[:F.RS_K]):
            allok = False
        worst = max(worst, n)
    check("corrects %2d errors" % nerr, allok, "(reported up to %d)" % worst)

# 17 errors is beyond t=16: must not silently return garbage as "ok"
undetected = 0
for trial in range(60):
    orig_msg = bytes(rng.integers(0, 256, F.RS_K, dtype=np.uint8))
    c = bytearray(F.rs_encode(orig_msg))
    pos = rng.choice(255, 17, replace=False)
    for p in pos:
        c[p] ^= int(rng.integers(1, 256))
    d, n, o = F.rs_decode(bytes(c))
    if o and d != orig_msg:
        undetected += 1
check("17 errors not miscorrected silently", undetected == 0,
      "(%d silent miscorrections / 60)" % undetected)

print("\n=== Convolutional code K=7 r=1/2 ===")
bits = rng.integers(0, 2, 500, dtype=np.uint8)
slow = F.cc_encode(bits)
fast = F.cc_encode_fast(bits)
check("fast encoder == reference encoder", np.array_equal(slow, fast),
      "(%d vs %d bits)" % (len(slow), len(fast)))
check("output length = 2*(n+6)", len(fast) == 2 * (len(bits) + 6))

# free distance check: a single input 1 should produce weight-10 output
imp = np.zeros(30, dtype=np.uint8); imp[0] = 1
check("dfree = 10 for impulse", int(F.cc_encode_fast(imp).sum()) == 10,
      "(weight=%d)" % int(F.cc_encode_fast(imp).sum()))

print("\n=== Soft Viterbi ===")
coded = F.cc_encode_fast(bits)
soft_clean = (1.0 - 2.0 * coded).astype(np.float32)
dec_bits, pm, nerr = F.viterbi_decode(soft_clean, n_info_bits=len(bits))
check("noiseless decode exact", np.array_equal(dec_bits, bits))
check("noiseless reports 0 channel errors", nerr == 0, "(got %d)" % nerr)

# deliberately corrupt a scattered handful of bits
soft_n = soft_clean.copy()
flip = rng.choice(len(soft_n), 25, replace=False)
soft_n[flip] *= -1
dec_bits, pm, nerr = F.viterbi_decode(soft_n, n_info_bits=len(bits))
check("corrects 25 scattered bit errors", np.array_equal(dec_bits, bits))
check("channel-error estimate matches injected", nerr == 25, "(got %d, injected 25)" % nerr)

# timing on a realistic frame
nb = 2 * F.RS_N * 8
big = rng.integers(0, 2, nb, dtype=np.uint8)
bigc = F.cc_encode_fast(big)
bigsoft = (1.0 - 2.0 * bigc).astype(np.float32) + rng.normal(0, 0.4, len(bigc)).astype(np.float32)
t0 = time.perf_counter()
db, _, _ = F.viterbi_decode(bigsoft, n_info_bits=nb)
dt = time.perf_counter() - t0
check("frame-size decode correct", np.array_equal(db, big))
print("       -> %d info bits decoded in %.1f ms (%.0f bits/s sustained)"
      % (nb, dt * 1e3, nb / dt))

print("\n=== Interleavers ===")
n = 8172
perm, inv = F.interleaver_perm(n)
check("permutation is a bijection", len(np.unique(perm)) == n)
check("interleave/deinterleave roundtrip",
      np.array_equal(F.deinterleave(F.interleave(np.arange(n))), np.arange(n)))
# how far apart are bits that were adjacent on air?
sep = np.abs(np.diff(inv))
sep = np.minimum(sep, n - sep)
check("min separation of air-adjacent bits > 100", sep.min() > 100,
      "(min=%d, median=%d)" % (sep.min(), int(np.median(sep))))

cws = bytes(rng.integers(0, 256, 2 * 255, dtype=np.uint8))
check("RS symbol interleave roundtrip",
      F.rs_symbol_deinterleave(F.rs_symbol_interleave(cws, 2), 2) == cws)

print("\n=== Scrambler / PRBS ===")
d = bytes(rng.integers(0, 256, 446, dtype=np.uint8))
check("scramble self-inverse", F.descramble(F.scramble(d)) == d)
check("scramble changes data", F.scramble(d) != d)
p = F.prbs15(446)
check("prbs deterministic", p == F.prbs15(446))
check("prbs roughly balanced",
      0.45 < np.unpackbits(np.frombuffer(p, np.uint8)).mean() < 0.55,
      "(ones fraction %.3f)" % np.unpackbits(np.frombuffer(p, np.uint8)).mean())

print("\n=== Whole-frame encode/decode ===")
NCW = 2
body = bytes(rng.integers(0, 256, F.frame_body_bytes(NCW), dtype=np.uint8))
air = F.encode_frame(body, NCW)
check("coded length matches formula", len(air) == F.coded_bits_per_frame(NCW),
      "(%d bits)" % len(air))
soft = (1.0 - 2.0 * air).astype(np.float32)
out, st = F.decode_frame(soft, NCW)
check("clean frame roundtrip", out == body and st['ok'])
check("clean frame reports zero errors",
      st['chan_bit_errors'] == 0 and st['rs_total_corrected'] == 0)

# A burst error: exactly the Viterbi failure mode RS is there to absorb.
for burst in (40, 120, 300):
    a = air.copy()
    start = 2000
    a[start:start + burst] ^= 1
    s = (1.0 - 2.0 * a).astype(np.float32)
    out, st = F.decode_frame(s, NCW)
    check("survives a %d-bit on-air burst" % burst, out == body and st['ok'],
          "(RS corrected %s, margin %d)" % (st['rs_corrected'], st['rs_margin']))

print("\n" + "=" * 60)
if FAIL:
    print("FAILURES (%d): %s" % (len(FAIL), ", ".join(FAIL)))
    sys.exit(1)
print("ALL FEC TESTS PASSED")
