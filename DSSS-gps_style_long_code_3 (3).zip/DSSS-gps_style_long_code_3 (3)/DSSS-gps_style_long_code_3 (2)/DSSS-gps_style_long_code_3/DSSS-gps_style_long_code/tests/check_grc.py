"""Validate the rewritten flowgraph without needing GNU Radio.

Checks that every connection names a real block and a real port on that
block, that port directions and data types agree, that no variable
references something that was deleted, and that every embedded block's
declared parameters match its actual constructor signature."""
import ast
import inspect
import os
import re
import sys

import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
GRC = os.path.join(HERE, 'deploy', 'dsss_bpsk_usrp.grc')

FAIL = []


def check(name, cond, extra=""):
    if not cond:
        FAIL.append(name)
    print("  [%s] %s %s" % ("ok  " if cond else "FAIL", name, extra))


with open(GRC) as fh:
    doc = yaml.safe_load(fh)

blocks = {b['name']: b for b in doc['blocks']}
conns = doc['connections']

# Ports for the stock blocks the flowgraph still uses.
STOCK = {
    'usrp_sink':        (['0'], ['async_msgs']),
    'usrp_source':      ([], ['0', 'async_msgs']),
    'tx_rrc':           (['0'], ['0']),
    'rx_mf':            (['0'], ['0']),
    'costas':           (['0'], ['0']),
    'chunks_to_symbols': (['0'], ['0']),
    'mag_conv':         (['0'], ['0']),
    'gui_tx_time':      (['0'], []),
    'gui_before_freq':  (['0'], []),
    'gui_before_waterfall': (['0'], []),
    'gui_after_const':  (['0'], []),
    'gui_corr_mag':     (['0'], []),
    'net_tx_in':        (['pdus'], ['pdus']),
    'net_rx_data':      (['pdus'], ['pdus']),
    'net_rx_status':    (['pdus'], ['pdus']),
    'net_diag':         (['pdus'], ['pdus']),
    'net_ctrl_in':      (['pdus'], ['pdus']),
    'msgpair_node':     (['inpair'], []),
    'msgpair_dest':     (['inpair'], []),
}


def epy_ports(block):
    cache = block['states'].get('_io_cache', '')
    if not cache:
        return None
    label, cls, params, ins, outs, doc_, settable = ast.literal_eval(cache)
    return ([p[0] for p in ins], [p[0] for p in outs], params, settable)


print("=== Blocks referenced by connections all exist ===")
missing = sorted({n for c in conns for n in (c[0], c[2]) if n not in blocks})
check("no connection references a deleted block", not missing, str(missing))

print("\n=== Every connection endpoint is a real port ===")
bad = []
for src, sp, dst, dp in conns:
    for name, port, want_out in ((src, sp, True), (dst, dp, False)):
        blk = blocks.get(name)
        if blk is None:
            continue
        if blk['id'] == 'epy_block':
            info = epy_ports(blk)
            if info is None:
                continue
            ins, outs, _, _ = info
            have = outs if want_out else ins
        elif name in STOCK:
            ins, outs = STOCK[name]
            have = outs if want_out else ins
        else:
            continue
        if port not in have:
            bad.append("%s.%s (%s) not in %s"
                       % (name, port, 'out' if want_out else 'in', have))
check("all ports resolve", not bad, "\n      " + "\n      ".join(bad) if bad else "")

print("\n=== Embedded block parameters match their constructors ===")
sys.path.insert(0, os.path.join(HERE, 'grmock'))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, 'blocks'))
prob = []
for name, blk in sorted(blocks.items()):
    if blk['id'] != 'epy_block':
        continue
    src = blk['parameters'].get('_source_code', '')
    ns = {}
    try:
        exec(compile(src, name, 'exec'), ns)
    except Exception as exc:
        prob.append("%s: source does not import (%s)" % (name, exc))
        continue
    cls = ns.get('blk')
    if cls is None:
        prob.append("%s: no class named blk" % name)
        continue
    sig = set(inspect.signature(cls.__init__).parameters) - {'self'}
    given = {k for k in blk['parameters']
             if not k.startswith('_') and k not in
             ('affinity', 'alias', 'comment', 'maxoutbuf', 'minoutbuf')}
    extra = given - sig
    if extra:
        prob.append("%s: flowgraph passes %s which __init__ does not accept"
                    % (name, sorted(extra)))
    cached = epy_ports(blk)
    if cached:
        cparams = {p[0] for p in cached[2]}
        if cparams != sig:
            prob.append("%s: io_cache params %s != constructor %s"
                        % (name, sorted(cparams), sorted(sig)))
check("constructors accept what the flowgraph passes", not prob,
      "\n      " + "\n      ".join(prob) if prob else "")

print("\n=== No variable references a deleted name ===")
deleted = {'access_code_str', 'access_code_threshold', 'coded_bits',
           'fec_repeat', 'frame_bits', 'frame_body_bytes',
           'frame_capture_bits', 'strobe_period_ms', 'symbols_per_frame',
           'tx_pace_margin_pct', 'node_prn_table', 'frag_header_bytes',
           'prn_taps'}
dangling = []
for name, blk in blocks.items():
    for k, v in blk['parameters'].items():
        if k.startswith('_') or not isinstance(v, str):
            continue
        for tok in re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', v):
            if tok in deleted:
                dangling.append("%s.%s references deleted %r" % (name, k, tok))
check("no dangling references", not dangling,
      "\n      " + "\n      ".join(sorted(set(dangling))) if dangling else "")

print("\n=== Signal path is complete and acyclic end to end ===")
stream = [(c[0], c[2]) for c in conns if c[1].isdigit()]
adj = {}
for a, b in stream:
    adj.setdefault(a, []).append(b)


def reaches(start, goal, seen=None):
    seen = seen or set()
    if start == goal:
        return True
    if start in seen:
        return False
    seen.add(start)
    return any(reaches(n, goal, seen) for n in adj.get(start, []))


check("TX source reaches the USRP sink",
      reaches('tx_frame_source', 'usrp_sink'))
check("USRP source reaches the frame decoder",
      reaches('usrp_source', 'rx_frame_decoder'))
check("spreading happens on the TX path",
      reaches('tx_frame_source', 'dsss_spreader') and
      reaches('dsss_spreader', 'usrp_sink'))
check("despreading happens before carrier recovery",
      reaches('dsss_despreader', 'costas') and
      not reaches('costas', 'dsss_despreader'))

print("\n=== The push-based transmit chain is really gone ===")
gone = ['idle_strobe', 'tx_scheduler', 'pkt_framer', 'pdu2tagged',
        'access_corr', 'pkt_capture', 'pkt_deframer', 'diff_enc', 'diff_dec',
        'fec_encoder', 'fec_decoder', 'slicer']
still = [g for g in gone if g in blocks]
check("no timer or push-chain block remains", not still, str(still))
check("no message_strobe of any kind",
      not any(b['id'] == 'blocks_message_strobe' for b in doc['blocks']))

print("\n=== Key settings ===")
vals = {n: b['parameters'].get('value')
        for n, b in blocks.items() if b['id'] == 'variable'}
check("chip rate 2.046 Mcps", vals.get('chip_rate') == '2046000.0',
      "(%s)" % vals.get('chip_rate'))
check("4 samples per chip", vals.get('sps') == '4')
check("sample rate 8.184 Msps",
      abs(float(vals['chip_rate']) * int(vals['sps']) - 8184000) < 1,
      "(%.3f Msps)" % (float(vals['chip_rate']) * int(vals['sps']) / 1e6))
check("clock source is a parameter", 'clock_source' in vals,
      "(%s)" % vals.get('clock_source'))
check("UHD buffering configured",
      'num_recv_frames' in (vals.get('usrp_dev_args') or ''))
check("detection mode is a parameter", 'detect_mode' in vals,
      "(%s)" % vals.get('detect_mode'))
check("code length still a variable", 'code_len' in vals,
      "(%s)" % vals.get('code_len'))

print("\n" + "=" * 62)
if FAIL:
    print("FAILURES (%d): %s" % (len(FAIL), ", ".join(FAIL)))
    sys.exit(1)
print("FLOWGRAPH VALIDATION PASSED")
