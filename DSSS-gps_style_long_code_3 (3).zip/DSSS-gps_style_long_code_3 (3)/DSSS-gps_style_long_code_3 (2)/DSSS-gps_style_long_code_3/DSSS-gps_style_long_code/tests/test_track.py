"""Despreader tests: acquisition, tracking through clock drift, CDMA
rejection, buried-in-noise recovery, and the CPU cost that was the whole
point of the rewrite."""
import os
import sys
import time
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import dsss_codes as CODES
from dsss_track import CodeTracker

FAIL = []


def check(name, cond, extra=""):
    if not cond:
        FAIL.append(name)
    print("  [%s] %s %s" % ("ok  " if cond else "FAIL", name, extra))


rng = np.random.default_rng(404)


def make_signal(nsym, code_len, node=0, offset=0, drift_ppm=0.0,
                snr_db=None, seed=1):
    """QPSK symbols spread by a node's Gold code, with optional sample
    clock drift and noise added at CHIP level."""
    r = np.random.default_rng(seed)
    code = CODES.gold_code(code_len, node)
    syms = np.exp(1j * (np.pi / 4 + r.integers(0, 4, nsym) * np.pi / 2)
                  ).astype(np.complex64)
    chips = (np.repeat(syms, code_len) * np.tile(code, nsym)).astype(np.complex64)

    if drift_ppm:
        # Resample to emulate a sample-clock difference between the ends.
        n = len(chips)
        src = np.arange(n) * (1.0 + drift_ppm * 1e-6)
        keep = src < n - 1
        src = src[keep]
        i0 = src.astype(int)
        f = (src - i0).astype(np.float32)
        chips = ((1 - f) * chips[i0] + f * chips[i0 + 1]).astype(np.complex64)

    if offset:
        chips = np.concatenate([
            (r.normal(0, 0.01, offset) + 1j * r.normal(0, 0.01, offset)
             ).astype(np.complex64), chips])

    if snr_db is not None:
        p = float(np.mean(np.abs(chips) ** 2))
        npow = p / (10 ** (snr_db / 10.0))
        chips = (chips + r.normal(0, np.sqrt(npow / 2), len(chips))
                 + 1j * r.normal(0, np.sqrt(npow / 2), len(chips))
                 ).astype(np.complex64)
    return chips, syms


def run(tracker, chips, chunk=40000):
    """Feed a tracker in chunks, the way GNU Radio would."""
    got = []
    base = 0
    buf = chips
    while True:
        avail = len(buf)
        if avail < tracker.code_len * 2 + 4:
            break
        take = min(chunk, avail)
        seg = buf[:take]
        if not tracker.acquired:
            used = tracker.acquire(seg, base)
            if not tracker.acquired:
                if used <= 0:
                    break
                base += used
                buf = buf[used:]
                continue
        syms, consumed = tracker.track(seg, base, take // tracker.code_len + 1)
        if len(syms):
            got.append(syms)
        if consumed <= 0:
            if take >= avail:
                break
            consumed = tracker.code_len
        base += consumed
        buf = buf[consumed:]
    return np.concatenate(got) if got else np.zeros(0, dtype=np.complex64)


print("=== Acquisition ===")
for code_len in (127, 511, 1023):
    chips, syms = make_signal(300, code_len, offset=137, seed=3)
    t = CodeTracker(code_len=code_len, node_id=0)
    out = run(t, chips)
    check("len=%-4d acquires and despreads" % code_len,
          t.acquired and len(out) > 200,
          "(%d symbols, %d acquisitions, margin %.1f dB)"
          % (len(out), t.acquisitions, t.margin_db))
    # despread symbols must be clean QPSK: constant magnitude ~code_len
    if len(out) > 50:
        mags = np.abs(out[10:])
        check("len=%-4d correlation peak ~= code_len" % code_len,
              abs(mags.mean() / code_len - 1.0) < 0.05,
              "(mean |corr| = %.0f, expected %d)" % (mags.mean(), code_len))

print("\n=== Tracking through sample-clock drift ===")
# Note on what is and is not achievable here: the despreader sees one
# sample per chip, so alignment can only ever be an integer number of
# chips. While a drifting clock carries the true alignment across a
# half-chip boundary the correlation genuinely halves - that is the
# sampling geometry, not a tracking failure, and it is why the test below
# asserts on the MEAN correlation and on lock being retained rather than
# on an instantaneous floor. (Despreading at two samples per chip would
# halve that worst-case loss, at twice the correlation cost.)
#
# 2 ppm is already far worse than two oscillators sharing a 10 MHz
# reference; 50 ppm is absurd, and is here to show the discriminator
# genuinely follows rather than merely surviving.
for ppm in (0.0, 2.0, 20.0, 50.0, -20.0):
    nsym = 600
    chips, syms = make_signal(nsym, 1023, offset=91, drift_ppm=ppm, seed=7)
    t = CodeTracker(code_len=1023, node_id=0)
    out = run(t, chips)
    mags = np.abs(out[5:]) if len(out) > 20 else np.array([0.0])
    # The faster the drift, the more of the run is spent crossing
    # half-chip boundaries where the correlation necessarily dips, so the
    # acceptable mean scales with how extreme the scenario is.
    floor_frac = 0.70 if abs(ppm) <= 20 else 0.55
    mean_ok = mags.mean() > floor_frac * 1023
    expect = abs(ppm) * 1e-6 * nsym * 1023        # chips of drift over the run
    tracked = t.phase_corrections >= 0.5 * expect
    check("drift %+6.1f ppm: lock held and followed" % ppm,
          t.acquired and len(out) > 400 and mean_ok and tracked,
          "(%d syms, mean |corr| %.0f/%d, %d corrections vs %.0f chips drift)"
          % (len(out), mags.mean(), 1023, t.phase_corrections, expect))

print("\n=== Buried under the noise floor ===")
for chip_snr in (-10, -20, -25, -28):
    chips, syms = make_signal(400, 1023, offset=55, snr_db=chip_snr, seed=11)
    t = CodeTracker(code_len=1023, node_id=0)
    out = run(t, chips)
    ok = t.acquired and len(out) > 250
    check("chip SNR %4d dB: recovered" % chip_snr, ok,
          "(%d symbols, measured margin %.1f dB, ideal %.1f dB)"
          % (len(out), t.margin_db, t.ideal_gain_db))

print("\n=== CDMA: a different node's code must NOT despread ===")
chips, syms = make_signal(300, 1023, node=0, offset=40, seed=13)
t_right = CodeTracker(code_len=1023, node_id=0)
out_right = run(t_right, chips)
t_wrong = CodeTracker(code_len=1023, node_id=5)
out_wrong = run(t_wrong, chips)
right_mag = float(np.abs(out_right[5:]).mean()) if len(out_right) > 10 else 0
wrong_mag = float(np.abs(out_wrong[5:]).mean()) if len(out_wrong) > 10 else 0
check("matching code despreads strongly", right_mag > 900,
      "(|corr| = %.0f)" % right_mag)
check("mismatched code stays at sidelobe level",
      wrong_mag < 0.15 * 1023,
      "(|corr| = %.0f, %.1f dB below)" % (
          wrong_mag, 20 * np.log10(right_mag / max(wrong_mag, 1e-9))))

print("\n=== Switching node code drops lock immediately ===")
t = CodeTracker(code_len=1023, node_id=0)
run(t, chips)
was = t.acquired
t.set_node(7)
check("lock dropped on code change", was and not t.acquired)

print("\n=== CPU cost (the point of the rewrite) ===")
for code_len, symrate, label in ((1023, 2000, "1023 @ 2.046 Mcps"),
                                 (511, 4004, "511"),
                                 (127, 16110, "127"),
                                 (63, 32476, "63")):
    nsym = 2000
    chips, _ = make_signal(nsym, code_len, seed=17)
    t = CodeTracker(code_len=code_len, node_id=0)
    run(t, chips[:code_len * 3])                 # warm up / acquire
    t2 = CodeTracker(code_len=code_len, node_id=0)
    t0 = time.perf_counter()
    out = run(t2, chips)
    dt = time.perf_counter() - t0
    per = dt / max(1, len(out))
    load = 100.0 * symrate * per
    check("len=%-4d CPU load under 25%% of a core" % code_len, load < 25.0,
          "(%.2f us/symbol -> %.2f%% of a core at %d sym/s)"
          % (per * 1e6, load, symrate))

print("\n" + "=" * 60)
if FAIL:
    print("FAILURES (%d): %s" % (len(FAIL), ", ".join(FAIL)))
    sys.exit(1)
print("ALL DESPREADER TESTS PASSED")
