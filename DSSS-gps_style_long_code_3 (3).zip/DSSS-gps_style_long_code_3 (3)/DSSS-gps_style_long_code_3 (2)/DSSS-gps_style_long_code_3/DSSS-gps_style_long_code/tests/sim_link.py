"""
End-to-end link simulation - no GNU Radio, no hardware.

Builds the complete transmit chain, pushes it through an AWGN channel
(optionally with real DSSS spreading and a frequency/phase offset), runs
the complete receive chain, and reports frame error rate, bit error rates
before and after FEC, and how much of the Reed-Solomon budget is being
consumed.

The point is to establish, independently of GNU Radio, that
  (a) the coding chain actually closes near the concatenated-code limit,
  (b) the metrics the link reports are truthful, and
  (c) the despreader recovers a signal genuinely buried under the noise.
"""
import argparse
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import dsss_fec as FEC
import dsss_frame as FR
import dsss_codes as CODES


# ---------------------------------------------------------------------------
# Transmit chain
# ---------------------------------------------------------------------------

def tx_symbols(frames_bits, mode=FR.MODE_COHERENT, diff_state=0):
    """Gray-map and modulate a bit stream.

    In differential mode the Gray dibit becomes a phase *increment*
    (what digital.diff_encoder_bb(4) does in the flowgraph); in coherent
    mode it indexes the constellation directly."""
    dibits = FR.bits_to_gray_dibits(frames_bits).astype(np.int64)
    if mode == FR.MODE_DIFFERENTIAL:
        # d[k] = (d[k-1] + g[k]) mod 4, running continuously across frames
        d = (np.cumsum(dibits) + diff_state) % 4
        state = int(d[-1]) if len(d) else diff_state
    else:
        d = dibits
        state = diff_state
    sym = np.exp(1j * (np.pi / 4 + d * (np.pi / 2))).astype(np.complex64)
    return sym, state


def spread(symbols, code):
    return (np.repeat(symbols, len(code))
            * np.tile(code, len(symbols))).astype(np.complex64)


def despread(chips, code):
    n = len(chips) // len(code)
    blocks = chips[:n * len(code)].reshape(n, len(code))
    return (blocks @ code).astype(np.complex64) / np.sqrt(len(code))


# ---------------------------------------------------------------------------
# Channel
# ---------------------------------------------------------------------------

def awgn(x, snr_db, rng):
    sig_p = float(np.mean(np.abs(x) ** 2))
    n_p = sig_p / (10 ** (snr_db / 10.0))
    noise = (rng.normal(0, np.sqrt(n_p / 2), len(x))
             + 1j * rng.normal(0, np.sqrt(n_p / 2), len(x)))
    return (x + noise).astype(np.complex64)


# ---------------------------------------------------------------------------
# Receive chain
# ---------------------------------------------------------------------------

def rx_frames(symbols, n_cw, mode=FR.MODE_COHERENT, chunk=4096):
    """Run the shared FrameScanner over a symbol stream.

    Fed in chunks rather than all at once, so the simulation exercises the
    same incremental, stateful path the live receive block uses - buffer
    carry-over, lock prediction and all."""
    scanner = FR.FrameScanner(n_cw=n_cw, mode=mode)
    results = []
    for i in range(0, len(symbols), chunk):
        results.extend(scanner.feed(symbols[i:i + chunk]))
    return results, scanner


# ---------------------------------------------------------------------------
# Experiments
# ---------------------------------------------------------------------------

def run_point(ebno_db, n_frames, n_cw, rng, spreading=False, code_len=1023,
              freq_off_hz=0.0, phase_off=0.0, symbol_rate=2000.0,
              mode=FR.MODE_COHERENT):
    pay_len = FR.payload_bytes(n_cw)
    rate = FR.code_rate(n_cw)

    payloads = [bytes(rng.integers(0, 256, pay_len, dtype=np.uint8))
                for _ in range(n_frames)]
    by_seq = {i & 0xFF: p for i, p in enumerate(payloads)}
    bits = np.concatenate([FR.build_frame_bits(i & 0xFF, p, n_cw)
                           for i, p in enumerate(payloads)])
    # a little lead-in so the first frame is not at sample zero, which is
    # also what a real receiver sees when it joins a continuous stream
    bits = np.concatenate([np.zeros(64, dtype=np.uint8), bits])

    sym, _ = tx_symbols(bits, mode)

    # Es/N0 = Eb/N0 * (bits per symbol) * (code rate)
    esno_db = ebno_db + 10 * np.log10(2.0 * rate)

    if spreading:
        code = CODES.gold_code(code_len, 0)
        chips = spread(sym, code)
        # Spreading divides the energy across code_len chips, so per-chip
        # SNR sits code_len below the symbol SNR - this is exactly the
        # "buried under the noise floor" condition.
        chip_snr_db = esno_db - 10 * np.log10(code_len)
        noisy = awgn(chips, chip_snr_db, rng)
        rx = despread(noisy, code)
    else:
        chip_snr_db = esno_db
        rx = awgn(sym, esno_db, rng)

    if freq_off_hz or phase_off:
        t = np.arange(len(rx)) / symbol_rate
        rx = (rx * np.exp(1j * (2 * np.pi * freq_off_hz * t + phase_off))
              ).astype(np.complex64)

    results, scanner = rx_frames(rx, n_cw, mode)

    found = len(results)
    crc_ok = 0
    correct = 0
    payload_bit_errors = 0
    total_payload_bits = 0
    chan_errors = 0
    chan_bits = 0
    rs_corr_total = 0
    rs_worst = 0
    rs_uncorr = 0

    for res in results:
        st = res['stats']
        chan_errors += st['chan_bit_errors']
        chan_bits += st['coded_bits']
        rs_corr_total += st['rs_total_corrected']
        rs_worst = max(rs_worst, st['rs_worst_cw'])
        rs_uncorr += st['rs_uncorrectable']
        payload = res['payload']
        if payload is None:
            continue
        crc_ok += 1
        want = by_seq.get(res['seq'])
        if want is None:
            continue
        if payload == want:
            correct += 1
        a = np.unpackbits(np.frombuffer(payload, dtype=np.uint8))
        b = np.unpackbits(np.frombuffer(want, dtype=np.uint8))
        payload_bit_errors += int(np.count_nonzero(a ^ b))
        total_payload_bits += len(a)

    return {
        'ebno': ebno_db,
        'esno': esno_db,
        'chip_snr': chip_snr_db,
        'sent': n_frames,
        'found': found,
        'crc_ok': crc_ok,
        'correct': correct,
        'fer': 1.0 - (correct / float(n_frames)),
        'pre_fec_ber': chan_errors / float(chan_bits) if chan_bits else 0.0,
        'post_fec_ber': (payload_bit_errors / float(total_payload_bits)
                         if total_payload_bits else 0.0),
        'rs_mean': rs_corr_total / float(max(1, found * n_cw)),
        'rs_worst': rs_worst,
        'rs_uncorr': rs_uncorr,
        'false_sync': scanner.false_sync,
        'resyncs': scanner.resyncs,
    }


def sweep(args):
    n_cw = args.codewords
    print("Frame geometry: %d RS codeword(s), %d body bytes, %d payload bytes, "
          "%d on-air bits (%d symbols), overall rate %.4f"
          % (n_cw, FR.body_bytes(n_cw), FR.payload_bytes(n_cw),
             FR.frame_bits(n_cw), FR.frame_symbols(n_cw), FR.code_rate(n_cw)))
    if args.spread:
        print("Spreading: %s" % CODES.describe(args.code_len))
    print("Detection: %s%s" % (args.mode,
                               "   (freq offset %.1f Hz, phase %.2f rad)"
                               % (args.freq_off, args.phase_off)
                               if (args.freq_off or args.phase_off) else ""))
    print()
    header = ("  Eb/N0   Es/N0  chipSNR  frames  good     FER    pre-FEC BER  "
              " post-FEC BER   RS avg/worst  uncorr  falsesync")
    print(header)
    print("  " + "-" * (len(header) - 2))

    rows = []
    for ebno in args.ebno:
        rng = np.random.default_rng(args.seed)
        r = run_point(ebno, args.frames, n_cw, rng,
                      spreading=args.spread, code_len=args.code_len,
                      freq_off_hz=args.freq_off, phase_off=args.phase_off,
                      mode=args.mode)
        rows.append(r)
        print("  %5.1f  %6.2f  %7.1f  %6d  %4d  %6.4f   %.3e      %.3e"
              "     %4.1f/%-2d     %3d     %4d"
              % (r['ebno'], r['esno'], r['chip_snr'], r['found'], r['correct'],
                 r['fer'], r['pre_fec_ber'], r['post_fec_ber'], r['rs_mean'],
                 r['rs_worst'], r['rs_uncorr'], r['false_sync']))
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--ebno', type=float, nargs='+',
                    default=[1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 5.0])
    ap.add_argument('--frames', type=int, default=30)
    ap.add_argument('--codewords', type=int, default=2)
    ap.add_argument('--spread', action='store_true')
    ap.add_argument('--code-len', type=int, default=1023)
    ap.add_argument('--mode', default=FR.MODE_COHERENT,
                    choices=[FR.MODE_COHERENT, FR.MODE_DIFFERENTIAL])
    ap.add_argument('--freq-off', type=float, default=0.0)
    ap.add_argument('--phase-off', type=float, default=0.0)
    ap.add_argument('--seed', type=int, default=2024)
    args = ap.parse_args()
    t0 = time.time()
    sweep(args)
    print("\n(%.1f s)" % (time.time() - t0))


if __name__ == '__main__':
    main()
