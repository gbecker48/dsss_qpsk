"""Transfer-layer tests: header packing, text reassembly, and real
multi-megabyte file transfer through a lossy simulated link."""
import os
import shutil
import sys
import tempfile
import time
import hashlib
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import dsss_transfer as T

FAIL = []


def check(name, cond, extra=""):
    if not cond:
        FAIL.append(name)
    print("  [%s] %s %s" % ("ok  " if cond else "FAIL", name, extra))


PAYLOAD = 441                      # 2 RS codewords: 2*223 - 1(seq) - 4(crc)
CHUNK = T.chunk_bytes_for(PAYLOAD)  # 428

print("=== Wire header ===")
h = T.pack_header(3, 250, T.TYPE_FILE_DATA, 65535, 16777215, 1234567, 428)
check("header is 13 bytes", len(h) == 13)
u = T.unpack_header(h)
check("roundtrip exact",
      u == {'src': 3, 'dst': 250, 'type': 2, 'msg_id': 65535,
            'frag_idx': 16777215, 'frag_total': 1234567, 'chunk_len': 428},
      str(u))
check("24-bit index ceiling >= 7 GB",
      (T.MAX_FRAG_INDEX + 1) * CHUNK > 7e9,
      "(%.1f GB)" % ((T.MAX_FRAG_INDEX + 1) * CHUNK / 1e9))
check("chunk size", CHUNK == 428, "(%d bytes/fragment)" % CHUNK)

frag = T.make_fragment(PAYLOAD, 1, 2, T.TYPE_TEXT, 7, 0, 1, b'hello')
check("fragment padded to exact payload size", len(frag) == PAYLOAD)

print("\n=== Text messages ===")
tmp = tempfile.mkdtemp(prefix='dsss_test_')
tx = T.TxQueue(PAYLOAD, my_node_id=1, dest_node_id=2)
rx = T.RxReassembler(PAYLOAD, my_node_id=2, dest_node_id=1,
                     inbox=os.path.join(tmp, 'inbox'))

msg = b'the quick brown fox ' * 200      # 4000 bytes -> 10 fragments
tx.enqueue_text(msg)
time.sleep(0.4)

delivered = []
for _ in range(60):
    st, dl = rx.handle(tx.next_payload())
    delivered.extend(dl)
check("multi-fragment text reassembled", delivered and delivered[0] == msg,
      "(%d bytes)" % (len(delivered[0]) if delivered else 0))

# idle frames must keep flowing when nothing is queued
idles = [T.unpack_header(tx.next_payload())['type'] for _ in range(20)]
check("transmitter emits idle frames when queue is empty",
      all(t == T.TYPE_IDLE for t in idles))

print("\n=== next_payload() never blocks or fails ===")
t0 = time.perf_counter()
N = 20000
for _ in range(N):
    p = tx.next_payload()
    assert len(p) == PAYLOAD
dt = time.perf_counter() - t0
check("20k payloads produced without error", True,
      "(%.1f us each, %.0f frames/s ceiling)" % (dt / N * 1e6, N / dt))

print("\n=== Real file transfer (4 MB, clean link) ===")
src_dir = os.path.join(tmp, 'src')
os.makedirs(src_dir, exist_ok=True)
big = os.path.join(src_dir, 'payload.bin')
data = np.random.default_rng(7).integers(0, 256, 4 * 1024 * 1024,
                                         dtype=np.uint8).tobytes()
with open(big, 'wb') as fh:
    fh.write(data)
want_hash = hashlib.sha256(data).hexdigest()

tx2 = T.TxQueue(PAYLOAD, my_node_id=1, dest_node_id=2)
inbox = os.path.join(tmp, 'inbox2')
rx2 = T.RxReassembler(PAYLOAD, my_node_id=2, dest_node_id=1, inbox=inbox)
tx2.enqueue_file(big)

need = (len(data) + CHUNK - 1) // CHUNK + 4
lines = []
idle_seen = 0
t0 = time.perf_counter()
# Drain far faster than any radio would, so the loop also exercises the
# background reader keeping up with a consumer that never waits.
for _ in range(need * 6):
    p = tx2.next_payload()
    if T.unpack_header(p)['type'] == T.TYPE_IDLE:
        idle_seen += 1
    st, _ = rx2.handle(p)
    lines.extend(st)
    if any(l.startswith('FILEDONE') for l in st):
        break
dt = time.perf_counter() - t0

done = [l for l in lines if l.startswith('FILEDONE')]
check("file transfer completed", bool(done), done[0][:96] if done else "(no FILEDONE)")
check("sha256 verified end to end", bool(done) and 'verify=OK' in done[0])
got = [f for f in os.listdir(inbox) if not f.startswith('.')]
check("exactly one file landed in the inbox", len(got) == 1, str(got))
if got:
    with open(os.path.join(inbox, got[0]), 'rb') as fh:
        rd = fh.read()
    check("received bytes identical to source", rd == data,
          "(%d bytes)" % len(rd))
    check("filename preserved", got[0] == 'payload.bin', got[0])
check("no .part files left behind",
      not any(f.startswith('.incoming') for f in os.listdir(inbox)))
prog = [l for l in lines if l.startswith('FILEPROG')]
# Progress is throttled to at most 1% steps AND at most one line a second,
# so a transfer that finishes in under a second reports only its endpoints.
# What matters is that it always brackets the transfer and never spams.
check("progress reported without spamming",
      2 <= len(prog) <= 105 and any('pct=100.0' in l for l in prog),
      "(%d progress lines over %.2fs)" % (len(prog), dt))
print("       -> %d fragments moved in %.2f s; %d idle gaps while the "
      "reader caught up" % (need, dt, idle_seen))

print("\n=== Lossy link: 2%% of fragments dropped ===")
tx3 = T.TxQueue(PAYLOAD, my_node_id=1, dest_node_id=2)
inbox3 = os.path.join(tmp, 'inbox3')
rx3 = T.RxReassembler(PAYLOAD, my_node_id=2, dest_node_id=1, inbox=inbox3,
                      stale_seconds=1.0)
small = os.path.join(src_dir, 'small.bin')
sdata = np.random.default_rng(9).integers(0, 256, 300 * 1024,
                                          dtype=np.uint8).tobytes()
with open(small, 'wb') as fh:
    fh.write(sdata)
tx3.enqueue_file(small)
time.sleep(0.4)                     # let the reader prime, as a real slot would
rng = np.random.default_rng(11)
lines3 = []
nfrag = (len(sdata) + CHUNK - 1) // CHUNK + 4
for _ in range(nfrag * 6):
    p = tx3.next_payload()
    if rng.random() < 0.02:            # drop it, exactly like a CRC failure
        continue
    st, _ = rx3.handle(p)
    lines3.extend(st)
check("incomplete transfer does not complete or corrupt",
      not any(l.startswith('FILEDONE') for l in lines3))
# Let it go stale and be reported. Feed a synthetic idle frame rather than
# another real one - a real data fragment would refresh the activity clock,
# which is correct behaviour but would never let the timeout fire.
time.sleep(1.1)
idle = T.make_fragment(PAYLOAD, 1, 2, T.TYPE_IDLE, 0, 0, 0, b'')
st, _ = rx3.handle(idle)
# The timeout may legitimately have fired during the loop itself if the
# run took longer than stale_seconds, so accept it from either place.
inc = [l for l in (lines3 + st) if l.startswith('INCOMPLETE')]
check("lost fragments reported as INCOMPLETE, not hung", bool(inc),
      inc[0][:90] if inc else "(none)")
check("partial file cleaned up",
      not os.path.isdir(inbox3) or
      not any(f.startswith('.incoming') for f in os.listdir(inbox3)))

print("\n=== Addressing ===")
rx4 = T.RxReassembler(PAYLOAD, my_node_id=5, dest_node_id=1,
                      inbox=os.path.join(tmp, 'inbox4'))
st, dl = rx4.handle(T.make_fragment(PAYLOAD, 1, 9, T.TYPE_TEXT, 1, 0, 1, b'x'))
check("fragment for another node rejected as FOREIGN",
      any(l.startswith('FOREIGN') for l in st))
st, dl = rx4.handle(T.make_fragment(PAYLOAD, 1, 0xFF, T.TYPE_TEXT, 2, 0, 1, b'bx'))
check("broadcast accepted", dl == [b'bx'])
st, dl = rx4.handle(T.make_fragment(PAYLOAD, 3, 5, T.TYPE_TEXT, 3, 0, 1, b'y'))
check("unexpected source flagged with WARN",
      any(l.startswith('WARN') for l in st))

print("\n=== Filename safety ===")
check("path traversal neutralised",
      T._safe_name('../../etc/passwd') == 'etc_passwd' or
      '/' not in T._safe_name('../../etc/passwd'),
      "(-> %r)" % T._safe_name('../../etc/passwd'))
check("absolute path neutralised", '/' not in T._safe_name('/etc/shadow'),
      "(-> %r)" % T._safe_name('/etc/shadow'))
check("windows path neutralised", '\\' not in T._safe_name(r'C:\windows\x.dll'),
      "(-> %r)" % T._safe_name(r'C:\windows\x.dll'))
check("empty name gets a fallback", T._safe_name('') == 'unnamed.bin')

tx.stop(); tx2.stop(); tx3.stop()
shutil.rmtree(tmp, ignore_errors=True)

print("\n" + "=" * 60)
if FAIL:
    print("FAILURES (%d): %s" % (len(FAIL), ", ".join(FAIL)))
    sys.exit(1)
print("ALL TRANSFER TESTS PASSED")
