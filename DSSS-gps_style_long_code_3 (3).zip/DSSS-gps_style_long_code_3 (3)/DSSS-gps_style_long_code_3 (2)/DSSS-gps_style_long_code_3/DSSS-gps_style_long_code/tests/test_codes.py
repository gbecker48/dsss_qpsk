"""Verify the Gold code generator against the defining mathematical
properties, and prove the 1023-chip codes are unchanged from the original."""
import os
import sys
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import dsss_codes as C

FAIL = []


def check(name, cond, extra=""):
    if not cond:
        FAIL.append(name)
    print("  [%s] %s %s" % ("ok  " if cond else "FAIL", name, extra))


def circ_corr(a, b):
    fa, fb = np.fft.fft(a), np.fft.fft(b)
    return np.round(np.real(np.fft.ifft(fa * np.conj(fb)))).astype(int)


print("=== Backward compatibility: the 1023-chip codes must not change ===")
same = True
for node in range(16):
    new = C.gold_code(1023, node)
    old = C.legacy_gps_gold_code(1023, C.LEGACY_PRN_TAPS[node])
    if not np.array_equal(new, old):
        same = False
        print("      node %d DIFFERS" % node)
check("all 16 node codes identical to the original generator", same)

print("\n=== Per-length Gold code properties ===")
for code_len in C.SUPPORTED_CODE_LENGTHS:
    n = {63: 6, 127: 7, 511: 9, 1023: 10, 2047: 11}[code_len]
    t = 1 + (1 << ((n + 2) // 2))
    allowed = {-1, -t, t - 2}
    print("\n  -- code_len = %d (n=%d), expected 3-valued spectrum {-1, -%d, %d}"
          % (code_len, n, t, t - 2))

    c0 = C.gold_code(code_len, 0)
    check("length is exactly %d" % code_len, len(c0) == code_len)
    check("bipolar +-1 only", set(np.unique(c0).tolist()) == {-1.0, 1.0})

    # Every node's code must be balanced, not just node 0 - an unbalanced
    # code puts a DC/carrier spike in the transmitted spectrum.
    worst_imbalance = 0
    for node in range(16):
        c = C.gold_code(code_len, node)
        worst_imbalance = max(worst_imbalance, abs(int(c.sum())))
    check("all 16 node codes balanced", worst_imbalance <= 1,
          "(worst |sum| = %d chip)" % worst_imbalance)

    ac = circ_corr(c0, c0)
    check("autocorrelation peak = %d at zero shift" % code_len, ac[0] == code_len)
    off_peak = set(ac[1:].tolist())
    check("off-peak autocorrelation is 3-valued", off_peak <= allowed,
          "(values %s)" % sorted(off_peak))
    # The sidelobe floor is t(n) by theory, not an arbitrary target -
    # assert it matches what Gold-code theory predicts for this length.
    worst_side = max(abs(v) for v in off_peak)
    check("worst sidelobe is exactly the theoretical t(n)=%d" % t,
          worst_side == t,
          "(peak/sidelobe = %.1f dB)" % (20 * np.log10(code_len / worst_side)))

    # Cross-correlation between every pair of node codes must also be
    # 3-valued - this is what makes simultaneous multi-node CDMA work.
    worst = 0
    xc_ok = True
    for a in range(8):
        for b in range(a + 1, 8):
            xc = circ_corr(C.gold_code(code_len, a), C.gold_code(code_len, b))
            vals = set(xc.tolist())
            if not vals <= allowed:
                xc_ok = False
            worst = max(worst, max(abs(v) for v in vals))
    check("all node-pair cross-correlations 3-valued", xc_ok)
    check("cross-correlation suppression",
          20 * np.log10(code_len / worst) > 10,
          "(%.1f dB below the autocorrelation peak)" % (20 * np.log10(code_len / worst)))

    shifts = [C.node_shift(code_len, i) for i in range(16)]
    check("16 distinct node shifts", len(set(shifts)) == 16)

print("\n=== Rejected lengths ===")
for bad in (255, 511 + 1, 100):
    try:
        C.gold_code(bad, 0)
        check("rejects code_len=%d" % bad, False)
    except ValueError as e:
        check("rejects code_len=%d" % bad, True,
              "(%s...)" % str(e)[:52])

print("\n" + "=" * 60)
if FAIL:
    print("FAILURES (%d): %s" % (len(FAIL), ", ".join(FAIL)))
    sys.exit(1)
print("ALL GOLD CODE TESTS PASSED")
