"""
dsss_frame.py - framing, Gray/differential mapping and soft demodulation
========================================================================

The one definition of what a frame looks like on the air. Both the
transmit block and the receive blocks import this, so the two ends of the
link cannot drift apart.

Frame layout
------------
    [ SYNC  64 bits, uncoded ][ CODED BODY  2*(n_cw*255*8 + 6) bits ]

    body (before coding) = [ SEQ 1 ][ PAYLOAD n_cw*223-5 ][ CRC32 4 ]
                           \\________________ scrambled ___________/

With the default n_cw = 2 that is 446 body bytes, a 441-byte payload and
8236 on-air bits per frame.

The sync word stays uncoded and unscrambled, as before, because it has to
be something the receiver can search for before it can decode anything.
Everything after it now goes through the concatenated FEC in dsss_fec.py.

Why the modulation mapping changed
----------------------------------
The original chain mapped dibits straight through `diff_encoder_bb(4)`
into the DQPSK constellation, which made the differential phase increment
equal to the dibit value: 0, 1, 2, 3 -> 0, 90, 180, 270 degrees. That
mapping is *not* Gray coded. Looking at what arrives after differential
demodulation, z = y[k] * conj(y[k-1]):

    dibit 00 -> 0 deg      dibit 01 ->  90 deg
    dibit 10 -> 180 deg    dibit 11 -> 270 deg

the most significant bit is 1 for the 180 and 270 degree points, which is
a half-plane and fine - but the least significant bit is 1 for the 90 and
270 degree points, which are *opposite corners*. No straight line
separates them, so that bit has no well-defined soft value at all: the
best you can do is a hard decision, and neighbouring constellation points
differ in two bits at once, which costs real dB.

That was harmless when the FEC was a repetition code making hard
decisions anyway. It is not harmless now: soft-decision Viterbi is worth
about 2 dB over hard-decision, and it can only collect that if every coded
bit has a meaningful confidence attached. So a Gray permutation [0,1,3,2]
is applied to the dibit before differential encoding, which rotates the
received constellation into:

    00 ->   0 deg    01 ->  90 deg    11 -> 180 deg    10 -> 270 deg

Now adjacent points differ in exactly one bit, and both soft values fall
out as simple linear functions of the received sample:

    LLR(b0) = Re(z) + Im(z)        LLR(b1) = Re(z) - Im(z)

(positive meaning "bit is more likely 0"), which is just the constellation
read in a frame rotated 45 degrees. One extra permutation on transmit buys
the full soft-decision coding gain.

Differential encoding still runs *continuously* across frame boundaries,
never reset per frame - the transmitter is always on, so there is always a
previous symbol, and resetting would break the first dibit of every frame.
"""

import numpy as np

from dsss_fec import (crc32, scramble, descramble, encode_frame, decode_frame,
                      coded_bits_per_frame, frame_body_bytes, RS_K)

# 64-bit sync pattern - unchanged from the original design.
SYNC_WORD = bytes([171, 55, 105, 56, 188, 163, 8, 63])
SYNC_BITS = np.unpackbits(np.frombuffer(SYNC_WORD, dtype=np.uint8))
SYNC_NBITS = len(SYNC_BITS)
# +1 where the sync bit is 0, -1 where it is 1 - matches the soft-value
# convention, so a correlation against this peaks at correct alignment.
SYNC_BIPOLAR = (1.0 - 2.0 * SYNC_BITS).astype(np.float32)

# Gray permutation applied to the dibit before differential encoding.
# Self-inverse, so the same table undoes it.
GRAY_MAP = np.array([0, 1, 3, 2], dtype=np.uint8)

DEFAULT_RS_CODEWORDS = 2


# ---------------------------------------------------------------------------
# Sizing helpers - every other module derives its constants from these
# ---------------------------------------------------------------------------


def body_bytes(n_cw=DEFAULT_RS_CODEWORDS):
    return frame_body_bytes(n_cw)


def payload_bytes(n_cw=DEFAULT_RS_CODEWORDS):
    """Usable payload per frame: body minus SEQ and CRC32."""
    return frame_body_bytes(n_cw) - 5


def frame_bits(n_cw=DEFAULT_RS_CODEWORDS):
    return SYNC_NBITS + coded_bits_per_frame(n_cw)


def frame_symbols(n_cw=DEFAULT_RS_CODEWORDS):
    return frame_bits(n_cw) // 2


def code_rate(n_cw=DEFAULT_RS_CODEWORDS):
    """Overall rate including the uncoded sync word."""
    return (payload_bytes(n_cw) * 8) / float(frame_bits(n_cw))


# ---------------------------------------------------------------------------
# Transmit
# ---------------------------------------------------------------------------


def build_frame_bits(seq, payload, n_cw=DEFAULT_RS_CODEWORDS):
    """One complete frame's on-air bits, sync word included."""
    want = payload_bytes(n_cw)
    payload = bytes(payload)
    if len(payload) != want:
        raise ValueError("payload must be exactly %d bytes, got %d"
                         % (want, len(payload)))
    head = bytes([int(seq) & 0xFF])
    body = head + payload
    body = body + crc32(body).to_bytes(4, 'big')
    coded = encode_frame(scramble(body), n_cw)
    return np.concatenate([SYNC_BITS, coded]).astype(np.uint8)


def bits_to_gray_dibits(bits):
    """Pack bits MSB-first into dibits and apply the Gray permutation.

    The result feeds `digital.diff_encoder_bb(4)` and then
    `chunks_to_symbols`, exactly as before - only the permutation is new."""
    bits = np.asarray(bits, dtype=np.uint8).ravel()
    if len(bits) % 2:
        raise ValueError("bit count must be even")
    m = (bits[0::2] << 1) | bits[1::2]
    return GRAY_MAP[m]


# ---------------------------------------------------------------------------
# Receive
# ---------------------------------------------------------------------------


MODE_COHERENT = 'coherent'
MODE_DIFFERENTIAL = 'differential'


def soft_dqpsk(symbols, prev=None, eps=1e-12):
    """Differentially demodulate carrier-recovered QPSK into soft bits.

    Returns (soft_bits, last_symbol). Two soft values per symbol, in
    transmit order, using the convention that positive favours a 0 bit.

    Differential demodulation is robust to the Costas loop's four-fold
    phase ambiguity, because only the phase *change* between consecutive
    symbols carries data and any constant rotation cancels. It pays about
    2.5-3 dB for that robustness, since noise enters on both symbols of
    every difference - see MODE_COHERENT for the alternative.

    IMPORTANT: one symbol of history is required. On the very first call
    `prev` is None and the first symbol is consumed as the reference,
    producing one fewer symbol's worth of soft bits. Callers must carry
    the returned `last` back in as `prev` on the next call, or the stream
    silently loses a dibit at every boundary - which shifts the entire
    bit stream and destroys frame alignment."""
    symbols = np.asarray(symbols, dtype=np.complex64).ravel()
    if len(symbols) == 0:
        return np.zeros(0, dtype=np.float32), prev
    if prev is None:
        z = symbols[1:] * np.conj(symbols[:-1])
    else:
        chain = np.concatenate([np.asarray([prev], dtype=np.complex64),
                                symbols])
        z = chain[1:] * np.conj(chain[:-1])
    last = symbols[-1]

    # Normalise by the mean magnitude so soft-value scale is independent of
    # AGC/gain. Scale does not change the Viterbi argmax, but it keeps the
    # reported path metrics and sync correlations comparable over time.
    mag = float(np.mean(np.abs(z))) if len(z) else 0.0
    if mag > eps:
        z = z / mag

    out = np.empty(len(z) * 2, dtype=np.float32)
    out[0::2] = (np.real(z) + np.imag(z)).astype(np.float32)   # LLR(b0)
    out[1::2] = (np.real(z) - np.imag(z)).astype(np.float32)   # LLR(b1)
    return out, last


def soft_coherent(symbols, eps=1e-12):
    """Coherent soft demodulation of Gray-mapped QPSK.

    With the Gray permutation applied on transmit, the constellation is
    exp(j*(pi/4 + g*pi/2)) for Gray-mapped dibit g, which puts b0 on the
    sign of the imaginary axis and b1 on the sign of the real axis - one
    bit per axis, each with a proper confidence attached. No differential
    difference means no doubled noise, which is where the ~3 dB comes
    from.

    The caller is responsible for having removed the carrier phase; the
    four-fold ambiguity that leaves is resolved per frame from the sync
    word (see FrameScanner)."""
    symbols = np.asarray(symbols, dtype=np.complex64).ravel()
    if len(symbols) == 0:
        return np.zeros(0, dtype=np.float32)
    mag = float(np.mean(np.abs(symbols)))
    s = symbols / mag if mag > eps else symbols
    out = np.empty(len(s) * 2, dtype=np.float32)
    out[0::2] = np.imag(s).astype(np.float32)     # LLR(b0)
    out[1::2] = np.real(s).astype(np.float32)     # LLR(b1)
    return out


def rotate_soft(soft, k):
    """Soft bits as they would be for a symbol stream rotated by k*90 deg.

    Multiplying a symbol by j maps (Re, Im) -> (-Im, Re), so the soft pair
    (l0, l1) = (Im, Re) becomes (l1, -l0). Applying that rule repeatedly
    gives all four rotations without re-deriving them from the symbols,
    which makes testing all four candidate phases during sync search
    nearly free."""
    k &= 3
    if k == 0:
        return soft
    if len(soft) & 1:
        raise ValueError("rotate_soft needs symbol-aligned pairs "
                         "(even length, starting on an l0)")
    l0 = soft[0::2]
    l1 = soft[1::2]
    if k == 1:
        n0, n1 = l1, -l0
    elif k == 2:
        n0, n1 = -l0, -l1
    else:
        n0, n1 = -l1, l0
    out = np.empty_like(soft)
    out[0::2] = n0
    out[1::2] = n1
    return out


def track_phase(symbols, block=64, carry=0.0):
    """Decision-directed residual phase tracking.

    Raising a QPSK symbol to the fourth power collapses all four
    constellation points onto one, so the mean angle of the fourth power
    estimates the residual rotation without needing to know the data -
    the classic non-data-aided fold estimator.

    Two details matter a great deal in practice:

    **Interpolate, don't step.** An earlier version applied one constant
    correction per block. Against a constant residual frequency offset
    that leaves up to half a block's worth of drift uncorrected at the
    block edges, and measurement showed the link falling over at only 2 Hz
    of residual offset. Estimating the phase at each block centre and
    interpolating linearly between centres tracks a constant frequency
    error exactly, which is the case that actually occurs.

    **Unwrap in the fourth-power domain.** The fold estimator only returns
    an angle modulo 90 degrees, so a drift of more than 45 degrees between
    block centres is ambiguous. Unwrapping the 4x angles before dividing
    by four extends the range to a continuous trajectory, and the block
    size sets the ceiling: 64 symbols tolerates about +-0.0123 rad/symbol,
    which is roughly +-4 Hz at a 2000 symbol/s rate and scales up with
    the symbol rate at shorter code lengths.

    The Costas loop upstream is still expected to do the real frequency
    work; this cleans up what it leaves behind and resolves nothing about
    the 90-degree ambiguity, which the sync word settles per frame.

    Returns (derotated_symbols, carry); pass `carry` back in to keep the
    correction continuous across calls."""
    symbols = np.asarray(symbols, dtype=np.complex64)
    n = len(symbols)
    if n == 0:
        return symbols, carry
    block = max(8, int(block))
    nblocks = max(1, n // block)
    fold = np.exp(-1j * np.pi / 4)
    if nblocks < 3:
        # Too short to estimate a rate; just take one phase measurement.
        m = np.mean((symbols * fold) ** 4)
        if np.abs(m) > 1e-12:
            carry = _align_ambiguity(float(np.angle(m)) / 4.0, carry)
        return (symbols * np.exp(-1j * carry)).astype(np.complex64), carry

    folded = (symbols[:nblocks * block] * fold) ** 4
    means = folded.reshape(nblocks, block).mean(axis=1)

    # Frequency first, by averaging the rotation between consecutive block
    # means. Unwrapping a noisy per-block angle sequence was tried and is
    # actively dangerous here: at these SNRs the fourth-power angle jitters
    # enough that np.unwrap occasionally inserts a 2*pi step, which is a
    # 90-degree error in the symbol domain and destroys the rest of the
    # frame. Averaging m[k+1]*conj(m[k]) needs no unwrapping at all, and
    # averaging over every block pair drives the estimator noise down
    # instead of letting it accumulate.
    d = np.mean(means[1:] * np.conj(means[:-1]))
    w = 0.0
    if np.abs(d) > 1e-12:
        w = (float(np.angle(d)) / 4.0) / float(block)   # rad per symbol

    idx = np.arange(n, dtype=np.float64)
    derot = symbols * np.exp(-1j * w * idx)

    # Now the residual phase, block by block, on the de-ramped signal.
    # Doing the frequency first is what makes this second stage safe: the
    # block-to-block phase steps are now small, so unwrapping them cannot
    # jump a whole cycle the way it does when a raw frequency offset is
    # still marching the angle forward. A global constant phase alone was
    # tried instead and measurably lost frames on a clean channel, because
    # it cannot follow any residual wander at all.
    folded2 = (derot[:nblocks * block] * fold) ** 4
    means2 = folded2.reshape(nblocks, block).mean(axis=1)
    if nblocks >= 5:
        # Light smoothing of the complex means before taking angles: cuts
        # estimator jitter without biasing the phase.
        k = np.ones(3) / 3.0
        means2 = np.convolve(means2, k, mode='same')
    theta = np.unwrap(np.angle(means2)) / 4.0

    # Resolve the fold estimator's 90-degree ambiguity toward wherever the
    # previous chunk left off, so the correction never jumps at a call
    # boundary. Only whole multiples of pi/2 are added - the measurement
    # itself is never overridden, which an earlier version of this line
    # did, dragging every estimate to `carry` and wrecking the tracking.
    theta = theta + (_align_ambiguity(theta[0], carry) - theta[0])

    centres = (np.arange(nblocks) + 0.5) * block
    phase = np.interp(idx, centres, theta)

    out = (derot * np.exp(-1j * phase)).astype(np.complex64)
    return out, float(theta[-1]) + w * n


def _align_ambiguity(value, reference):
    """`value` shifted by whole multiples of pi/2 to sit nearest `reference`."""
    step = np.pi / 2.0
    return float(value + step * np.round((reference - value) / step))


def sync_correlate(soft):
    """Normalised sliding correlation of soft bits against the sync word.

    Returns an array the same length as the number of valid start
    positions; 1.0 is a perfect match, 0.0 is noise. Using the soft values
    rather than hard-sliced bits makes detection noticeably more reliable
    at low SNR, because a confidently-correct bit counts for more than a
    marginal one."""
    soft = np.asarray(soft, dtype=np.float32).ravel()
    n = len(soft) - SYNC_NBITS + 1
    if n <= 0:
        return np.zeros(0, dtype=np.float32)
    corr = np.correlate(soft, SYNC_BIPOLAR, mode='valid')
    energy = np.convolve(np.abs(soft), np.ones(SYNC_NBITS, dtype=np.float32),
                         mode='valid')
    with np.errstate(divide='ignore', invalid='ignore'):
        out = np.where(energy > 1e-9, corr / energy, 0.0)
    return out.astype(np.float32)[:n]


def decode_frame_soft(soft_body, n_cw=DEFAULT_RS_CODEWORDS):
    """Decode one frame's coded soft bits (sync word already stripped).

    Returns (seq, payload_or_None, stats). `stats` carries the full FEC
    report from dsss_fec.decode_frame plus the CRC result."""
    body, stats = decode_frame(soft_body, n_cw)
    stats['crc_ok'] = False
    stats['seq'] = -1
    if body is None:
        return -1, None, stats

    plain = descramble(body)
    crc_off = len(plain) - 4
    rx_crc = int.from_bytes(plain[crc_off:], 'big')
    if crc32(plain[:crc_off]) != rx_crc:
        stats['seq'] = plain[0]
        return plain[0], None, stats

    stats['crc_ok'] = True
    stats['seq'] = plain[0]
    return plain[0], plain[1:crc_off], stats


# ---------------------------------------------------------------------------
# Frame scanner
# ---------------------------------------------------------------------------


class FrameScanner:
    """Finds and decodes frames in a continuous symbol stream.

    Shared by the simulation and the live receive block so there is one
    implementation to get right and one to test.

    Two lessons are baked into how it searches:

    **A sync hit is a hypothesis, not a fact.** Correlating a 64-bit
    pattern against a noisy soft stream throws up spurious peaks -
    normalised correlation over 64 bits has a standard deviation around
    0.125 against noise, so a 0.45 "hit" happens by chance every few
    thousand positions, and there are thousands of positions per frame.
    An earlier version of this scanner trusted such a hit and skipped a
    whole frame's worth of bits past it, which threw away the *real* frame
    that followed and then did the same thing again, cascading into total
    loss on a link that was otherwise decoding perfectly. So: the CRC is
    what confirms a frame. A hit whose frame fails CRC advances the search
    by one bit, not by a frame.

    **Once locked, frames are predictable.** The transmitter is
    continuous, so after one good frame the next sync word is exactly one
    frame later. Searching a narrow window around the prediction is both
    cheaper and far less prone to false alarms than free-running search;
    the scanner falls back to a full search after a few consecutive
    misses."""

    # Thresholds are set from measured distributions, not guessed (see
    # exp_sync.py). The normalised correlation against noise is zero-mean
    # with sigma ~= 0.15, while a true sync word stays above ~0.73 even at
    # the Eb/N0 where the FEC itself gives out. So:
    #
    #   ACQUIRE at 0.68  - about 4.5 sigma, roughly one false alarm per
    #                      200 frames, and still comfortably under the
    #                      worst observed true-sync value.
    #   TRACK   at 0.45  - once locked the frame position is known to
    #                      within a few bits, so this only has to answer
    #                      "is anything there at all", and the scanner
    #                      takes the strongest peak in the window rather
    #                      than the first one over the line.
    ACQUIRE_THRESHOLD = 0.68
    TRACK_THRESHOLD = 0.45
    # A correlation this strong is a real sync word even if the frame
    # behind it fails to decode - used to tell "the FEC gave out" apart
    # from "that peak was noise" in the statistics.
    CONFIDENT_SYNC = 0.75

    def __init__(self, n_cw=DEFAULT_RS_CODEWORDS, mode=MODE_COHERENT,
                 sync_threshold=None, track_threshold=None,
                 track_block=64, max_misses=3, predict_window=48):
        self.n_cw = int(n_cw)
        self.mode = mode
        self.sync_threshold = float(sync_threshold
                                    if sync_threshold is not None
                                    else self.ACQUIRE_THRESHOLD)
        self.track_threshold = float(track_threshold
                                     if track_threshold is not None
                                     else self.TRACK_THRESHOLD)
        self.track_block = int(track_block)
        self.max_misses = int(max_misses)
        self.predict_window = int(predict_window)

        self.coded_bits = coded_bits_per_frame(self.n_cw)
        self.frame_nbits = SYNC_NBITS + self.coded_bits

        self._soft = np.zeros(0, dtype=np.float32)
        self._sym_buf = np.zeros(0, dtype=np.complex64)
        # Phase tracking needs a decent span of symbols to estimate a rate
        # from, and GNU Radio hands over whatever buffer size it likes -
        # sometimes a few hundred samples. Accumulating to a known minimum
        # before demodulating keeps the estimator's quality independent of
        # the scheduler's chunking.
        self.track_min = max(1024, 16 * int(track_block))
        self._prev_sym = None
        self._carry = 0.0
        self._rotation = 0
        self._locked = False
        self._next_expected = None      # bit offset of the next sync word
        self._misses = 0

        # counters for telemetry
        self.frames_detected = 0
        self.frames_crc_ok = 0
        self.frames_crc_fail = 0
        self.false_sync = 0
        self.resyncs = 0

    # -- state ----------------------------------------------------------

    @property
    def locked(self):
        return self._locked

    def reset_lock(self):
        self._locked = False
        self._next_expected = None
        self._misses = 0

    # -- main entry point -------------------------------------------------

    def feed(self, symbols):
        """Push carrier-recovered symbols; returns a list of decoded frames.

        Each result is a dict with seq, payload (None on CRC failure) and
        the full FEC statistics for that frame."""
        symbols = np.asarray(symbols, dtype=np.complex64).ravel()
        if len(symbols) == 0:
            return []

        if self.mode == MODE_COHERENT:
            self._sym_buf = np.concatenate([self._sym_buf, symbols])
            if len(self._sym_buf) < self.track_min:
                return []
            tracked, self._carry = track_phase(self._sym_buf,
                                               self.track_block, self._carry)
            self._sym_buf = np.zeros(0, dtype=np.complex64)
            new_soft = soft_coherent(tracked)
        else:
            new_soft, self._prev_sym = soft_dqpsk(symbols, self._prev_sym)

        self._soft = np.concatenate([self._soft, new_soft])
        return self._scan()

    # -- internals -------------------------------------------------------

    def _correlate(self, lo, hi):
        """Best sync correlation for start positions in [lo, hi).

        Returns (values, rotations, lo). In coherent mode all four phase
        rotations are tried, which costs nothing much because a rotation
        is just a swap-and-negate of the soft pair rather than a fresh
        demodulation. When locked, `lo`/`hi` bound a narrow window around
        the predicted frame boundary, so this is cheap in the common case
        and only does a full sweep while hunting."""
        # A frame always begins on a symbol boundary, so its sync word
        # starts at an even bit index. Forcing `lo` even keeps every
        # segment aligned to an (l0, l1) pair - which the rotation trick
        # requires to be meaningful - and halves the search at the same
        # time. Odd positions are masked out below rather than searched.
        lo = max(0, lo)
        lo -= lo & 1
        hi = min(hi, len(self._soft) - SYNC_NBITS + 1)
        if hi <= lo:
            empty = np.zeros(0, dtype=np.float32)
            return empty, np.zeros(0, dtype=np.int8), lo
        # Correlation at position p needs soft[p : p+SYNC_NBITS].
        seg = self._soft[lo:hi + SYNC_NBITS - 1]
        if len(seg) & 1:
            seg = seg[:-1]
        if len(seg) < SYNC_NBITS:
            empty = np.zeros(0, dtype=np.float32)
            return empty, np.zeros(0, dtype=np.int8), lo

        def _mask_odd(c):
            # positions lo+1, lo+3, ... are mid-symbol and can never be a
            # real frame start
            c = c.copy()
            c[1::2] = -1.0
            return c

        if self.mode != MODE_COHERENT:
            c = _mask_odd(sync_correlate(seg))
            return c, np.zeros(len(c), dtype=np.int8), lo

        best = None
        best_rot = None
        # Try the last known rotation first so it wins ties, which stops
        # the scanner flapping between equivalent phases.
        order = [self._rotation] + [k for k in range(4) if k != self._rotation]
        for k in order:
            c = _mask_odd(sync_correlate(rotate_soft(seg, k)))
            if best is None:
                best = c
                best_rot = np.full(len(c), k, dtype=np.int8)
            else:
                better = c > best
                best = np.where(better, c, best)
                best_rot = np.where(better, k, best_rot).astype(np.int8)
        return best, best_rot, lo

    def _try_decode(self, pos, rot):
        """Attempt one frame starting at sync position `pos`."""
        start = pos + SYNC_NBITS
        if start + self.coded_bits > len(self._soft):
            return None
        body = self._soft[start:start + self.coded_bits]
        if self.mode == MODE_COHERENT and rot:
            body = rotate_soft(body, rot)
        seq, payload, stats = decode_frame_soft(body, self.n_cw)
        stats['sync_rotation'] = int(rot)
        return seq, payload, stats

    def _scan(self):
        out = []
        need = self.frame_nbits
        guard = SYNC_NBITS - 1

        while len(self._soft) >= need + SYNC_NBITS:
            pos = None
            peak = 0.0
            rot = 0

            if self._locked:
                centre = self._next_expected or 0
                corr, rots, base = self._correlate(
                    centre - self.predict_window,
                    centre + self.predict_window + 1)
                if len(corr):
                    rel = int(np.argmax(corr))
                    if float(corr[rel]) >= self.track_threshold:
                        pos = base + rel
                        peak = float(corr[rel])
                        rot = int(rots[rel])

                if pos is None:
                    # Nothing where a frame was due. Don't drop the lock on
                    # the first miss - a single deep fade should not cost a
                    # full re-acquisition - but don't hold it forever either.
                    self._misses += 1
                    self.frames_crc_fail += 1
                    if self._misses > self.max_misses:
                        self._locked = False
                        self._next_expected = None
                        self._misses = 0
                        self.resyncs += 1
                        continue
                    self._advance(min(len(self._soft), centre + need))
                    self._next_expected = 0
                    continue
            else:
                corr, rots, base = self._correlate(0, len(self._soft))
                if len(corr) == 0:
                    break
                hits = np.nonzero(corr >= self.sync_threshold)[0]
                if len(hits) == 0:
                    # Every position in the buffer is ruled out; keep only
                    # enough tail for a sync word straddling the boundary.
                    self._advance(len(self._soft) - guard)
                    break
                rel = int(hits[0])
                pos = base + rel
                peak = float(corr[rel])
                rot = int(rots[rel])

            res = self._try_decode(pos, rot)
            if res is None:
                break                      # frame not fully buffered yet

            seq, payload, stats = res
            stats['sync_corr'] = peak
            self.frames_detected += 1

            if stats.get('crc_ok'):
                self.frames_crc_ok += 1
                self._locked = True
                self._rotation = rot
                self._misses = 0
                out.append({'seq': seq, 'payload': payload, 'stats': stats})
                self._advance(pos + need)
                self._next_expected = 0
            elif self._locked:
                # Arrived where a frame was due, so it was almost certainly
                # a real frame the channel destroyed. Report it and stay in
                # step rather than re-hunting.
                self.frames_crc_fail += 1
                self._misses += 1
                out.append({'seq': seq, 'payload': None, 'stats': stats})
                self._advance(pos + need)
                self._next_expected = 0
                if self._misses > self.max_misses:
                    self._locked = False
                    self._next_expected = None
                    self._misses = 0
                    self.resyncs += 1
            elif peak >= self.CONFIDENT_SYNC:
                # A correlation this strong is a genuine sync word, so the
                # FEC gave out rather than the detector crying wolf. Report
                # it as a frame error and step past it.
                self.frames_crc_fail += 1
                out.append({'seq': seq, 'payload': None, 'stats': stats})
                self._advance(pos + need)
            else:
                # Unlocked, marginal correlation, CRC failed: treat it as a
                # spurious peak and resume searching at the next symbol.
                # Skipping a whole frame here would discard the real frame
                # that follows, which is how a working link turns into a
                # dead one.
                self.false_sync += 1
                self._advance(pos + 2)

        return out

    def _advance(self, n):
        # Always an even number of bits, so index 0 of the buffer stays on
        # a symbol boundary - the rotation and pairing logic depends on it.
        n = max(0, min(int(n), len(self._soft)))
        n -= n & 1
        if n:
            self._soft = self._soft[n:]

    def stats(self):
        return {
            'locked': self._locked,
            'rotation': self._rotation,
            'frames_detected': self.frames_detected,
            'frames_crc_ok': self.frames_crc_ok,
            'frames_crc_fail': self.frames_crc_fail,
            'false_sync': self.false_sync,
            'resyncs': self.resyncs,
            'buffered_bits': len(self._soft),
        }


__all__ = [
    'SYNC_WORD', 'SYNC_BITS', 'SYNC_NBITS', 'SYNC_BIPOLAR', 'GRAY_MAP',
    'DEFAULT_RS_CODEWORDS', 'MODE_COHERENT', 'MODE_DIFFERENTIAL',
    'body_bytes', 'payload_bytes', 'frame_bits',
    'frame_symbols', 'code_rate', 'build_frame_bits', 'bits_to_gray_dibits',
    'soft_dqpsk', 'soft_coherent', 'rotate_soft', 'track_phase',
    'sync_correlate', 'decode_frame_soft', 'FrameScanner',
]
