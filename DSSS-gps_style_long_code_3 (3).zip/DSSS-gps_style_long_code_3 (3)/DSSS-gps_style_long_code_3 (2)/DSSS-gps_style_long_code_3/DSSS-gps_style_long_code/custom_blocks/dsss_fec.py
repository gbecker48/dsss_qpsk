"""
dsss_fec.py - concatenated forward error correction for the DSSS/QPSK link
=========================================================================

A self-contained, pure-NumPy implementation of a classic CCSDS-style
concatenated code:

    data -> CRC32 -> scramble -> Reed-Solomon(255,223) -> RS symbol
    interleave -> convolutional K=7 rate-1/2 (zero-terminated) -> channel
    bit interleave -> on air

and its exact inverse on the way back, with a *soft-decision* Viterbi
decoder at the inner stage.

Why this particular stack
-------------------------
Each layer is doing a job the others cannot:

  * **Soft-decision Viterbi (K=7, rate 1/2)** buys roughly 5 dB of coding
    gain over uncoded QPSK at useful error rates. Its failure mode is
    well known and important: when it does fail, it does not sprinkle
    isolated bit errors, it emits a *burst* of them (typically 10-40 bits
    while the survivor path is off the correct trellis path).

  * **The channel bit interleaver** sits between the convolutional
    encoder and the modulator. Viterbi is near-optimal against
    *independent* errors and poor against clustered ones, so anything the
    channel does in a burst - a momentary despreader slip, an
    interference hit, a gain step - must be scattered before the decoder
    sees it. The interleaver guarantees that bits adjacent on air are far
    apart in the trellis.

  * **Reed-Solomon(255,223)** is the outer code and it is specifically
    the right partner for Viterbi, because RS is a *symbol*-oriented code:
    it corrects any 16 wrong bytes per 255-byte codeword no matter how
    the bit errors are distributed inside those bytes. A 40-bit Viterbi
    burst touches at most 6 bytes, so RS eats an entire Viterbi failure
    event without noticing. This is exactly the pairing that makes the
    concatenated scheme so much stronger than either code alone.

  * **The RS symbol interleaver** spreads each codeword's bytes across
    the whole frame, so even a burst long enough to damage several bytes
    distributes those bytes across all the codewords in the frame rather
    than eating one codeword's entire correction budget.

Net effect: the link closes at roughly 2.5 dB Eb/N0 - essentially the
classic concatenated-code limit - instead of the ~9.6 dB uncoded QPSK
needs for the same error rate.

Everything here is deliberately dependency-free (NumPy only) and lives in
a plain module next to the flowgraph so that both the transmit and the
receive embedded blocks can import exactly the same code. Having one
definition of the codec, rather than two copies pasted into two GRC
blocks, is the only reliable way to keep the two ends of a link in sync.

Performance note: the Viterbi decoder is vectorized *across trellis
states* - all 64 states advance in a handful of NumPy operations per
trellis step - rather than looping over states in Python. That is the
difference between roughly 40 ms and several seconds per frame, and it is
what makes a Python decoder viable at these frame rates at all.
"""

import numpy as np
import zlib

# ---------------------------------------------------------------------------
# CRC-32 (zlib's, i.e. the standard IEEE 802.3 polynomial)
# ---------------------------------------------------------------------------


def crc32(data: bytes) -> int:
    return zlib.crc32(data) & 0xFFFFFFFF


# ---------------------------------------------------------------------------
# Additive scrambler / whitener
# ---------------------------------------------------------------------------
#
# A 9-bit maximal-length LFSR (period 511) XORed over the frame body. Kept
# from the original design and unchanged on the wire so that the framing
# layer behaves identically; it is restarted fresh every frame, since every
# frame is independent and the same fixed size.

SCRAMBLER_NBITS = 9
SCRAMBLER_TAPS = 0b110011
SCRAMBLER_SEED = 0b011010110

_SCRAMBLER_CACHE = {}


def lfsr_keystream(length: int, n_bits: int = SCRAMBLER_NBITS,
                   taps: int = SCRAMBLER_TAPS, seed: int = SCRAMBLER_SEED):
    """`length` keystream *bits* from a Fibonacci LFSR, cached by length."""
    key = (length, n_bits, taps, seed)
    cached = _SCRAMBLER_CACHE.get(key)
    if cached is not None:
        return cached
    state = seed & ((1 << n_bits) - 1)
    if state == 0:
        state = 1
    out = np.empty(length, dtype=np.uint8)
    for i in range(length):
        out[i] = state & 1
        fb = bin(state & taps).count('1') & 1
        state = (state >> 1) | (fb << (n_bits - 1))
    out.setflags(write=False)
    _SCRAMBLER_CACHE[key] = out
    return out


def scramble(data: bytes) -> bytes:
    """Self-inverse: scramble(scramble(x)) == x."""
    bits = np.unpackbits(np.frombuffer(data, dtype=np.uint8))
    return np.packbits(bits ^ lfsr_keystream(len(bits))).tobytes()


descramble = scramble


# ---------------------------------------------------------------------------
# PRBS-15 - the known pattern carried by idle frames
# ---------------------------------------------------------------------------
#
# Idle frames are not wasted air time here. They are filled with a
# deterministic PRBS the receiver can regenerate, which means the link
# measures its own *post-FEC* bit error rate continuously, on live traffic
# conditions, without needing a special test mode or a loopback. Pre-FEC
# BER is measured separately (see viterbi_decode's re-encode comparison),
# so both sides of the coding gain are observable at once.

_PRBS_CACHE = {}


def prbs15(length: int, seed: int = 0x4A5) -> bytes:
    """`length` bytes of PRBS-15 (x^15 + x^14 + 1), cached per (len, seed)."""
    key = (length, seed)
    cached = _PRBS_CACHE.get(key)
    if cached is not None:
        return cached
    state = seed & 0x7FFF
    if state == 0:
        state = 1
    bits = np.empty(length * 8, dtype=np.uint8)
    for i in range(length * 8):
        fb = ((state >> 14) ^ (state >> 13)) & 1
        bits[i] = fb
        state = ((state << 1) | fb) & 0x7FFF
    out = np.packbits(bits).tobytes()
    _PRBS_CACHE[key] = out
    return out


# ---------------------------------------------------------------------------
# GF(256) arithmetic for Reed-Solomon
# ---------------------------------------------------------------------------
#
# Primitive polynomial x^8 + x^4 + x^3 + x^2 + 1 (0x11D), the conventional
# choice and the one used by CCSDS/DVB-style RS(255,223). Log/antilog
# tables make every multiply a pair of lookups, which vectorizes cleanly.

GF_PRIM = 0x11D

_GF_EXP = np.zeros(512, dtype=np.uint8)
_GF_LOG = np.zeros(256, dtype=np.int16)


def _build_gf_tables():
    x = 1
    for i in range(255):
        _GF_EXP[i] = x
        _GF_LOG[x] = i
        x <<= 1
        if x & 0x100:
            x ^= GF_PRIM
    for i in range(255, 512):
        _GF_EXP[i] = _GF_EXP[i - 255]
    _GF_LOG[0] = -1          # log(0) is undefined; guarded at every use site


_build_gf_tables()


def gf_mul(a, b):
    """GF(256) multiply. Works on scalars or NumPy arrays (broadcasting)."""
    a = np.asarray(a, dtype=np.int16)
    b = np.asarray(b, dtype=np.int16)
    nz = (a != 0) & (b != 0)
    idx = np.where(nz, (_GF_LOG[a] + _GF_LOG[b]) % 255, 0)
    return np.where(nz, _GF_EXP[idx], 0).astype(np.uint8)


def gf_div(a, b):
    a = np.asarray(a, dtype=np.int16)
    b = np.asarray(b, dtype=np.int16)
    if np.any(b == 0):
        raise ZeroDivisionError("GF(256) division by zero")
    nz = a != 0
    idx = np.where(nz, (_GF_LOG[a] - _GF_LOG[b]) % 255, 0)
    return np.where(nz, _GF_EXP[idx], 0).astype(np.uint8)


def gf_pow(a, n):
    a = int(a)
    if a == 0:
        return 0
    return int(_GF_EXP[(_GF_LOG[a] * int(n)) % 255])


def gf_inv(a):
    a = int(a)
    if a == 0:
        raise ZeroDivisionError("GF(256) inverse of zero")
    return int(_GF_EXP[(255 - _GF_LOG[a]) % 255])


def gf_poly_mul(p, q):
    """Multiply two GF(256) polynomials given as coefficient arrays.

    Order-agnostic (it is a plain convolution), so it works for both the
    descending-power arrays used by the encoder and the ascending-power
    arrays used by the decoder."""
    p = np.asarray(p, dtype=np.uint8)
    q = np.asarray(q, dtype=np.uint8)
    out = np.zeros(len(p) + len(q) - 1, dtype=np.uint8)
    for i, c in enumerate(p):
        if c:
            out[i:i + len(q)] ^= gf_mul(np.full(len(q), c, dtype=np.uint8), q)
    return out


def gf_poly_eval(poly, x):
    """Horner evaluation of a GF(256) polynomial, HIGHEST power first."""
    y = 0
    x = int(x)
    for c in np.asarray(poly, dtype=np.uint8):
        y = int(gf_mul(np.uint8(y), np.uint8(x))) ^ int(c)
    return y


def gf_poly_eval_asc(poly, x):
    """Horner evaluation of a GF(256) polynomial, LOWEST power first.

    The decoder works entirely in ascending order (Lambda(x) = 1 + L1*x +
    ...), which is the convention every textbook statement of
    Berlekamp-Massey and Forney uses. Mixing the two orders is the single
    easiest way to get a Reed-Solomon decoder subtly wrong, so the two
    evaluators are kept explicitly separate."""
    y = 0
    x = int(x)
    for c in np.asarray(poly, dtype=np.uint8)[::-1]:
        y = int(gf_mul(np.uint8(y), np.uint8(x))) ^ int(c)
    return y


# ---------------------------------------------------------------------------
# Reed-Solomon (255, 223), t = 16
# ---------------------------------------------------------------------------

RS_N = 255
RS_K = 223
RS_NROOTS = RS_N - RS_K          # 32 parity symbols
RS_T = RS_NROOTS // 2            # corrects up to 16 symbol errors
RS_FCR = 1                       # first consecutive root is alpha^1
#
# fcr = 1 is chosen deliberately: it is the value for which Forney's error
# magnitude reduces to the plain Omega(X^-1) / Lambda'(X^-1), with no
# X^(1-fcr) correction factor to get wrong. Both ends of the link use this
# module, so the only requirement is self-consistency.


def _rs_generator_poly(nroots=RS_NROOTS, fcr=RS_FCR):
    g = np.array([1], dtype=np.uint8)
    for i in range(nroots):
        g = gf_poly_mul(g, np.array([1, gf_pow(2, i + fcr)], dtype=np.uint8))
    return g


RS_GEN = _rs_generator_poly()
# Generator coefficients excluding the leading 1, in the order the
# systematic encoder's feedback shift register wants them.
_RS_GEN_TAIL = RS_GEN[1:].copy()


def rs_encode(data: bytes) -> bytes:
    """Systematic RS(255,223): returns `data` (223 B) + 32 parity bytes."""
    data = bytes(data)
    if len(data) != RS_K:
        raise ValueError("rs_encode expects exactly %d bytes, got %d"
                         % (RS_K, len(data)))
    msg = np.frombuffer(data, dtype=np.uint8)
    parity = np.zeros(RS_NROOTS, dtype=np.uint8)
    for b in msg:
        feedback = int(b) ^ int(parity[0])
        parity[:-1] = parity[1:]
        parity[-1] = 0
        if feedback:
            parity ^= gf_mul(np.full(RS_NROOTS, feedback, dtype=np.uint8),
                             _RS_GEN_TAIL)
    return data + parity.tobytes()


def _rs_syndromes(cw):
    """Syndromes S_j = r(alpha^(j+fcr)) for j in 0..nroots-1, ascending.

    The received word is treated as a polynomial with cw[0] as the
    coefficient of x^254, so plain Horner over the bytes evaluates it.
    Vectorized: all 32 syndromes advance together, one NumPy step per
    received symbol, instead of 32 separate polynomial evaluations."""
    alphas = np.array([gf_pow(2, j + RS_FCR) for j in range(RS_NROOTS)],
                      dtype=np.uint8)
    synd = np.zeros(RS_NROOTS, dtype=np.uint8)
    for sym in cw:
        synd = gf_mul(synd, alphas) ^ np.uint8(sym)
    return synd


def _berlekamp_massey(synd):
    """Error-locator polynomial Lambda, ASCENDING powers, Lambda[0] == 1.

    Textbook Berlekamp-Massey over GF(2^m): subtraction is XOR, so the
    usual minus signs vanish."""
    c = [1]                     # current connection polynomial
    b = [1]                     # copy of c from the last length change
    ell = 0                     # current register length
    m = 1                       # steps since the last length change
    bb = 1                      # discrepancy at that last change

    for n in range(RS_NROOTS):
        d = int(synd[n])
        for i in range(1, ell + 1):
            if i < len(c):
                d ^= int(gf_mul(np.uint8(c[i]), np.uint8(synd[n - i])))
        if d == 0:
            m += 1
            continue

        scale = int(gf_mul(np.uint8(d), np.uint8(gf_inv(bb))))
        shifted = [0] * m + [int(gf_mul(np.uint8(scale), np.uint8(v)))
                             for v in b]
        new = list(c) + [0] * max(0, len(shifted) - len(c))
        for i in range(len(shifted)):
            new[i] ^= shifted[i]

        if 2 * ell <= n:
            b = list(c)
            bb = d
            ell = n + 1 - ell
            m = 1
            c = new
        else:
            c = new
            m += 1

    while len(c) > 1 and c[-1] == 0:
        c.pop()
    return np.array(c, dtype=np.uint8), ell


def _poly_deriv_asc(poly):
    """Formal derivative of an ASCENDING-power polynomial.

    In characteristic 2 the even-power terms differentiate to zero, so
    only the odd-power coefficients survive, shifted down by one."""
    poly = np.asarray(poly, dtype=np.uint8)
    if len(poly) <= 1:
        return np.array([0], dtype=np.uint8)
    out = np.zeros(len(poly) - 1, dtype=np.uint8)
    for k in range(1, len(poly)):
        if k & 1:
            out[k - 1] = poly[k]
    return out


def rs_decode(cw: bytes):
    """Decode one 255-byte RS codeword.

    Returns (message_bytes, n_corrected, ok). `n_corrected` is the number
    of symbol errors actually repaired - the single most useful FEC health
    number there is, because it says how much of the 16-symbol budget the
    channel is consuming right now. `ok` is False if the codeword carried
    more than 16 errors and could not be corrected.

    Every correction is verified by recomputing the syndromes, so a
    miscorrection (which is what a >t error pattern usually produces) is
    reported as a failure rather than handed upward as clean data."""
    cw = bytes(cw)
    if len(cw) != RS_N:
        raise ValueError("rs_decode expects %d bytes, got %d" % (RS_N, len(cw)))
    r = np.frombuffer(cw, dtype=np.uint8).copy()

    synd = _rs_syndromes(r)
    if not synd.any():
        return r[:RS_K].tobytes(), 0, True

    lam, nerr = _berlekamp_massey(synd)
    if nerr < 1 or nerr > RS_T:
        return r[:RS_K].tobytes(), 0, False

    # Chien search. An error at byte index i has locator X = alpha^(254-i),
    # and Lambda's roots are the inverses X^-1 = alpha^-(254-i), which
    # reduces to alpha^((i + 1) mod 255).
    positions = []
    for i in range(RS_N):
        x_inv = gf_pow(2, (i + 1) % 255)
        if gf_poly_eval_asc(lam, x_inv) == 0:
            positions.append(i)
    if len(positions) != nerr:
        return r[:RS_K].tobytes(), 0, False

    # Forney. Omega(x) = S(x)*Lambda(x) mod x^nroots, everything ascending.
    omega = gf_poly_mul(synd, lam)[:RS_NROOTS]
    lam_deriv = _poly_deriv_asc(lam)

    for pos in positions:
        x_inv = gf_pow(2, (pos + 1) % 255)
        num = gf_poly_eval_asc(omega, x_inv)
        den = gf_poly_eval_asc(lam_deriv, x_inv)
        if den == 0:
            return r[:RS_K].tobytes(), 0, False
        r[pos] ^= int(gf_mul(np.uint8(num), np.uint8(gf_inv(den))))

    # A genuine correction zeroes every syndrome; anything else was a
    # miscorrection and must be reported as an uncorrectable codeword.
    if _rs_syndromes(r).any():
        return r[:RS_K].tobytes(), 0, False

    return r[:RS_K].tobytes(), nerr, True


# ---------------------------------------------------------------------------
# Convolutional code, K = 7, rate 1/2, zero-terminated
# ---------------------------------------------------------------------------
#
# Generators 0o171 / 0o133 - the NASA/Voyager pair, the same one CCSDS,
# DVB-S and 802.11 use, and the best-known rate-1/2 K=7 code by free
# distance (dfree = 10).

CC_K = 7
CC_STATES = 1 << (CC_K - 1)      # 64
CC_G0 = 0o171
CC_G1 = 0o133
CC_TAIL = CC_K - 1               # 6 flush bits


def _parity7(v):
    return bin(v & 0x7F).count('1') & 1


def _build_trellis():
    """Branch tables indexed by (state * 2 + input_bit).

    State holds the last 6 input bits with the most recent in the MSB, so
    the 7-bit shift-register word is (bit << 6) | state and the next state
    is that word shifted right by one."""
    n = CC_STATES * 2
    nxt = np.zeros(n, dtype=np.int64)
    out0 = np.zeros(n, dtype=np.uint8)
    out1 = np.zeros(n, dtype=np.uint8)
    for state in range(CC_STATES):
        for bit in (0, 1):
            word = (bit << 6) | state
            idx = state * 2 + bit
            nxt[idx] = word >> 1
            out0[idx] = _parity7(word & CC_G0)
            out1[idx] = _parity7(word & CC_G1)
    return nxt, out0, out1


CC_NEXT, CC_OUT0, CC_OUT1 = _build_trellis()

# Bipolar versions of the branch outputs: +1 for a transmitted 0, -1 for a
# transmitted 1, matching the soft-value convention below.
CC_SIGN0 = (1.0 - 2.0 * CC_OUT0).astype(np.float32)
CC_SIGN1 = (1.0 - 2.0 * CC_OUT1).astype(np.float32)

# Branch index -> originating state (just idx // 2), precomputed.
CC_SRC = (np.arange(CC_STATES * 2) // 2).astype(np.int64)


def _build_predecessors():
    """For each next-state, the two branch indices that arrive at it.

    Given next state ns, the input bit is ns >> 5 and the originating
    state is one of 2*(ns & 0x1F) or 2*(ns & 0x1F) + 1."""
    pred = np.zeros((CC_STATES, 2), dtype=np.int64)
    for ns in range(CC_STATES):
        bit = ns >> 5
        base = (ns & 0x1F) * 2
        pred[ns, 0] = base * 2 + bit
        pred[ns, 1] = (base + 1) * 2 + bit
    return pred


CC_PRED = _build_predecessors()
_CC_ARANGE = np.arange(CC_STATES)


def cc_encode(bits) -> np.ndarray:
    """Encode unpacked bits (0/1). Appends 6 zero flush bits, so the
    decoder always starts and ends in state 0 and needs no tail-biting.
    Returns 2 * (len(bits) + 6) output bits."""
    bits = np.asarray(bits, dtype=np.uint8).ravel()
    padded = np.concatenate([bits, np.zeros(CC_TAIL, dtype=np.uint8)])
    out = np.empty(len(padded) * 2, dtype=np.uint8)
    state = 0
    for i, b in enumerate(padded):
        idx = state * 2 + int(b)
        out[2 * i] = CC_OUT0[idx]
        out[2 * i + 1] = CC_OUT1[idx]
        state = int(CC_NEXT[idx])
    return out


def cc_encode_fast(bits) -> np.ndarray:
    """Same as cc_encode but without the Python loop.

    The shift-register contents at every step are just windows over the
    input, so the whole codeword is two convolutions-by-parity, which
    NumPy does in a couple of vectorized passes."""
    bits = np.asarray(bits, dtype=np.uint8).ravel()
    n = len(bits)
    padded = np.concatenate([np.zeros(CC_K - 1, dtype=np.uint8), bits,
                             np.zeros(CC_TAIL, dtype=np.uint8)])
    # windows[i] = the 7 register bits at step i, newest first
    windows = np.lib.stride_tricks.sliding_window_view(padded, CC_K)[:n + CC_TAIL]
    # sliding_window_view gives oldest-bit-first; reverse so column j lines
    # up with bit (6 - j) of the shift-register word, i.e. column 0 is the
    # newest input bit == bit 6.
    windows = windows[:, ::-1]
    g0 = np.array([(CC_G0 >> (6 - i)) & 1 for i in range(CC_K)], dtype=np.uint8)
    g1 = np.array([(CC_G1 >> (6 - i)) & 1 for i in range(CC_K)], dtype=np.uint8)
    o0 = (windows & g0).sum(axis=1) & 1
    o1 = (windows & g1).sum(axis=1) & 1
    out = np.empty((n + CC_TAIL) * 2, dtype=np.uint8)
    out[0::2] = o0
    out[1::2] = o1
    return out


def viterbi_decode(soft, n_info_bits=None):
    """Soft-decision Viterbi decoder.

    `soft` is a float array of received soft values, two per trellis step,
    using the convention that a POSITIVE value favours a transmitted 0 and
    a negative one favours a 1 (i.e. the bipolar mapping s = 1 - 2*bit,
    scaled by confidence). Magnitudes carry the reliability - feeding hard
    +-1 values here costs the usual ~2 dB versus true soft decisions.

    Returns (decoded_bits, path_metric, n_channel_errors).

    `n_channel_errors` is obtained by re-encoding the decoded sequence and
    comparing it against the hard decisions of the received soft values.
    That is a direct, live measurement of the *pre-FEC* channel bit error
    rate, needing no test pattern and no known data - the decoder's own
    output is the reference. Watching that number next to the post-FEC
    error rate is how you see the coding gain actually being spent.

    The decoder advances all 64 states per step with a handful of NumPy
    operations rather than a Python loop over states, which is what keeps
    it fast enough to run per-frame inside a GNU Radio block."""
    soft = np.asarray(soft, dtype=np.float32).ravel()
    nsteps = len(soft) // 2
    if nsteps <= CC_TAIL:
        return np.zeros(0, dtype=np.uint8), 0.0, 0
    if n_info_bits is None:
        n_info_bits = nsteps - CC_TAIL

    r0 = soft[0:2 * nsteps:2]
    r1 = soft[1:2 * nsteps:2]

    NEG_INF = np.float32(-1e18)
    metrics = np.full(CC_STATES, NEG_INF, dtype=np.float32)
    metrics[0] = 0.0                       # encoder always starts in state 0
    decisions = np.empty((nsteps, CC_STATES), dtype=np.uint8)

    pred = CC_PRED
    src = CC_SRC
    sign0 = CC_SIGN0
    sign1 = CC_SIGN1
    arange = _CC_ARANGE

    for k in range(nsteps):
        bm = r0[k] * sign0 + r1[k] * sign1        # 128 branch metrics
        cand = metrics[src] + bm                  # 128 candidate metrics
        pair = cand[pred]                         # (64, 2)
        sel = np.argmax(pair, axis=1)
        metrics = pair[arange, sel]
        decisions[k] = sel

    # The encoder is zero-terminated, so the survivor path must end in
    # state 0 - no need to guess the best final state.
    state = 0
    path_metric = float(metrics[0])
    bits = np.empty(nsteps, dtype=np.uint8)
    for k in range(nsteps - 1, -1, -1):
        sel = decisions[k, state]
        branch = int(pred[state, sel])
        bits[k] = branch & 1
        state = branch >> 1

    info = bits[:n_info_bits]

    # Pre-FEC channel bit error estimate: re-encode and compare with the
    # hard decisions we were handed.
    reenc = cc_encode_fast(info)
    hard = (soft[:2 * nsteps] < 0).astype(np.uint8)
    m = min(len(reenc), len(hard))
    n_channel_errors = int(np.count_nonzero(reenc[:m] ^ hard[:m]))

    return info, path_metric, n_channel_errors


# ---------------------------------------------------------------------------
# Interleavers
# ---------------------------------------------------------------------------
#
# A stride ("golden ratio") permutation rather than a rectangular block
# interleaver, because it works for *any* length - no awkward factoring of
# the frame size, no padding - while still guaranteeing that bits adjacent
# on air came from trellis positions far apart, which is the whole point.

_INTERLEAVER_CACHE = {}


def _coprime_stride(n):
    """A stride near n/phi that is coprime with n."""
    if n < 3:
        return 1
    stride = int(n * 0.6180339887498949) | 1
    stride = max(1, min(stride, n - 1))
    for delta in range(0, n):
        for cand in (stride + delta, stride - delta):
            if 1 <= cand < n and np.gcd(cand, n) == 1:
                return cand
    return 1


def interleaver_perm(n):
    """Returns (perm, inv_perm). out[i] = in[perm[i]]."""
    cached = _INTERLEAVER_CACHE.get(n)
    if cached is not None:
        return cached
    stride = _coprime_stride(n)
    perm = (np.arange(n, dtype=np.int64) * stride) % n
    inv = np.empty(n, dtype=np.int64)
    inv[perm] = np.arange(n, dtype=np.int64)
    perm.setflags(write=False)
    inv.setflags(write=False)
    _INTERLEAVER_CACHE[n] = (perm, inv)
    return perm, inv


def interleave(arr):
    arr = np.asarray(arr)
    perm, _ = interleaver_perm(len(arr))
    return arr[perm]


def deinterleave(arr):
    arr = np.asarray(arr)
    _, inv = interleaver_perm(len(arr))
    return arr[inv]


def rs_symbol_interleave(codewords: bytes, n_cw: int) -> bytes:
    """Column-wise read of `n_cw` stacked 255-byte codewords.

    Byte j of every codeword goes out together, so a burst of consecutive
    bytes on air is shared evenly among all the codewords rather than
    landing entirely inside one and eating its whole 16-symbol budget."""
    arr = np.frombuffer(codewords, dtype=np.uint8).reshape(n_cw, RS_N)
    return arr.T.reshape(-1).tobytes()


def rs_symbol_deinterleave(data: bytes, n_cw: int) -> bytes:
    arr = np.frombuffer(data, dtype=np.uint8).reshape(RS_N, n_cw)
    return arr.T.reshape(-1).tobytes()


# ---------------------------------------------------------------------------
# Whole-frame encode / decode
# ---------------------------------------------------------------------------


def frame_body_bytes(n_cw: int) -> int:
    """Uncoded bytes carried by a frame with `n_cw` RS codewords."""
    return n_cw * RS_K


def coded_bits_per_frame(n_cw: int) -> int:
    """On-air bits after RS + convolutional coding (excludes the sync word)."""
    return 2 * (n_cw * RS_N * 8 + CC_TAIL)


def encode_frame(body: bytes, n_cw: int) -> np.ndarray:
    """body (n_cw*223 bytes, already scrambled) -> on-air bits."""
    body = bytes(body)
    expect = frame_body_bytes(n_cw)
    if len(body) != expect:
        raise ValueError("encode_frame expects %d bytes, got %d"
                         % (expect, len(body)))
    cws = b''.join(rs_encode(body[i * RS_K:(i + 1) * RS_K])
                   for i in range(n_cw))
    inter = rs_symbol_interleave(cws, n_cw)
    bits = np.unpackbits(np.frombuffer(inter, dtype=np.uint8))
    coded = cc_encode_fast(bits)
    return interleave(coded)


def decode_frame(soft, n_cw: int):
    """Inverse of encode_frame, with a full diagnostic report.

    Returns (body_bytes_or_None, stats dict). The stats are the point:
    they separate what the channel did from what each coding layer had to
    do about it, which is the only way to tell a link that is comfortable
    from one that is one dB from falling over."""
    soft = np.asarray(soft, dtype=np.float32).ravel()
    expect = coded_bits_per_frame(n_cw)
    stats = {
        'coded_bits': expect,
        'chan_bit_errors': 0,
        'chan_ber': 0.0,
        'path_metric': 0.0,
        'rs_corrected': [],
        'rs_total_corrected': 0,
        'rs_uncorrectable': 0,
        'rs_worst_cw': 0,
        'rs_margin': RS_T,
        'post_viterbi_byte_errors': 0,
        'post_viterbi_ber_bytes': 0.0,
        'ok': False,
    }
    if len(soft) < expect:
        return None, stats
    soft = soft[:expect]

    deinter = deinterleave(soft)
    n_info = n_cw * RS_N * 8
    bits, path_metric, chan_errors = viterbi_decode(deinter, n_info_bits=n_info)
    stats['path_metric'] = path_metric
    stats['chan_bit_errors'] = chan_errors
    stats['chan_ber'] = chan_errors / float(expect) if expect else 0.0

    if len(bits) < n_info:
        return None, stats

    inter_bytes = np.packbits(bits[:n_info]).tobytes()
    cws = rs_symbol_deinterleave(inter_bytes, n_cw)

    pieces = []
    corrected = []
    uncorrectable = 0
    for i in range(n_cw):
        msg, ncorr, ok = rs_decode(cws[i * RS_N:(i + 1) * RS_N])
        pieces.append(msg)
        corrected.append(ncorr)
        if not ok:
            uncorrectable += 1

    stats['rs_corrected'] = corrected
    stats['rs_total_corrected'] = int(sum(corrected))
    stats['rs_uncorrectable'] = uncorrectable
    stats['rs_worst_cw'] = int(max(corrected)) if corrected else 0
    stats['rs_margin'] = RS_T - stats['rs_worst_cw']
    stats['post_viterbi_byte_errors'] = stats['rs_total_corrected']
    total_bytes = n_cw * RS_N
    stats['post_viterbi_ber_bytes'] = (stats['rs_total_corrected'] /
                                       float(total_bytes)) if total_bytes else 0.0
    stats['ok'] = (uncorrectable == 0)

    return b''.join(pieces), stats


__all__ = [
    'crc32', 'scramble', 'descramble', 'prbs15',
    'rs_encode', 'rs_decode', 'RS_N', 'RS_K', 'RS_T', 'RS_NROOTS',
    'cc_encode', 'cc_encode_fast', 'viterbi_decode',
    'CC_K', 'CC_TAIL', 'CC_G0', 'CC_G1',
    'interleave', 'deinterleave', 'interleaver_perm',
    'rs_symbol_interleave', 'rs_symbol_deinterleave',
    'frame_body_bytes', 'coded_bits_per_frame', 'encode_frame', 'decode_frame',
]
