"""
Node Control - parses commands from the ground station's control port
======================================================================

Still handles `NODE=<n>` and `DEST=<n>` exactly as before, with the same
client-side range check (an out-of-range id would otherwise crash the
flowgraph the instant the code table is indexed).

New commands, all fire-and-forget UDP like the originals:

    FILE=<path>      transmit a file of any size from the radio's own
                     filesystem. Emitted on a separate port so it reaches
                     the TX Frame Source directly rather than going
                     through the node-id machinery.
    RESYNC           drop the despreader lock and force a fresh
                     acquisition - useful after moving an antenna.
    STATUS           ask for an immediate telemetry line instead of
                     waiting for the next periodic one.
"""

import pmt
from gnuradio import gr

import dsss_codes as CODES


def pdu_data(msg):
    vec = pmt.cdr(msg) if pmt.is_pair(msg) else msg
    try:
        return bytes(bytearray(pmt.u8vector_elements(vec)))
    except Exception:
        return b''


def text_pdu(text):
    data = text.encode('utf-8', 'replace')
    return pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(data), list(data)))


class blk(gr.basic_block):
    """Node Control"""

    def __init__(self, table_size=16):
        gr.basic_block.__init__(self, name='Node Control', in_sig=[], out_sig=[])
        self.table_size = int(table_size)
        self.message_port_register_in(pmt.intern('in'))
        self.message_port_register_out(pmt.intern('node_msg'))
        self.message_port_register_out(pmt.intern('dest_msg'))
        self.message_port_register_out(pmt.intern('file_msg'))
        self.message_port_register_out(pmt.intern('status'))
        self.set_msg_handler(pmt.intern('in'), self.handle_msg)

    def handle_msg(self, msg):
        try:
            text = pdu_data(msg).decode('utf-8', 'replace').strip()
        except Exception:
            return
        if not text:
            return

        upper = text.upper()

        if upper == 'RESYNC':
            self.message_port_pub(pmt.intern('status'),
                                  text_pdu('CTRL resync requested'))
            return

        if '=' not in text:
            print("[Node Control] unknown command %r - ignored" % text)
            return

        key, _, val = text.partition('=')
        key = key.strip().upper()
        val = val.strip()

        if key == 'FILE':
            # Passed straight through - the path is the transmitter's
            # business, and it reports its own errors.
            self.message_port_pub(pmt.intern('file_msg'), text_pdu(text))
            print("[Node Control] file transmit requested: %s" % val)
            return

        try:
            n = int(val)
        except ValueError:
            print("[Node Control] bad value in %r - ignored" % text)
            return

        if not (0 <= n < self.table_size):
            print("[Node Control] node id %d out of range [0, %d) - ignored"
                  % (n, self.table_size))
            self.message_port_pub(
                pmt.intern('status'),
                text_pdu("CTRL node id %d out of range" % n))
            return

        if key == 'NODE':
            self.message_port_pub(
                pmt.intern('node_msg'),
                pmt.cons(pmt.intern('my_node_id'), pmt.from_long(n)))
            print("[Node Control] my_node_id -> %d" % n)
        elif key == 'DEST':
            self.message_port_pub(
                pmt.intern('dest_msg'),
                pmt.cons(pmt.intern('dest_node_id'), pmt.from_long(n)))
            print("[Node Control] dest_node_id -> %d" % n)
        else:
            print("[Node Control] unknown command %r - ignored" % text)
