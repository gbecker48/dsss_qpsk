"""
DSSS Spreader (GPS-style, symbol-domain, per-node code, multi-length)
=====================================================================

Unchanged in behaviour from the original at the default 1023-chip length -
the generated codes are bit-for-bit identical, verified in test_codes.py
against the original tap-pair generator. What is new is that `code_len`
is now a real knob, and that the per-node code is selected by node id
rather than by a pair of G2 register taps.

Every incoming complex QPSK symbol is held for one full period of the
spreading code and multiplied chip by chip, exactly as GPS spreads its
navigation data - so it is the transmitted *waveform* that gets spread
across ~code_len times the bandwidth, not merely the bits before
modulation.

Why code length is worth having as a knob: raising the chip rate buys
occupied bandwidth but not throughput, because symbol rate is
chip_rate/code_len. Only shortening the code raises the data rate. At
2.046 Mcps a 127-chip code still hides the signal 21 dB under the noise
floor while running roughly eight times faster than the GPS-length code,
which is the difference between a link that can move a file and one that
cannot. See dsss_codes.py for which lengths exist and why 255 is not one
of them.

`node_id` is a normal runtime-settable GRC parameter, tied to the
flowgraph's `my_node_id` variable. Changing it rebuilds the code
immediately, the same way `prn_taps` used to.
"""

import numpy as np
import pmt
from gnuradio import gr

import dsss_codes as CODES


class blk(gr.interp_block):
    """DSSS Spreader (GPS-style Gold code, per-node)"""

    def __init__(self, code_len=1023, node_id=0):
        gr.interp_block.__init__(
            self, name='DSSS Spreader',
            in_sig=[np.complex64], out_sig=[np.complex64],
            interp=int(code_len))
        self.code_len = int(code_len)
        self._node_id = -1
        self.code = CODES.gold_code(self.code_len, int(node_id))
        self._node_id = int(node_id)
        self.set_tag_propagation_policy(gr.TPP_DONT)

    # GRC's generated variable-setter code assigns to this attribute
    # directly rather than calling a method, so a property is what turns a
    # plain assignment into "rebuild the code array".
    @property
    def node_id(self):
        return self._node_id

    @node_id.setter
    def node_id(self, value):
        value = int(value)
        if value == self._node_id:
            return
        self._node_id = value
        self.code = CODES.gold_code(self.code_len, value)

    def work(self, input_items, output_items):
        in0 = input_items[0]
        out = output_items[0]
        n = len(in0)
        if n == 0:
            return 0
        code = self.code
        # out[k*L : (k+1)*L] = in0[k] * code
        np.multiply(in0.reshape(n, 1), code.reshape(1, self.code_len),
                    out=out[:n * self.code_len].reshape(n, self.code_len))
        return n * self.code_len
