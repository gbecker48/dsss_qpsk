"""
dsss_codes.py - GPS-style Gold code generation, multiple lengths
================================================================

The original link generated exactly one code family: the real GPS C/A
1023-chip Gold code, from the two 10-bit LFSRs the GPS ICD specifies.
That code is kept here bit-for-bit identical - nothing about the 1023-chip
on-air waveform changes - but the generator is now parameterized so the
spreading factor itself becomes a knob.

Why that knob matters
---------------------
Symbol rate is chip_rate / code_len, so with a fixed chip rate the code
length sets the data rate and the processing gain simultaneously, in
opposite directions:

    code_len   processing gain   symbol rate at 2.046 Mcps   net payload
       2047        33.1 dB              1000 /s                ~0.8 kbps
       1023        30.1 dB              2000 /s                ~1.7 kbps
        511        27.1 dB              4004 /s                ~3.3 kbps
        127        21.0 dB             16110 /s                ~13.4 kbps
         63        18.0 dB             32476 /s                ~27 kbps

Raising the chip rate buys bandwidth but *not* throughput; only shortening
the code buys throughput. For moving a file, 127 chips still puts the
signal a healthy 21 dB under the noise floor while going roughly eight
times faster than the GPS-length code. 1023 remains the default, because
the deep-burial demonstration is the point of the link.

Which lengths exist, and why 255 is missing
-------------------------------------------
Gold codes only exist where a *preferred pair* of m-sequences does, which
requires the LFSR degree n to be odd or n = 2 mod 4. That admits
n = 6, 7, 9, 10, 11 (lengths 63, 127, 511, 1023, 2047) and rules out
n = 8 - so there is no 255-chip Gold code, however convenient the number
looks. Offering one anyway would mean shipping a pair of m-sequences whose
cross-correlation is not 3-valued, which is exactly the property the
multi-node CDMA separation depends on, so the length is simply not
offered.

Every pair below was verified numerically before being used: each
polynomial genuinely generates an m-sequence (balance 2^(n-1), and an
autocorrelation of N at zero shift and -1 at every other shift), and each
pair's cross-correlation takes only the three values {-1, -t(n), t(n)-2}
with t(n) = 1 + 2^floor((n+2)/2) that Gold-code theory predicts. See
test_codes.py, which re-runs those checks.

Per-node codes (CDMA)
---------------------
A Gold family is {G1 XOR (G2 shifted by k)} over the N possible shifts k.
GPS picks its per-satellite shift with a two-tap XOR of the G2 register;
this module works directly in terms of the shift k, which is the same
thing expressed canonically and - unlike tap pairs, of which there are
only n(n-1)/2 - always provides a full N codes regardless of length.

The n = 10 shift table below was derived from the project's original PRN
tap pairs, so node ids 0-15 produce exactly the same 1023-chip codes they
always have. Verified in test_codes.py against the legacy tap-pair
generator.
"""

import numpy as np

# code_len -> (n, G1 feedback taps, G2 feedback taps), taps 1-indexed with
# the x^0 term implicit. n = 10 is GPS's own G1/G2 pair.
_CODE_CONFIG = {
      63: (6,  [1, 6],                [1, 2, 5, 6]),
     127: (7,  [3, 7],                [1, 2, 3, 7]),
     511: (9,  [4, 9],                [3, 4, 6, 9]),
    1023: (10, [3, 10],               [2, 3, 6, 8, 9, 10]),
    2047: (11, [2, 11],               [2, 5, 8, 11]),
}

SUPPORTED_CODE_LENGTHS = tuple(sorted(_CODE_CONFIG))
DEFAULT_CODE_LEN = 1023

# G2 cyclic shifts for node ids 0..15 at n = 10, derived from the original
# PRN tap pairs {0:(2,6), 1:(3,7), ...} so the existing on-air 1023-chip
# codes are preserved exactly.
_LEGACY_1023_SHIFTS = [1018, 1017, 1016, 1015, 1006, 1005, 884, 883,
                       882, 772, 771, 769, 768, 767, 766, 765]

MAX_NODES = 16


def m_sequence(n, taps):
    """Fibonacci LFSR m-sequence, all-ones seed, output taken from the
    oldest register stage - structurally identical to the project's
    original g1_sequence/g2_sequence, so nothing about the waveform moved."""
    reg = [1] * n
    length = (1 << n) - 1
    out = np.empty(length, dtype=np.uint8)
    idx = [t - 1 for t in taps]
    for i in range(length):
        out[i] = reg[n - 1]
        fb = 0
        for j in idx:
            fb ^= reg[j]
        reg = [fb] + reg[:-1]
    return out


def _node_shifts(code_len):
    """G2 shift for each node id at this code length.

    Every shift in the family has the same guaranteed 3-valued
    cross-correlation, so correlation quality does not pick between them -
    but *balance* does. A Gold code is not automatically balanced (only
    some members of the family are), and an unbalanced spreading code
    carries a DC term, which on air becomes a residual carrier spike
    sitting right in the middle of the transmitted band. On a link whose
    entire premise is being invisible underneath the noise floor, that
    spike is the one artefact a spectrum analyser could actually find, so
    it is worth designing out.

    GPS solves this by hand-selecting balanced codes for its satellites;
    this does the same thing by construction - only balanced shifts are
    offered to nodes, spread as evenly as possible around the code period
    so that neighbouring node ids are far apart in code phase.
    """
    if code_len == 1023:
        # The original GPS-derived table, already balanced. Preserved
        # exactly so the 1023-chip on-air codes never change.
        return list(_LEGACY_1023_SHIFTS)

    n, g1_taps, g2_taps = _CODE_CONFIG[code_len]
    g1 = m_sequence(n, g1_taps)
    g2 = m_sequence(n, g2_taps)

    balanced = []
    for k in range(code_len):
        ones = int((g1 ^ np.roll(g2, -k)).sum())
        if abs(2 * ones - code_len) == 1:      # balanced to within one chip
            balanced.append(k)

    if len(balanced) >= MAX_NODES:
        # Spread the picks evenly through the balanced set.
        step = len(balanced) / float(MAX_NODES)
        return [balanced[int(i * step)] for i in range(MAX_NODES)]

    # Shouldn't happen for the supported lengths, but never ship a table
    # with duplicate codes: fall back to ranking every shift by how close
    # to balanced it is and taking the best MAX_NODES.
    scored = sorted(range(code_len),
                    key=lambda k: abs(2 * int((g1 ^ np.roll(g2, -k)).sum())
                                      - code_len))
    return scored[:MAX_NODES]


_SHIFT_TABLES = {cl: _node_shifts(cl) for cl in _CODE_CONFIG}


def node_shift(code_len, node_id):
    table = _SHIFT_TABLES.get(int(code_len))
    if table is None:
        raise ValueError(
            "unsupported code_len %r - Gold codes exist only for lengths %s "
            "(a preferred pair of m-sequences requires LFSR degree n odd or "
            "n = 2 mod 4, which is why there is no 255-chip Gold code)"
            % (code_len, list(SUPPORTED_CODE_LENGTHS)))
    return table[int(node_id) % len(table)]


_CODE_CACHE = {}


def gold_code(code_len=DEFAULT_CODE_LEN, node_id=0):
    """Bipolar (+-1 float32) Gold code of `code_len` chips for `node_id`.

    Cached - the LFSR generation is a Python loop and this is called on
    every code or node change, but never in the sample path."""
    code_len = int(code_len)
    node_id = int(node_id)
    key = (code_len, node_id)
    cached = _CODE_CACHE.get(key)
    if cached is not None:
        return cached

    if code_len not in _CODE_CONFIG:
        raise ValueError(
            "unsupported code_len %r - supported lengths are %s"
            % (code_len, list(SUPPORTED_CODE_LENGTHS)))

    n, g1_taps, g2_taps = _CODE_CONFIG[code_len]
    g1 = m_sequence(n, g1_taps)
    g2 = m_sequence(n, g2_taps)
    shifted = np.roll(g2, -node_shift(code_len, node_id))
    bits = g1 ^ shifted
    code = (1.0 - 2.0 * bits.astype(np.float32)).astype(np.float32)
    code.setflags(write=False)
    _CODE_CACHE[key] = code
    return code


def processing_gain_db(code_len):
    return 10.0 * np.log10(float(code_len))


def describe(code_len):
    """Human-readable summary, used in status/telemetry lines."""
    n, g1, g2 = _CODE_CONFIG[int(code_len)]
    return ("Gold code len=%d (n=%d LFSRs, G1 taps %s, G2 taps %s), "
            "processing gain %.1f dB"
            % (code_len, n, g1, g2, processing_gain_db(code_len)))


# ---------------------------------------------------------------------------
# Legacy tap-pair generator, kept only so the tests can prove the new
# shift-based generator reproduces the original 1023-chip codes exactly.
# Nothing in the signal path calls this.
# ---------------------------------------------------------------------------

LEGACY_PRN_TAPS = {0: (2, 6), 1: (3, 7), 2: (4, 8), 3: (5, 9), 4: (1, 9),
                   5: (2, 10), 6: (1, 8), 7: (2, 9), 8: (3, 10), 9: (2, 3),
                   10: (3, 4), 11: (5, 6), 12: (6, 7), 13: (7, 8),
                   14: (8, 9), 15: (9, 10)}


def legacy_gps_gold_code(code_len=1023, prn_taps=(2, 6)):
    """The project's original generator, verbatim in behaviour."""
    def g1_sequence(n_chips):
        reg = [1] * 10
        out = np.empty(n_chips, dtype=np.uint8)
        for i in range(n_chips):
            out[i] = reg[9]
            fb = reg[2] ^ reg[9]
            reg = [fb] + reg[:-1]
        return out

    def g2_sequence(taps, n_chips):
        reg = [1] * 10
        t0, t1 = taps[0] - 1, taps[1] - 1
        out = np.empty(n_chips, dtype=np.uint8)
        for i in range(n_chips):
            out[i] = reg[t0] ^ reg[t1]
            fb = reg[1] ^ reg[2] ^ reg[5] ^ reg[7] ^ reg[8] ^ reg[9]
            reg = [fb] + reg[:-1]
        return out

    bits = g1_sequence(code_len) ^ g2_sequence(prn_taps, code_len)
    return 1.0 - 2.0 * bits.astype(np.float32)


__all__ = ['gold_code', 'node_shift', 'm_sequence', 'processing_gain_db',
           'describe', 'SUPPORTED_CODE_LENGTHS', 'DEFAULT_CODE_LEN',
           'MAX_NODES', 'LEGACY_PRN_TAPS', 'legacy_gps_gold_code']
