"""
Link Metrics - the aggregator behind the Debug window
======================================================

One block that knows about every other block, samples their counters on a
timer, derives the numbers that are not directly measurable anywhere, and
emits a single telemetry line per tick. Everything here is read-only
observation: nothing sits in the signal path and nothing it does can
affect TX pacing or RX decode timing.

The point is to answer the questions that actually matter when a link is
misbehaving, rather than only reporting what is easy to count:

**What rate am I really getting?** Configured chip rate, sample rate, code
length and symbol rate give the theoretical ceiling; measured goodput over
a sliding window gives the truth, and the ratio between them is how much
of the air time is carrying payload rather than idle filler.

**How hard is the FEC working?** Three separate error rates, each meaning
something different:

  * *pre-FEC (channel) BER* - measured by re-encoding the Viterbi output
    and comparing against the received hard decisions. This is the raw
    channel, before any correction, and needs no test pattern.
  * *post-Viterbi symbol errors* - what Reed-Solomon had to repair, i.e.
    what the inner code let through.
  * *post-FEC BER* - measured against the known PRBS carried by idle
    frames, so it is a true end-to-end number on live conditions.

**How much margin is left?** RS(255,223) corrects 16 symbols per codeword.
Reporting the worst-case corrections per frame and `16 - worst` as
headroom turns "it's working" into "it's working with three symbols to
spare", which is the difference between a link that is fine and one that
is about to fall over. Eb/N0 is estimated from the measured pre-FEC BER,
so it can be compared against the ~2.5 dB the concatenated code needs.

**Is the physical layer healthy?** Despreader lock state, measured versus
ideal processing gain, acquisition count (a link quietly re-acquiring over
and over looks the same as a slow one from the outside), EVM, RX power and
the UHD underflow/overflow counters.
"""

import math
import time

import numpy as np
import pmt
from gnuradio import gr


def make_pdu(text):
    data = text.encode('utf-8', 'replace')
    return pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(data), list(data)))


def q_inverse(p):
    """Inverse Gaussian tail, good enough for an Eb/N0 estimate."""
    if p <= 0:
        return float('inf')
    if p >= 0.5:
        return 0.0
    # Acklam-style rational approximation
    a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02,
         1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00]
    b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02,
         6.680131188771972e+01, -1.328068155288572e+01]
    c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00,
         -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00]
    d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00,
         3.754408661907416e+00]
    plow = 0.02425
    if p < plow:
        q = math.sqrt(-2 * math.log(p))
        return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / \
               ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1)
    q = p - 0.5
    r = q * q
    return -(((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / \
           (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1)


class blk(gr.sync_block):
    """Link Metrics (aggregator)"""

    def __init__(self, tx_source=None, rx_decoder=None, despreader=None,
                 reassembler=None, chip_rate=2046000.0, code_len=1023,
                 sps=4, rs_codewords=2, period_s=1.0, window_s=10.0):
        gr.sync_block.__init__(self, name='Link Metrics',
                               in_sig=[], out_sig=[])
        self.tx_source = tx_source
        self.rx_decoder = rx_decoder
        self.despreader = despreader
        self.reassembler = reassembler

        import dsss_frame as FR
        import dsss_fec as FEC
        self.chip_rate = float(chip_rate)
        self.code_len = int(code_len)
        self.sps = int(sps)
        self.n_cw = int(rs_codewords)
        self.samp_rate = self.chip_rate * self.sps
        self.symbol_rate = self.chip_rate / float(self.code_len)
        self.frame_symbols = FR.frame_symbols(self.n_cw)
        self.frame_period = self.frame_symbols / self.symbol_rate
        self.payload_per_frame = FR.payload_bytes(self.n_cw)
        self.code_rate = FR.code_rate(self.n_cw)
        self.raw_bitrate = self.symbol_rate * 2.0
        self.payload_bitrate = self.payload_per_frame * 8 / self.frame_period
        self.rs_t = FEC.RS_T
        self.ideal_gain_db = 10.0 * math.log10(self.code_len)

        self.period_s = float(period_s)
        self.window_s = float(window_s)

        self.message_port_register_out(pmt.intern('diag'))
        self.message_port_register_in(pmt.intern('health'))
        self.set_msg_handler(pmt.intern('health'), self._on_health)

        self._health = {}
        self._hist = []
        self._last = 0.0
        self._start = time.time()

        # A source block with no inputs is never called by the scheduler,
        # so drive the periodic emission from a timer thread instead.
        import threading
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True,
                                        name='dsss-metrics')
        self._thread.start()

    # -- inputs ------------------------------------------------------------

    def _on_health(self, msg):
        try:
            vec = pmt.cdr(msg) if pmt.is_pair(msg) else msg
            text = bytes(bytearray(pmt.u8vector_elements(vec))).decode(
                'utf-8', 'replace')
        except Exception:
            return
        # "HEALTH TX UNDERFLOW #3 (total async events=12)"
        parts = text.split()
        if len(parts) >= 3 and parts[0] == 'HEALTH':
            key = "%s_%s" % (parts[1], parts[2])
            self._health[key] = self._health.get(key, 0) + 1

    def work(self, input_items, output_items):
        return 0

    def stop(self):
        self._stop.set()
        return True

    def _run(self):
        while not self._stop.wait(self.period_s):
            try:
                self._emit()
            except Exception:
                pass

    # -- derived metrics ---------------------------------------------------

    def _emit(self):
        now = time.time()
        rx = self.rx_decoder.stats() if self.rx_decoder else {}
        tx = self.tx_source.stats() if self.tx_source else {}
        ds = self.despreader.stats() if self.despreader else {}
        ra = self.reassembler.stats() if self.reassembler else {}

        # sliding window for rate measurements
        self._hist.append((now, rx.get('payload_bytes_ok', 0),
                           tx.get('payload_bytes_sent', 0),
                           rx.get('frames_ok', 0) + rx.get('frames_bad', 0)))
        cutoff = now - self.window_s
        while len(self._hist) > 2 and self._hist[0][0] < cutoff:
            self._hist.pop(0)

        goodput = tx_rate = frame_rate = 0.0
        if len(self._hist) >= 2:
            dt = self._hist[-1][0] - self._hist[0][0]
            if dt > 0:
                goodput = (self._hist[-1][1] - self._hist[0][1]) * 8 / dt
                tx_rate = (self._hist[-1][2] - self._hist[0][2]) * 8 / dt
                frame_rate = (self._hist[-1][3] - self._hist[0][3]) / dt

        frames_ok = rx.get('frames_ok', 0)
        frames_bad = rx.get('frames_bad', 0)
        total = frames_ok + frames_bad
        fer = (frames_bad / float(total)) if total else 0.0

        chan_ber = rx.get('chan_ber', 0.0)
        post_ber = rx.get('post_fec_ber', None)

        # Eb/N0 implied by the measured raw channel BER. For coherent QPSK
        # the coded-bit error rate is Q(sqrt(2*Ec/N0)), and Eb = Ec / rate.
        ebno = float('nan')
        if 0 < chan_ber < 0.5:
            x = q_inverse(chan_ber)
            ecno = (x * x) / 2.0
            if ecno > 0:
                ebno = 10 * math.log10(ecno / self.code_rate)

        rs_worst = rx.get('rs_worst', 0)
        headroom = self.rs_t - rs_worst

        parts = [
            "LINK",
            "uptime=%.0f" % (now - self._start),
            # configuration
            "chiprate=%.0f" % self.chip_rate,
            "samprate=%.0f" % self.samp_rate,
            "codelen=%d" % self.code_len,
            "procgain_ideal=%.1f" % self.ideal_gain_db,
            "symrate=%.1f" % self.symbol_rate,
            "rawbitrate=%.1f" % self.raw_bitrate,
            "coderate=%.4f" % self.code_rate,
            "maxpayloadrate=%.1f" % self.payload_bitrate,
            "framesyms=%d" % self.frame_symbols,
            "frameperiod=%.3f" % self.frame_period,
            "payloadperframe=%d" % self.payload_per_frame,
            # measured throughput
            "goodput=%.1f" % goodput,
            "txrate=%.1f" % tx_rate,
            "framerate=%.2f" % frame_rate,
            "efficiency=%.3f" % (goodput / self.payload_bitrate
                                 if self.payload_bitrate else 0.0),
            # FEC
            "framesok=%d" % frames_ok,
            "framesbad=%d" % frames_bad,
            "fer=%.4e" % fer,
            "prefec_ber=%.4e" % chan_ber,
            "prefec_errbits=%d" % rx.get('chan_err_bits', 0),
            "prefec_totalbits=%d" % rx.get('chan_total_bits', 0),
            "postfec_ber=%s" % ("%.4e" % post_ber if post_ber is not None
                                else "n/a"),
            "postfec_bits=%d" % rx.get('prbs_total_bits', 0),
            "rs_corrected=%d" % rx.get('rs_corrected', 0),
            "rs_uncorrectable=%d" % rx.get('rs_uncorrectable', 0),
            "rs_worst=%d" % rs_worst,
            "rs_limit=%d" % self.rs_t,
            "rs_headroom=%d" % headroom,
            "ebno_est=%s" % ("%.2f" % ebno if ebno == ebno else "n/a"),
            # sync / physical
            "locked=%d" % (1 if rx.get('locked') else 0),
            "resyncs=%d" % rx.get('resyncs', 0),
            "falsesync=%d" % rx.get('false_sync', 0),
            "procgain_actual=%.1f" % ds.get('margin_db', float('nan')),
            "acquisitions=%d" % ds.get('acquisitions', 0),
            "locklosses=%d" % ds.get('lock_losses', 0),
            "acqsecs=%.2f" % (ds.get('acq_seconds') or -1.0),
            "chipcorrections=%d" % ds.get('phase_corrections', 0),
            "drift=%.3e" % ds.get('phase_corrections', 0),
            # transfers
            "txqueued=%d" % tx.get('queued', 0),
            "txframes=%d" % tx.get('frames_sent', 0),
            "txidle=%d" % tx.get('idle_sent', 0),
            "txdata=%d" % tx.get('data_sent', 0),
            "rxtext=%d" % ra.get('text_done', 0),
            "rxfiles=%d" % ra.get('files_done', 0),
            "rxverified=%d" % ra.get('files_verified', 0),
        ]

        for k, v in sorted(self._health.items()):
            parts.append("health_%s=%d" % (k.lower(), v))

        for t in ra.get('active', [])[:3]:
            parts.append("xfer=%s:%d/%d:%.0f" % (
                t['name'][:24].replace(' ', '_'), t['got'], t['total'],
                t['rate']))

        self.message_port_pub(pmt.intern('diag'), make_pdu(' '.join(parts)))
