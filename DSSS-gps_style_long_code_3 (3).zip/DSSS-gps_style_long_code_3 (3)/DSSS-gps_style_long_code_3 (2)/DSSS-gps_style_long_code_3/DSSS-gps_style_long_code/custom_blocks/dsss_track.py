"""
dsss_track.py - code acquisition and batched tracking
======================================================

The despreading core, kept out of the GNU Radio block so it can be tested
directly (see test_track.py) rather than only inside a running flowgraph.
The block in custom_blocks/dsss_despreader.py is a thin wrapper around
this.

Acquisition is GPS's own parallel code-phase search: one FFT correlates
the incoming samples against all `code_len` rotations of the local replica
at once, O(N log N) instead of O(N^2) over a serial search - accumulated
non-coherently over many code periods, which turns out to be essential.

A single code period is not enough to acquire
----------------------------------------------
The original acquisition tested one code period and declared lock when the
correlation peak stood `acq_threshold` (3.0) times above the median of the
other bins. Measured against pure noise, that test fires on its own about
83% of the time at 1023 chips: the peak-to-median ratio of 1023 Rayleigh
samples averages about 3.3 all by itself, with no signal present at all.
So the receiver would routinely "acquire" onto noise and then sit there
for `lock_loss_symbols` before giving up and trying again.

Worse, raising the threshold alone does not fix it, because at the SNR
this link is designed for there is genuinely nothing to see in one code
period. At -28 dB chip SNR - the operating point implied by 1023 chips of
spreading gain and a 2 dB Es/N0 - a single period gives a peak-to-median
around 1.8, which is inside the noise distribution.

Accumulating |correlation|^2 over 64 code periods fixes both ends at once:
the noise statistic concentrates (peak/median falls to about 1.7) while
the signal peak keeps growing, giving clean separation down to -28 dB.
The data modulation changes every code period, so the accumulation has to
be non-coherent - magnitudes, not complex values - which is exactly what a
GPS receiver does for the same reason.

Tracking used to re-search a window of chip offsets for *every* symbol,
which measured at about 46 microseconds per symbol - fine at 500 symbols
per second, fatal at 32,000, and the direct cause of RX overflow when the
sample rate went up. The observation that fixes it: chip alignment barely
moves. Two oscillators a few parts per million apart drift roughly 0.002
chips per symbol, so over a batch of 64 symbols the code phase shifts by
about an eighth of a chip - nothing. So a whole batch is despread with a
single matrix multiply, and alignment is maintained between batches by an
early/late discriminator computed over that same batch.

That is 0.33 microseconds per symbol, about 140x cheaper, which is what
turns the receive chain from "cannot keep up" into "barely registers".
"""

import numpy as np

import dsss_codes as CODES


class CodeTracker:
    """Acquires and tracks a spreading code, despreading in batches."""

    def __init__(self, code_len=1023, node_id=0, batch_symbols=64,
                 acq_threshold=1.8, acq_periods=64, lock_loss_symbols=500,
                 track_gain=0.35):
        self.code_len = int(code_len)
        self.max_batch = max(1, int(batch_symbols))
        self.batch_symbols = self.max_batch
        # Threshold applies to the NON-COHERENTLY ACCUMULATED peak/median,
        # not to a single code period - see the module docstring for why a
        # single-period test at 3.0 fires on noise most of the time.
        self.acq_threshold = float(acq_threshold)
        self.acq_periods = max(1, int(acq_periods))
        self.lock_loss_symbols = int(lock_loss_symbols)
        self.track_gain = float(track_gain)
        self.ideal_gain_db = CODES.processing_gain_db(self.code_len)

        self.acquired = False
        self.center = 0.0          # absolute sample index of next symbol
        self.rate = 0.0            # estimated drift, chips per symbol
        self.weak_count = 0
        self.acquisitions = 0
        self.lock_losses = 0
        self.phase_corrections = 0
        self.last_peak = 0.0
        self.last_floor = 0.0
        self._clean_batches = 0

        self._acq_acc = None
        self._acq_count = 0

        self.set_node(int(node_id), force=True)

    def _reset_acq(self):
        self._acq_acc = np.zeros(self.code_len, dtype=np.float64)
        self._acq_count = 0

    def set_node(self, node_id, force=False):
        node_id = int(node_id)
        if not force and node_id == getattr(self, 'node_id', None):
            return
        self.node_id = node_id
        self.code = CODES.gold_code(self.code_len, node_id)
        self.code_c = self.code.astype(np.complex64)
        self.code_fft = np.conj(np.fft.fft(self.code))
        # Half-period rotation of the same code: correlating the on-time
        # windows against this is a genuinely decorrelated reference, so
        # the reported processing gain is a measurement of the peak above
        # the local noise floor rather than an assumption.
        self.code_ref = np.roll(self.code_c, self.code_len // 2)
        self._reset_acq()
        if not force:
            # Switching who we listen to invalidates any existing lock at
            # once - a stale lock on the old code must not be trusted for
            # even one more symbol.
            self.acquired = False
            self.weak_count = 0
            self.rate = 0.0

    @property
    def margin_db(self):
        if self.last_floor > 0 and self.last_peak > 0:
            return 20.0 * np.log10(self.last_peak / self.last_floor)
        return float('-inf')

    # -- acquisition -------------------------------------------------------

    def acquire(self, samples, base=0):
        """Accumulate one code period into the acquisition search.

        Returns the number of samples consumed. Accumulation is spread
        across calls rather than demanding all `acq_periods * code_len`
        samples at once, so the block never has to ask the scheduler for a
        buffer measured in hundreds of thousands of samples."""
        L = self.code_len
        if len(samples) < L:
            return 0

        corr = np.fft.ifft(np.fft.fft(samples[:L]) * self.code_fft)
        # Non-coherent: the data symbol changes every code period, so
        # magnitudes accumulate where complex values would cancel.
        self._acq_acc += np.abs(corr) ** 2
        self._acq_count += 1

        if self._acq_count < self.acq_periods:
            return L

        acc = self._acq_acc
        best = int(np.argmax(acc))
        peak = float(acc[best])
        floor = float(np.median(acc))
        self.last_peak = np.sqrt(peak)
        self.last_floor = np.sqrt(floor) if floor > 0 else 0.0

        if floor > 0 and peak > self.acq_threshold * floor:
            # `best` is the code phase within the period just consumed;
            # the accumulation ran over `acq_periods` of them, all sharing
            # that phase, so the next symbol starts one period on from the
            # last window's start.
            self.center = float(base + best + L)
            self.rate = 0.0
            self.acquired = True
            self.weak_count = 0
            self._clean_batches = 0
            self.batch_symbols = self.max_batch
            self.acquisitions += 1
            self._reset_acq()
            # Keep from `best` onward: the tracker's first batch needs a
            # chip of guard before `center`, which lies inside this
            # symbol's own span.
            return best

        self._reset_acq()
        return L

    # -- tracking ----------------------------------------------------------

    def track(self, samples, base, max_symbols):
        """Despread up to `max_symbols`. Returns (symbols, consumed)."""
        L = self.code_len
        n_avail = len(samples)
        out = []
        produced = 0

        while produced < max_symbols:
            idx = int(round(self.center))
            rel = idx - base
            room = (n_avail - rel - 1) // L if rel >= 1 else 0
            m = min(max_symbols - produced, self.batch_symbols, room)
            if m < 1:
                break

            # Early, on-time and late for the whole batch: three BLAS
            # calls total, not three per symbol. reshape on a contiguous
            # slice is a view, so nothing is copied.
            cands = []
            for shift in (-1, 0, 1):
                blk = samples[rel + shift:rel + shift + m * L].reshape(m, L)
                v = blk @ self.code_c
                cands.append((float(np.abs(v).mean()), shift, v))

            # Take whichever alignment is actually strongest rather than
            # always taking on-time and correcting next time round. At
            # integer chip spacing a DSSS correlation is all-or-nothing -
            # one chip out and it collapses to the sidelobe floor - so
            # emitting the on-time batch while a chip behind would hand
            # the decoder a whole batch of noise. Choosing the best of the
            # three costs nothing extra, since all three are computed for
            # the discriminator anyway, and makes drift cost no symbols.
            best_mean, shift, best = max(cands, key=lambda c: c[0])

            block = samples[rel + shift:rel + shift + m * L].reshape(m, L)
            floor = float(np.abs(block @ self.code_ref).mean())

            out.append(best)
            produced += m
            self.last_peak, self.last_floor = best_mean, floor

            # Advance, then let an integrator learn the drift rate. Once
            # `rate` matches the real clock offset the predicted advance
            # absorbs it and the one-chip corrections stop, which is what
            # lets this follow a constant drift instead of forever lagging
            # it by up to a chip.
            self.center += m * L + shift + self.rate * m
            if shift:
                self.phase_corrections += 1
                self.rate += self.track_gain * shift / float(m)
                self._clean_batches = 0
                # Drifting fast? Look more often, so the error never gets
                # more than a chip ahead of the discriminator.
                self.batch_symbols = max(8, self.batch_symbols // 2)
            else:
                self._clean_batches += 1
                if self._clean_batches >= 8:
                    self._clean_batches = 0
                    self.batch_symbols = min(self.max_batch,
                                             self.batch_symbols * 2)

            if floor <= 0 or best_mean <= 2.0 * floor:
                self.weak_count += m
            else:
                self.weak_count = 0

            if self.weak_count >= self.lock_loss_symbols:
                self.acquired = False
                self.rate = 0.0
                self.lock_losses += 1
                break

        consumed = max(0, min(n_avail, int(round(self.center)) - 1 - base))
        syms = (np.concatenate(out) if out
                else np.zeros(0, dtype=np.complex64))
        return syms, consumed

    def process(self, samples, base=0, max_symbols=None):
        """Convenience path for tests: acquire if needed, then track."""
        if max_symbols is None:
            max_symbols = len(samples) // self.code_len + 1
        if not self.acquired:
            used = self.acquire(samples, base)
            if not self.acquired:
                return np.zeros(0, dtype=np.complex64), used
            return self.track(samples, base, max_symbols)
        return self.track(samples, base, max_symbols)

    def stats(self):
        return {
            'locked': self.acquired,
            'acquisitions': self.acquisitions,
            'lock_losses': self.lock_losses,
            'phase_corrections': self.phase_corrections,
            'margin_db': self.margin_db,
            'ideal_gain_db': self.ideal_gain_db,
            'code_len': self.code_len,
            'node_id': self.node_id,
        }


__all__ = ['CodeTracker']
