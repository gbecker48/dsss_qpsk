"""
DSSS Despreader - the processing-gain step
===========================================

Still the very first thing done to the received signal, before AGC and
before carrier recovery, for the same reason as always: a Costas loop
cannot lock onto something it cannot see, so the spreading gain has to be
applied before anything else looks at the signal. This is also how a GPS
receiver orders its code and carrier loops.

The algorithm lives in `dsss_track.CodeTracker`, deliberately kept out of
this block so it can be unit-tested directly (test_track.py) instead of
only inside a running flowgraph. Two things about it changed materially,
both of which were RX-side failures rather than refinements:

**Acquisition could fire on noise.** The old test compared one code
period's correlation peak against 3x the median of the other bins. The
peak-to-median of 1023 pure-noise bins averages about 3.3 all by itself,
so that test passed on noise roughly 83% of the time, and the receiver
would sit on a false lock for `lock_loss_symbols` before retrying. It is
now accumulated non-coherently over 64 code periods, which concentrates
the noise statistic while the real peak keeps growing - clean separation
all the way down to -28 dB chip SNR, which is the operating point 1023
chips of spreading implies.

**Tracking was the RX overflow.** Re-searching a window of chip offsets
for every symbol measured at ~46 microseconds per symbol: 9% of a core at
the default code length and around 150% - i.e. impossible - at the
shortest. Since symbol rate is chip_rate/code_len, raising the sample
rate drove this straight into overflow. Chip alignment barely moves
though, so a whole batch of symbols is now despread with a single matrix
multiply and alignment is maintained by an early/late discriminator over
that same batch, with an integrator that learns the clock drift rate.
Measured at 0.7-4.8% of a core across every supported code length.

Each despread symbol is still tagged with its correlation magnitude, but
decimated (`tag_every`) - one Python call per symbol was pure overhead for
a GUI readout that refreshes ten times a second.
"""

import time

import numpy as np
import pmt
from gnuradio import gr

import dsss_codes as CODES
from dsss_track import CodeTracker


class blk(gr.basic_block):
    """DSSS Despreader (acquisition + batched tracking, per-node Gold code)"""

    def __init__(self, code_len=1023, node_id=1, batch_symbols=64,
                 acq_threshold=1.8, acq_periods=64, lock_loss_symbols=500,
                 stats_period_symbols=200, tag_every=16):
        gr.basic_block.__init__(
            self, name='DSSS Despreader',
            in_sig=[np.complex64], out_sig=[np.complex64])
        self.code_len = int(code_len)
        self.tag_every = max(0, int(tag_every))
        self.stats_period_symbols = max(1, int(stats_period_symbols))

        self.tracker = CodeTracker(code_len=self.code_len, node_id=int(node_id),
                                   batch_symbols=int(batch_symbols),
                                   acq_threshold=float(acq_threshold),
                                   acq_periods=int(acq_periods),
                                   lock_loss_symbols=int(lock_loss_symbols))

        self._node_id = int(node_id)
        self._sym_count = 0
        self._was_locked = False
        self._search_started = time.time()
        self.last_acq_seconds = float('nan')

        self.set_tag_propagation_policy(gr.TPP_DONT)
        # Tell the scheduler this decimates by code_len, so it sizes work
        # requests sensibly instead of asking for an output that would
        # need millions of input samples.
        try:
            self.set_relative_rate(1.0 / self.code_len)
        except Exception:
            pass

        self.message_port_register_out(pmt.intern('stats'))

    # -- per-node code selection (settable live from GRC) -----------------

    @property
    def node_id(self):
        return self._node_id

    @node_id.setter
    def node_id(self, value):
        value = int(value)
        if value == self._node_id:
            return
        self._node_id = value
        was = self.tracker.acquired
        self.tracker.set_node(value)
        self._search_started = time.time()
        if was:
            self._publish_stats(locked=False)

    # -- telemetry ---------------------------------------------------------

    def _publish_stats(self, locked):
        t = self.tracker
        text = ("PROCGAIN actual=%.1f ideal=%.1f locked=%d acq=%d losses=%d "
                "acqsecs=%.2f corrections=%d drift=%.3e codelen=%d node=%d"
                % (t.margin_db if np.isfinite(t.margin_db) else -99.0,
                   t.ideal_gain_db, int(locked), t.acquisitions,
                   t.lock_losses,
                   self.last_acq_seconds
                   if self.last_acq_seconds == self.last_acq_seconds else -1.0,
                   t.phase_corrections, t.rate, self.code_len, self._node_id))
        try:
            self.message_port_pub(
                pmt.intern('stats'),
                pmt.cons(pmt.PMT_NIL,
                         pmt.init_u8vector(len(text), list(text.encode('utf-8')))))
        except Exception:
            pass

    def forecast(self, noutput_items, ninputs):
        need = (noutput_items + 2) * self.code_len + 8
        return [need] * ninputs

    # -- main --------------------------------------------------------------

    def general_work(self, input_items, output_items):
        in0 = input_items[0]
        out = output_items[0]
        base = self.nitems_read(0)
        t = self.tracker

        if not t.acquired:
            used = t.acquire(in0, base)
            if t.acquired:
                self.last_acq_seconds = time.time() - self._search_started
                self._was_locked = True
                self._publish_stats(locked=True)
            self.consume(0, max(0, used))
            return 0

        syms, consumed = t.track(in0, base, len(out))
        n = len(syms)
        if n:
            out[:n] = syms
            if self.tag_every:
                start = self.nitems_written(0)
                mags = np.abs(syms)
                for j in range(0, n, self.tag_every):
                    self.add_item_tag(0, start + j, pmt.intern('corr_mag'),
                                      pmt.from_double(float(mags[j])))

        self._sym_count += n
        if self._sym_count >= self.stats_period_symbols:
            self._sym_count = 0
            self._publish_stats(locked=t.acquired)

        if self._was_locked and not t.acquired:
            self._was_locked = False
            self._search_started = time.time()
            self._publish_stats(locked=False)

        self.consume(0, max(0, consumed))
        return n

    def stats(self):
        s = self.tracker.stats()
        s['acq_seconds'] = self.last_acq_seconds
        return s
