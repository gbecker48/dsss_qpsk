"""
Fragment Reassembler - text messages and arbitrary-size files
==============================================================

Wraps `dsss_transfer.RxReassembler`. Text messages behave exactly as
before: assembled in memory and published on the RX data port, so the
ground station's message panes are unchanged.

Files take a different path, because they have to. UDP datagrams cap out
at 64 KB and a multi-gigabyte transfer cannot be buffered in RAM, so file
fragments are written straight into a sparse file at their own offsets as
they arrive, with only a received-fragment bitmap held in memory. A 4 GB
transfer costs about a megabyte of bookkeeping rather than 4 GB. On
completion the file is truncated to its declared length, its SHA-256 is
checked against the sender's, and its path is announced on the status
port.

Addressing behaves as before: a fragment not addressed to this node (or
to the 0xFF broadcast id) is reported as FOREIGN rather than silently
consumed, and a fragment whose SRC does not match the node we are
despreading gets a WARN, which is a strong hint that two nodes have picked
the same code.
"""

import numpy as np
import pmt
from gnuradio import gr

import dsss_transfer as XFER


def pdu_bytes(msg):
    vec = pmt.cdr(msg) if pmt.is_pair(msg) else msg
    try:
        return bytes(bytearray(pmt.u8vector_elements(vec)))
    except Exception:
        return b''


def make_pdu(data):
    data = bytes(data)
    return pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(data), list(data)))


class blk(gr.basic_block):
    """Fragment Reassembler (text + files, node-addressed)"""

    def __init__(self, rs_codewords=2, my_node_id=0, dest_node_id=1,
                 inbox='rx_files', stale_seconds=600.0, quiet_idle=True):
        gr.basic_block.__init__(self, name='Fragment Reassembler',
                                in_sig=[], out_sig=[])
        import dsss_frame as FR
        self.payload_bytes = FR.payload_bytes(int(rs_codewords))
        self.quiet_idle = bool(quiet_idle)
        self._my_node_id = int(my_node_id)
        self._dest_node_id = int(dest_node_id)

        self.rx = XFER.RxReassembler(self.payload_bytes,
                                     my_node_id=self._my_node_id,
                                     dest_node_id=self._dest_node_id,
                                     inbox=inbox,
                                     stale_seconds=float(stale_seconds))

        self.message_port_register_in(pmt.intern('in'))
        self.message_port_register_out(pmt.intern('msg'))
        self.message_port_register_out(pmt.intern('status'))
        self.set_msg_handler(pmt.intern('in'), self.handle)

    @property
    def my_node_id(self):
        return self._my_node_id

    @my_node_id.setter
    def my_node_id(self, value):
        self._my_node_id = int(value)
        self.rx.set_nodes(my_node_id=self._my_node_id)

    @property
    def dest_node_id(self):
        return self._dest_node_id

    @dest_node_id.setter
    def dest_node_id(self, value):
        self._dest_node_id = int(value)
        self.rx.set_nodes(dest_node_id=self._dest_node_id)

    def handle(self, msg):
        raw = pdu_bytes(msg)
        if len(raw) < 1:
            return
        seq, payload = raw[0], raw[1:]
        try:
            status, delivered = self.rx.handle(payload, seq)
        except Exception as exc:
            self._status("RXERR reassembly fault (%s)" % exc)
            return

        for line in status:
            # Idle heartbeats are useful for a link-alive indicator but
            # flood the log at short code lengths, where frames arrive
            # tens of times a second instead of once every two seconds.
            if self.quiet_idle and line.startswith('IDLE'):
                continue
            self._status(line)
        for data in delivered:
            self.message_port_pub(pmt.intern('msg'), make_pdu(data))

    def _status(self, text):
        print("[RX] " + text)
        self.message_port_pub(pmt.intern('status'),
                              make_pdu(text.encode('utf-8', 'replace')))

    def stats(self):
        return {
            'frames_rx': self.rx.frames_rx,
            'idle_rx': self.rx.idle_rx,
            'foreign_rx': self.rx.foreign_rx,
            'text_done': self.rx.text_done,
            'files_done': self.rx.files_done,
            'files_verified': self.rx.files_verified,
            'payload_bytes_rx': self.rx.payload_bytes_rx,
            'active': self.rx.active_transfers(),
        }
