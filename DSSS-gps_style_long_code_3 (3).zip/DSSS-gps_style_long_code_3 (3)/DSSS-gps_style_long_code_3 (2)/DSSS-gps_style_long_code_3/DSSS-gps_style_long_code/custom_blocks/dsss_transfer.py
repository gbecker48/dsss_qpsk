"""
dsss_transfer.py - fragmentation, reassembly and arbitrary-size file transfer
=============================================================================

The original link could carry a message of at most 64,000 bytes, because
the fragment index on the wire was a single byte: 256 fragments x 250
usable bytes and no more. This replaces that with a transfer layer that
has no practical ceiling, and that moves files without ever holding one
in memory at either end.

What changed on the wire
------------------------
The 6-byte fragment header grew to 13 bytes:

    [0]      SRC          node id of the sender
    [1]      DST          node id of the addressee (0xFF = broadcast)
    [2]      TYPE         0 idle, 1 text, 2 file data, 3 file metadata
    [3:5]    MSG_ID       uint16, identifies the object
    [5:8]    FRAG_IDX     uint24  <- was 1 byte
    [8:11]   FRAG_TOTAL   uint24  <- was 1 byte
    [11:13]  CHUNK_LEN    uint16  <- was 1 byte

A 24-bit fragment index at 428 data bytes per fragment puts the ceiling at
roughly 7.2 GB per object, which is well past anything this link could
transmit in a human lifetime - so "any size" is, practically, true.

Why files never sit in RAM
--------------------------
A 64 KB message can be assembled in memory and handed over a UDP socket.
A file cannot: UDP datagrams top out at 64 KB, and a multi-gigabyte
transfer would otherwise need a multi-gigabyte buffer at each end. So
files take a different path from text:

  * **Transmit** reads the file lazily, one fragment at a time, on a
    background thread that keeps a small queue of ready-to-send fragments.
    That thread is what makes this safe: the radio's own work() call never
    touches the disk, so a slow or cold read can never stall the sample
    path and cause an underflow. If the queue ever does run dry the
    transmitter emits an idle frame and picks the file back up on the next
    slot - it degrades to slower, never to broken.

  * **Receive** writes each fragment straight into a sparse file at its
    own offset (offset = index x chunk size, which is why file fragments
    carry no per-fragment offset field), keeping only a received-fragment
    bitmap in memory. A 4 GB transfer costs a 1 MB bitmap, not 4 GB of
    RAM. When every fragment has arrived the file is truncated to its
    declared length and its SHA-256 is checked against the sender's.

Text messages still travel the old way - assembled in memory, delivered
over the existing RX data socket - so the ground station's message panes
behave exactly as before.

Metadata is sent twice
----------------------
There is no ARQ on this link, so a lost fragment is lost. The file's name,
length and hash ride in their own single-fragment metadata object sent
*before* the data and repeated *after* it. Losing one copy costs nothing;
losing both only costs the filename (the data still lands, under a
recovered-by-id name) rather than the transfer.
"""

import hashlib
import os
import struct
import threading
import time
from collections import deque

import numpy as np

# ---------------------------------------------------------------------------
# Wire format
# ---------------------------------------------------------------------------

FRAG_HEADER_BYTES = 13

TYPE_IDLE = 0
TYPE_TEXT = 1
TYPE_FILE_DATA = 2
TYPE_FILE_META = 3

TYPE_NAMES = {TYPE_IDLE: 'IDLE', TYPE_TEXT: 'TEXT',
              TYPE_FILE_DATA: 'FILE', TYPE_FILE_META: 'FILEMETA'}

BROADCAST_NODE = 0xFF

MAX_FRAG_INDEX = (1 << 24) - 1


def _u24(value):
    v = int(value) & 0xFFFFFF
    return bytes(((v >> 16) & 0xFF, (v >> 8) & 0xFF, v & 0xFF))


def _r24(buf, off):
    return (buf[off] << 16) | (buf[off + 1] << 8) | buf[off + 2]


def pack_header(src, dst, typ, msg_id, frag_idx, frag_total, chunk_len):
    return (bytes((int(src) & 0xFF, int(dst) & 0xFF, int(typ) & 0xFF))
            + struct.pack('>H', int(msg_id) & 0xFFFF)
            + _u24(frag_idx) + _u24(frag_total)
            + struct.pack('>H', int(chunk_len) & 0xFFFF))


def unpack_header(buf):
    if len(buf) < FRAG_HEADER_BYTES:
        return None
    return {
        'src': buf[0],
        'dst': buf[1],
        'type': buf[2],
        'msg_id': (buf[3] << 8) | buf[4],
        'frag_idx': _r24(buf, 5),
        'frag_total': _r24(buf, 8),
        'chunk_len': (buf[11] << 8) | buf[12],
    }


def make_fragment(payload_bytes, src, dst, typ, msg_id, frag_idx,
                  frag_total, data):
    """Build one fixed-size, zero-padded fragment payload."""
    chunk_bytes = payload_bytes - FRAG_HEADER_BYTES
    data = data[:chunk_bytes]
    header = pack_header(src, dst, typ, msg_id, frag_idx, frag_total, len(data))
    return header + data + bytes(chunk_bytes - len(data))


def chunk_bytes_for(payload_bytes):
    return int(payload_bytes) - FRAG_HEADER_BYTES


# ---------------------------------------------------------------------------
# Transmit side
# ---------------------------------------------------------------------------


class _TextObject:
    """A whole in-memory object (a text message, or file metadata)."""

    def __init__(self, msg_id, typ, data, chunk_bytes, label=''):
        self.msg_id = msg_id
        self.type = typ
        self.data = data
        self.chunk_bytes = chunk_bytes
        self.label = label
        self.total = max(1, (len(data) + chunk_bytes - 1) // chunk_bytes)
        self.next_idx = 0
        self.bytes_total = len(data)

    def done(self):
        return self.next_idx >= self.total

    def take(self):
        i = self.next_idx
        self.next_idx += 1
        return i, self.total, self.data[i * self.chunk_bytes:
                                        (i + 1) * self.chunk_bytes]


class _FileObject:
    """A file read lazily from disk, fragment by fragment."""

    def __init__(self, msg_id, path, chunk_bytes):
        self.msg_id = msg_id
        self.type = TYPE_FILE_DATA
        self.path = path
        self.chunk_bytes = chunk_bytes
        self.size = os.path.getsize(path)
        self.total = max(1, (self.size + chunk_bytes - 1) // chunk_bytes)
        if self.total > MAX_FRAG_INDEX + 1:
            raise ValueError("file too large for the 24-bit fragment index "
                             "(%d bytes needs %d fragments, max %d)"
                             % (self.size, self.total, MAX_FRAG_INDEX + 1))
        self.next_idx = 0
        self.bytes_total = self.size
        self._fh = open(path, 'rb')
        self.label = os.path.basename(path)

    def done(self):
        return self.next_idx >= self.total

    def take(self):
        i = self.next_idx
        self.next_idx += 1
        self._fh.seek(i * self.chunk_bytes)
        return i, self.total, self._fh.read(self.chunk_bytes)

    def close(self):
        try:
            self._fh.close()
        except Exception:
            pass


def file_sha256(path, block=1 << 20):
    h = hashlib.sha256()
    with open(path, 'rb') as fh:
        while True:
            b = fh.read(block)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


class TxQueue:
    """Produces one ready-to-send fragment payload on demand, forever.

    `next_payload()` is called from the radio's work() function and must
    never block and never fail - if there is nothing queued it returns an
    idle fragment. All disk access happens on the background thread, so a
    slow read delays a file transfer but can never stall the transmitter.
    """

    def __init__(self, payload_bytes, my_node_id=0, dest_node_id=1,
                 prefetch=512, status_cb=None):
        self.payload_bytes = int(payload_bytes)
        self.chunk_bytes = chunk_bytes_for(payload_bytes)
        self.my_node_id = int(my_node_id)
        self.dest_node_id = int(dest_node_id)
        self.status_cb = status_cb

        self._lock = threading.Lock()
        self._objects = deque()          # pending objects, in order
        self._ready = deque()            # prebuilt fragment payloads
        self._prefetch = int(prefetch)
        self._msg_id = 0
        self._stop = threading.Event()
        self._wake = threading.Event()

        # counters, read by the metrics layer
        self.frames_sent = 0
        self.idle_sent = 0
        self.data_sent = 0
        self.payload_bytes_sent = 0
        self.current_label = ''
        self.current_sent = 0
        self.current_total = 0

        self._thread = threading.Thread(target=self._run, daemon=True,
                                        name='dsss-tx-reader')
        self._thread.start()

    # -- public API ------------------------------------------------------

    def set_nodes(self, my_node_id=None, dest_node_id=None):
        with self._lock:
            if my_node_id is not None:
                self.my_node_id = int(my_node_id)
            if dest_node_id is not None:
                self.dest_node_id = int(dest_node_id)

    def _next_msg_id(self):
        mid = self._msg_id
        self._msg_id = (self._msg_id + 1) & 0xFFFF
        return mid

    def enqueue_text(self, data):
        data = bytes(data)
        if not data:
            return None
        with self._lock:
            mid = self._next_msg_id()
            obj = _TextObject(mid, TYPE_TEXT, data, self.chunk_bytes,
                              label='message')
            self._objects.append(obj)
        self._note("QUEUED type=TEXT msg=%d bytes=%d frags=%d"
                   % (mid, len(data), obj.total))
        self._wake.set()
        return mid

    def enqueue_file(self, path):
        """Queue a file of any size. Metadata is sent before and after."""
        path = os.path.abspath(os.path.expanduser(path))
        if not os.path.isfile(path):
            self._note("FILEERR path=%s (not a file)" % path)
            return None
        try:
            size = os.path.getsize(path)
            digest = file_sha256(path)
        except OSError as exc:
            self._note("FILEERR path=%s (%s)" % (path, exc))
            return None

        with self._lock:
            mid = self._next_msg_id()
            try:
                fobj = _FileObject(mid, path, self.chunk_bytes)
            except (OSError, ValueError) as exc:
                self._note("FILEERR path=%s (%s)" % (path, exc))
                return None
            meta = build_file_meta(mid, os.path.basename(path), size,
                                   digest, self.chunk_bytes, fobj.total)
            self._objects.append(_TextObject(mid, TYPE_FILE_META, meta,
                                             self.chunk_bytes, label='meta'))
            self._objects.append(fobj)
            # repeat the metadata as a trailer, so losing one copy is free
            self._objects.append(_TextObject(mid, TYPE_FILE_META, meta,
                                             self.chunk_bytes, label='meta'))
        self._note("QUEUED type=FILE msg=%d name=%s bytes=%d frags=%d sha256=%s"
                   % (mid, os.path.basename(path), size, fobj.total, digest[:16]))
        self._wake.set()
        return mid

    def pending_fragments(self):
        with self._lock:
            n = len(self._ready)
            for obj in self._objects:
                n += max(0, obj.total - obj.next_idx)
            return n

    def next_payload(self):
        """Never blocks, never raises. Returns exactly payload_bytes bytes.

        This is called straight from the radio's work() function, so the
        one hard rule is that it must always return immediately. It has
        three tiers:

          1. a fragment the background reader already prepared;
          2. failing that, an in-memory object (a text message, or file
             metadata) built inline - safe because it touches no disk, and
             worth doing because it means a short message always goes out
             on the very next slot instead of waiting for a thread to be
             scheduled;
          3. failing that, an idle frame.

        Only file data ever falls through to tier 3, and only for as long
        as it takes the reader to get ahead again."""
        payload = None
        with self._lock:
            if self._ready:
                payload, _ = self._ready.popleft()
            elif self._objects and isinstance(self._objects[0], _TextObject):
                obj = self._objects[0]
                idx, total, data = obj.take()
                payload = make_fragment(self.payload_bytes, self.my_node_id,
                                        self.dest_node_id, obj.type,
                                        obj.msg_id, idx, total, data)
                self.current_label = obj.label
                self.current_sent = obj.next_idx
                self.current_total = obj.total
                if obj.done():
                    self._objects.popleft()

            if payload is not None:
                self.frames_sent += 1
                self.data_sent += 1
                self.payload_bytes_sent += self.chunk_bytes
            else:
                self.frames_sent += 1
                self.idle_sent += 1
                src, dst = self.my_node_id, self.dest_node_id

        self._wake.set()
        if payload is not None:
            return payload
        return self._idle_payload(src, dst)

    def stop(self):
        self._stop.set()
        self._wake.set()

    # -- internals -------------------------------------------------------

    def _idle_payload(self, src, dst):
        # Idle frames are filled with a deterministic PRBS rather than
        # zeros, so the receiver - which can regenerate the same pattern -
        # measures the true post-FEC bit error rate continuously, on live
        # link conditions, with no test mode and no known-data setup.
        from dsss_fec import prbs15
        return make_fragment(self.payload_bytes, src, dst, TYPE_IDLE,
                             0, 0, 0, prbs15(self.chunk_bytes))

    def _run(self):
        while not self._stop.is_set():
            try:
                self._fill()
            except Exception as exc:          # never let the thread die
                self._note("TXERR %s" % exc)
                time.sleep(0.1)
                continue
            # Only go to sleep when there is genuinely nothing left to
            # prepare. Waiting on the wake event while work is outstanding
            # would let the prefetch queue run dry under a fast consumer,
            # which shows up as idle frames interrupting a file transfer.
            with self._lock:
                has_file_work = any(isinstance(o, _FileObject)
                                    for o in self._objects)
                idle = (not has_file_work) or len(self._ready) >= self._prefetch
            if idle:
                self._wake.wait(0.2)
                self._wake.clear()

    def _fill(self):
        while True:
            if self._stop.is_set():
                return
            with self._lock:
                if len(self._ready) >= self._prefetch:
                    return
                if not self._objects:
                    return
                obj = self._objects[0]
                # In-memory objects belong to next_payload(), which builds
                # them inline. Keeping each object type owned by exactly
                # one path removes any chance of the two racing for the
                # same fragment index.
                if not isinstance(obj, _FileObject):
                    return
                src, dst = self.my_node_id, self.dest_node_id
            try:
                idx, total, data = obj.take()
            except OSError as exc:
                self._note("FILEERR msg=%d (%s)" % (obj.msg_id, exc))
                with self._lock:
                    if self._objects and self._objects[0] is obj:
                        self._objects.popleft()
                if isinstance(obj, _FileObject):
                    obj.close()
                continue

            payload = make_fragment(self.payload_bytes, src, dst, obj.type,
                                    obj.msg_id, idx, total, data)
            with self._lock:
                self._ready.append((payload, False))
                self.current_label = obj.label
                self.current_sent = obj.next_idx
                self.current_total = obj.total

            if obj.done():
                with self._lock:
                    if self._objects and self._objects[0] is obj:
                        self._objects.popleft()
                if isinstance(obj, _FileObject):
                    obj.close()
                    self._note("SENT type=FILE msg=%d name=%s frags=%d"
                               % (obj.msg_id, obj.label, obj.total))
                elif obj.type == TYPE_TEXT:
                    self._note("SENT type=TEXT msg=%d bytes=%d"
                               % (obj.msg_id, obj.bytes_total))

    def _note(self, text):
        if self.status_cb:
            try:
                self.status_cb(text)
            except Exception:
                pass


# ---------------------------------------------------------------------------
# File metadata object (a tiny, human-readable key=value blob)
# ---------------------------------------------------------------------------


def build_file_meta(msg_id, name, size, sha256, chunk, total):
    safe = name.replace('\n', '_').replace('\t', '_')
    text = ("FILEMETA id=%d chunk=%d total=%d size=%d sha256=%s name=%s"
            % (msg_id, chunk, total, size, sha256, safe))
    return text.encode('utf-8', 'replace')


def parse_file_meta(data):
    try:
        text = bytes(data).decode('utf-8', 'replace').strip()
    except Exception:
        return None
    if not text.startswith('FILEMETA '):
        return None
    out = {}
    # name is last and may contain spaces, so split it off first
    head, _, name = text[9:].partition(' name=')
    out['name'] = name.strip() or 'unnamed.bin'
    for tok in head.split():
        key, _, val = tok.partition('=')
        out[key] = val
    try:
        out['id'] = int(out['id'])
        out['chunk'] = int(out['chunk'])
        out['total'] = int(out['total'])
        out['size'] = int(out['size'])
    except (KeyError, ValueError):
        return None
    out.setdefault('sha256', '')
    return out


# ---------------------------------------------------------------------------
# Receive side
# ---------------------------------------------------------------------------


def _safe_name(name):
    """Never let a peer's filename escape the inbox directory."""
    name = os.path.basename(str(name).replace('\\', '/'))
    name = ''.join(ch for ch in name if ch.isprintable() and ch not in '\r\n\t')
    name = name.strip().lstrip('.') or 'unnamed.bin'
    return name[:180]


def _unique_path(directory, name):
    base, ext = os.path.splitext(name)
    candidate = os.path.join(directory, name)
    n = 1
    while os.path.exists(candidate):
        candidate = os.path.join(directory, "%s_%d%s" % (base, n, ext))
        n += 1
    return candidate


class _RxFile:
    def __init__(self, msg_id, total, chunk, directory):
        self.msg_id = msg_id
        self.total = total
        self.chunk = chunk
        self.have = np.zeros(total, dtype=bool)
        self.meta = None
        self.bytes_written = 0
        self.started = time.time()
        self.last_activity = self.started
        self.last_progress = 0.0
        os.makedirs(directory, exist_ok=True)
        self.part_path = os.path.join(directory, ".incoming_%d.part" % msg_id)
        self._fh = open(self.part_path, 'w+b')

    def write(self, idx, data):
        if idx >= self.total or self.have[idx]:
            return False
        self._fh.seek(idx * self.chunk)
        self._fh.write(data)
        self.have[idx] = True
        self.bytes_written += len(data)
        self.last_activity = time.time()
        return True

    def received(self):
        return int(self.have.sum())

    def complete(self):
        return bool(self.have.all())

    def missing(self, limit=12):
        idx = np.nonzero(~self.have)[0]
        return idx[:limit].tolist(), len(idx)

    def close(self):
        try:
            self._fh.close()
        except Exception:
            pass

    def finish(self, directory):
        """Truncate to the declared size, verify the hash, and name it."""
        self._fh.flush()
        size = self.meta['size'] if self.meta else self.bytes_written
        self._fh.truncate(size)
        self._fh.close()

        digest = file_sha256(self.part_path)
        expected = (self.meta or {}).get('sha256', '')
        verified = bool(expected) and digest == expected

        name = _safe_name(self.meta['name']) if self.meta \
            else "recovered_%d.bin" % self.msg_id
        final = _unique_path(directory, name)
        os.replace(self.part_path, final)
        return final, digest, verified, size


class RxReassembler:
    """Reassembles both text messages and files.

    Text is buffered in memory and handed back whole. Files are written
    straight to disk as fragments arrive, so size is bounded by the disk
    rather than by RAM."""

    def __init__(self, payload_bytes, my_node_id=0, dest_node_id=1,
                 inbox='rx_files', stale_seconds=600.0):
        self.payload_bytes = int(payload_bytes)
        self.chunk_bytes = chunk_bytes_for(payload_bytes)
        self.my_node_id = int(my_node_id)
        self.dest_node_id = int(dest_node_id)
        self.inbox = inbox
        self.stale_seconds = float(stale_seconds)

        self._text = {}          # msg_id -> {'total','chunks','last'}
        self._files = {}         # msg_id -> _RxFile
        self._pending_meta = {}  # msg_id -> meta dict seen before any data
        self._done_ids = deque(maxlen=256)

        # counters for the metrics layer
        self.frames_rx = 0
        self.idle_rx = 0
        self.foreign_rx = 0
        self.text_done = 0
        self.files_done = 0
        self.files_verified = 0
        self.payload_bytes_rx = 0

    def set_nodes(self, my_node_id=None, dest_node_id=None):
        if my_node_id is not None:
            self.my_node_id = int(my_node_id)
        if dest_node_id is not None:
            self.dest_node_id = int(dest_node_id)

    # -- main entry point -------------------------------------------------

    def handle(self, payload, seq=0):
        """Feed one deframed, CRC-verified payload.

        Returns (status_lines, delivered_messages). `delivered_messages`
        holds only completed *text* objects - files land on disk and are
        announced via a status line instead, since a multi-gigabyte
        transfer cannot travel back over a UDP socket."""
        status = []
        delivered = []

        hdr = unpack_header(payload)
        if hdr is None:
            return status, delivered
        data = payload[FRAG_HEADER_BYTES:
                       FRAG_HEADER_BYTES + hdr['chunk_len']]

        self.frames_rx += 1
        addressed = (hdr['dst'] == self.my_node_id or
                     hdr['dst'] == BROADCAST_NODE)

        if hdr['type'] == TYPE_IDLE:
            self.idle_rx += 1
            if addressed:
                status.append("IDLE seq=%d src=%d dst=%d"
                              % (seq, hdr['src'], hdr['dst']))
            status.extend(self._expire())
            return status, delivered

        if not addressed:
            self.foreign_rx += 1
            status.append("FOREIGN src=%d dst=%d msg=%d (not for node %d)"
                          % (hdr['src'], hdr['dst'], hdr['msg_id'],
                             self.my_node_id))
            return status, delivered

        if hdr['src'] != self.dest_node_id:
            status.append("WARN unexpected src=%d while listening to node %d"
                          % (hdr['src'], self.dest_node_id))

        self.payload_bytes_rx += len(data)

        if hdr['type'] == TYPE_TEXT:
            s, d = self._handle_text(hdr, data, seq)
        elif hdr['type'] == TYPE_FILE_META:
            s, d = self._handle_meta(hdr, data)
        elif hdr['type'] == TYPE_FILE_DATA:
            s, d = self._handle_file(hdr, data, seq)
        else:
            s, d = ["WARN unknown fragment type %d" % hdr['type']], []

        status.extend(s)
        delivered.extend(d)
        status.extend(self._expire())
        return status, delivered

    # -- per-type handling ------------------------------------------------

    def _handle_text(self, hdr, data, seq):
        mid = hdr['msg_id']
        entry = self._text.setdefault(mid, {'total': hdr['frag_total'],
                                            'chunks': {}, 'last': time.time()})
        entry['total'] = hdr['frag_total']
        entry['chunks'][hdr['frag_idx']] = data
        entry['last'] = time.time()

        status = ["FRAG type=TEXT msg=%d idx=%d total=%d seq=%d crc=OK len=%d "
                  "src=%d dst=%d" % (mid, hdr['frag_idx'], hdr['frag_total'],
                                     seq, len(data), hdr['src'], hdr['dst'])]

        if len(entry['chunks']) >= entry['total']:
            try:
                whole = b''.join(entry['chunks'][i]
                                 for i in range(entry['total']))
            except KeyError:
                return status, []
            del self._text[mid]
            self.text_done += 1
            status.append("DONE type=TEXT msg=%d fragments=%d bytes=%d src=%d"
                          % (mid, entry['total'], len(whole), hdr['src']))
            return status, [whole]
        return status, []

    def _handle_meta(self, hdr, data):
        meta = parse_file_meta(data)
        if not meta:
            return ["WARN unparseable file metadata msg=%d" % hdr['msg_id']], []
        mid = meta['id']
        if mid in self._done_ids:
            return [], []

        rxf = self._files.get(mid)
        if rxf is None:
            self._pending_meta[mid] = meta
            return ["FILESTART msg=%d name=%s bytes=%d frags=%d"
                    % (mid, meta['name'], meta['size'], meta['total'])], []

        if rxf.meta is None:
            rxf.meta = meta
            return ["FILEMETA msg=%d name=%s bytes=%d"
                    % (mid, meta['name'], meta['size'])], []
        return [], []

    def _handle_file(self, hdr, data, seq):
        mid = hdr['msg_id']
        if mid in self._done_ids:
            return [], []

        rxf = self._files.get(mid)
        if rxf is None:
            total = hdr['frag_total']
            if total <= 0 or total > MAX_FRAG_INDEX + 1:
                return ["WARN bad fragment total %d for msg=%d" % (total, mid)], []
            try:
                rxf = _RxFile(mid, total, self.chunk_bytes, self.inbox)
            except OSError as exc:
                return ["FILEERR msg=%d cannot open inbox (%s)" % (mid, exc)], []
            rxf.meta = self._pending_meta.pop(mid, None)
            self._files[mid] = rxf

        fresh = rxf.write(hdr['frag_idx'], data)
        if not fresh:
            return [], []

        got, total = rxf.received(), rxf.total
        status = []
        # Progress at a readable cadence: every 1% of the transfer, but no
        # more than once a second, and always at the two ends. Percentage
        # alone spams the log for a small transfer (where 1% is one
        # fragment) and a fast one; the time floor keeps it readable.
        step = max(1, total // 100)
        now = time.time()
        due = (got == 1 or got == total or
               (got % step == 0 and now - rxf.last_progress >= 1.0))
        if due:
            rxf.last_progress = now
            elapsed = max(1e-3, time.time() - rxf.started)
            rate = rxf.bytes_written / elapsed
            eta = (total - got) * (elapsed / got) if got else 0.0
            status.append("FILEPROG msg=%d got=%d total=%d pct=%.1f "
                          "bytes=%d rate=%.0f eta=%.0f"
                          % (mid, got, total, 100.0 * got / total,
                             rxf.bytes_written, rate, eta))

        if rxf.complete():
            status.extend(self._finish_file(mid, rxf))
        return status, []

    def _finish_file(self, mid, rxf):
        elapsed = max(1e-3, time.time() - rxf.started)
        try:
            path, digest, verified, size = rxf.finish(self.inbox)
        except OSError as exc:
            rxf.close()
            self._files.pop(mid, None)
            return ["FILEERR msg=%d could not finalise (%s)" % (mid, exc)]

        self._files.pop(mid, None)
        self._done_ids.append(mid)
        self.files_done += 1
        if verified:
            self.files_verified += 1

        return ["FILEDONE msg=%d path=%s bytes=%d secs=%.1f rate=%.0f "
                "sha256=%s verify=%s"
                % (mid, path, size, elapsed, size / elapsed, digest[:16],
                   'OK' if verified else
                   ('NO-META' if not (rxf.meta or {}).get('sha256')
                    else 'MISMATCH'))]

    # -- housekeeping -----------------------------------------------------

    def _expire(self):
        """Drop partial objects that have gone quiet.

        There is no ARQ, so a transfer with a permanently missing fragment
        would otherwise sit in the table forever. Files are timed out
        rather than counted out, because a large transfer can legitimately
        span many minutes."""
        now = time.time()
        status = []

        for mid in [m for m, e in self._text.items()
                    if now - e['last'] > self.stale_seconds]:
            entry = self._text.pop(mid)
            missing = [i for i in range(entry['total'])
                       if i not in entry['chunks']][:12]
            status.append("INCOMPLETE type=TEXT msg=%d missing=%s"
                          % (mid, ','.join(str(i) for i in missing)))

        for mid in [m for m, f in self._files.items()
                    if now - f.last_activity > self.stale_seconds]:
            rxf = self._files.pop(mid)
            shown, nmissing = rxf.missing()
            rxf.close()
            try:
                os.remove(rxf.part_path)
            except OSError:
                pass
            status.append("INCOMPLETE type=FILE msg=%d got=%d/%d missing=%d "
                          "first_missing=%s"
                          % (mid, rxf.received(), rxf.total, nmissing,
                             ','.join(str(i) for i in shown)))
        return status

    def active_transfers(self):
        out = []
        for mid, rxf in self._files.items():
            elapsed = max(1e-3, time.time() - rxf.started)
            out.append({
                'msg_id': mid,
                'name': (rxf.meta or {}).get('name', 'unknown'),
                'got': rxf.received(),
                'total': rxf.total,
                'bytes': rxf.bytes_written,
                'rate': rxf.bytes_written / elapsed,
            })
        return out

    def close(self):
        for rxf in self._files.values():
            rxf.close()
        self._files.clear()


__all__ = [
    'FRAG_HEADER_BYTES', 'TYPE_IDLE', 'TYPE_TEXT', 'TYPE_FILE_DATA',
    'TYPE_FILE_META', 'TYPE_NAMES', 'BROADCAST_NODE', 'MAX_FRAG_INDEX',
    'pack_header', 'unpack_header', 'make_fragment', 'chunk_bytes_for',
    'TxQueue', 'RxReassembler', 'build_file_meta', 'parse_file_meta',
    'file_sha256',
]
