"""
RX Frame Decoder - sync, soft demodulation and concatenated FEC
================================================================

Replaces the old Correlate-Access-Code -> Packet Capture -> FEC vote ->
Packet Deframer chain with one block wrapping the shared
`dsss_frame.FrameScanner`, so the receiver and the simulation run
literally the same code.

What it does per frame
----------------------
  carrier-recovered QPSK symbols
    -> residual phase/frequency tracking (coherent mode)
    -> soft demodulation to log-likelihood values
    -> sync-word search (all four phase rotations)
    -> channel de-interleave
    -> soft-decision Viterbi (K=7, rate 1/2)
    -> Reed-Solomon de-interleave and RS(255,223) decode
    -> descramble, CRC32
    -> payload PDU

Why the FEC moved out of the sample path
----------------------------------------
The old repetition FEC was a streaming block, which meant it had to
rescale `packet_len` tags on every buffer and run on every single bit at
the sample rate. Running the real decoder that way would be both far more
expensive and far more fragile. Because the sync word is transmitted
uncoded, the frame boundary is known *before* anything has to be decoded,
so decoding can happen once per frame on a complete buffer instead. That
also makes soft-decision decoding possible at all: the decoder gets the
whole frame's soft values at once, which is exactly what Viterbi needs.

Measured cost is about 30 ms of CPU per frame, against a frame period of
2.06 s at the default 1023-chip code - roughly 1.5% of one core, and still
only about 12% at the shortest code length.

Telemetry
---------
Every frame publishes a rich statistics line: the *pre-FEC* channel bit
error rate (measured by re-encoding the Viterbi output and comparing it
with the received hard decisions - no test pattern needed), how many
symbols Reed-Solomon had to repair and how much of its 16-symbol budget
that leaves, the Viterbi path metric, the sync correlation strength, and
the CRC result. Idle frames carry a known PRBS, so the decoder also
reports a true *post-FEC* bit error rate on live traffic without any
special test mode.
"""

import numpy as np
import pmt
from gnuradio import gr

import dsss_frame as FR
import dsss_fec as FEC


def bytes_pdu(data):
    data = bytes(data)
    return pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(data), list(data)))


class blk(gr.sync_block):
    """RX Frame Decoder (sync + soft Viterbi + Reed-Solomon)"""

    def __init__(self, rs_codewords=2, mode='coherent', sync_threshold=0.68,
                 track_block=64, report_every=1):
        gr.sync_block.__init__(self, name='RX Frame Decoder',
                               in_sig=[np.complex64], out_sig=[])
        self.n_cw = int(rs_codewords)
        self.mode = mode
        self.report_every = max(1, int(report_every))

        self.scanner = FR.FrameScanner(n_cw=self.n_cw, mode=mode,
                                       sync_threshold=float(sync_threshold),
                                       track_block=int(track_block))

        self.message_port_register_out(pmt.intern('payload'))
        self.message_port_register_out(pmt.intern('status'))
        self.message_port_register_out(pmt.intern('diag'))

        # rolling counters for the metrics layer
        self.frames_ok = 0
        self.frames_bad = 0
        self.chan_err_bits = 0
        self.chan_total_bits = 0
        self.rs_corrected = 0
        self.rs_uncorrectable = 0
        self.rs_worst = 0
        self.payload_bytes_ok = 0
        self.prbs_err_bits = 0
        self.prbs_total_bits = 0
        self._report_count = 0

        self._idle_ref = None

    def _publish(self, port, text):
        try:
            self.message_port_pub(pmt.intern(port), bytes_pdu(
                text.encode('utf-8', 'replace')))
        except Exception:
            pass

    def work(self, input_items, output_items):
        in0 = input_items[0]
        n = len(in0)
        if n == 0:
            return 0

        try:
            frames = self.scanner.feed(in0)
        except Exception as exc:
            self._publish('status', "RXERR decoder fault (%s)" % exc)
            return n

        for fr in frames:
            self._handle_frame(fr)
        return n

    def _handle_frame(self, fr):
        st = fr['stats']
        payload = fr['payload']

        self.chan_err_bits += st['chan_bit_errors']
        self.chan_total_bits += st['coded_bits']
        self.rs_corrected += st['rs_total_corrected']
        self.rs_uncorrectable += st['rs_uncorrectable']
        self.rs_worst = max(self.rs_worst, st['rs_worst_cw'])

        if payload is None:
            self.frames_bad += 1
            self._publish('status', "seq=%3d  FEC FAIL (uncorrectable=%d, "
                                    "pre-FEC BER=%.3e) - frame dropped"
                          % (st.get('seq', -1), st['rs_uncorrectable'],
                             st['chan_ber']))
        else:
            self.frames_ok += 1
            self.payload_bytes_ok += len(payload)
            self.message_port_pub(pmt.intern('payload'),
                                  bytes_pdu(bytes([st.get('seq', 0) & 0xFF])
                                            + payload))
            self._check_prbs(payload)

        self._report_count += 1
        if self._report_count >= self.report_every:
            self._report_count = 0
            self._publish('diag', self._frame_line(st, payload))

    def _check_prbs(self, payload):
        """Idle frames carry a known pattern, so they measure the true
        post-FEC bit error rate on live traffic with no test mode."""
        try:
            import dsss_transfer as XFER
            hdr = XFER.unpack_header(payload)
            if hdr is None or hdr['type'] != XFER.TYPE_IDLE:
                return
            chunk = len(payload) - XFER.FRAG_HEADER_BYTES
            if self._idle_ref is None or len(self._idle_ref) != chunk:
                self._idle_ref = FEC.prbs15(chunk)
            got = payload[XFER.FRAG_HEADER_BYTES:]
            a = np.frombuffer(got, dtype=np.uint8)
            b = np.frombuffer(self._idle_ref, dtype=np.uint8)
            m = min(len(a), len(b))
            errs = int(np.unpackbits(a[:m] ^ b[:m]).sum())
            self.prbs_err_bits += errs
            self.prbs_total_bits += m * 8
        except Exception:
            pass

    def _frame_line(self, st, payload):
        return ("FECFRAME crc=%d seq=%d syncorr=%.3f rot=%d chanber=%.4e "
                "chanerr=%d codedbits=%d rscorr=%s rsworst=%d rsmargin=%d "
                "rsuncorr=%d pathmetric=%.1f locked=%d"
                % (1 if payload is not None else 0, st.get('seq', -1),
                   st.get('sync_corr', 0.0), st.get('sync_rotation', 0),
                   st['chan_ber'], st['chan_bit_errors'], st['coded_bits'],
                   ','.join(str(v) for v in st['rs_corrected']),
                   st['rs_worst_cw'], st['rs_margin'], st['rs_uncorrectable'],
                   st['path_metric'], 1 if self.scanner.locked else 0))

    def stats(self):
        s = self.scanner.stats()
        s.update({
            'frames_ok': self.frames_ok,
            'frames_bad': self.frames_bad,
            'chan_ber': (self.chan_err_bits / float(self.chan_total_bits)
                         if self.chan_total_bits else 0.0),
            'chan_err_bits': self.chan_err_bits,
            'chan_total_bits': self.chan_total_bits,
            'rs_corrected': self.rs_corrected,
            'rs_uncorrectable': self.rs_uncorrectable,
            'rs_worst': self.rs_worst,
            'payload_bytes_ok': self.payload_bytes_ok,
            'post_fec_ber': (self.prbs_err_bits / float(self.prbs_total_bits)
                             if self.prbs_total_bits else None),
            'prbs_total_bits': self.prbs_total_bits,
        })
        return s
