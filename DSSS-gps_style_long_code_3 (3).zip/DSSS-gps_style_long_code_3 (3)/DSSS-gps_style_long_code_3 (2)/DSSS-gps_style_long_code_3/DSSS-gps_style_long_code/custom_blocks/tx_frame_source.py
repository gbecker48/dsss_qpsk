"""
TX Frame Source - hardware-paced, structurally cannot underflow
================================================================

This replaces the message_strobe + TX Scheduler + Packet Framer +
PDU-to-Tagged-Stream chain with a single GNU Radio *source* block, and it
is the fix for the underflow/overflow problem rather than another attempt
to tune around it.

Why the old design could never be tuned into working
-----------------------------------------------------
The transmitter used to be *pushed* by a wall-clock timer: a
`blocks.message_strobe` ticked every `strobe_period_ms` and each tick
produced exactly one frame. But the USRP consumes samples at *its* rate,
set by its own oscillator. Those are two independent clocks, and nothing
kept them in step:

  * strobe slightly slow  -> the sink runs out of samples -> TX UNDERFLOW,
    and because the despreader's correlation peak collapses the instant a
    chip goes missing, the far end loses lock and has to re-acquire;
  * strobe slightly fast  -> frames pile up behind the sink, the PDU queue
    grows without bound, and latency and memory climb until something
    gives.

There is no third case. The `tx_pace_margin_pct` slider moved the problem
between those two failure modes; it could not remove it, because no fixed
timer value can track a hardware clock it has no connection to. That is
why "no matter how I change my sample rate and sps I can't get rid of
them" was the honest description of a design property, not a tuning miss.

The fix
-------
Make the transmitter *pulled* instead of pushed. As a source block with no
inputs, this is called by the USRP sink's own demand for samples, and it
can always satisfy that demand because it synthesises what it returns. The
hardware clock is now the only clock in the system. Underflow caused by
the data path is not made unlikely, it is made impossible - there is no
timer left to disagree with the radio.

A previous revision of this project tried a source block and found it made
things *worse*. That attempt also cut every downstream buffer to a few
frames to keep latency down, and that is what actually caused the
regression: real hardware needs generous buffering to absorb OS and USB
scheduling jitter, which a pure simulation never exercises. So this
version keeps GNU Radio's default (generous) buffer sizing everywhere
downstream, and bounds latency at the one place where it is cheap - this
block's own output buffer, which holds a small, explicit number of frames
(`max_queued_frames`).

Disk never touches the sample path either: file transfers are prepared by
a background thread inside `dsss_transfer.TxQueue`, so a slow read delays
a transfer but can never stall the radio.

Output
------
A stream of uint8 symbol indices 0-3, ready for
`digital.chunks_to_symbols_bc`. The Gray mapping and, in differential
mode, the mod-4 differential accumulation both happen here, so the
flowgraph needs no `diff_encoder_bb` and the coherent/differential choice
is a single live parameter rather than a rewiring job.
"""

import numpy as np
import pmt
from gnuradio import gr

import dsss_frame as FR
import dsss_fec as FEC
import dsss_transfer as XFER


def pdu_to_bytes(msg):
    vec = pmt.cdr(msg) if pmt.is_pair(msg) else msg
    try:
        return bytes(bytearray(pmt.u8vector_elements(vec)))
    except Exception:
        return b''


def text_pdu(text):
    data = text.encode('utf-8', 'replace') if isinstance(text, str) else bytes(text)
    return pmt.cons(pmt.PMT_NIL, pmt.init_u8vector(len(data), list(data)))


class blk(gr.sync_block):
    """TX Frame Source (continuous, hardware-paced)"""

    def __init__(self, rs_codewords=2, my_node_id=0, dest_node_id=1,
                 mode='coherent', max_queued_frames=3, spool_dir='tx_spool'):
        gr.sync_block.__init__(self, name='TX Frame Source',
                               in_sig=[], out_sig=[np.uint8])
        self.n_cw = int(rs_codewords)
        self.mode = mode
        self._my_node_id = int(my_node_id)
        self._dest_node_id = int(dest_node_id)
        self.spool_dir = spool_dir

        self.payload_bytes = FR.payload_bytes(self.n_cw)
        self.frame_nbits = FR.frame_bits(self.n_cw)
        self.frame_nsyms = FR.frame_symbols(self.n_cw)

        self.message_port_register_in(pmt.intern('queue_in'))
        self.message_port_register_in(pmt.intern('ctrl'))
        self.message_port_register_out(pmt.intern('status'))
        self.message_port_register_out(pmt.intern('diag'))
        self.set_msg_handler(pmt.intern('queue_in'), self._on_message)
        self.set_msg_handler(pmt.intern('ctrl'), self._on_ctrl)

        self.tx = XFER.TxQueue(self.payload_bytes,
                               my_node_id=self._my_node_id,
                               dest_node_id=self._dest_node_id,
                               status_cb=self._status)

        self._buf = np.zeros(0, dtype=np.uint8)     # pending output symbols
        self._seq = 0
        self._diff_state = 0
        self._upload = None                         # in-progress file upload

        self.frames_built = 0
        self.symbols_out = 0

        # The one place latency is bounded. Everything downstream keeps
        # GNU Radio's default generous buffers, which is what real
        # hardware needs to ride out scheduling jitter; capping them all
        # was the mistake that made a previous source-based attempt worse.
        self.set_max_output_buffer(
            max(self.frame_nsyms * max(1, int(max_queued_frames)), 8192))

    # -- node ids, settable live from GRC ---------------------------------

    @property
    def my_node_id(self):
        return self._my_node_id

    @my_node_id.setter
    def my_node_id(self, value):
        self._my_node_id = int(value)
        self.tx.set_nodes(my_node_id=self._my_node_id)

    @property
    def dest_node_id(self):
        return self._dest_node_id

    @dest_node_id.setter
    def dest_node_id(self, value):
        self._dest_node_id = int(value)
        self.tx.set_nodes(dest_node_id=self._dest_node_id)

    # -- inbound messages --------------------------------------------------

    def _on_message(self, msg):
        """A plain text/binary message from the terminal's UDP port.

        Also carries the chunked file-upload protocol, so that a ground
        station running on a different machine from the radio can still
        send files without needing a shared filesystem or a datagram
        bigger than UDP allows."""
        data = pdu_to_bytes(msg)
        if not data:
            return
        if data.startswith(b'\x00FILEUP'):
            self._on_upload(data)
            return
        self.tx.enqueue_text(data)

    def _on_ctrl(self, msg):
        text = pdu_to_bytes(msg).decode('utf-8', 'replace').strip()
        if text.upper().startswith('FILE='):
            path = text[5:].strip()
            self.tx.enqueue_file(path)

    def _on_upload(self, data):
        """Chunked file upload: \\0FILEUP <verb> <args>\\n<payload>."""
        try:
            head, _, body = data.partition(b'\n')
            parts = head.decode('utf-8', 'replace').split()
            verb = parts[1].upper() if len(parts) > 1 else ''
        except Exception:
            return

        import os
        if verb == 'BEGIN':
            name = ' '.join(parts[3:]) if len(parts) > 3 else 'upload.bin'
            try:
                os.makedirs(self.spool_dir, exist_ok=True)
                path = os.path.join(self.spool_dir,
                                    XFER._safe_name(name))
                self._upload = {'path': path, 'fh': open(path, 'wb'),
                                'name': name, 'next': 0}
                self._status("UPLOAD BEGIN name=%s" % name)
                self._ack(0)
            except OSError as exc:
                self._status("FILEERR upload (%s)" % exc)
                self._upload = None
        elif verb == 'CHUNK' and self._upload:
            try:
                idx = int(parts[2])
            except (IndexError, ValueError):
                return
            if idx == self._upload['next']:
                self._upload['fh'].write(body)
                self._upload['next'] += 1
            # Re-acknowledge duplicates too, so a lost ACK costs one
            # retransmission rather than stalling the whole upload.
            self._ack(self._upload['next'])
        elif verb == 'END' and self._upload:
            up = self._upload
            self._upload = None
            try:
                up['fh'].close()
            except Exception:
                pass
            self._status("UPLOAD DONE name=%s -> queued" % up['name'])
            self.tx.enqueue_file(up['path'])
            self._ack(-1)

    def _ack(self, n):
        self.message_port_pub(pmt.intern('status'),
                              text_pdu("UPLOADACK %d" % n))

    def _status(self, text):
        self.message_port_pub(pmt.intern('status'), text_pdu(text))

    # -- frame production --------------------------------------------------

    def _build_frame(self):
        """One frame's worth of output symbols. Never blocks, never fails."""
        payload = self.tx.next_payload()
        seq = self._seq
        self._seq = (self._seq + 1) & 0xFF
        try:
            bits = FR.build_frame_bits(seq, payload, self.n_cw)
        except Exception as exc:
            # A frame must always be produced - the radio is waiting. Fall
            # back to an all-zero payload rather than starving the sink.
            self._status("TXERR frame build failed (%s)" % exc)
            bits = FR.build_frame_bits(seq, bytes(self.payload_bytes), self.n_cw)

        dibits = FR.bits_to_gray_dibits(bits).astype(np.uint8)
        if self.mode == FR.MODE_DIFFERENTIAL:
            # d[k] = (d[k-1] + g[k]) mod 4, continuous across frames - the
            # job digital.diff_encoder_bb(4) used to do in the flowgraph.
            acc = (np.cumsum(dibits.astype(np.int64)) + self._diff_state) % 4
            self._diff_state = int(acc[-1])
            dibits = acc.astype(np.uint8)

        self.frames_built += 1
        return dibits

    def work(self, input_items, output_items):
        out = output_items[0]
        want = len(out)
        # Top up from whole frames until the request is covered. Because
        # this block has no input, this loop can always succeed - which is
        # precisely what makes a data-path underflow impossible.
        while len(self._buf) < want:
            self._buf = np.concatenate([self._buf, self._build_frame()])
        out[:want] = self._buf[:want]
        self._buf = self._buf[want:]
        self.symbols_out += want
        return want

    def stats(self):
        return {
            'frames_built': self.frames_built,
            'symbols_out': self.symbols_out,
            'frames_sent': self.tx.frames_sent,
            'idle_sent': self.tx.idle_sent,
            'data_sent': self.tx.data_sent,
            'payload_bytes_sent': self.tx.payload_bytes_sent,
            'queued': self.tx.pending_fragments(),
            'label': self.tx.current_label,
            'cur_sent': self.tx.current_sent,
            'cur_total': self.tx.current_total,
        }

    def stop(self):
        try:
            self.tx.stop()
        except Exception:
            pass
        return True
