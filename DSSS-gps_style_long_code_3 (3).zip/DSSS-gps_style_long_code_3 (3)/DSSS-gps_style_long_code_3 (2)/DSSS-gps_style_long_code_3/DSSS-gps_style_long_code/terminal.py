#!/usr/bin/env python3
"""
terminal.py -- send/receive terminal for the QPSK + DSSS burst comms link.

Talks to the running GNU Radio flowgraph (dsss_bpsk_sim.grc /
dsss_bpsk_usrp.grc) purely over UDP -- it has no idea GNU Radio exists.
Whatever you type gets sent as ONE UDP datagram to the flowgraph's
"net_tx_in" block (a Socket PDU block in UDP_SERVER mode); the flowgraph's
TX Scheduler splits it into fragments and paces them out on its own if it's
longer than one fragment (~252 bytes) - this script never fragments
client-side. Two background threads listen for what comes back out of the
flowgraph's RX chain (this script just prints whatever text arrives on
either port - it doesn't parse the status grammar the way ground_station.py
does, so it works unchanged no matter how that grammar evolves):

  - the "data" port:   a complete, reassembled, CRC-validated message -
                        only sent once every fragment of it arrived intact.
  - the "status" port: one line per event, e.g.
                        "FRAG msg=0 idx=3 total=12 seq=19 crc=OK len=252"
                        "IDLE seq=41"  (a periodic keep-alive - the link is
                        continuous, not burst-based, so this prints even
                        when nobody's sent anything)
                        "DONE msg=0 fragments=12 bytes=3000"
                        "INCOMPLETE msg=0 missing=6"  (a fragment was lost
                        and the message gave up reassembling - there's no
                        retransmission on this link, see the README)

Run one instance to chat with yourself through the simulated link (it's
a loopback -- TX and RX both live in the same flowgraph), or point two
instances at two different flowgraphs / machines once you've got this
running over real USRPs.

Usage:
    python3 terminal.py
    python3 terminal.py --host 127.0.0.1 --tx-port 52001 \\
                         --rx-data-port 52002 --rx-status-port 52003
"""

import os
import sys


def _sanitize_snap_polluted_ld_library_path():
    """See the identical guard in ground_station.py for the full story:
    an LD_LIBRARY_PATH inherited from a Snap-packaged app's environment
    can make the dynamic linker resolve libpthread.so.0 against an old,
    incompatible Snap-bundled copy instead of the system's own glibc,
    crashing with a symbol lookup error the instant any thread is created
    - which this script's UDP listener threads do immediately. Strip any
    Snap path and re-exec once, before `threading` ever gets imported."""
    if os.environ.get("_TERM_ENV_SANITIZED"):
        return
    ld_path = os.environ.get("LD_LIBRARY_PATH", "")
    if not ld_path:
        return
    parts = ld_path.split(os.pathsep)
    kept = [p for p in parts if "/snap/" not in p]
    if len(kept) == len(parts):
        return
    os.environ["_TERM_ENV_SANITIZED"] = "1"
    if kept:
        os.environ["LD_LIBRARY_PATH"] = os.pathsep.join(kept)
    else:
        os.environ.pop("LD_LIBRARY_PATH", None)
    try:
        os.execve(sys.executable, [sys.executable] + sys.argv, os.environ)
    except OSError:
        pass


_sanitize_snap_polluted_ld_library_path()

import argparse
import socket
import threading
import time

BANNER = r"""
======================================================================
  QPSK + DSSS burst link terminal
  type a message and press Enter to transmit it over the link
  /help for commands, /quit to exit
======================================================================
"""

HELP = """
Commands:
  /help              show this help
  /quit, /exit       quit the terminal
  /stats             show send/recv counters
  /node <n>          set MY node id (0-15) - which PRN code this radio
                     transmits on
  /dest <n>          set the DESTINATION node id (0-15) - which peer's
                     PRN code this radio despreads against (who it's
                     currently listening to)
  /send <path>       transmit a file of any size. The radio reads the
                     file itself and streams it fragment by fragment, so
                     nothing is copied and nothing is held in memory; the
                     far end writes it straight to disk and checks its
                     SHA-256. The path is resolved on whichever machine
                     the flowgraph is running on, not this one.
  /resync            drop the despreader lock and re-acquire (useful
                     after moving an antenna)
  (anything else)    send it as a message over the link
"""

NODE_TABLE_SIZE = 16  # must match the flowgraph's node table


class Colors:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    CYAN = '\033[96m'
    RED = '\033[91m'
    DIM = '\033[2m'
    BOLD = '\033[1m'
    RESET = '\033[0m'

    @classmethod
    def disable(cls):
        for name in ('GREEN', 'YELLOW', 'CYAN', 'RED', 'DIM', 'BOLD', 'RESET'):
            setattr(cls, name, '')


def make_listener(sock, on_message):
    def run():
        while True:
            try:
                data, _addr = sock.recvfrom(65535)
            except OSError:
                return
            on_message(data)
    t = threading.Thread(target=run, daemon=True)
    t.start()
    return t


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                  formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--host', default='127.0.0.1',
                     help='host the flowgraph is running on (default: 127.0.0.1)')
    ap.add_argument('--tx-port', type=int, default=52001,
                     help='UDP port the flowgraph listens on for outgoing messages (default: 52001)')
    ap.add_argument('--rx-data-port', type=int, default=52002,
                     help='local UDP port the flowgraph sends recovered messages to (default: 52002)')
    ap.add_argument('--rx-status-port', type=int, default=52003,
                     help='local UDP port the flowgraph sends per-packet status lines to (default: 52003)')
    ap.add_argument('--ctrl-port', type=int, default=52004,
                     help='UDP port the flowgraph listens on for /node and /dest '
                          'commands (default: 52004)')
    ap.add_argument('--diag-port', type=int, default=52005,
                     help='local UDP port the flowgraph sends debug telemetry to - '
                          'EVM/RX power/processing gain/FEC (default: 52005)')
    ap.add_argument('--show-diag', action='store_true',
                     help='also print diagnostics-port telemetry (noisy - the '
                          'processing-gain reading alone updates ~20x/sec); off '
                          'by default. See ground_station.py for a proper Debug '
                          'window instead of raw lines.')
    ap.add_argument('--bind-host', default='127.0.0.1',
                     help='local address to bind the receive sockets to (default: 127.0.0.1)')
    ap.add_argument('--no-color', action='store_true', help='disable ANSI colors')
    args = ap.parse_args()

    if args.no_color or not sys.stdout.isatty():
        Colors.disable()

    tx_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    ctrl_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    rx_data_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    rx_data_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    rx_data_sock.bind((args.bind_host, args.rx_data_port))

    rx_status_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    rx_status_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    rx_status_sock.bind((args.bind_host, args.rx_status_port))

    counters = {'sent': 0, 'recv_ok': 0, 'recv_status': 0}
    lock = threading.Lock()

    def on_data(data):
        with lock:
            counters['recv_ok'] += 1
        text = data.decode('utf-8', 'replace')
        sys.stdout.write('\r' + ' ' * 80 + '\r')
        print(f"{Colors.GREEN}{Colors.BOLD}[RECV]{Colors.RESET} {text}")
        sys.stdout.write(f"{Colors.CYAN}> {Colors.RESET}")
        sys.stdout.flush()

    def on_status(data):
        with lock:
            counters['recv_status'] += 1
        text = data.decode('utf-8', 'replace')
        color = Colors.RED if 'FAIL' in text or 'dropped' in text and 'CRC OK' not in text else Colors.DIM
        sys.stdout.write('\r' + ' ' * 80 + '\r')
        print(f"{color}[link] {text}{Colors.RESET}")
        sys.stdout.write(f"{Colors.CYAN}> {Colors.RESET}")
        sys.stdout.flush()

    make_listener(rx_data_sock, on_data)
    make_listener(rx_status_sock, on_status)

    if args.show_diag:
        diag_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        diag_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        diag_sock.bind((args.bind_host, args.diag_port))

        def on_diag(data):
            text = data.decode('utf-8', 'replace')
            sys.stdout.write('\r' + ' ' * 80 + '\r')
            print(f"{Colors.DIM}[diag] {text}{Colors.RESET}")
            sys.stdout.write(f"{Colors.CYAN}> {Colors.RESET}")
            sys.stdout.flush()

        make_listener(diag_sock, on_diag)

    print(f"{Colors.BOLD}{BANNER}{Colors.RESET}")
    print(f"  sending to   {args.host}:{args.tx_port}")
    print(f"  data from    {args.bind_host}:{args.rx_data_port}")
    print(f"  status from  {args.bind_host}:{args.rx_status_port}")
    print(f"  control to   {args.host}:{args.ctrl_port}  (/node, /dest)")
    print()

    try:
        while True:
            try:
                line = input(f"{Colors.CYAN}> {Colors.RESET}")
            except EOFError:
                break

            if not line:
                continue
            if line in ('/quit', '/exit'):
                break
            if line == '/help':
                print(HELP)
                continue
            if line == '/stats':
                with lock:
                    print(f"  sent={counters['sent']}  "
                          f"recv_ok={counters['recv_ok']}  "
                          f"status_lines={counters['recv_status']}")
                continue
            if line.startswith('/send'):
                parts = line.split(None, 1)
                if len(parts) != 2 or not parts[1].strip():
                    print(f"{Colors.RED}usage: /send <path on the "
                          f"flowgraph's machine>{Colors.RESET}")
                    continue
                path = parts[1].strip()
                ctrl_sock.sendto(f"FILE={path}".encode('utf-8'),
                                 (args.host, args.ctrl_port))
                print(f"{Colors.YELLOW}[CTRL]{Colors.RESET} queued file "
                      f"{path} for transmission")
                print(f"       watch for FILEPROG / FILEDONE status lines; "
                      f"an error appears as FILEERR")
                continue
            if line.strip() == '/resync':
                ctrl_sock.sendto(b'RESYNC', (args.host, args.ctrl_port))
                print(f"{Colors.YELLOW}[CTRL]{Colors.RESET} re-acquisition "
                      f"requested")
                continue
            if line.startswith('/node') or line.startswith('/dest'):
                parts = line.split()
                cmd = parts[0][1:].upper()
                if len(parts) != 2 or not parts[1].lstrip('-').isdigit():
                    print(f"{Colors.RED}usage: /{cmd.lower()} <0-{NODE_TABLE_SIZE-1}>{Colors.RESET}")
                    continue
                n = int(parts[1])
                if not (0 <= n < NODE_TABLE_SIZE):
                    print(f"{Colors.RED}node id must be 0-{NODE_TABLE_SIZE-1}{Colors.RESET}")
                    continue
                ctrl_sock.sendto(f"{cmd}={n}".encode('ascii'), (args.host, args.ctrl_port))
                label = "my node id" if cmd == 'NODE' else "listening to (dest node)"
                print(f"{Colors.YELLOW}[CTRL]{Colors.RESET} {label} -> {n}")
                continue

            tx_sock.sendto(line.encode('utf-8'), (args.host, args.tx_port))
            with lock:
                counters['sent'] += 1
            print(f"{Colors.YELLOW}[SENT]{Colors.RESET} {line}")
    except KeyboardInterrupt:
        pass
    finally:
        print("\nbye")


if __name__ == '__main__':
    main()
