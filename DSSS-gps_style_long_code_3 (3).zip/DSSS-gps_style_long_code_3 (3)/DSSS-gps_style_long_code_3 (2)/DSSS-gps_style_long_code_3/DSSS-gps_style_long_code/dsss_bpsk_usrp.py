#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: GPS-Style DSSS + QPSK Continuous Comms Link (USRP Hardware)
# Description: GPS-style long-code DSSS + QPSK continuous comms link (USRP hardware)
# GNU Radio version: 3.10.12.0

from PyQt5 import Qt
from gnuradio import qtgui
from PyQt5 import QtCore
from gnuradio import blocks
import pmt
from gnuradio import blocks, gr
from gnuradio import digital
from gnuradio import filter
from gnuradio.filter import firdes
from gnuradio import gr
from gnuradio.fft import window
import sys
import signal
from PyQt5 import Qt
from argparse import ArgumentParser
from gnuradio.eng_arg import eng_float, intx
from gnuradio import eng_notation
from gnuradio import gr, pdu
from gnuradio import network
from gnuradio import uhd
import time
import dsss_bpsk_usrp_dsss_despreader as dsss_despreader  # embedded python block
import dsss_bpsk_usrp_dsss_spreader as dsss_spreader  # embedded python block
import dsss_bpsk_usrp_evm_probe as evm_probe  # embedded python block
import dsss_bpsk_usrp_link_metrics as link_metrics  # embedded python block
import dsss_bpsk_usrp_node_ctrl as node_ctrl  # embedded python block
import dsss_bpsk_usrp_reassembler as reassembler  # embedded python block
import dsss_bpsk_usrp_rx_frame_decoder as rx_frame_decoder  # embedded python block
import dsss_bpsk_usrp_rx_health as rx_health  # embedded python block
import dsss_bpsk_usrp_rx_power_probe as rx_power_probe  # embedded python block
import dsss_bpsk_usrp_tx_frame_source as tx_frame_source  # embedded python block
import dsss_bpsk_usrp_tx_health as tx_health  # embedded python block
import dsss_frame
import dsss_fec
import dsss_codes
import sip
import threading



class dsss_bpsk_usrp(gr.top_block, Qt.QWidget):

    def __init__(self):
        gr.top_block.__init__(self, "GPS-Style DSSS + QPSK Continuous Comms Link (USRP Hardware)", catch_exceptions=True)
        Qt.QWidget.__init__(self)
        self.setWindowTitle("GPS-Style DSSS + QPSK Continuous Comms Link (USRP Hardware)")
        qtgui.util.check_set_qss()
        try:
            self.setWindowIcon(Qt.QIcon.fromTheme('gnuradio-grc'))
        except BaseException as exc:
            print(f"Qt GUI: Could not set Icon: {str(exc)}", file=sys.stderr)
        self.top_scroll_layout = Qt.QVBoxLayout()
        self.setLayout(self.top_scroll_layout)
        self.top_scroll = Qt.QScrollArea()
        self.top_scroll.setFrameStyle(Qt.QFrame.NoFrame)
        self.top_scroll_layout.addWidget(self.top_scroll)
        self.top_scroll.setWidgetResizable(True)
        self.top_widget = Qt.QWidget()
        self.top_scroll.setWidget(self.top_widget)
        self.top_layout = Qt.QVBoxLayout(self.top_widget)
        self.top_grid_layout = Qt.QGridLayout()
        self.top_layout.addLayout(self.top_grid_layout)

        self.settings = Qt.QSettings("gnuradio/flowgraphs", "dsss_bpsk_usrp")

        try:
            geometry = self.settings.value("geometry")
            if geometry:
                self.restoreGeometry(geometry)
        except BaseException as exc:
            print(f"Qt GUI: Could not restore geometry: {str(exc)}", file=sys.stderr)
        self.flowgraph_started = threading.Event()

        ##################################################
        # Variables
        ##################################################
        self.rs_codewords = rs_codewords = 2
        self.code_len = code_len = 1023
        self.chip_rate = chip_rate = 2046000.0
        self.sps = sps = 4
        self.symbol_rate = symbol_rate = chip_rate/code_len
        self.samp_rate = samp_rate = int(chip_rate*sps)
        self.payload_bytes = payload_bytes = dsss_frame.payload_bytes(rs_codewords)
        self.frame_symbols = frame_symbols = dsss_frame.frame_symbols(rs_codewords)
        self.frame_period_s = frame_period_s = frame_symbols/symbol_rate
        self.detect_mode = detect_mode = 'coherent'
        self.clock_source = clock_source = 'external'
        self.rx_agc = rx_agc = True
        self.usrp_dev_args = usrp_dev_args = 'num_recv_frames=1024,recv_frame_size=8192,num_send_frames=1024,send_frame_size=8192'
        self.tx_queue_frames = tx_queue_frames = 3
        self.rx_inbox = rx_inbox = 'rx_files'
        self.diag_period_s = diag_period_s = 1.0
        self.usrp_dev_addr = usrp_dev_addr = ''
        self.tx_udp_port = tx_udp_port = 52001
        self.tx_gain = tx_gain = 0
        self.rx_status_udp_port = rx_status_udp_port = 52003
        self.rx_gain = rx_gain = 20
        self.rx_data_udp_port = rx_data_udp_port = 52002
        self.rrc_ntaps = rrc_ntaps = 11*sps
        self.rrc_alpha = rrc_alpha = 0.35
        self.my_node_id = my_node_id = 0
        self.diag_udp_port = diag_udp_port = 52005
        self.dest_node_id = dest_node_id = 1
        self.ctrl_udp_port = ctrl_udp_port = 52004
        self.center_freq = center_freq = 915000000
        ##################################################
        # Blocks
        ##################################################

        self._tx_gain_range = qtgui.Range(0, 1, 0.01, 0, 200)
        self._tx_gain_win = qtgui.RangeWidget(self._tx_gain_range, self.set_tx_gain, "TX Gain (dB)", "counter_slider", float, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._tx_gain_win, 0, 2, 1, 2)
        for r in range(0, 1):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(2, 4):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._center_freq_range = qtgui.Range(70000000, 6000000000, 1000000, 915000000, 200)
        self._center_freq_win = qtgui.RangeWidget(self._center_freq_range, self.set_center_freq, "Center Frequency (Hz)", "counter_slider", float, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._center_freq_win, 0, 0, 1, 2)
        for r in range(0, 1):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(0, 2):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.usrp_source = uhd.usrp_source(
            ",".join((usrp_dev_addr, usrp_dev_args)),
            uhd.stream_args(
                cpu_format="fc32",
                args='',
                channels=list(range(0,1)),
            ),
        )
        self.usrp_source.set_clock_source(clock_source, 0)
        self.usrp_source.set_samp_rate(samp_rate)
        self.usrp_source.set_time_unknown_pps(uhd.time_spec(0))

        self.usrp_source.set_center_freq(center_freq, 0)
        self.usrp_source.set_antenna("RX2", 0)
        self.usrp_source.set_rx_agc(bool(rx_agc), 0)
        if not rx_agc:
            self.usrp_source.set_gain(rx_gain, 0)
        self.usrp_sink = uhd.usrp_sink(
            ",".join((usrp_dev_addr, usrp_dev_args)),
            uhd.stream_args(
                cpu_format="fc32",
                args='',
                channels=list(range(0,1)),
            ),
            '',
        )
        self.usrp_sink.set_clock_source(clock_source, 0)
        self.usrp_sink.set_samp_rate(samp_rate)
        self.usrp_sink.set_time_unknown_pps(uhd.time_spec(0))

        self.usrp_sink.set_center_freq(center_freq, 0)
        self.usrp_sink.set_antenna('TX/RX', 0)
        self.usrp_sink.set_normalized_gain(tx_gain, 0)
        self.tx_rrc = filter.interp_fir_filter_ccf(
            sps,
            firdes.root_raised_cosine(
                1,
                samp_rate,
                chip_rate,
                rrc_alpha,
                rrc_ntaps))
        self.tx_health = tx_health.blk(label='TX', log_every=1)
        self.rx_power_probe = rx_power_probe.blk(period_samples=200000)
        self.rx_mf = filter.fir_filter_ccf(
            sps,
            firdes.root_raised_cosine(
                1,
                samp_rate,
                chip_rate,
                rrc_alpha,
                rrc_ntaps))
        self.rx_health = rx_health.blk(label='RX', log_every=1)
        self._rx_gain_range = qtgui.Range(0, 31.5, 0.5, 20, 200)
        self._rx_gain_win = qtgui.RangeWidget(self._rx_gain_range, self.set_rx_gain, "RX Gain (dB)", "counter_slider", float, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._rx_gain_win, 0, 4, 1, 2)
        for r in range(0, 1):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(4, 6):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.net_tx_in = network.socket_pdu('UDP_SERVER', '', str(tx_udp_port), 65536, False)
        self.net_rx_status = network.socket_pdu('UDP_CLIENT', '127.0.0.1', str(rx_status_udp_port), 1500, False)
        self.net_rx_data = network.socket_pdu('UDP_CLIENT', '127.0.0.1', str(rx_data_udp_port), 65536, False)
        self.net_diag = network.socket_pdu('UDP_CLIENT', '127.0.0.1', str(diag_udp_port), 1500, False)
        self.net_ctrl_in = network.socket_pdu('UDP_SERVER', '', str(ctrl_udp_port), 1500, False)
        self.msgpair_node = blocks.msg_pair_to_var(self.set_my_node_id)
        self.msgpair_dest = blocks.msg_pair_to_var(self.set_dest_node_id)
        self.mag_conv = blocks.complex_to_mag(1)
        self.gui_tx_time = qtgui.time_sink_c(
            4096, #size
            samp_rate, #samp_rate
            'TX Waveform (spread, pre-channel)', #name
            1, #number of inputs
            None # parent
        )
        self.gui_tx_time.set_update_time(0.10)
        self.gui_tx_time.set_y_axis(-1, 1)

        self.gui_tx_time.set_y_label('Amplitude', '')

        self.gui_tx_time.enable_tags(True)
        self.gui_tx_time.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, 0, "")
        self.gui_tx_time.enable_autoscale(True)
        self.gui_tx_time.enable_grid(True)
        self.gui_tx_time.enable_axis_labels(True)
        self.gui_tx_time.enable_control_panel(False)
        self.gui_tx_time.enable_stem_plot(False)


        labels = ['Signal 1', 'Signal 2', 'Signal 3', 'Signal 4', 'Signal 5',
            'Signal 6', 'Signal 7', 'Signal 8', 'Signal 9', 'Signal 10']
        widths = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        colors = ['blue', 'red', 'green', 'black', 'cyan',
            'magenta', 'yellow', 'dark red', 'dark green', 'dark blue']
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]
        styles = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        markers = [-1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1]


        for i in range(2):
            if len(labels[i]) == 0:
                if (i % 2 == 0):
                    self.gui_tx_time.set_line_label(i, "Re{{Data {0}}}".format(i/2))
                else:
                    self.gui_tx_time.set_line_label(i, "Im{{Data {0}}}".format(i/2))
            else:
                self.gui_tx_time.set_line_label(i, labels[i])
            self.gui_tx_time.set_line_width(i, widths[i])
            self.gui_tx_time.set_line_color(i, colors[i])
            self.gui_tx_time.set_line_style(i, styles[i])
            self.gui_tx_time.set_line_marker(i, markers[i])
            self.gui_tx_time.set_line_alpha(i, alphas[i])

        self._gui_tx_time_win = sip.wrapinstance(self.gui_tx_time.qwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._gui_tx_time_win, 1, 0, 1, 3)
        for r in range(1, 2):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(0, 3):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.gui_corr_mag = qtgui.time_sink_f(
            2000, #size
            symbol_rate, #samp_rate
            'Despread correlation magnitude (processing gain readout)', #name
            1, #number of inputs
            None # parent
        )
        self.gui_corr_mag.set_update_time(0.10)
        self.gui_corr_mag.set_y_axis(-1, 1)

        self.gui_corr_mag.set_y_label('Correlation magnitude', '')

        self.gui_corr_mag.enable_tags(True)
        self.gui_corr_mag.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, 0, "")
        self.gui_corr_mag.enable_autoscale(True)
        self.gui_corr_mag.enable_grid(True)
        self.gui_corr_mag.enable_axis_labels(True)
        self.gui_corr_mag.enable_control_panel(False)
        self.gui_corr_mag.enable_stem_plot(False)


        labels = ['Signal 1', 'Signal 2', 'Signal 3', 'Signal 4', 'Signal 5',
            'Signal 6', 'Signal 7', 'Signal 8', 'Signal 9', 'Signal 10']
        widths = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        colors = ['blue', 'red', 'green', 'black', 'cyan',
            'magenta', 'yellow', 'dark red', 'dark green', 'dark blue']
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]
        styles = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        markers = [-1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1]


        for i in range(1):
            if len(labels[i]) == 0:
                self.gui_corr_mag.set_line_label(i, "Data {0}".format(i))
            else:
                self.gui_corr_mag.set_line_label(i, labels[i])
            self.gui_corr_mag.set_line_width(i, widths[i])
            self.gui_corr_mag.set_line_color(i, colors[i])
            self.gui_corr_mag.set_line_style(i, styles[i])
            self.gui_corr_mag.set_line_marker(i, markers[i])
            self.gui_corr_mag.set_line_alpha(i, alphas[i])

        self._gui_corr_mag_win = sip.wrapinstance(self.gui_corr_mag.qwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._gui_corr_mag_win, 3, 0, 1, 6)
        for r in range(3, 4):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(0, 6):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.gui_before_waterfall = qtgui.waterfall_sink_c(
            2048, #size
            window.WIN_BLACKMAN_hARRIS, #wintype
            0, #fc
            samp_rate, #bw
            'BEFORE despread: waterfall (looks like pure noise)', #name
            1, #number of inputs
            None # parent
        )
        self.gui_before_waterfall.set_update_time(0.10)
        self.gui_before_waterfall.enable_grid(False)
        self.gui_before_waterfall.enable_axis_labels(True)



        labels = ['', '', '', '', '',
                  '', '', '', '', '']
        colors = [0, 0, 0, 0, 0,
                  0, 0, 0, 0, 0]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
                  1.0, 1.0, 1.0, 1.0, 1.0]

        for i in range(1):
            if len(labels[i]) == 0:
                self.gui_before_waterfall.set_line_label(i, "Data {0}".format(i))
            else:
                self.gui_before_waterfall.set_line_label(i, labels[i])
            self.gui_before_waterfall.set_color_map(i, colors[i])
            self.gui_before_waterfall.set_line_alpha(i, alphas[i])

        self.gui_before_waterfall.set_intensity_range(-140, 10)

        self._gui_before_waterfall_win = sip.wrapinstance(self.gui_before_waterfall.qwidget(), Qt.QWidget)

        self.top_grid_layout.addWidget(self._gui_before_waterfall_win, 2, 0, 1, 3)
        for r in range(2, 3):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(0, 3):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.gui_before_freq = qtgui.freq_sink_c(
            4096, #size
            window.WIN_BLACKMAN_hARRIS, #wintype
            0, #fc
            samp_rate, #bw
            'BEFORE despread: signal buried in noise', #name
            1,
            None # parent
        )
        self.gui_before_freq.set_update_time(0.10)
        self.gui_before_freq.set_y_axis((-140), 10)
        self.gui_before_freq.set_y_label('Relative Gain', 'dB')
        self.gui_before_freq.set_trigger_mode(qtgui.TRIG_MODE_FREE, 0.0, 0, "")
        self.gui_before_freq.enable_autoscale(False)
        self.gui_before_freq.enable_grid(True)
        self.gui_before_freq.set_fft_average(1.0)
        self.gui_before_freq.enable_axis_labels(True)
        self.gui_before_freq.enable_control_panel(False)
        self.gui_before_freq.set_fft_window_normalized(False)



        labels = ['', '', '', '', '',
            '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        colors = ["blue", "red", "green", "black", "cyan",
            "magenta", "yellow", "dark red", "dark green", "dark blue"]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]

        for i in range(1):
            if len(labels[i]) == 0:
                self.gui_before_freq.set_line_label(i, "Data {0}".format(i))
            else:
                self.gui_before_freq.set_line_label(i, labels[i])
            self.gui_before_freq.set_line_width(i, widths[i])
            self.gui_before_freq.set_line_color(i, colors[i])
            self.gui_before_freq.set_line_alpha(i, alphas[i])

        self._gui_before_freq_win = sip.wrapinstance(self.gui_before_freq.qwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._gui_before_freq_win, 1, 3, 1, 3)
        for r in range(1, 2):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(3, 6):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.gui_after_const = qtgui.const_sink_c(
            1024, #size
            'AFTER despread: recovered QPSK constellation', #name
            1, #number of inputs
            None # parent
        )
        self.gui_after_const.set_update_time(0.10)
        self.gui_after_const.set_y_axis((-2), 2)
        self.gui_after_const.set_x_axis((-2), 2)
        self.gui_after_const.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, "")
        self.gui_after_const.enable_autoscale(False)
        self.gui_after_const.enable_grid(True)
        self.gui_after_const.enable_axis_labels(True)


        labels = ['', '', '', '', '',
            '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        colors = ["blue", "red", "green", "black", "cyan",
            "magenta", "yellow", "dark red", "dark green", "dark blue"]
        styles = [0, 0, 0, 0, 0,
            0, 0, 0, 0, 0]
        markers = [0, 0, 0, 0, 0,
            0, 0, 0, 0, 0]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]

        for i in range(1):
            if len(labels[i]) == 0:
                self.gui_after_const.set_line_label(i, "Data {0}".format(i))
            else:
                self.gui_after_const.set_line_label(i, labels[i])
            self.gui_after_const.set_line_width(i, widths[i])
            self.gui_after_const.set_line_color(i, colors[i])
            self.gui_after_const.set_line_style(i, styles[i])
            self.gui_after_const.set_line_marker(i, markers[i])
            self.gui_after_const.set_line_alpha(i, alphas[i])

        self._gui_after_const_win = sip.wrapinstance(self.gui_after_const.qwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._gui_after_const_win, 2, 3, 1, 3)
        for r in range(2, 3):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(3, 6):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.evm_probe = evm_probe.blk(period_symbols=200)
        self.costas = digital.costas_loop_cc(.15, 4, False)
        self.chunks_to_symbols = digital.chunks_to_symbols_bc([1.4142135381698608+1.4142135381698608j, -1.4142135381698608+1.4142135381698608j, -1.4142135381698608-1.4142135381698608j, 1.4142135381698608-1.4142135381698608j], 1)


        self.tx_frame_source = tx_frame_source.blk(rs_codewords=rs_codewords, my_node_id=my_node_id, dest_node_id=dest_node_id, mode=detect_mode, max_queued_frames=tx_queue_frames, spool_dir='tx_spool')
        self.rx_frame_decoder = rx_frame_decoder.blk(rs_codewords=rs_codewords, mode=detect_mode, sync_threshold=0.68, track_block=64, report_every=1)
        self.dsss_spreader = dsss_spreader.blk(code_len=code_len, node_id=my_node_id)
        self.dsss_despreader = dsss_despreader.blk(code_len=code_len, node_id=dest_node_id, batch_symbols=64, acq_threshold=1.8, acq_periods=64, lock_loss_symbols=500, stats_period_symbols=200, tag_every=16)
        self.reassembler = reassembler.blk(rs_codewords=rs_codewords, my_node_id=my_node_id, dest_node_id=dest_node_id, inbox=rx_inbox, stale_seconds=600.0, quiet_idle=True)
        self.node_ctrl = node_ctrl.blk(table_size=16)
        self.link_metrics = link_metrics.blk(tx_source=self.tx_frame_source, rx_decoder=self.rx_frame_decoder, despreader=self.dsss_despreader, reassembler=self.reassembler, chip_rate=chip_rate, code_len=code_len, sps=sps, rs_codewords=rs_codewords, period_s=diag_period_s, window_s=10.0)
        ##################################################
        # Connections
        ##################################################
        self.msg_connect((self.dsss_despreader, 'stats'), (self.net_diag, 'pdus'))
        self.msg_connect((self.evm_probe, 'evm'), (self.net_diag, 'pdus'))
        self.msg_connect((self.link_metrics, 'diag'), (self.net_diag, 'pdus'))
        self.msg_connect((self.net_ctrl_in, 'pdus'), (self.node_ctrl, 'in'))
        self.msg_connect((self.net_tx_in, 'pdus'), (self.tx_frame_source, 'queue_in'))
        self.msg_connect((self.node_ctrl, 'dest_msg'), (self.msgpair_dest, 'inpair'))
        self.msg_connect((self.node_ctrl, 'node_msg'), (self.msgpair_node, 'inpair'))
        self.msg_connect((self.node_ctrl, 'file_msg'), (self.tx_frame_source, 'ctrl'))
        self.msg_connect((self.node_ctrl, 'status'), (self.net_rx_status, 'pdus'))
        self.msg_connect((self.reassembler, 'msg'), (self.net_rx_data, 'pdus'))
        self.msg_connect((self.reassembler, 'status'), (self.net_rx_status, 'pdus'))
        self.msg_connect((self.rx_frame_decoder, 'payload'), (self.reassembler, 'in'))
        self.msg_connect((self.rx_frame_decoder, 'status'), (self.net_rx_status, 'pdus'))
        self.msg_connect((self.rx_frame_decoder, 'diag'), (self.net_diag, 'pdus'))
        self.msg_connect((self.rx_health, 'status'), (self.net_rx_status, 'pdus'))
        self.msg_connect((self.rx_health, 'status'), (self.link_metrics, 'health'))
        self.msg_connect((self.rx_power_probe, 'power'), (self.net_diag, 'pdus'))
        self.msg_connect((self.tx_frame_source, 'status'), (self.net_rx_status, 'pdus'))
        self.msg_connect((self.tx_frame_source, 'diag'), (self.net_diag, 'pdus'))
        self.msg_connect((self.tx_health, 'status'), (self.net_rx_status, 'pdus'))
        self.msg_connect((self.tx_health, 'status'), (self.link_metrics, 'health'))
        self.msg_connect((self.usrp_sink, 'async_msgs'), (self.tx_health, 'async_in'))
        self.msg_connect((self.usrp_source, 'async_msgs'), (self.rx_health, 'async_in'))
        self.connect((self.chunks_to_symbols, 0), (self.dsss_spreader, 0))
        self.connect((self.costas, 0), (self.evm_probe, 0))
        self.connect((self.costas, 0), (self.gui_after_const, 0))
        self.connect((self.costas, 0), (self.rx_frame_decoder, 0))
        self.connect((self.dsss_despreader, 0), (self.costas, 0))
        self.connect((self.dsss_despreader, 0), (self.mag_conv, 0))
        self.connect((self.dsss_spreader, 0), (self.tx_rrc, 0))
        self.connect((self.mag_conv, 0), (self.gui_corr_mag, 0))
        self.connect((self.rx_mf, 0), (self.dsss_despreader, 0))
        self.connect((self.tx_frame_source, 0), (self.chunks_to_symbols, 0))
        self.connect((self.tx_rrc, 0), (self.gui_tx_time, 0))
        self.connect((self.tx_rrc, 0), (self.usrp_sink, 0))
        self.connect((self.usrp_source, 0), (self.gui_before_freq, 0))
        self.connect((self.usrp_source, 0), (self.gui_before_waterfall, 0))
        self.connect((self.usrp_source, 0), (self.rx_mf, 0))
        self.connect((self.usrp_source, 0), (self.rx_power_probe, 0))
    def closeEvent(self, event):
        self.settings = Qt.QSettings("gnuradio/flowgraphs", "dsss_bpsk_usrp")
        self.settings.setValue("geometry", self.saveGeometry())
        self.stop()
        self.wait()

        event.accept()

    def get_rs_codewords(self):
        return self.rs_codewords

    def set_rs_codewords(self, rs_codewords):
        self.rs_codewords = rs_codewords
        self.set_payload_bytes(dsss_frame.payload_bytes(self.rs_codewords))
        self.set_frame_symbols(dsss_frame.frame_symbols(self.rs_codewords))

    def get_code_len(self):
        return self.code_len

    def set_code_len(self, code_len):
        self.code_len = code_len
        self.set_symbol_rate(self.chip_rate/self.code_len)

    def get_chip_rate(self):
        return self.chip_rate

    def set_chip_rate(self, chip_rate):
        self.chip_rate = chip_rate
        self.set_samp_rate(int(self.chip_rate*self.sps))
        self.set_symbol_rate(self.chip_rate/self.code_len)

    def get_sps(self):
        return self.sps

    def set_sps(self, sps):
        self.sps = sps
        self.set_rrc_ntaps(11*self.sps)
        self.set_samp_rate(int(self.chip_rate*self.sps))

    def get_symbol_rate(self):
        return self.symbol_rate

    def set_symbol_rate(self, symbol_rate):
        self.symbol_rate = symbol_rate
        self.set_frame_period_s(self.frame_symbols/self.symbol_rate)

    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.gui_before_freq.set_frequency_range(self.center_freq, self.samp_rate)
        self.gui_before_waterfall.set_frequency_range(self.center_freq, self.samp_rate)
        self.gui_tx_time.set_samp_rate(self.samp_rate)
        self.rx_mf.set_taps(firdes.root_raised_cosine(1, self.samp_rate, self.chip_rate, self.rrc_alpha, self.rrc_ntaps))
        self.tx_rrc.set_taps(firdes.root_raised_cosine(1, self.samp_rate, self.chip_rate, self.rrc_alpha, self.rrc_ntaps))
        self.usrp_sink.set_samp_rate(self.samp_rate)
        self.usrp_source.set_samp_rate(self.samp_rate)

    def get_payload_bytes(self):
        return self.payload_bytes

    def set_payload_bytes(self, payload_bytes):
        self.payload_bytes = payload_bytes

    def get_frame_symbols(self):
        return self.frame_symbols

    def set_frame_symbols(self, frame_symbols):
        self.frame_symbols = frame_symbols
        self.set_frame_period_s(self.frame_symbols/self.symbol_rate)

    def get_frame_period_s(self):
        return self.frame_period_s

    def set_frame_period_s(self, frame_period_s):
        self.frame_period_s = frame_period_s

    def get_detect_mode(self):
        return self.detect_mode

    def set_detect_mode(self, detect_mode):
        self.detect_mode = detect_mode

    def get_clock_source(self):
        return self.clock_source

    def set_clock_source(self, clock_source):
        self.clock_source = clock_source

    def get_rx_agc(self):
        return self.rx_agc

    def set_rx_agc(self, rx_agc):
        self.rx_agc = rx_agc
        self.usrp_source.set_rx_agc(bool(self.rx_agc), 0)

    def get_usrp_dev_args(self):
        return self.usrp_dev_args

    def set_usrp_dev_args(self, usrp_dev_args):
        self.usrp_dev_args = usrp_dev_args

    def get_tx_queue_frames(self):
        return self.tx_queue_frames

    def set_tx_queue_frames(self, tx_queue_frames):
        self.tx_queue_frames = tx_queue_frames

    def get_rx_inbox(self):
        return self.rx_inbox

    def set_rx_inbox(self, rx_inbox):
        self.rx_inbox = rx_inbox

    def get_diag_period_s(self):
        return self.diag_period_s

    def set_diag_period_s(self, diag_period_s):
        self.diag_period_s = diag_period_s

    def get_usrp_dev_addr(self):
        return self.usrp_dev_addr

    def set_usrp_dev_addr(self, usrp_dev_addr):
        self.usrp_dev_addr = usrp_dev_addr

    def get_tx_udp_port(self):
        return self.tx_udp_port

    def set_tx_udp_port(self, tx_udp_port):
        self.tx_udp_port = tx_udp_port

    def get_tx_gain(self):
        return self.tx_gain

    def set_tx_gain(self, tx_gain):
        self.tx_gain = tx_gain
        self.usrp_sink.set_normalized_gain(self.tx_gain, 0)

    def get_rx_status_udp_port(self):
        return self.rx_status_udp_port

    def set_rx_status_udp_port(self, rx_status_udp_port):
        self.rx_status_udp_port = rx_status_udp_port

    def get_rx_gain(self):
        return self.rx_gain

    def set_rx_gain(self, rx_gain):
        self.rx_gain = rx_gain
        self.usrp_source.set_gain(self.rx_gain, 0)

    def get_rx_data_udp_port(self):
        return self.rx_data_udp_port

    def set_rx_data_udp_port(self, rx_data_udp_port):
        self.rx_data_udp_port = rx_data_udp_port

    def get_rrc_ntaps(self):
        return self.rrc_ntaps

    def set_rrc_ntaps(self, rrc_ntaps):
        self.rrc_ntaps = rrc_ntaps
        self.rx_mf.set_taps(firdes.root_raised_cosine(1, self.samp_rate, self.chip_rate, self.rrc_alpha, self.rrc_ntaps))
        self.tx_rrc.set_taps(firdes.root_raised_cosine(1, self.samp_rate, self.chip_rate, self.rrc_alpha, self.rrc_ntaps))

    def get_rrc_alpha(self):
        return self.rrc_alpha

    def set_rrc_alpha(self, rrc_alpha):
        self.rrc_alpha = rrc_alpha
        self.rx_mf.set_taps(firdes.root_raised_cosine(1, self.samp_rate, self.chip_rate, self.rrc_alpha, self.rrc_ntaps))
        self.tx_rrc.set_taps(firdes.root_raised_cosine(1, self.samp_rate, self.chip_rate, self.rrc_alpha, self.rrc_ntaps))

    def get_my_node_id(self):
        return self.my_node_id

    def set_my_node_id(self, my_node_id):
        self.my_node_id = my_node_id
        self.dsss_spreader.node_id = self.my_node_id
        self.reassembler.my_node_id = self.my_node_id
        self.tx_frame_source.my_node_id = self.my_node_id

    def get_diag_udp_port(self):
        return self.diag_udp_port

    def set_diag_udp_port(self, diag_udp_port):
        self.diag_udp_port = diag_udp_port

    def get_dest_node_id(self):
        return self.dest_node_id

    def set_dest_node_id(self, dest_node_id):
        self.dest_node_id = dest_node_id
        self.dsss_despreader.node_id = self.dest_node_id
        self.reassembler.dest_node_id = self.dest_node_id
        self.tx_frame_source.dest_node_id = self.dest_node_id

    def get_ctrl_udp_port(self):
        return self.ctrl_udp_port

    def set_ctrl_udp_port(self, ctrl_udp_port):
        self.ctrl_udp_port = ctrl_udp_port

    def get_center_freq(self):
        return self.center_freq

    def set_center_freq(self, center_freq):
        self.center_freq = center_freq
        self.gui_before_freq.set_frequency_range(self.center_freq, self.samp_rate)
        self.gui_before_waterfall.set_frequency_range(self.center_freq, self.samp_rate)
        self.usrp_sink.set_center_freq(self.center_freq, 0)
        self.usrp_source.set_center_freq(self.center_freq, 0)


def main(top_block_cls=dsss_bpsk_usrp, options=None):

    qapp = Qt.QApplication(sys.argv)

    tb = top_block_cls()

    tb.start()
    tb.flowgraph_started.set()

    tb.show()

    def sig_handler(sig=None, frame=None):
        tb.stop()
        tb.wait()

        Qt.QApplication.quit()

    signal.signal(signal.SIGINT, sig_handler)
    signal.signal(signal.SIGTERM, sig_handler)

    timer = Qt.QTimer()
    timer.start(500)
    timer.timeout.connect(lambda: None)

    qapp.exec_()

if __name__ == '__main__':
    main()
