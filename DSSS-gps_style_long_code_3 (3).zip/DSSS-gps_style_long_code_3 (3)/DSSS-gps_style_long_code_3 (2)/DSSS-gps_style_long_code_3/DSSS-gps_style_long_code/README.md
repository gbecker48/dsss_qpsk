# GPS-Style Long-Code DSSS + QPSK Comms Link

A from-scratch GNU Radio Companion flowgraph implementing a continuous
spread-spectrum radio link built around the idea GPS uses: a very long
pseudo-noise code buys a lot of processing gain, which lets you pull a
signal out from *underneath* the noise floor rather than just above it.
QPSK modulation, concatenated forward error correction, file transfer of
any size, and a PyQt5 "ground station" terminal are all included.

Two flowgraphs are in the repo:

- **`dsss_bpsk_usrp.grc`** — the real link, `uhd_usrp_sink` /
  `uhd_usrp_source`. **This is the one that has been rebuilt** (see
  [What changed in v6](#what-changed-in-v6)).
- **`dsss_bpsk_sim.grc`** — the older simulated-channel version. It still
  runs standalone exactly as before, but it has *not* been updated to the
  new framing, FEC or transfer layer, so **it will not interoperate with
  the USRP flowgraph**. See [The sim flowgraph](#the-sim-flowgraph).

---

## What changed in v6

Three problems, three fixes.

### 1. TX underflow / RX overflow, fixed structurally rather than tuned

The old transmitter was **pushed by a wall-clock timer**: a
`blocks.message_strobe` ticked every `strobe_period_ms` and each tick
produced one frame. But the USRP consumes samples at *its* rate, set by
its own oscillator. Those are two independent clocks with nothing keeping
them in step, and there are only two possible outcomes:

| | |
|---|---|
| strobe slightly **slow** | the sink runs out of samples → **TX underflow**. The despreader's correlation peak collapses the instant a chip goes missing, so the far end loses lock and has to re-acquire. |
| strobe slightly **fast** | frames pile up behind the sink, the PDU queue grows without bound, and latency and memory climb until something gives. |

There is no third case. `tx_pace_margin_pct` moved the problem between
those two failure modes; it could never remove it, because no fixed timer
value can track a hardware clock it has no connection to. "No matter how I
change my sample rate and sps I can't get rid of them" was an accurate
description of a design property, not a tuning miss.

**The fix is to make the transmitter pulled instead of pushed.**
`tx_frame_source.py` is a GNU Radio *source* block with no inputs, called
by the USRP sink's own demand for samples, and it can always satisfy that
demand because it synthesises what it returns. The hardware clock is now
the only clock in the system. A data-path underflow is not made unlikely,
it is made *impossible* — there is no timer left to disagree with the
radio. The strobe, TX Scheduler, Packet Framer and PDU-to-Tagged-Stream
blocks are all gone, and so is the `tx_pace_margin_pct` slider, because
there is nothing left for it to tune.

A previous revision tried a source block and found it made things *worse*.
That attempt also cut every downstream buffer to a few frames to keep
latency down, and that is what actually caused the regression: real
hardware needs generous buffering to absorb OS and USB scheduling jitter,
which a pure simulation never exercises. So this version keeps GNU Radio's
default buffer sizing everywhere downstream and bounds latency at the one
place it is cheap — the source block's own output buffer, `tx_queue_frames`
(default 3 frames). UHD is given generous buffers too, via `usrp_dev_args`.

**RX overflow had a separate cause: the despreader.** Tracking re-searched
a window of chip offsets for *every symbol*, which measured at ~46 µs per
symbol — 9% of a CPU core at the default code length and around **150%,
i.e. impossible**, at the shortest. Since symbol rate is
`chip_rate / code_len`, raising the sample rate drove this straight into
overflow. But chip alignment barely moves: two oscillators a few parts per
million apart drift about 0.002 chips per symbol, so the code phase is
effectively constant over tens of symbols. A whole batch is now despread
with a single matrix multiply, with an early/late discriminator over that
same batch maintaining alignment and an integrator learning the clock drift
rate. **Measured at 0.33 µs per symbol — about 140× less CPU**, taking the
worst case from 150% of a core to under 1%.

While measuring that, a latent bug turned up in the old acquisition test:
it declared lock when the correlation peak stood 3× above the median of the
other bins, but the peak-to-median of 1023 *pure noise* bins averages about
3.3 by itself. **That test passed on noise roughly 83% of the time.**
Acquisition now accumulates `|correlation|²` non-coherently over 64 code
periods, which concentrates the noise statistic while the real peak keeps
growing — clean separation down to −28 dB chip SNR.

### 2. Real forward error correction

The old FEC was a repetition code, off by default. It is replaced by the
classic CCSDS-style concatenated stack:

```
data → CRC32 → scramble → Reed-Solomon(255,223) → RS symbol interleave
     → convolutional K=7 rate-1/2 → channel bit interleave → on air
```

Each layer does a job the others cannot:

- **Soft-decision Viterbi (K=7, rate 1/2)** buys about 5 dB of coding gain.
  Its failure mode matters: when it fails it emits a *burst* of 10–40 wrong
  bits, not isolated ones.
- **The channel bit interleaver** sits between the convolutional encoder
  and the modulator, so anything the channel does in a burst is scattered
  before Viterbi — which is near-optimal against independent errors and
  poor against clustered ones.
- **Reed-Solomon(255,223)** is the right partner for Viterbi precisely
  because it is *symbol*-oriented: it corrects any 16 wrong bytes per
  255-byte codeword however the bit errors fall inside them. A 40-bit
  Viterbi burst touches at most 6 bytes, so RS eats an entire Viterbi
  failure event without noticing.
- **The RS symbol interleaver** spreads each codeword's bytes across the
  whole frame, so a long burst is shared among all codewords rather than
  eating one codeword's entire correction budget.

**Measured performance** (`tests/sim_link.py`, 25 frames per point):

| Eb/N0 | frames good | FER | pre-FEC BER | RS worst / 16 |
|---|---|---|---|---|
| 4.0 dB | 24/24 | 0.00 | 7.3e-02 | 1 |
| 3.5 dB | 24/24 | 0.00 | 8.5e-02 | 6 |
| 3.0 dB | 23/24 | 0.04 | 1.0e-01 | 8 |
| 2.5 dB | 18/24 | 0.25 | 1.2e-01 | 15 |
| 2.0 dB | 7/24 | 0.71 | 1.3e-01 | 16 |

**The link closes at about 2.5–3 dB Eb/N0** — essentially the classic
concatenated-code limit — while correcting a raw channel error rate of
better than one bit in ten. Uncoded QPSK needs roughly 9.6 dB for a useful
error rate, so this is 6–7 dB of coding gain. Post-FEC bit errors are zero
throughout: the CRC catches every frame the FEC could not fully repair, so
delivered data is always correct.

**One modulation change was needed to collect that gain.** The old chain
mapped dibits straight through `diff_encoder_bb(4)`, which made the
differential phase increment equal to the dibit value — a mapping that is
*not* Gray coded. After differential demodulation the least significant bit
is 1 for the 90° and 270° points, which are opposite corners: no straight
line separates them, so that bit has no meaningful soft value at all. That
was harmless when the FEC made hard decisions anyway, but soft-decision
Viterbi is worth ~2 dB and can only collect it if every coded bit carries a
confidence. A Gray permutation `[0,1,3,2]` applied before modulation fixes
it, and both soft values then fall out as simple linear functions of the
received sample.

The receiver now also detects **coherently** by default, resolving QPSK's
four-fold phase ambiguity from the sync word once per frame and tracking
residual phase with a fold estimator. Differential detection is robust but
pays 2.5–3 dB because noise enters on both symbols of every difference;
measured side by side, differential closes at ~5.5 dB against coherent's
2.5 dB. Set `detect_mode = 'differential'` to switch back if the Costas
loop ever misbehaves on your hardware — it is a live parameter, not a
rewiring job.

### 3. File transfer of any size

The old ceiling was 64,000 bytes, because the fragment index on the wire
was one byte. The header is now 13 bytes with a **24-bit fragment index**,
putting the ceiling at roughly **7.2 GB per object**.

More importantly, files never sit in RAM at either end:

- **Transmit** reads the file lazily on a background thread that keeps a
  queue of ready fragments. The radio's `work()` call never touches the
  disk, so a slow or cold read can never stall the sample path.
- **Receive** writes each fragment straight into a sparse file at its own
  offset, keeping only a received-fragment bitmap in memory. A 4 GB
  transfer costs about a megabyte of bookkeeping. On completion the file is
  truncated to its declared length and its **SHA-256 is verified** against
  the sender's.

Text messages still travel the old way — assembled in memory, delivered
over the RX data socket — so the ground station's message panes are
unchanged.

---

## Quick start

```bash
gnuradio-companion dsss_bpsk_usrp.grc     # or: python3 dsss_bpsk_usrp.py
python3 ground_station.py                 # in another terminal
```

Send a message by typing it and pressing Ctrl+Enter. Send a file with the
**ATTACH FILE** button, or from `terminal.py` with `/send <path>`.
Received files land in `rx_files/` next to the flowgraph.

Open **Debug ▸** in the ground station's header bar for the live metrics.

---

## Signal chain

```
TERMINAL (UDP) ─▶ Socket PDU ─▶ ┌──────────────────────────────────┐
                                │      TX FRAME SOURCE             │
                                │  fragments, frames, scrambles,   │
                                │  RS-encodes, interleaves,        │
                                │  convolutionally encodes, Gray-  │
                                │  maps — and is PULLED by the     │
                                │  USRP sink, so it can never      │
                                │  starve it                       │
                                └──────────────────────────────────┘
                                                │ symbol indices 0-3
                                                ▼
                                  Chunks to Symbols (QPSK)
                                                ▼
                                  DSSS Spreader  (each QPSK SYMBOL is
                                                ▼ held for one full code
                                                  period and multiplied
                                                  chip by chip)
                                  RRC pulse shaping ─▶ uhd_usrp_sink
                                                           │
                                            [ BEFORE-despread plots tap
                                              in here — the signal is
                                              genuinely invisible ]
                                                           │
                                  uhd_usrp_source ─▶ RRC matched filter
                                                           ▼
                        ╔══════════════════════════════════════════╗
                        ║            DSSS DESPREADER                ║
                        ║  the processing-gain step, done FIRST,    ║
                        ║  before any carrier recovery:             ║
                        ║   1. ACQUISITION: FFT parallel code-phase ║
                        ║      search, accumulated non-coherently   ║
                        ║      over 64 code periods                 ║
                        ║   2. TRACKING: batched despreading with   ║
                        ║      an early/late discriminator and a    ║
                        ║      drift-rate integrator                ║
                        ╚══════════════════════════════════════════╝
                                                │
                             [ AFTER-despread constellation taps in
                               here — signal now recovered ]
                                                ▼
                                  Costas Loop (order 4)
                                                ▼
                        ┌──────────────────────────────────────────┐
                        │           RX FRAME DECODER               │
                        │  residual phase tracking → soft demod →  │
                        │  sync search (all 4 rotations) →         │
                        │  de-interleave → soft Viterbi →          │
                        │  RS decode → descramble → CRC32          │
                        └──────────────────────────────────────────┘
                                                ▼
                        Fragment Reassembler (text in RAM, files
                        streamed to disk + SHA-256) ─▶ UDP ─▶ TERMINAL
```

### Why despread *before* carrier recovery?

Unchanged from v3, and still the crux. A Costas loop cannot lock onto
something it cannot see, so the ~30 dB of processing gain is applied before
anything else even looks at the signal. This is also literally how a GPS
receiver's code and carrier loops are ordered relative to each other.

### The Gold codes

Generated exactly the way GPS C/A codes are: two LFSRs combined as
`G1 XOR (a shifted G2)`. **The 1023-chip codes are bit-for-bit identical to
the ones this project has always transmitted** — verified in
`tests/test_codes.py` against the original tap-pair generator.

What is new is that `code_len` is a real knob, because it is the only
lever that changes *throughput*. Raising the chip rate buys occupied
bandwidth but not data rate, since `symbol_rate = chip_rate / code_len`:

| `code_len` | processing gain | symbol rate @ 2.046 Mcps | net payload |
|---|---|---|---|
| 2047 | 33.1 dB | 1,000 /s | ~0.8 kbit/s |
| **1023** (default) | **30.1 dB** | **2,000 /s** | **~1.7 kbit/s** |
| 511 | 27.1 dB | 4,004 /s | ~3.3 kbit/s |
| 127 | 21.0 dB | 16,110 /s | ~13.4 kbit/s |
| 63 | 18.0 dB | 32,476 /s | ~27 kbit/s |

For moving a file, 127 chips still hides the signal 21 dB under the noise
floor while running about eight times faster than the GPS-length code.

**There is no 255-chip option**, and that is not an oversight. Gold codes
only exist where a *preferred pair* of m-sequences does, which requires the
LFSR degree to be odd or ≡ 2 mod 4. That admits 63, 127, 511, 1023 and
2047 and rules out 255. Offering one anyway would mean shipping a pair
whose cross-correlation is not 3-valued — exactly the property multi-node
CDMA separation depends on.

Every code was verified numerically before use: exact period, balanced chip
distribution (an unbalanced code carries a DC term, which on air is a
carrier spike sitting in the middle of the band — the one artefact a
spectrum analyser could actually find on a link whose whole premise is
invisibility), and the textbook 3-valued correlation spectrum
`{-1, -t(n), t(n)-2}`. `tests/test_codes.py` re-runs all of it.

---

## Packet format

```
[ SYNC 8 B, uncoded ][ CODED BODY  2*(n_cw*255*8 + 6) bits ]

body (before coding) = [ SEQ 1 ][ PAYLOAD n_cw*223-5 ][ CRC32 4 ]
                       \________________ scrambled ___________/
```

With the default `rs_codewords = 2`: 446 body bytes, a 441-byte payload,
8236 on-air bits per frame, 4118 QPSK symbols, 2.06 s per frame at the
default code length.

The sync word stays uncoded so the receiver can search for it before it can
decode anything. Fragment header (13 bytes, inside the payload):

```
[SRC 1][DST 1][TYPE 1][MSG_ID 2][FRAG_IDX 3][FRAG_TOTAL 3][CHUNK_LEN 2]
```

`TYPE` is 0 idle, 1 text, 2 file data, 3 file metadata. Usable data per
fragment: **428 bytes**.

**Idle frames are not wasted air time.** They carry a deterministic PRBS
the receiver regenerates, which means the link measures its own *post-FEC*
bit error rate continuously, on live conditions, with no test mode and no
loopback.

---

## Metrics

**Debug ▸** in the ground station opens a much larger diagnostics window.
The numbers that matter most:

| Field | What it means |
|---|---|
| **Pre-FEC BER** | The raw channel error rate, measured by re-encoding the Viterbi output and comparing it against the received hard decisions. Needs no test pattern and no known data — the decoder's own output is the reference. |
| **Post-FEC BER** | A true end-to-end error rate, measured against the known PRBS in idle frames. |
| **Eb/N0 implied by raw BER** | Inverted from the measured pre-FEC BER, and *interpreted*: "comfortable", "close to the 2.5 dB cliff", or "BELOW the code's threshold". |
| **RS headroom** | How many of Reed-Solomon's 16 correctable symbols per codeword are still spare, drawn as a bar. This is the difference between "it's working" and "it's working with three symbols to spare". |
| **Viterbi corrections** | How many of the frame's coded bits the inner code had to repair. |
| **Goodput / efficiency** | Measured payload throughput over a sliding window, against the theoretical ceiling. |
| **Processing gain, ideal vs actual** | `10*log10(code_len)` against the correlation peak's real margin over a decorrelated reference. |
| **Acquisitions / lock losses / resyncs** | A link quietly re-acquiring over and over looks the same as a slow one from the outside. |
| **TX underflow / RX overflow** | UHD async event counts. These should now stay at zero. |

`terminal.py --show-diag` prints the same telemetry as raw text.

---

## Adjustable parameters

| Variable | Default | Meaning |
|---|---|---|
| `chip_rate` | 2046000.0 | Chips/sec. Sets occupied bandwidth. |
| `sps` | 4 | Samples per chip → `samp_rate` = 8.184 Msps. |
| `code_len` | 1023 | Spreading factor. 63/127/511/1023/2047. The throughput knob. |
| `rs_codewords` | 2 | RS codewords per frame → payload size. |
| `detect_mode` | `'coherent'` | `'coherent'` (2.5 dB) or `'differential'` (5.5 dB, more robust). |
| `my_node_id` / `dest_node_id` | 0 / 1 | Which code this radio transmits on / listens to. |
| `clock_source` | `'external'` | `'external'` needs a 10 MHz reference; use `'internal'` if you have none. |
| `rx_agc` | True | AD9361 AGC. Set False to use `rx_gain` manually. |
| `usrp_dev_args` | see file | UHD buffer sizing. Raise if you still see overflow. |
| `tx_queue_frames` | 3 | TX latency cap, in frames. |
| `rx_inbox` | `'rx_files'` | Where received files land. |
| `costas_bw` | 0.15 | Costas loop bandwidth. |
| `center_freq`, `tx_gain`, `rx_gain` | 915 MHz, 0, 20 | Live GUI sliders. |

**Check your local spectrum regulations before transmitting.**

---

## Tests

Everything is verifiable without a radio, and most of it without GNU Radio:

```bash
cd tests
python3 test_fec.py        # GF(256), RS, Viterbi, interleavers
python3 test_codes.py      # Gold code properties + 1023-chip compatibility
python3 test_frame.py      # framing, soft demod, FrameScanner
python3 test_track.py      # acquisition, drift tracking, CDMA, CPU cost
python3 test_transfer.py   # 4 MB file transfer, lossy link, path safety
python3 test_blocks.py     # every block, against a mock GNU Radio runtime
python3 test_gs.py         # the ground station, headless
python3 sim_link.py        # Eb/N0 sweep of the whole chain
python3 check_grc.py       # flowgraph structure and wiring
python3 check_py.py        # generated Python agrees with the .grc
```

`test_blocks.py` runs a full transmit → spread → 22 dB below the noise
floor → despread → decode → reassemble loop through the real block code,
using a mock GNU Radio runtime (`tests/grmock/`).

---

## Files

```
dsss_bpsk_usrp.grc            the flowgraph
dsss_bpsk_usrp.py             pre-generated, runs without opening GRC
dsss_bpsk_usrp_<block>.py     one module per embedded block (GRC writes these)

dsss_fec.py                   RS(255,223), K=7 soft Viterbi, interleavers
dsss_frame.py                 framing, Gray/differential mapping, FrameScanner
dsss_codes.py                 multi-length Gold codes
dsss_track.py                 code acquisition and batched tracking
dsss_transfer.py              fragmentation, reassembly, file transfer

ground_station.py             PyQt5 terminal, file transfer, metrics window
terminal.py                   plain-text alternative (/send, /node, /dest)
custom_blocks/                reference copies — editing these does nothing
tests/                        the suite above
```

**The five `dsss_*.py` modules are shared by both ends of the link**, which
is the only reliable way to keep a transmitter and receiver in step. They
sit next to the flowgraph, which is on `sys.path` when it runs, so the
embedded blocks import them directly. There is still nothing to build and
no out-of-tree module to install.

As before, **editing `custom_blocks/` does nothing** — those are reference
copies. Edit a block's source inside GRC.

---

## The sim flowgraph

`dsss_bpsk_sim.grc` was left alone, as requested. It still runs standalone
with its own copies of the old blocks, but it now speaks a **different wire
format** — old framing, repetition FEC, 6-byte fragment header — so it
cannot talk to the USRP flowgraph. If you want a no-hardware test of the
new chain, `tests/sim_link.py` exercises the whole thing over a simulated
AWGN channel with real spreading, and `tests/test_blocks.py` runs the
actual block code end to end.

---

## Running on real USRPs

1. `uhd_find_devices` to confirm UHD sees the radio.
2. Set `usrp_dev_addr` if you have more than one.
3. `clock_source` defaults to `'external'` — it needs a 10 MHz reference
   on REF IN. **If you do not have one connected, set it to `'internal'`**,
   or the device free-runs unlocked, which alone can produce constant
   over/underflow.
4. Start with low gain and a dummy load or attenuator between TX and RX.

### Two-node full duplex

Run the flowgraph on two machines. On node A leave `my_node_id = 0`,
`dest_node_id = 1`; on node B set `my_node_id = 1`, `dest_node_id = 0`
(the ground station's MY NODE / TALKING TO boxes do this live). Both radios
then transmit continuously on their own code and receive continuously on
their peer's, at the same time on the same frequency — genuine full duplex.
Gold codes are only ~−24 dB cross-correlated rather than orthogonal, but
combined with despreading gain that is enough separation.

---

## Known quirks and honest limits

- **No ARQ.** A fragment lost to noise means its object never completes;
  the reassembler reports `INCOMPLETE` rather than hanging on to it. For a
  large file that means a full resend. Adding ARQ is the clean next step
  and is out of scope here.
- **The despreader sees one sample per chip**, so alignment is an integer
  number of chips. While a drifting clock carries the true alignment across
  a half-chip boundary the correlation genuinely halves — sampling
  geometry, not a tracking failure. With a shared 10 MHz reference this
  effectively does not arise. Despreading at two samples per chip would
  halve the worst case, at twice the correlation cost.
- **Residual frequency offset** after the Costas loop is tolerated to about
  ±3 Hz at the default symbol rate (it scales with symbol rate). The Costas
  loop is expected to do the real frequency work.
- **The first frame after start-up is always lost** to acquisition. This is
  normal for any freshly-started acquisition/tracking receiver, and it is
  exactly why the transmitter is continuous rather than bursting.
- **TX amplitude is unchanged** from previous versions: the constellation
  points have magnitude 2.0, which the USRP sink clips to full scale. For a
  constant-envelope spread signal that is a uniform scaling rather than
  distortion, so it was left alone — but it is worth knowing it is
  happening if you start looking at the transmitted spectrum closely.
- GRC may still print a deprecation warning for a stock block; harmless.

---

## Version history

- **v6 (current): the underflow fix, real FEC, and unlimited file
  transfer.** Replaced the timer-pushed transmit chain with a
  hardware-pulled source block, which makes data-path underflow
  structurally impossible rather than merely unlikely. Rewrote despreader
  tracking to work in batches (~140× less CPU) and fixed an acquisition
  test that passed on pure noise 83% of the time. Replaced the repetition
  FEC with concatenated RS(255,223) + K=7 rate-1/2 soft Viterbi +
  interleaving, closing the link at ~2.5 dB Eb/N0. Fixed the non-Gray
  constellation mapping that was preventing soft decisions from paying off,
  and moved to coherent detection by default. Raised the sample rate to
  8.184 Msps and made `code_len` a real knob. Replaced the 64 KB message
  ceiling with 24-bit fragment indexing, disk-backed transfer at both ends
  and SHA-256 verification. Rebuilt the metrics window around measured
  pre- and post-FEC error rates, RS headroom and Eb/N0. Added a test suite
  that runs without a radio.
- **v5: reverted the v4 TX redesign, kept its networking work, added a
  Debug window.**
- **v4: multi-node networking, per-node CDMA codes, first underflow
  redesign** (later reverted).
- **v3: GPS-style long-code DSSS, QPSK, continuous transmission.**
- **v2: QPSK + spreading_factor=11.**
- **v1: BPSK + spreading_factor=7.**
