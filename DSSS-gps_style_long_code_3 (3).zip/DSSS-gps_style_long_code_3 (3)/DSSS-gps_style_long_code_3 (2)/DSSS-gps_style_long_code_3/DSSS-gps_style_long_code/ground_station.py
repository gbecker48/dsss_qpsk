#!/usr/bin/env python3
"""
ground_station.py -- PyQt5 desktop "ground station" console for the QPSK +
DSSS burst comms link.

This is a full graphical replacement for terminal.py's plain-text terminal.
It is a pure UDP client/front-end for the (separately developed) GNU Radio
flowgraph: there is NO "import gnuradio" anywhere in this file, and the app
never assumes the flowgraph is already running. If nothing is listening on
the TX port yet, sends are still fire-and-forget UDP datagrams (no error);
if nothing has ever arrived on the RX ports, the UI just sits in a clean
"NO LINK" state and waits, reconnecting to nothing in particular (UDP has no
connection to lose) until traffic shows up.

=== UDP protocol (frozen contract with the flowgraph -- do not change) ===

  TX   (this app -> flowgraph), host:tx_port, default 127.0.0.1:52001
       Send the ENTIRE message as ONE UDP datagram (UTF-8). The flowgraph
       does its own fragmentation on the wire; we never fragment client
       side. Hard ceiling: 256 fragments x 252 bytes/fragment = 64512 bytes.

  RX data   (flowgraph -> this app), bind_host:rx_data_port, default 52002
       A complete, reassembled, CRC-validated message, one per datagram,
       UTF-8 (decoded with errors='replace'). Only sent once ALL fragments
       of a message were received successfully.

  RX status (flowgraph -> this app), bind_host:rx_status_port, default 52003
       UTF-8 text, one event per datagram, in one of these grammars:
         "FRAG msg=<id> idx=<i> total=<n> seq=<seq> crc=OK|FAIL len=<bytes> src=<s> dst=<d>"
         "IDLE seq=<seq> src=<s> dst=<d>"
         "DONE msg=<id> fragments=<n> bytes=<total_bytes> src=<s>"
         "INCOMPLETE msg=<id> missing=<comma,separated,fragment,indices>"
         "FOREIGN src=<s> dst=<d> msg=<id> (...)"   -- a frame not addressed
                                                        to this node
         "WARN unexpected src=<s> ..."               -- possible code collision
         "HEALTH <TX|RX> <EVENT> #<n> (...)"         -- UHD underflow/overflow
                                                        telemetry, real hardware only
       Parsed leniently: split on whitespace, then split each token on the
       *first* '=' as key/value. Any line that doesn't match, is missing
       fields, has extra unknown keys, or isn't one of the above keywords
       at all must never crash the app -- worst case we just show the raw
       text in the log panel.

  CONTROL (this app -> flowgraph), host:ctrl_port, default 127.0.0.1:52004
       Plain ASCII "NODE=<n>" / "DEST=<n>" commands from the node switcher
       in the header bar. NODE sets which PRN this radio transmits on;
       DEST sets which peer's PRN it despreads against (who it's currently
       listening to). Fire-and-forget, same as TX -- there is no ack, but
       the effect shows up within a few status lines (src=/dst= fields).

=== Key design assumptions (see also inline comments where used) ===

  1. Sent-message <-> flowgraph msg-id correlation: the protocol does not
     tell the sender which wire-format msg id its own send became. This app
     assumes a single client talking to a single flowgraph instance, and
     that the flowgraph assigns msg ids to incoming sends in the same
     strictly-increasing (mod 256) order it receives them on the TX port.
     So we assign ids 0, 1, 2, ... wrapping at 256 to our own sends, in send
     order, and correlate FRAG/DONE/INCOMPLETE status lines against that
     assumed id. This breaks if multiple clients share one flowgraph, or if
     UDP ever reorders/drops a send before it reaches the flowgraph's socket
     (loopback in practice does not reorder). Good enough for this single-
     client ground-station-console use case.

  2. IDLE status lines are intentionally OMITTED from the scrolling Link Log
     (they're a once-a-second heartbeat and would drown out real events).
     They still feed the link-alive indicator, per spec. FRAG/DONE/INCOMPLETE
     (and any unrecognized status line, logged as-is) DO appear in the log.

  3. Sending itself (socket.sendto of a small/medium UDP datagram on a
     loopback socket) is treated as effectively non-blocking and is issued
     directly from the GUI thread -- there is no kernel-level queueing
     concern for a single sendto() call the way there is for the *receive*
     side, which must block in recvfrom() forever and therefore needs a
     background thread. Only the two receive sockets get worker threads.
"""

import os
import os
import sys

# ----------------------------------------------------------------------------
# Work around a real, confirmed Ubuntu/Snap crash, BEFORE anything else in
# this file runs - in particular before PyQt5/Qt ever get imported. This
# isn't a generic "just in case" guard: the exact failure below was
# reproduced and root-caused directly (see the project history) while fixing
# a real user report, and the fix here is the specific, verified fix for it,
# not a guess.
#
# THE SYMPTOM:
#   QSocketNotifier: Can only be used with threads started with QThread
#   python3: symbol lookup error: .../snap/core20/current/lib/.../libpthread.so.0:
#   undefined symbol: __libc_pthread_init, version GLIBC_PRIVATE
#
# THE ACTUAL CAUSE (confirmed by reproducing it directly): on a GNOME-based
# Ubuntu desktop, Qt auto-detects the desktop environment and tries to load
# its "gtk3" platform theme integration plugin for native-looking widgets -
# either automatically, or because something in the session (a Snap app's
# own launch environment, e.g. VS Code's, which can leak GTK_PATH/
# QT_QPA_PLATFORMTHEME into a terminal spawned from it) points Qt at that
# plugin. Loading it pulls in a GTK module from a Snap's bundled library
# directory (GTK_PATH pointing into e.g. .../snap/<app>/current/usr/lib/.../
# gtk-3.0), and that module was built against its Snap's own base (commonly
# core20) - whose bundled, standalone libpthread.so.0 predates glibc 2.34
# merging pthread into libc.so.6, and is binary-incompatible with the host
# system's actual glibc. The crash fires from that mismatch, at plugin-load
# time - it has NOTHING to do with sockets, this app's own UDP listener
# threads, or anything else in this file (this was verified directly:
# setting QT_QPA_PLATFORMTHEME=gtk3 alone reproduces the exact crash with no
# other code involved at all; clearing it, or clearing a Snap-polluted
# GTK_PATH, independently prevents it).
#
# THE FIX: this app draws its own dark theme via an explicit stylesheet
# anyway (see build_stylesheet() below) - it has no use for native GTK theme
# integration in the first place, so the simplest fix is to unconditionally
# disable it, and strip Snap paths from a few related GTK/GIO module-lookup
# variables as a second, independent layer of defense in case some other
# Qt subsystem (e.g. a native file dialog) would otherwise also try to load
# a module from one of them later in the app's life. Both changes take
# effect via plain os.environ writes made before PyQt5 is ever imported -
# no process re-exec is needed for these (they're read lazily, at the point
# Qt actually loads a plugin, not baked in at process start the way the
# dynamic linker's own LD_LIBRARY_PATH search is).
# ----------------------------------------------------------------------------
os.environ["QT_QPA_PLATFORMTHEME"] = ""
for _var in ("GTK_PATH", "GIO_MODULE_DIR", "GIO_EXTRA_MODULES",
             "GDK_PIXBUF_MODULEDIR", "GDK_PIXBUF_MODULE_FILE",
             "GTK_IM_MODULE_FILE", "XDG_DATA_DIRS"):
    _val = os.environ.get(_var, "")
    if "/snap/" in _val:
        _kept = os.pathsep.join(p for p in _val.split(os.pathsep) if "/snap/" not in p)
        if _kept:
            os.environ[_var] = _kept
        else:
            os.environ.pop(_var, None)
del _var, _val


def _sanitize_snap_polluted_ld_library_path():
    """A separate, independent layer of defense against the same class of
    problem via a different vector: if LD_LIBRARY_PATH itself (not just the
    GTK-specific variables above) contains a Snap path - e.g. from a shell
    that was launched from, or ever sourced environment from, a Snap
    application - the dynamic linker can resolve libpthread.so.0 (or other
    libraries) against it directly, independent of anything Qt/GTK-related.
    That has to be fixed by re-executing this process with a cleaned
    environment, since LD_LIBRARY_PATH is consulted by the dynamic linker
    at process/library-load time, not lazily re-read the way the GTK
    variables above are. A guard env var prevents looping.
    """
    if os.environ.get("_GS_ENV_SANITIZED"):
        return
    ld_path = os.environ.get("LD_LIBRARY_PATH", "")
    if not ld_path:
        return
    parts = ld_path.split(os.pathsep)
    kept = [p for p in parts if "/snap/" not in p]
    if len(kept) == len(parts):
        return  # nothing Snap-related to strip
    os.environ["_GS_ENV_SANITIZED"] = "1"
    if kept:
        os.environ["LD_LIBRARY_PATH"] = os.pathsep.join(kept)
    else:
        os.environ.pop("LD_LIBRARY_PATH", None)
    try:
        os.execve(sys.executable, [sys.executable] + sys.argv, os.environ)
    except OSError:
        pass  # if re-exec itself fails for some reason, just carry on as-is


_sanitize_snap_polluted_ld_library_path()

import argparse
import math
import socket
import threading
import time
import traceback
from datetime import datetime

from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QObject
from PyQt5.QtGui import QFont, QTextCursor, QColor, QKeySequence
from PyQt5.QtWidgets import (
    QProgressBar, QFileDialog, QMessageBox, QScrollArea,
    QApplication, QMainWindow, QWidget, QLabel, QPushButton, QTableWidget,
    QTableWidgetItem, QHeaderView, QAbstractItemView, QPlainTextEdit,
    QTextEdit, QSplitter, QVBoxLayout, QHBoxLayout, QDialog, QDialogButtonBox,
    QMessageBox, QFrame, QStatusBar, QShortcut, QSizePolicy, QSpinBox,
)

# --------------------------------------------------------------------------
# Protocol / estimate constants -- kept together near the top so they're a
# one-line fix if the flowgraph's real numbers ever change.
# --------------------------------------------------------------------------
FRAGMENT_PAYLOAD_BYTES = 428        # bytes/fragment on the wire (payload_bytes
                                     # minus the 6-byte SRC/DST/MSG_ID/FRAG_IDX/
                                     # FRAG_TOTAL/CHUNK_LEN inner header)
MAX_FRAGMENTS = 256                 # 1-byte fragment-index field on the wire
MAX_MESSAGE_BYTES = MAX_FRAGMENTS * FRAGMENT_PAYLOAD_BYTES  # 64000

# NOTE: this is an ESTIMATE only, not measured from the real flowgraph.
# Purely informational -- sending is never blocked or gated on it. The
# flowgraph paces one fragment per ~1.1s (the on-air time for one
# 1023-chip-spread frame at this link's default settings) via a
# blocks.message_strobe, kept slightly ahead of real-time by the
# flowgraph's own tx_pace_margin_pct slider rather than a fixed margin
# baked in here - see the README's "Continuous transmission" section.
EST_SECONDS_PER_FRAGMENT = 1.1

MSG_ID_WRAP = 256                   # wire format's 1-byte msg id field

HEARTBEAT_STALE_SEC = 5.0           # no status-port traffic this long -> NO LINK
HEARTBEAT_POLL_MS = 1000

LOG_MAX_LINES = 4000                # cap the Link Log so it can't leak memory
RECV_SOCK_TIMEOUT_S = 0.5           # so listener threads can notice stop()

PREVIEW_LEN = 60

NODE_TABLE_SIZE = 16                # must match the flowgraph's node_prn_table


# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------

def human_bytes(n) -> str:
    """Byte counts that a person can read at a glance."""
    try:
        n = float(n)
    except (TypeError, ValueError):
        return "--"
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if abs(n) < 1024.0 or unit == 'TB':
            return "%.0f %s" % (n, unit) if unit == 'B' else "%.1f %s" % (n, unit)
        n /= 1024.0
    return "%.1f TB" % n


def human_rate(bps) -> str:
    """Bit rates, scaled."""
    try:
        bps = float(bps)
    except (TypeError, ValueError):
        return "--"
    if bps < 1000:
        return "%.0f bit/s" % bps
    if bps < 1e6:
        return "%.2f kbit/s" % (bps / 1e3)
    return "%.2f Mbit/s" % (bps / 1e6)


def human_secs(s) -> str:
    try:
        s = float(s)
    except (TypeError, ValueError):
        return "--"
    if s < 0:
        return "--"
    if s < 90:
        return "%.0f s" % s
    if s < 5400:
        return "%.1f min" % (s / 60.0)
    return "%.1f h" % (s / 3600.0)


def now_hms() -> str:
    return datetime.now().strftime('%H:%M:%S')


def make_preview(text: str, length: int = PREVIEW_LEN) -> str:
    """Single-line preview: collapse newlines so multi-line messages don't
    break the table row, then truncate with an ellipsis."""
    flat = text.replace('\r\n', ' ⏎ ').replace('\n', ' ⏎ ').replace('\r', ' ⏎ ')
    if len(flat) > length:
        return flat[:length] + '…'
    return flat


def parse_status_line(line: str):
    """Lenient parser for the RX-status grammar. Returns (keyword, {k: v})
    or None for a totally empty line. Never raises -- any token that isn't
    'key=value' is just skipped rather than causing a crash."""
    parts = line.strip().split()
    if not parts:
        return None
    keyword = parts[0]
    kv = {}
    for tok in parts[1:]:
        if '=' in tok:
            k, _, v = tok.partition('=')
            if k:
                kv[k] = v
    return keyword, kv


# --------------------------------------------------------------------------
# Background UDP receive workers
#
# Each listener owns one blocking UDP socket and runs its recvfrom() loop on
# a plain Python daemon thread (using QThread is not necessary here -- a
# QObject whose signals are emitted from a foreign thread is a well-defined,
# safe pattern in PyQt5: Qt auto-queues the connection onto the receiving
# object's thread, which is the GUI thread here, so widgets are only ever
# touched from GUI-thread slots). A short socket timeout lets the loop wake
# up periodically to notice stop() without needing to rely on close()
# reliably interrupting recvfrom() on every platform.
# --------------------------------------------------------------------------

class UdpListener(QObject):
    datagram_received = pyqtSignal(bytes)
    bind_failed = pyqtSignal(str)

    def __init__(self, label: str, host: str, port: int, parent=None):
        super().__init__(parent)
        self.label = label
        self.host = host
        self.port = port
        self._sock = None
        self._stop_event = threading.Event()
        self._thread = None

    def start(self) -> bool:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind((self.host, self.port))
            sock.settimeout(RECV_SOCK_TIMEOUT_S)
        except OSError as exc:
            self.bind_failed.emit(
                f"{self.label}: could not bind {self.host}:{self.port} ({exc})"
            )
            return False
        self._sock = sock
        self._thread = threading.Thread(
            target=self._run, name=f"udp-{self.label}", daemon=True
        )
        self._thread.start()
        return True

    def _run(self):
        while not self._stop_event.is_set():
            try:
                data, _addr = self._sock.recvfrom(65535)
            except socket.timeout:
                continue
            except OSError:
                return
            try:
                self.datagram_received.emit(bytes(data))
            except RuntimeError:
                # underlying QObject was torn down mid-flight; just stop.
                return

    def stop(self):
        self._stop_event.set()
        if self._sock is not None:
            try:
                self._sock.close()
            except OSError:
                pass


# --------------------------------------------------------------------------
# Compose box: multi-line, plain Enter inserts a newline, Ctrl+Enter (or
# Cmd+Enter on macOS, via the Meta modifier) sends.
# --------------------------------------------------------------------------

class ComposeEdit(QPlainTextEdit):
    send_requested = pyqtSignal()

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key_Return, Qt.Key_Enter) and (
            event.modifiers() & (Qt.ControlModifier | Qt.MetaModifier)
        ):
            self.send_requested.emit()
            return
        super().keyPressEvent(event)


# --------------------------------------------------------------------------
# Small "full message" viewer dialog (double-click a table row).
# --------------------------------------------------------------------------

class FullTextDialog(QDialog):
    def __init__(self, title: str, text: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(640, 440)
        layout = QVBoxLayout(self)
        viewer = QPlainTextEdit(self)
        viewer.setReadOnly(True)
        viewer.setPlainText(text)
        mono = QFont("DejaVu Sans Mono", 10)
        mono.setStyleHint(QFont.Monospace)
        viewer.setFont(mono)
        layout.addWidget(viewer)
        buttons = QDialogButtonBox(QDialogButtonBox.Close, self)
        buttons.rejected.connect(self.reject)
        buttons.accepted.connect(self.accept)
        layout.addWidget(buttons)


# --------------------------------------------------------------------------
# Diagnostics / debug window
#
# Everything shown here is either parsed straight out of the existing RX
# status text (packet error rate, UHD health event counts - zero new
# flowgraph plumbing) or fed by a handful of small, purely additive probe
# blocks added to the flowgraph (EVM Probe, RX Power Probe, and a few new
# message ports on the DSSS Despreader / FEC Decoder) that tap the signal
# path via a second connection rather than sitting inline in it - none of
# them can affect the TX pacing or existing RX decode timing. This window
# is independent of the Link Log on purpose: it can get busy (the
# processing-gain reading alone updates ~20x/sec) and none of it belongs
# mixed into the human-readable message log.
# --------------------------------------------------------------------------

class DiagnosticsWindow(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Diagnostics")
        self.setModal(False)
        self.resize(520, 820)
        self.setStyleSheet(_QSS)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        inner = QWidget(scroll)
        scroll.setWidget(inner)
        outer.addWidget(scroll)
        layout = QVBoxLayout(inner)
        layout.setSpacing(4)

        self.labels = {}

        def section(title):
            lbl = QLabel(title, inner)
            lbl.setObjectName("panelTitle")
            layout.addSpacing(8)
            layout.addWidget(lbl)

        def row(key, title, initial="--"):
            box = QHBoxLayout()
            name = QLabel(title, inner)
            name.setMinimumWidth(230)
            val = QLabel(initial, inner)
            val.setObjectName("diagValue")
            mono = QFont("DejaVu Sans Mono", 10)
            mono.setStyleHint(QFont.Monospace)
            val.setFont(mono)
            box.addWidget(name)
            box.addWidget(val, stretch=1)
            layout.addLayout(box)
            self.labels[key] = val

        section("LINK CONFIGURATION")
        row('cfg_chip', 'Chip rate / sample rate')
        row('cfg_code', 'Code length / processing gain')
        row('cfg_sym', 'Symbol rate / raw bit rate')
        row('cfg_frame', 'Frame size / period')
        row('cfg_rate', 'Code rate (payload / on-air)')
        row('cfg_ceiling', 'Max payload throughput')

        section("MEASURED THROUGHPUT")
        row('goodput', 'Goodput (RX payload, 10 s avg)')
        row('txrate', 'TX payload rate (10 s avg)')
        row('framerate', 'Frame rate')
        row('efficiency', 'Air-time efficiency')
        row('xfer', 'Active transfer')

        section("FORWARD ERROR CORRECTION")
        row('ber_pre', 'Pre-FEC BER (raw channel)')
        row('ber_post', 'Post-FEC BER (measured on idle PRBS)')
        row('coding_gain', 'Errors corrected per 1000 bits')
        row('ebno', 'Eb/N0 implied by raw BER')
        row('viterbi', 'Viterbi corrections, last frame')
        row('rs_last', 'RS corrections, last frame')
        row('rs_worst', 'RS worst case seen')
        row('rs_head', 'RS headroom (of 16 symbols)')
        row('rs_uncorr', 'RS uncorrectable codewords')
        row('fer', 'Frame error rate (CRC)')
        row('frames', 'Frames decoded ok / failed')

        section("PROCESSING GAIN  (the whole point of this project)")
        row('lock', 'Despreader lock status', 'UNKNOWN')
        row('proc_ideal', 'Ideal (10*log10(code_len))')
        row('proc_actual', 'Actual (measured, live)')
        row('proc_gap', 'Gap vs. ideal')
        row('acq', 'Acquisitions / lock losses')
        row('sync', 'Frame sync / resyncs / false')

        section("SIGNAL QUALITY")
        row('power', 'RX power (dBFS)')
        row('evm_last', 'EVM, last reading')
        row('evm_avg', 'EVM, rolling average')

        section("USRP HEALTH  (real hardware only)")
        row('underflow', 'TX underflow events')
        row('overflow', 'RX overflow events')
        row('other_health', 'Other UHD async events')

        section("SESSION")
        row('uptime', 'Uptime')
        row('counts', 'Messages sent / received')
        row('files', 'Files received / verified')

        layout.addStretch(1)
        note = QLabel(
            "Pre-FEC BER is measured by re-encoding the Viterbi output and "
            "comparing it with what actually arrived, so it needs no test "
            "pattern. Post-FEC BER is measured against the known PRBS "
            "carried by idle frames, so it is a true end-to-end number on "
            "live traffic. RS headroom is how many of Reed-Solomon's 16 "
            "correctable symbols per codeword are still spare - when that "
            "reaches zero the link is at its cliff. UHD health events only "
            "ever appear on real hardware.",
            self)
        note.setWordWrap(True)
        note.setObjectName("cfgLabel")
        layout.addWidget(note)

    def set_value(self, key, text):
        lbl = self.labels.get(key)
        if lbl is not None:
            lbl.setText(text)


# --------------------------------------------------------------------------
# Main window
# --------------------------------------------------------------------------

class GroundStationWindow(QMainWindow):
    def __init__(self, host, tx_port, rx_data_port, rx_status_port, bind_host,
                 ctrl_port, diag_port):
        super().__init__()
        self.host = host
        self.tx_port = tx_port
        self.rx_data_port = rx_data_port
        self.rx_status_port = rx_status_port
        self.bind_host = bind_host
        self.ctrl_port = ctrl_port
        self.diag_port = diag_port

        # ---- diagnostics state ---------------------------------
        self.diag_window = None
        self._start_monotonic = time.monotonic()
        self._crc_ok_count = 0
        self._crc_fail_count = 0
        self._underflow_count = 0
        self._overflow_count = 0
        self._other_health_count = 0
        self._evm_history = []
        self._upload_ack = 0
        self._link_fields = {}
        self._last_link_raw = ''
        self._msgs_received = 0

        self.setWindowTitle("GROUND STATION — QPSK/DSSS LINK TERMINAL")
        self.resize(1200, 800)

        # ---- state -------------------------------------------------
        self._next_tx_msg_id = 0
        # msg_id -> dict(status_item=QTableWidgetItem, expected=int, seen=set)
        # See module docstring assumption (1) for why this correlation is
        # only an assumption, not something the protocol guarantees.
        self.pending_sends = {}
        self._last_status_rx_monotonic = None  # time.monotonic(), or None
        self._log_line_count = 0

        self._build_ui()
        self._apply_stylesheet()

        # ---- background UDP workers --------------------------------
        self.tx_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.ctrl_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        self.data_listener = UdpListener("RX-DATA", self.bind_host, self.rx_data_port)
        self.data_listener.datagram_received.connect(self._on_data_datagram)
        self.data_listener.bind_failed.connect(self._on_bind_failed)

        self.status_listener = UdpListener("RX-STATUS", self.bind_host, self.rx_status_port)
        self.status_listener.datagram_received.connect(self._on_status_datagram)
        self.status_listener.bind_failed.connect(self._on_bind_failed)

        self.diag_listener = UdpListener("DIAG", self.bind_host, self.diag_port)
        self.diag_listener.datagram_received.connect(self._on_diag_datagram)
        self.diag_listener.bind_failed.connect(self._on_bind_failed)

        ok_data = self.data_listener.start()
        ok_status = self.status_listener.start()
        self.diag_listener.start()   # optional - Debug window just stays blank without it
        if ok_data and ok_status:
            self._log_plain("link log ready; waiting for flowgraph traffic...", "#8b949e")

        # ---- heartbeat / link-alive timer ---------------------------
        self.heartbeat_timer = QTimer(self)
        self.heartbeat_timer.timeout.connect(self._update_heartbeat_display)
        self.heartbeat_timer.start(HEARTBEAT_POLL_MS)
        self._update_heartbeat_display()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------
    def _build_ui(self):
        central = QWidget(self)
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(8)

        root.addWidget(self._build_header())
        root.addWidget(self._build_bind_error_banner())

        splitter = QSplitter(Qt.Vertical, self)
        splitter.addWidget(self._build_tables_row())
        splitter.addWidget(self._build_log_panel())
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 2)
        root.addWidget(splitter, stretch=1)

        root.addWidget(self._build_compose_panel())

        self.setStatusBar(QStatusBar(self))
        self.statusBar().showMessage("ready")

    def _build_header(self):
        bar = QFrame(self)
        bar.setObjectName("headerBar")
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(12, 8, 12, 8)

        title = QLabel("GROUND STATION — QPSK/DSSS LINK TERMINAL", bar)
        title.setObjectName("titleLabel")

        cfg_text = (
            f"TX→{self.host}:{self.tx_port}   "
            f"RX-DATA←{self.bind_host}:{self.rx_data_port}   "
            f"RX-STATUS←{self.bind_host}:{self.rx_status_port}"
        )
        cfg = QLabel(cfg_text, bar)
        cfg.setObjectName("cfgLabel")
        mono = QFont("DejaVu Sans Mono", 9)
        mono.setStyleHint(QFont.Monospace)
        cfg.setFont(mono)

        layout.addWidget(title)
        layout.addSpacing(20)
        layout.addWidget(cfg)
        layout.addStretch(1)

        # ---- node / destination switcher --------------------------
        # Sends plain-text "NODE=<n>"/"DEST=<n>" UDP control commands to the
        # flowgraph's ctrl port, which retunes this radio's OWN spreading
        # code (who it transmits as) and which peer's code it despreads
        # against (who it's currently listening to) - see node_ctrl.py /
        # node_prn_table in the flowgraph. Two nodes each set to the other's
        # id is what makes full-duplex, non-interfering operation between
        # them possible on one shared frequency.
        node_box = QFrame(bar)
        node_box.setObjectName("nodeBox")
        node_layout = QHBoxLayout(node_box)
        node_layout.setContentsMargins(8, 2, 8, 2)
        node_layout.setSpacing(4)

        node_layout.addWidget(QLabel("MY NODE", node_box))
        self.my_node_spin = QSpinBox(node_box)
        self.my_node_spin.setRange(0, NODE_TABLE_SIZE - 1)
        self.my_node_spin.setValue(0)
        self.my_node_spin.valueChanged.connect(self._on_my_node_changed)
        node_layout.addWidget(self.my_node_spin)

        node_layout.addSpacing(10)
        node_layout.addWidget(QLabel("TALKING TO", node_box))
        self.dest_node_spin = QSpinBox(node_box)
        self.dest_node_spin.setRange(0, NODE_TABLE_SIZE - 1)
        self.dest_node_spin.setValue(1)
        self.dest_node_spin.valueChanged.connect(self._on_dest_node_changed)
        node_layout.addWidget(self.dest_node_spin)

        layout.addWidget(node_box)
        layout.addSpacing(12)

        self.debug_button = QPushButton("Debug ▸", bar)
        self.debug_button.setObjectName("debugButton")
        self.debug_button.setCheckable(True)
        self.debug_button.clicked.connect(self._toggle_debug_window)
        layout.addWidget(self.debug_button)
        layout.addSpacing(12)

        self.link_dot = QLabel(bar)
        self.link_dot.setFixedSize(14, 14)
        self.link_heartbeat_label = QLabel("NO LINK", bar)
        self.link_heartbeat_label.setObjectName("heartbeatLabel")

        layout.addWidget(self.link_dot)
        layout.addWidget(self.link_heartbeat_label)
        return bar

    def _build_bind_error_banner(self):
        self.bind_error_banner = QLabel("", self)
        self.bind_error_banner.setObjectName("bindErrorBanner")
        self.bind_error_banner.setWordWrap(True)
        self.bind_error_banner.hide()
        return self.bind_error_banner

    def _make_table(self, headers):
        table = QTableWidget(0, len(headers), self)
        table.setHorizontalHeaderLabels(headers)
        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setSelectionBehavior(QAbstractItemView.SelectRows)
        table.setSelectionMode(QAbstractItemView.SingleSelection)
        table.setAlternatingRowColors(True)
        table.setWordWrap(False)
        header = table.horizontalHeader()
        header.setStretchLastSection(True)
        mono = QFont("DejaVu Sans Mono", 9)
        mono.setStyleHint(QFont.Monospace)
        table.setFont(mono)
        return table

    def _build_tables_row(self):
        container = QSplitter(Qt.Horizontal, self)

        # ---- SENT panel ----
        sent_box = QWidget(self)
        sent_layout = QVBoxLayout(sent_box)
        sent_layout.setContentsMargins(0, 0, 0, 0)
        sent_label = QLabel("SENT", sent_box)
        sent_label.setObjectName("panelTitle")
        self.sent_table = self._make_table(["Time", "Size", "Preview", "Status"])
        self.sent_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.sent_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.sent_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.sent_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.sent_table.itemDoubleClicked.connect(self._on_sent_row_double_clicked)
        sent_layout.addWidget(sent_label)
        sent_layout.addWidget(self.sent_table)

        # ---- RECEIVED panel ----
        recv_box = QWidget(self)
        recv_layout = QVBoxLayout(recv_box)
        recv_layout.setContentsMargins(0, 0, 0, 0)
        recv_label = QLabel("RECEIVED", recv_box)
        recv_label.setObjectName("panelTitle")
        self.recv_table = self._make_table(["Time", "Size", "Preview"])
        self.recv_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.recv_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.recv_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.recv_table.itemDoubleClicked.connect(self._on_recv_row_double_clicked)
        recv_layout.addWidget(recv_label)
        recv_layout.addWidget(self.recv_table)

        container.addWidget(sent_box)
        container.addWidget(recv_box)
        container.setStretchFactor(0, 1)
        container.setStretchFactor(1, 1)
        return container

    def _build_log_panel(self):
        box = QWidget(self)
        layout = QVBoxLayout(box)
        layout.setContentsMargins(0, 0, 0, 0)

        header_row = QHBoxLayout()
        title = QLabel("LINK LOG", box)
        title.setObjectName("panelTitle")
        header_row.addWidget(title)
        header_row.addStretch(1)
        clear_btn = QPushButton("Clear", box)
        clear_btn.setObjectName("clearLogBtn")
        clear_btn.clicked.connect(self._clear_log)
        header_row.addWidget(clear_btn)
        layout.addLayout(header_row)

        self.log_edit = QTextEdit(box)
        self.log_edit.setReadOnly(True)
        self.log_edit.setLineWrapMode(QTextEdit.NoWrap)
        mono = QFont("DejaVu Sans Mono", 9)
        mono.setStyleHint(QFont.Monospace)
        self.log_edit.setFont(mono)
        layout.addWidget(self.log_edit)
        return box

    def _build_compose_panel(self):
        box = QFrame(self)
        box.setObjectName("composePanel")
        layout = QVBoxLayout(box)

        label = QLabel("COMPOSE  (Enter = newline, Ctrl+Enter / Cmd+Enter = send)", box)
        label.setObjectName("panelTitle")
        layout.addWidget(label)

        self.compose_edit = ComposeEdit(box)
        self.compose_edit.setPlaceholderText("Type a message to transmit over the link...")
        self.compose_edit.setMinimumHeight(90)
        mono = QFont("DejaVu Sans Mono", 10)
        mono.setStyleHint(QFont.Monospace)
        self.compose_edit.setFont(mono)
        self.compose_edit.textChanged.connect(self._update_compose_stats)
        self.compose_edit.send_requested.connect(self._on_send_clicked)
        layout.addWidget(self.compose_edit)

        stats_row = QHBoxLayout()
        self.byte_counter_label = QLabel("0 bytes", box)
        self.byte_counter_label.setObjectName("byteCounterLabel")
        self.estimate_label = QLabel(
            "0 fragments · ~0.0s on-air (est.)", box
        )
        self.estimate_label.setObjectName("estimateLabel")
        stats_row.addWidget(self.byte_counter_label)
        stats_row.addSpacing(16)
        stats_row.addWidget(self.estimate_label)
        stats_row.addStretch(1)

        self.attach_button = QPushButton("ATTACH FILE", box)
        self.attach_button.setObjectName("sendButton")
        self.attach_button.setToolTip(
            "Transmit a file of any size over the link. Files are written "
            "straight to disk at the far end and verified with SHA-256.")
        self.attach_button.clicked.connect(self._on_attach_clicked)
        stats_row.addWidget(self.attach_button)

        self.send_button = QPushButton("SEND ▶", box)
        self.send_button.setObjectName("sendButton")
        self.send_button.clicked.connect(self._on_send_clicked)
        stats_row.addWidget(self.send_button)
        layout.addLayout(stats_row)

        self.transfer_bar = QProgressBar(box)
        self.transfer_bar.setTextVisible(True)
        self.transfer_bar.setFormat("%p%  %v/%m fragments")
        self.transfer_bar.hide()
        layout.addWidget(self.transfer_bar)

        # Also bind a QShortcut as a belt-and-suspenders send trigger (in
        # case focus is ever outside the compose box but the window is
        # active); ComposeEdit.keyPressEvent handles the normal case.
        self._send_shortcut = QShortcut(QKeySequence("Ctrl+Return"), self)
        self._send_shortcut.activated.connect(self._on_send_clicked)

        self._update_compose_stats()
        return box

    def _apply_stylesheet(self):
        self.setStyleSheet(_QSS)

    # ------------------------------------------------------------------
    # Node / destination switcher
    # ------------------------------------------------------------------
    def _send_ctrl(self, text: str):
        try:
            self.ctrl_sock.sendto(text.encode('ascii'), (self.host, self.ctrl_port))
        except OSError as exc:
            self._log_html(
                f"<span style='color:#f85149'><b>CONTROL SEND FAILED:</b> "
                f"{_html_escape(str(exc))}</span>"
            )

    def _on_my_node_changed(self, value: int):
        self._send_ctrl(f"NODE={value}")
        self._log_plain(f"my node id -> {value} (this radio now transmits "
                         f"on node {value}'s code)", "#58a6ff")

    def _on_dest_node_changed(self, value: int):
        self._send_ctrl(f"DEST={value}")
        self._log_plain(f"listening to -> node {value} (despreading against "
                         f"node {value}'s code now)", "#58a6ff")

    # ------------------------------------------------------------------
    # Debug / diagnostics window
    # ------------------------------------------------------------------
    def _toggle_debug_window(self, checked: bool):
        if self.diag_window is None:
            self.diag_window = DiagnosticsWindow(self)
            self.diag_window.finished.connect(
                lambda _: self.debug_button.setChecked(False))
        if checked:
            self._refresh_debug_window()
            self.diag_window.show()
            self.diag_window.raise_()
            self.diag_window.activateWindow()
        else:
            self.diag_window.hide()

    def _refresh_debug_window(self):
        if self.diag_window is None:
            return
        w = self.diag_window
        uptime_s = time.monotonic() - self._start_monotonic
        h, rem = divmod(int(uptime_s), 3600)
        m, s = divmod(rem, 60)
        w.set_value('uptime', f"{h:02d}:{m:02d}:{s:02d}")
        w.set_value('counts', f"sent={self._next_tx_msg_id}  received={self._msgs_received}")
        w.set_value('underflow', str(self._underflow_count))
        w.set_value('overflow', str(self._overflow_count))
        w.set_value('other_health', str(self._other_health_count))
        total_crc = self._crc_ok_count + self._crc_fail_count
        if total_crc:
            pct = 100.0 * self._crc_fail_count / total_crc
            w.set_value('pkt_err', f"{pct:.2f}%  ({self._crc_fail_count}/{total_crc} frames)")
        if self._evm_history:
            w.set_value('evm_avg', f"{sum(self._evm_history)/len(self._evm_history):.2f}%")

    # ------------------------------------------------------------------
    # Diagnostics port: EVM / RX power / processing gain / FEC corrections
    # ------------------------------------------------------------------
    def _on_diag_datagram(self, data: bytes):
        line = data.decode('utf-8', errors='replace').strip()
        if not line:
            return
        try:
            self._handle_diag_line(line)
        except Exception:
            traceback.print_exc()

    def _handle_diag_line(self, line: str):
        self._last_link_raw = line
        parsed = parse_status_line(line)
        if parsed is None:
            return
        keyword, kv = parsed
        w = self.diag_window

        if keyword == "PROCGAIN":
            actual = kv.get('actual')
            ideal = kv.get('ideal')
            locked = kv.get('locked')
            if w is not None:
                if locked is not None:
                    w.set_value('lock', "ACQUIRED (tracking)" if locked == '1'
                                else "SEARCHING (no lock)")
                if ideal is not None:
                    w.set_value('proc_ideal', f"{ideal} dB")
                if actual is not None:
                    w.set_value('proc_actual', f"{actual} dB")
                if actual is not None and ideal is not None:
                    try:
                        gap = float(ideal) - float(actual)
                        w.set_value('proc_gap', f"{gap:+.1f} dB")
                    except ValueError:
                        pass
        elif keyword == "EVM":
            pct = kv.get('pct')
            if pct is not None:
                try:
                    val = float(pct)
                    self._evm_history.append(val)
                    if len(self._evm_history) > 50:
                        self._evm_history.pop(0)
                    if w is not None:
                        w.set_value('evm_last', f"{val:.2f}%")
                except ValueError:
                    pass
        elif keyword == "RXPOWER":
            dbfs = kv.get('dbfs')
            if dbfs is not None and w is not None:
                w.set_value('power', f"{dbfs} dBFS")
        elif keyword == "FECFRAME":
            self._handle_fec_frame(kv)
        elif keyword == "LINK":
            self._handle_link_line(kv)
        # unrecognized diag lines are simply ignored - this port is
        # optional/best-effort telemetry, never load-bearing for the link.

    def _handle_fec_frame(self, kv):
        """Per-frame FEC report from the decoder."""
        w = self.diag_window
        if w is None:
            return
        chan_err = kv.get('chanerr')
        coded = kv.get('codedbits')
        if chan_err is not None and coded:
            w.set_value('viterbi',
                        f"{chan_err} of {coded} coded bits repaired")
        rs = kv.get('rscorr')
        if rs is not None:
            worst = kv.get('rsworst', '?')
            uncorr = kv.get('rsuncorr', '0')
            w.set_value('rs_last',
                        f"[{rs}] symbols  (worst {worst}, uncorrectable {uncorr})")
        margin = kv.get('rsmargin')
        if margin is not None:
            try:
                m = int(margin)
                bar = "#" * max(0, m) + "." * max(0, 16 - m)
                w.set_value('rs_head', f"{m}/16  [{bar}]")
            except ValueError:
                pass

    def _handle_link_line(self, kv):
        """The aggregated telemetry line from the Link Metrics block."""
        w = self.diag_window
        self._link_fields = kv
        if w is None:
            return

        def f(key, default=None):
            try:
                return float(kv[key])
            except (KeyError, ValueError, TypeError):
                return default

        chip = f('chiprate')
        samp = f('samprate')
        if chip and samp:
            w.set_value('cfg_chip',
                        f"{chip/1e6:.3f} Mcps  /  {samp/1e6:.3f} Msps")
        code = kv.get('codelen')
        pg = kv.get('procgain_ideal')
        if code:
            w.set_value('cfg_code', f"{code} chips  /  {pg} dB")
        sym = f('symrate')
        raw = f('rawbitrate')
        if sym and raw:
            w.set_value('cfg_sym', f"{sym:,.0f} sym/s  /  {human_rate(raw)}")
        fs = kv.get('framesyms')
        fp = f('frameperiod')
        pf = kv.get('payloadperframe')
        if fs and fp:
            w.set_value('cfg_frame',
                        f"{fs} symbols, {pf} B payload  /  {fp:.3f} s")
        cr = f('coderate')
        if cr:
            w.set_value('cfg_rate', f"{cr:.4f}  ({1/cr:.2f}x expansion)")
        mx = f('maxpayloadrate')
        if mx:
            w.set_value('cfg_ceiling', human_rate(mx))

        gp = f('goodput')
        if gp is not None:
            w.set_value('goodput', human_rate(gp))
        txr = f('txrate')
        if txr is not None:
            w.set_value('txrate', human_rate(txr))
        fr = f('framerate')
        if fr is not None:
            w.set_value('framerate', f"{fr:.2f} frames/s")
        eff = f('efficiency')
        if eff is not None:
            w.set_value('efficiency', f"{100*eff:.1f}% of the ceiling")

        pre = f('prefec_ber')
        if pre is not None:
            bits = kv.get('prefec_totalbits', '0')
            w.set_value('ber_pre', f"{pre:.3e}   ({bits} bits observed)")
            w.set_value('coding_gain', f"{pre*1000:.1f} raw errors / 1000 bits")
        post = kv.get('postfec_ber')
        if post is not None:
            if post == 'n/a':
                w.set_value('ber_post', "n/a  (no idle frames decoded yet)")
            else:
                try:
                    pb = float(post)
                    nb = kv.get('postfec_bits', '0')
                    w.set_value('ber_post',
                                ("0  (no errors in %s bits)" % nb) if pb == 0
                                else f"{pb:.3e}   ({nb} bits)")
                except ValueError:
                    pass
        eb = kv.get('ebno_est')
        if eb and eb != 'n/a':
            try:
                ebv = float(eb)
                verdict = ("comfortable" if ebv > 4.0 else
                           "close to the 2.5 dB cliff" if ebv > 2.2 else
                           "BELOW the code's threshold")
                w.set_value('ebno', f"{ebv:+.2f} dB   ({verdict})")
            except ValueError:
                pass
        elif eb == 'n/a':
            w.set_value('ebno', "n/a  (no errors yet - above measurement range)")

        rw = kv.get('rs_worst')
        if rw is not None:
            w.set_value('rs_worst', f"{rw} of {kv.get('rs_limit', 16)} symbols")
        ru = kv.get('rs_uncorrectable')
        if ru is not None:
            w.set_value('rs_uncorr', ru)
        fer = f('fer')
        if fer is not None:
            w.set_value('fer', f"{fer:.3e}")
        ok, bad = kv.get('framesok'), kv.get('framesbad')
        if ok is not None:
            w.set_value('frames', f"{ok} ok / {bad} failed")

        locked = kv.get('locked')
        if locked is not None:
            w.set_value('sync', "LOCKED" if locked == '1' else "searching")
            w.set_value('sync',
                        ("LOCKED" if locked == '1' else "SEARCHING")
                        + f"  /  {kv.get('resyncs', 0)} resyncs"
                        + f"  /  {kv.get('falsesync', 0)} false")
        acq = kv.get('acquisitions')
        if acq is not None:
            w.set_value('acq', f"{acq} acquisitions / {kv.get('locklosses', 0)} losses"
                               + (f", last took {kv['acqsecs']}s"
                                  if kv.get('acqsecs', '-1') not in ('-1', '-1.00')
                                  else ""))
        pa = kv.get('procgain_actual')
        if pa is not None:
            w.set_value('proc_actual', f"{pa} dB")
        rxf = kv.get('rxfiles')
        if rxf is not None:
            w.set_value('files', f"{rxf} received / {kv.get('rxverified', 0)} sha256-verified")

        xfers = [v for k, v in kv.items() if k == 'xfer']
        raw_xfer = [tok for tok in getattr(self, '_last_link_raw', '').split()
                    if tok.startswith('xfer=')]
        if raw_xfer:
            parts = raw_xfer[0][5:].split(':')
            if len(parts) == 3:
                name, prog, rate = parts
                w.set_value('xfer', f"{name}  {prog} fragments  "
                                    f"{human_bytes(float(rate))}/s")
        elif not xfers:
            w.set_value('xfer', "idle")

    # ------------------------------------------------------------------
    # Compose / send
    # ------------------------------------------------------------------
    def _update_compose_stats(self):
        text = self.compose_edit.toPlainText()
        n_bytes = len(text.encode('utf-8'))
        over_limit = n_bytes > MAX_MESSAGE_BYTES
        frags = math.ceil(n_bytes / FRAGMENT_PAYLOAD_BYTES) if n_bytes else 0
        est_seconds = frags * EST_SECONDS_PER_FRAGMENT

        self.byte_counter_label.setText(f"{n_bytes:,} bytes")
        self.byte_counter_label.setProperty("overLimit", over_limit)
        self.byte_counter_label.style().unpolish(self.byte_counter_label)
        self.byte_counter_label.style().polish(self.byte_counter_label)

        if over_limit:
            self.estimate_label.setText(
                f"EXCEEDS {MAX_MESSAGE_BYTES:,}-byte limit — will not send"
            )
        else:
            self.estimate_label.setText(
                f"{frags} fragment{'s' if frags != 1 else ''} · "
                f"~{est_seconds:.1f}s on-air (est.)"
            )
        self.send_button.setEnabled(not over_limit)

    def _on_attach_clicked(self):
        """Send a file of any size.

        Two paths, chosen automatically. When the flowgraph is on this
        same machine (the normal case) the path is simply handed over and
        the radio reads the file itself - nothing is copied. When it is
        somewhere else, the file is uploaded in acknowledged chunks over
        the existing TX port, because a UDP datagram cannot exceed 64 KB
        and a large transfer must not be buffered whole at either end."""
        path, _ = QFileDialog.getOpenFileName(self, "Transmit file", "",
                                              "All files (*)")
        if not path:
            return
        try:
            size = os.path.getsize(path)
        except OSError as exc:
            self._log_html(f'<span style="color:#f85149;">Cannot read '
                           f'{_html_escape(path)}: {_html_escape(str(exc))}</span>')
            return

        frags = max(1, math.ceil(size / FRAGMENT_PAYLOAD_BYTES))
        est = frags * EST_SECONDS_PER_FRAGMENT
        name = os.path.basename(path)
        answer = QMessageBox.question(
            self, "Transmit file",
            f"{name}\n\n{human_bytes(size)} — {frags:,} fragments\n"
            f"Estimated on-air time: {human_secs(est)}\n\n"
            f"There is no retransmission on this link, so a fragment lost "
            f"to noise means the transfer will not complete. Send it?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
        if answer != QMessageBox.Yes:
            return

        if self.host in ('127.0.0.1', 'localhost', '::1'):
            self._send_ctrl(f"FILE={os.path.abspath(path)}")
            self._log_html(
                f'<span style="color:#58a6ff;">Queued '
                f'{_html_escape(name)} ({human_bytes(size)}, {frags:,} '
                f'fragments) for transmission.</span>')
        else:
            self._upload_file(path, size)

        self.transfer_bar.setMaximum(frags)
        self.transfer_bar.setValue(0)
        self.transfer_bar.show()

    def _upload_file(self, path, size):
        """Chunked, acknowledged upload to a flowgraph on another host."""
        CHUNK = 8192
        name = os.path.basename(path)
        self._log_html(f'<span style="color:#58a6ff;">Uploading '
                       f'{_html_escape(name)} to {self.host}...</span>')
        try:
            with open(path, 'rb') as fh:
                self._upload_send(b'\x00FILEUP BEGIN 0 ' +
                                  name.encode('utf-8', 'replace') + b'\n')
                idx = 0
                while True:
                    block = fh.read(CHUNK)
                    if not block:
                        break
                    header = ('\x00FILEUP CHUNK %d\n' % idx).encode()
                    for attempt in range(5):
                        self._upload_send(header + block)
                        if self._await_ack(idx + 1, 0.5):
                            break
                    else:
                        raise IOError("no acknowledgement for chunk %d" % idx)
                    idx += 1
                self._upload_send(b'\x00FILEUP END\n')
        except (OSError, IOError) as exc:
            self._log_html(f'<span style="color:#f85149;">Upload failed: '
                           f'{_html_escape(str(exc))}</span>')
            return
        self._log_html(f'<span style="color:#58a6ff;">Upload complete; '
                       f'{_html_escape(name)} queued for transmission.</span>')

    def _upload_send(self, payload: bytes):
        self.tx_sock.sendto(payload, (self.host, self.tx_port))

    def _await_ack(self, want, timeout):
        """The flowgraph acknowledges each chunk on the status port."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            if self._upload_ack >= want:
                return True
            QApplication.processEvents()
            time.sleep(0.005)
        return False

    def _on_send_clicked(self):
        text = self.compose_edit.toPlainText()
        if text == "":
            return
        encoded = text.encode('utf-8')
        if len(encoded) > MAX_MESSAGE_BYTES:
            QMessageBox.warning(
                self, "Message too large",
                f"This message is {len(encoded):,} bytes, which exceeds the "
                f"{MAX_MESSAGE_BYTES:,}-byte ceiling ({MAX_FRAGMENTS} fragments "
                f"× {FRAGMENT_PAYLOAD_BYTES} bytes). Trim it before sending "
                f"-- it will NOT be sent partially/truncated."
            )
            return

        try:
            self.tx_sock.sendto(encoded, (self.host, self.tx_port))
        except OSError as exc:
            QMessageBox.critical(self, "Send failed", f"sendto() failed: {exc}")
            self._log_html(f"<span style='color:#f85149'><b>SEND FAILED:</b> {exc}</span>")
            return

        # Assumption (1), documented at module top: assign msg ids in
        # strictly-increasing send order and assume the flowgraph will
        # attach the same id to the fragments it produces from this send.
        msg_id = self._next_tx_msg_id
        self._next_tx_msg_id = (self._next_tx_msg_id + 1) % MSG_ID_WRAP

        expected_fragments = max(1, math.ceil(len(encoded) / FRAGMENT_PAYLOAD_BYTES))

        row = 0
        self.sent_table.insertRow(row)
        ts_item = QTableWidgetItem(now_hms())
        size_item = QTableWidgetItem(f"{len(encoded):,}")
        preview_item = QTableWidgetItem(make_preview(text))
        preview_item.setData(Qt.UserRole, text)
        status_item = QTableWidgetItem("sending…")
        for item in (ts_item, size_item, preview_item, status_item):
            item.setFlags(item.flags() & ~Qt.ItemIsEditable)
        self.sent_table.setItem(row, 0, ts_item)
        self.sent_table.setItem(row, 1, size_item)
        self.sent_table.setItem(row, 2, preview_item)
        self.sent_table.setItem(row, 3, status_item)

        self.pending_sends[msg_id] = {
            "status_item": status_item,
            "expected": expected_fragments,
            "seen": set(),
        }

        self.statusBar().showMessage(
            f"sent msg_id={msg_id} ({len(encoded):,} bytes, "
            f"~{expected_fragments} fragments)", 5000
        )
        self.compose_edit.clear()

    # ------------------------------------------------------------------
    # RX data port (complete, CRC-good messages)
    # ------------------------------------------------------------------
    def _on_data_datagram(self, data: bytes):
        self._msgs_received += 1
        text = data.decode('utf-8', errors='replace')
        row = 0
        self.recv_table.insertRow(row)
        ts_item = QTableWidgetItem(now_hms())
        size_item = QTableWidgetItem(f"{len(data):,}")
        preview_item = QTableWidgetItem(make_preview(text))
        preview_item.setData(Qt.UserRole, text)
        for item in (ts_item, size_item, preview_item):
            item.setFlags(item.flags() & ~Qt.ItemIsEditable)
        self.recv_table.setItem(row, 0, ts_item)
        self.recv_table.setItem(row, 1, size_item)
        self.recv_table.setItem(row, 2, preview_item)
        self._flash_row(self.recv_table, row)
        self.recv_table.scrollToTop()
        self.statusBar().showMessage(f"received {len(data):,} bytes", 4000)

    def _flash_row(self, table: QTableWidget, row: int, color="#1f6feb", ms=1200):
        items = [table.item(row, c) for c in range(table.columnCount())]
        originals = [it.background() for it in items]
        flash = QColor(color)
        for it in items:
            it.setBackground(flash)

        def restore():
            # Row indices may have shifted since new rows are always
            # inserted at 0; re-fetch items by identity is not possible on
            # QTableWidgetItem across relayouts, so guard against a table
            # that shrank underneath us.
            for it, orig in zip(items, originals):
                try:
                    it.setBackground(orig)
                except RuntimeError:
                    pass

        QTimer.singleShot(ms, restore)

    # ------------------------------------------------------------------
    # RX status port (FRAG / IDLE / DONE / INCOMPLETE / unknown)
    # ------------------------------------------------------------------
    def _on_status_datagram(self, data: bytes):
        # Anything at all arriving on this port means the link is alive,
        # independent of whether we can parse it.
        self._last_status_rx_monotonic = time.monotonic()

        line = data.decode('utf-8', errors='replace').strip()
        if not line:
            return

        try:
            self._handle_status_line(line)
        except Exception:
            # Absolute last-resort fallback per spec: never crash on a
            # malformed/adversarial status line, just show the raw text.
            traceback.print_exc()
            self._log_html(
                f"<span style='color:#8b949e'>[unparsed] "
                f"{_html_escape(line)}</span>"
            )

    def _handle_status_line(self, line: str):
        parsed = parse_status_line(line)
        if parsed is None:
            return
        keyword, kv = parsed

        if keyword == "FRAG":
            self._handle_frag(kv, line)
        elif keyword == "IDLE":
            pass  # heartbeat only -- intentionally not logged, see assumption (2)
        elif keyword == "DONE":
            self._handle_done(kv, line)
        elif keyword == "INCOMPLETE":
            self._handle_incomplete(kv, line)
        elif keyword == "FILESTART":
            self._handle_file_start(kv, line)
        elif keyword == "FILEPROG":
            self._handle_file_progress(kv, line)
        elif keyword == "FILEDONE":
            self._handle_file_done(kv, line)
        elif keyword in ("FILEERR", "TXERR", "RXERR"):
            self._log_html(f'<span style="color:#f85149;">'
                           f'{_html_escape(line)}</span>')
        elif keyword == "UPLOADACK":
            try:
                self._upload_ack = max(self._upload_ack,
                                       int(next(iter(kv), '0')
                                           if kv else line.split()[-1]))
            except (ValueError, IndexError):
                pass
        elif keyword in ("QUEUED", "SENT", "UPLOAD", "CTRL"):
            self._log_plain(line, "#8b949e")
        elif keyword == "HEALTH":
            # UHD async-message telemetry (TX underflow / RX overflow / seq
            # or time errors) from uhd_health_monitor.py - real hardware
            # only, never appears in the sim. Loud on purpose: this is
            # exactly the signal that used to go unreported before a sink
            # underflow silently cascaded into total loss of sync.
            self._count_health_event(line)
            self._log_html(
                f"<span style='color:#d29922; font-weight:bold'>"
                f"{_html_escape(line)}</span>"
            )
        elif keyword in ("WARN", "FOREIGN"):
            self._log_html(
                f"<span style='color:#d29922'>{_html_escape(line)}</span>"
            )
        else:
            # Unknown leading keyword: log as-is, don't crash. Packet
            # Deframer's own CRC-fail lines land here too ("seq=123  CRC
            # FAIL (packet dropped)") - not a recognized keyword grammar,
            # but still worth counting for the debug window's packet
            # error rate, via a plain substring check.
            if "CRC FAIL" in line:
                self._crc_fail_count += 1
            self._log_html(f"<span style='color:#8b949e'>{_html_escape(line)}</span>")

    def _count_health_event(self, line: str):
        # "HEALTH <TX|RX> <EVENT_NAME> #<n> (...)" - see uhd_health_monitor.py.
        # gr-uhd doesn't expose a distinct RX "overflow" event code the way
        # it does TX underflow, so any RX-labeled async event is bucketed
        # as overflow (that side's own problem signal); every TX-labeled
        # event other than UNDERFLOW (sequence/time errors) goes in the
        # generic "other" bucket.
        parts = line.split()
        side = parts[1] if len(parts) > 1 else ""
        event = parts[2] if len(parts) > 2 else ""
        if side == "RX":
            self._overflow_count += 1
        elif event in ("UNDERFLOW", "UNDERFLOW_IN_PACKET"):
            self._underflow_count += 1
        else:
            self._other_health_count += 1
        self._refresh_debug_window()

    def _safe_int(self, kv, key):
        try:
            return int(kv[key])
        except (KeyError, ValueError, TypeError):
            return None

    def _handle_file_start(self, kv, raw_line):
        name = kv.get('name', 'unknown')
        # the reassembler emits this as frags=, not total=
        total = kv.get('frags', kv.get('total', '?'))
        self._log_html(
            f'<span style="color:#58a6ff;">Incoming file '
            f'<b>{_html_escape(name)}</b> — '
            f'{human_bytes(kv.get("bytes", 0))}, {total} fragments</span>')
        try:
            self.transfer_bar.setMaximum(int(total))
            self.transfer_bar.setValue(0)
            self.transfer_bar.show()
        except (TypeError, ValueError):
            pass

    def _handle_file_progress(self, kv, raw_line):
        try:
            got, total = int(kv['got']), int(kv['total'])
        except (KeyError, ValueError):
            return
        self.transfer_bar.setMaximum(total)
        self.transfer_bar.setValue(got)
        self.transfer_bar.show()
        rate = kv.get('rate')
        eta = kv.get('eta')
        if rate:
            self.transfer_bar.setFormat(
                f"%p%  %v/%m fragments  ·  {human_bytes(rate)}/s"
                + (f"  ·  ETA {human_secs(eta)}" if eta else ""))

    def _handle_file_done(self, kv, raw_line):
        path = kv.get('path', '?')
        verify = kv.get('verify', '?')
        colour = "#3fb950" if verify == 'OK' else "#d29922"
        mark = "verified" if verify == 'OK' else f"hash {verify}"
        self._log_html(
            f'<span style="color:{colour};">File received: '
            f'<b>{_html_escape(os.path.basename(path))}</b> — '
            f'{human_bytes(kv.get("bytes", 0))} in {kv.get("secs", "?")}s '
            f'({human_bytes(kv.get("rate", 0))}/s), SHA-256 {mark}<br>'
            f'<span style="color:#8b949e;">saved to '
            f'{_html_escape(path)}</span></span>')
        self.transfer_bar.hide()
        self.transfer_bar.setFormat("%p%  %v/%m fragments")

    def _handle_frag(self, kv, raw_line):
        crc = kv.get('crc', '?')
        if crc == "OK":
            self._crc_ok_count += 1
        color = "#3fb950" if crc == "OK" else "#f85149"
        weight = "normal" if crc == "OK" else "bold"
        self._log_html(
            f"<span style='color:{color}; font-weight:{weight}'>"
            f"{_html_escape(raw_line)}</span>"
        )

        msg_id = self._safe_int(kv, 'msg')
        if msg_id is None:
            return
        entry = self.pending_sends.get(msg_id)
        if entry is None:
            return

        idx = self._safe_int(kv, 'idx')
        if idx is not None:
            entry["seen"].add(idx)
        total = self._safe_int(kv, 'total') or entry["expected"]
        n_seen = len(entry["seen"]) if entry["seen"] else min(1, total)
        try:
            entry["status_item"].setText(f"sent ({n_seen}/{total} fragments)")
        except RuntimeError:
            self.pending_sends.pop(msg_id, None)

    def _handle_done(self, kv, raw_line):
        self._log_html(
            f"<span style='color:#3fb950; font-weight:bold'>"
            f"{_html_escape(raw_line)}</span>"
        )
        msg_id = self._safe_int(kv, 'msg')
        if msg_id is None:
            return
        entry = self.pending_sends.pop(msg_id, None)
        if entry is None:
            return
        try:
            entry["status_item"].setText("delivered")
            entry["status_item"].setForeground(QColor("#3fb950"))
        except RuntimeError:
            pass

    def _handle_incomplete(self, kv, raw_line):
        self._log_html(
            f"<span style='color:#f85149; font-weight:bold'>"
            f"{_html_escape(raw_line)}</span>"
        )
        msg_id = self._safe_int(kv, 'msg')
        if msg_id is None:
            return
        entry = self.pending_sends.pop(msg_id, None)
        if entry is None:
            return
        missing = kv.get('missing', '?')
        try:
            entry["status_item"].setText(f"incomplete (missing {missing})")
            entry["status_item"].setForeground(QColor("#f85149"))
        except RuntimeError:
            pass

    # ------------------------------------------------------------------
    # Link-alive indicator
    # ------------------------------------------------------------------
    def _update_heartbeat_display(self):
        self._refresh_debug_window()
        if self._last_status_rx_monotonic is None:
            self._set_link_dot(False)
            self.link_heartbeat_label.setText("NO LINK")
            return
        elapsed = time.monotonic() - self._last_status_rx_monotonic
        if elapsed <= HEARTBEAT_STALE_SEC:
            self._set_link_dot(True)
            self.link_heartbeat_label.setText(f"last heartbeat: {elapsed:.0f}s ago")
        else:
            self._set_link_dot(False)
            self.link_heartbeat_label.setText(f"NO LINK (last: {elapsed:.0f}s ago)")

    def _set_link_dot(self, alive: bool):
        color = "#3fb950" if alive else "#6e7681"
        self.link_dot.setStyleSheet(
            f"background-color:{color}; border-radius:7px; "
            f"border:1px solid #010409;"
        )

    # ------------------------------------------------------------------
    # Bind failures -> banner (app still opens in a degraded state)
    # ------------------------------------------------------------------
    def _on_bind_failed(self, message: str):
        current = self.bind_error_banner.text()
        combined = (current + "\n" if current else "") + ("⚠ " + message)
        self.bind_error_banner.setText(combined)
        self.bind_error_banner.show()
        self._log_html(f"<span style='color:#f85149; font-weight:bold'>{_html_escape(message)}</span>")

    # ------------------------------------------------------------------
    # Link log helpers
    # ------------------------------------------------------------------
    def _log_html(self, html_fragment: str):
        ts = now_hms()
        self.log_edit.append(f"<span style='color:#8b949e'>[{ts}]</span> {html_fragment}")
        self._log_line_count += 1
        self._trim_log_if_needed()

    def _log_plain(self, text: str, color="#c9d1d9"):
        self._log_html(f"<span style='color:{color}'>{_html_escape(text)}</span>")

    def _trim_log_if_needed(self):
        doc = self.log_edit.document()
        while doc.blockCount() > LOG_MAX_LINES:
            cursor = QTextCursor(doc.findBlockByNumber(0))
            cursor.select(QTextCursor.BlockUnderCursor)
            cursor.removeSelectedText()
            cursor.deleteChar()  # eat the now-leading newline

    def _clear_log(self):
        self.log_edit.clear()
        self._log_line_count = 0

    # ------------------------------------------------------------------
    # Double-click -> full message dialogs
    # ------------------------------------------------------------------
    def _on_sent_row_double_clicked(self, item):
        row = item.row()
        preview_item = self.sent_table.item(row, 2)
        full_text = preview_item.data(Qt.UserRole) if preview_item else ""
        dlg = FullTextDialog("Sent message", full_text or "", self)
        dlg.exec_()

    def _on_recv_row_double_clicked(self, item):
        row = item.row()
        preview_item = self.recv_table.item(row, 2)
        full_text = preview_item.data(Qt.UserRole) if preview_item else ""
        dlg = FullTextDialog("Received message", full_text or "", self)
        dlg.exec_()

    # ------------------------------------------------------------------
    # Shutdown
    # ------------------------------------------------------------------
    def closeEvent(self, event):
        try:
            self.data_listener.stop()
            self.status_listener.stop()
            self.diag_listener.stop()
            self.tx_sock.close()
            self.ctrl_sock.close()
            if self.diag_window is not None:
                self.diag_window.close()
        except Exception:
            pass
        super().closeEvent(event)


def _html_escape(s: str) -> str:
    return (
        s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    )


_QSS = """
QWidget {
    background-color: #0d1117;
    color: #c9d1d9;
    font-family: "DejaVu Sans", "Segoe UI", sans-serif;
    font-size: 12px;
}
#headerBar {
    background-color: #161b22;
    border: 1px solid #30363d;
    border-radius: 4px;
}
#titleLabel {
    color: #58a6ff;
    font-size: 15px;
    font-weight: bold;
    letter-spacing: 1px;
}
#cfgLabel {
    color: #8b949e;
}
#heartbeatLabel {
    color: #c9d1d9;
    font-weight: bold;
    padding-left: 4px;
}
#nodeBox {
    background-color: #0d1117;
    border: 1px solid #30363d;
    border-radius: 4px;
}
#nodeBox QLabel {
    color: #8b949e;
    font-weight: bold;
    font-size: 10px;
}
#nodeBox QSpinBox {
    background-color: #161b22;
    color: #58a6ff;
    border: 1px solid #30363d;
    border-radius: 3px;
    padding: 1px 4px;
    font-weight: bold;
    min-width: 32px;
}
#diagValue {
    color: #3fb950;
    font-weight: bold;
}
#debugButton {
    background-color: #21262d;
    color: #c9d1d9;
    border: 1px solid #30363d;
    border-radius: 3px;
    padding: 3px 12px;
}
#debugButton:hover {
    background-color: #30363d;
}
#bindErrorBanner {
    background-color: #3d1c1c;
    color: #ffb3ab;
    border: 1px solid #f85149;
    border-radius: 4px;
    padding: 6px 10px;
    font-weight: bold;
}
#panelTitle {
    color: #58a6ff;
    font-weight: bold;
    letter-spacing: 1px;
    padding: 2px 0px;
}
QTableWidget {
    background-color: #0d1117;
    alternate-background-color: #12181f;
    gridline-color: #21262d;
    border: 1px solid #30363d;
    selection-background-color: #1f6feb;
    selection-color: #ffffff;
}
QHeaderView::section {
    background-color: #161b22;
    color: #8b949e;
    border: 1px solid #30363d;
    padding: 4px;
    font-weight: bold;
}
QTextEdit, QPlainTextEdit {
    background-color: #010409;
    color: #c9d1d9;
    border: 1px solid #30363d;
    border-radius: 4px;
    selection-background-color: #1f6feb;
}
#composePanel {
    background-color: #161b22;
    border: 1px solid #30363d;
    border-radius: 4px;
}
#byteCounterLabel {
    color: #8b949e;
    font-family: "DejaVu Sans Mono", monospace;
}
#byteCounterLabel[overLimit="true"] {
    color: #f85149;
    font-weight: bold;
}
#estimateLabel {
    color: #8b949e;
    font-family: "DejaVu Sans Mono", monospace;
}
#sendButton {
    background-color: #238636;
    color: #ffffff;
    border: 1px solid #2ea043;
    border-radius: 4px;
    padding: 6px 18px;
    font-weight: bold;
}
#sendButton:hover {
    background-color: #2ea043;
}
#sendButton:disabled {
    background-color: #30363d;
    color: #6e7681;
    border: 1px solid #30363d;
}
#clearLogBtn {
    background-color: #21262d;
    color: #c9d1d9;
    border: 1px solid #30363d;
    border-radius: 3px;
    padding: 2px 10px;
}
#clearLogBtn:hover {
    background-color: #30363d;
}
QSplitter::handle {
    background-color: #30363d;
}
QStatusBar {
    background-color: #161b22;
    color: #8b949e;
    border-top: 1px solid #30363d;
}
QScrollBar:vertical {
    background: #0d1117;
    width: 12px;
}
QScrollBar::handle:vertical {
    background: #30363d;
    border-radius: 4px;
    min-height: 20px;
}
QScrollBar:horizontal {
    background: #0d1117;
    height: 12px;
}
QScrollBar::handle:horizontal {
    background: #30363d;
    border-radius: 4px;
    min-width: 20px;
}
"""


def _install_crash_guard():
    """PyQt5 aborts the process by default if an exception escapes a slot,
    UNLESS sys.excepthook has been overridden -- so we override it. This is
    defense-in-depth on top of the try/except blocks in the status-line
    handling code above; it means a bug we didn't anticipate logs a
    traceback to stderr instead of taking the whole console down."""
    def _hook(exc_type, exc_value, exc_tb):
        traceback.print_exception(exc_type, exc_value, exc_tb)
    sys.excepthook = _hook


def parse_args(argv=None):
    ap = argparse.ArgumentParser(
        description="GROUND STATION -- PyQt5 GUI front-end for the QPSK/DSSS "
                    "burst comms link (UDP-only, no gnuradio import).",
    )
    ap.add_argument('--host', default='127.0.0.1',
                     help='host the flowgraph is running on (default: 127.0.0.1)')
    ap.add_argument('--tx-port', type=int, default=52001,
                     help='UDP port the flowgraph listens on for outgoing messages (default: 52001)')
    ap.add_argument('--rx-data-port', type=int, default=52002,
                     help='local UDP port the flowgraph sends recovered messages to (default: 52002)')
    ap.add_argument('--rx-status-port', type=int, default=52003,
                     help='local UDP port the flowgraph sends per-packet status lines to (default: 52003)')
    ap.add_argument('--ctrl-port', type=int, default=52004,
                     help='UDP port the flowgraph listens on for NODE=/DEST= '
                          'node-switcher commands (default: 52004)')
    ap.add_argument('--diag-port', type=int, default=52005,
                     help='local UDP port the flowgraph sends debug-window '
                          'telemetry to - EVM/RX power/processing gain/FEC '
                          '(default: 52005)')
    ap.add_argument('--bind-host', default='127.0.0.1',
                     help='local address to bind the receive sockets to (default: 127.0.0.1)')
    return ap.parse_args(argv)


def main():
    _install_crash_guard()
    args = parse_args()

    app = QApplication(sys.argv)
    app.setApplicationName("Ground Station")

    win = GroundStationWindow(
        host=args.host,
        tx_port=args.tx_port,
        rx_data_port=args.rx_data_port,
        rx_status_port=args.rx_status_port,
        bind_host=args.bind_host,
        ctrl_port=args.ctrl_port,
        diag_port=args.diag_port,
    )
    win.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
